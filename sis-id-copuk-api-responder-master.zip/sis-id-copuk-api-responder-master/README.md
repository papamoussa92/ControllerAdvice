# Sis ID CopUK API Responder

## Maven setup

cf https://maven.apache.org/guides/mini/guide-encryption.html


Required : make sure to have maven installed


1. Maven master password

Generate a master password

```
mvn --encrypt-master-password monMDP
```
Write it in `~/.m2/settings-security.xml` like so :

```
    <settingsSecurity>
      <master>{jSMOWnoPFgsHVpMvz5VrIt5kRbzGpI8u+9EF1iFQyJQ=}</master>
    </settingsSecurity>
```

2. Edit your your settings.xml

 * Copy and paste the `settings.xml` file at the root of the project at this location : `~/.m2/settings.xml`.
 * Hash your nexus password : 
   ```
   mvn --encrypt-password
   ```
 * Replace environment variables with your username and hashed password :
 
 ```
 <settings>
    <servers>
        <server>
            <id>snapshots</id>
            <username>myUserName</username>
            <password>{hashed password}</password>
        </server>
        <server>
            <id>releases</id>
            <username>myUserName</username>
            <password>{hashed password}</password>
        </server>
    </servers>
    <profiles>
    [...]
    </profiles>
 </setttings>
 ```

Request for test API
 ```
 curl -X 'POST' \
  'https://editor.swagger.io/open-banking/v3.1/confirmation-payee/accounts/name-verification' \
  -H 'accept: application/json' \
  -H 'Authorization: aaaa' \
  -H 'x-fapi-financial-id: aaaa' \
  -H 'x-fapi-interaction-id: hjdfhjd' \
  -H 'x-jws-signature: sdfsfd' \
  -H 'Content-Type: application/json' \
  -d '{
  "Data": {
    "SchemeName": "SortCodeAccountNumber",
    "AccountType": "Business",
    "Identification": "30611274476788",
    "Name": "string",
    "SecondaryIdentification": "string"
  }
}'
 ```
 
## Integration tests

This application relies on information from the BNP `payee information server`.
Calls to the `payee information server` are authenticated with an OAUTH2 client credentials flow, through mutual TLS.

 * Authenticating with oauth requires the `copuk responder` to hold client credentials to authenticate itself with the `auth server`.
 * Mutual TLS requires the `copuk responder` to access both the `auth server` and the `payee information server` with a client tls certificate.

```
┌────────────────┐            ┌───────────────┐
│COPUK RESPONDER │      MTLS  │BNP PAYEE INFO │
│                ├────┬─────► │               │
│ - client cert  │    │       │ - server cert │
│ - oauth2       │    │       │               │
│   client cred. │    │       └─────────┬─────┘
│                │    │                 │
└────────────────┘    │                 ▼
                      │       ┌───────────────┐
                      │ MTLS  │BNP AUTH SERVER│
                      └──────►│               │
                              │ - server cert │
                              │ - authenticate│
                              │   oauth2      │
                              └───────────────┘
```

In an integration test setup, the following components are mocked with testcontainers.

 * The `payee information server` is mocked with a [mockserver](https://www.mock-server.com/) test container
 * The `BNPP auth server` is mocked with a [keycloak test container](https://github.com/dasniko/testcontainers-keycloak)
 * The `Sis ID CoPUK auth server` is mocked with a [keycloak test container](https://github.com/dasniko/testcontainers-keycloak)
 * The `Responder audit DB` is mocked with a [postgresql test container](https://www.testcontainers.org/modules/databases/postgres/)
 
For the mtls setup to work, both BNPP test containers need to be reachable through https, and to be able to validate the certificate with which the `copuk responder` application calls them.

This is achieved by generating a certificate authority that is used to sign both the server certificate used by the mockservers, and the client certificate used by the `copuk responder` in a test setup. The same server certificate is used for both test containers.
Testcontainers are started in parallel. It is also possible to reuse testcontainers from previous test runs to save development time with a property:
```shell
echo "testcontainers.reuse.enable=true" >> $HOME/.testcontainers.properties
```



### Generating test TLS certificates

Here are some notes regarding how to go about generating test certificates :

#### Generate a certificate authority

```
openssl req -x509 -sha256 -days 3650 -newkey rsa:4096 -keyout bnpCA.key -out bnpCA.crt
# pass : copuk
```


#### Generate a server certificate

 * Generate a certificate signing request
 
```
openssl req -new -newkey rsa:4096 -nodes -keyout bnp-server.key –out bnp-server.csr
# pass : copuk
```

 * Fill in a `.ext` file
 
DNS mappings are relevant and should be filled in with the host names at which the test containers are to be reachable.

```
authorityKeyIdentifier=keyid,issuer
basicConstraints=CA:FALSE
subjectAltName = @alt_names
[alt_names]
DNS.1 = localhost
DNS.2 = docker
```

 * Sign the certificate signing request using the CA
 
```
openssl x509 -req -CA bnpCA.crt -CAkey bnpCA.key -in bnp-server.csr -out bnp-server.crt -days 365 -CAcreateserial -extfile bnp-server.ext
```
 
#### Generate a client certificate 
 
 * Generate a certificate signing request
 
 ```
openssl req -new -newkey rsa:4096 -nodes -keyout bnp-responder-client.key -out bnp-responder-client.csr
# cn : bnp-responder
# password : copuk
 ```
 
 * Sign the certificate using the CA
 
```
openssl x509 -req -CA bnpCA.crt -CAkey bnpCA.key -in bnp-responder-client.csr -out bnp-responder-client.crt -days 365 -CAcreateserial 
``` 


Additional steps are then required to convert keys and certs into the formats supported by the tools we use.

### Manage trusted certificates to the authorisation server
keytool -importcert -keystore src/main/resources/copuk.truststore -alias copuk -storepass f9d366b4-d783-11ec-a634-bbc1b2efa9e5 -file src/main/resources/certs/copuk-authorisation-server.crt -noprompt

 
#### Generate certificat PKCS12
```
keytool -genkeypair -alias baeldung -keyalg RSA -keysize 2048 -storetype PKCS12 -keystore baeldung.p12 -validity 3650
keytool -v -list -keystore baeldung.p12
keytool -exportcert -keystore  baeldung.p12 -file baeldung.cer -alias baeldung
keytool -printcert -file baeldung.cer
ou
keytool -genkeypair -alias solr-ssl -keyalg RSA -keysize 2048 -keypass secret -storepass secret -validity 9999 -keystore solr-ssl.keystore.jks -ext SAN=DNS:localhost,IP:192.168.1.3,IP:127.0.0.1 -dname "CN=localhost, OU=Organizational Unit, O=Organization, L=Location, ST=State, C=Country"
ref:https://www.codetd.com/en/article/6297034
```

### Validating the responder against "real" reference accounts
To run functional tests against CIB API :
1. add BNPP CIB client key and certificates in classpath : certs/copuk-stg-ev.key and certs/stg-ev_sis-id4banks_com.crt
2. mvn integration-test -P validation