DELETE FROM name_matching_log;
DELETE FROM audit;
INSERT INTO audit (correlation_id,account_currency, identification, input_account_name) VALUES
                                        ('fapi1','$', '53987060069514','compte1'),
                                        ('fapi2','$','53987060069524','compte2'),
                                        ('fapi3','$','53987060069534','compte3');