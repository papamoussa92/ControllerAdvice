DELETE FROM nature_enterprise;
INSERT INTO nature_enterprise (nature) VALUES('solicitor'), ('solicitors'), ('Technology'), ('technologies'), ('tech'), ('group'), ('services'), ('financial');