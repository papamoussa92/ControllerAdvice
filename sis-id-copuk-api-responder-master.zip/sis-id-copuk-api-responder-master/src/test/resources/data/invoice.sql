DELETE FROM prefix;
INSERT INTO prefix (prefix) VALUES('.+\s+RE');