DELETE FROM company_synonyms;
INSERT INTO company_synonyms (account_name, trading_name) VALUES
                                                              ('Alpha Beta company','ABC'),
                                                              ('Alpha Beta company','AB company'),
                                                              ('Alpha Beta company','Alpha BC'),
                                                              ('Alpha Beta company','A Beta C'),
                                                              ('General Motor company','GMC'),
                                                              ('General Motor company','G Motor C'),
                                                              ('General Motor company','G M Company'),
                                                              ('Facebook Company','Meta'),
                                                              ('Facebook Company','Whatsapp'),
                                                              ('Facebook Company','Instagramm'),
                                                              ('Company Ltd','company limited');