package fr.sis.sisid.copuk.service;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockserver.client.MockServerClient;
import org.mockserver.model.HttpRequest;
import org.mockserver.model.HttpResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import fr.sis.sisid.copuk.exceptions.OBErrorResponseException;
import fr.sis.sisid.copuk.model.AccountType;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import lombok.extern.slf4j.Slf4j;

@Slf4j
class PayeeInformationServiceIT extends SpringTestConfiguration {

    @Autowired
    PayeeInformationServiceImpl payeeInfoService;

    @Autowired
    @Qualifier("bnp-mockserver-client")
    MockServerClient payeeInfoMockClient;

    @BeforeEach
    void setUp() {
        payeeInfoMockClient.reset();
        payeeInfoMockClient.when(HttpRequest.request("*")).respond(HttpResponse.response().withStatusCode(404));
    }

    @Test
    void testNotFound() {
        var request = CoreCopRequest.builder()
                .name("Fake company ltd")
                .accountType(AccountType.BUSINESS)
                .build();
        try {
            payeeInfoService.getAccountInfo(request).block();
        } catch (OBErrorResponseException err) {
            Assertions.assertThat(err.getStatusCode()).isEqualTo(503);
            return;
        }
        Assertions.fail("WebClientResponseException to be thrown, because of HTTP404");
    }
}
