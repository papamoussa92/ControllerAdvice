package fr.sis.sisid.copuk.controllers.errors;

import com.nimbusds.jose.JOSEException;
import fr.sis.sisid.copuk.OpenBankingConstants;
import fr.sis.sisid.copuk.tools.ResponseSigner;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.test.StepVerifier;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ExceptionProcessorTest {


    @Test
    void testExceptionProcessingDefault() throws JOSEException {
        var responseSigner = mock(ResponseSigner.class);
        when(responseSigner.signPayload(any(String.class), any(Instant.class))).thenReturn("signature1");
        Throwable t = new ArrayIndexOutOfBoundsException();
        var response = new ExceptionProcessor(t, responseSigner).when(NullPointerException.class)
                .status(HttpStatus.CONFLICT)
                .body((e, status) -> e.getMessage())
                .elseDefaults(HttpStatus.BAD_GATEWAY, (e, status) -> "default exception");
        StepVerifier.create(response)
                .assertNext((ServerResponse r) -> {
                    assertEquals(502, r.rawStatusCode());
                    assertEquals(MediaType.APPLICATION_JSON, r.headers().getContentType());
                    assertEquals("signature1", r.headers().getFirst(OpenBankingConstants.NON_REPUDIATION_HEADER));
                }).verifyComplete();
    }

    @Test
    void testExceptionProcessing() throws JOSEException {
        var responseSigner = mock(ResponseSigner.class);
        when(responseSigner.signPayload(any(String.class), any(Instant.class))).thenReturn("signature2");
        Throwable t = new ArrayIndexOutOfBoundsException();
        var response = new ExceptionProcessor(t, responseSigner)
                .when(NullPointerException.class)
                .status(HttpStatus.CONFLICT)
                .body((e, status) -> e.getMessage())

                .when(ArrayIndexOutOfBoundsException.class)
                .status(HttpStatus.NOT_FOUND)
                .body((e, status) -> "array exception")

                .elseDefaults(HttpStatus.BAD_GATEWAY, (e, status) -> "default exception");
        StepVerifier.create(response)
                .expectNextMatches(r -> {
                    assertEquals(404, r.rawStatusCode());
                    assertEquals(MediaType.APPLICATION_JSON, r.headers().getContentType());
                    assertEquals("signature2", r.headers().getFirst(OpenBankingConstants.NON_REPUDIATION_HEADER));
                    return true;
                }).verifyComplete();
    }

}