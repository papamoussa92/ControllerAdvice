package fr.sis.sisid.copuk.cop.core.stubs;

import fr.sis.sisid.copuk.namematching.NameMatchingProvider;
import fr.sis.sisid.copuk.namematching.model.CompanySynonyms;
import fr.sis.sisid.copuk.namematching.model.MatchingResult;
import fr.sis.sisid.copuk.namematching.processors.NamePairProcessorType;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

import java.util.List;

@Slf4j
@Getter
public class NameMatchingProviderStub implements NameMatchingProvider {

    @Setter
    private MatchingResult nameMatchingResult;

    private String input;

    private String target;

    public NameMatchingProviderStub(MatchingResult nameMetchingResult) {
        this.nameMatchingResult = nameMetchingResult;
    }

    @Override
    public Mono<MatchingResult> nameMatch(String input, String target) {
        this.input = input;
        this.target = target;
        return Mono.just(nameMatchingResult);
    }

    @Override
    public String getProcessedAccountName(String reference, NamePairProcessorType namePairProcessorType) {
        return null;
    }


}
