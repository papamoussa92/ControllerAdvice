package fr.sis.sisid.copuk.tools;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.sis.sisid.copuk.OpenBankingConstants;
import fr.sis.sisid.copuk.copapi.model.AccountsNameVerificationData;
import fr.sis.sisid.copuk.copapi.model.InlineObject;
import fr.sis.sisid.copuk.copapi.model.OBExternalAccountType1Code;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import lombok.Getter;
import org.apache.http.HttpHeaders;

import java.util.HashMap;
import java.util.Map;

public class NameVerificationRequestTools {

    @Getter
    private static final String interactionId = "71216ad2-f7b3-11ec-85e0-57cb18777a1f";
    @Getter
    private static final String defaultIdentification = "12345674859698";

    private NameVerificationRequestTools() {
    }

    public static Map<String, String> getRequestHeaders(String orgId, String authToken, String correlationId,
            String nonRepudiationToken) {
        Map<String, String> headers = new HashMap<>();
        headers.put(HttpHeaders.CONTENT_TYPE, "application/json");
        headers.put(OpenBankingConstants.ORGANISATION_HEADER, orgId);
        headers.put("Authorization", "Bearer " + authToken);
        headers.put(OpenBankingConstants.CORRELATION_ID_HEADER, correlationId);
        headers.put(OpenBankingConstants.NON_REPUDIATION_HEADER, nonRepudiationToken);
        headers.put(HttpHeaders.ACCEPT, "application/json");
        return headers;
    }

    public static Response performNameVerification(
            String name, String orgId, TokenTool tokenTool, int serverPort) {
        return performNameVerification(
                name, orgId, tokenTool, serverPort, interactionId,
                OBExternalAccountType1Code.BUSINESS);
    }

    public static Response performNameVerification(
            String name, String orgId, TokenTool tokenTool, int serverPort, String interactionId) {
        return performNameVerification(
                name, orgId, tokenTool, serverPort, interactionId,
                OBExternalAccountType1Code.BUSINESS);
    }

    public static Response performNameVerification(
            String name, String orgId, TokenTool tokenTool, int serverPort, String interactionId,
            OBExternalAccountType1Code accountType) {
        try {

            var requestBody = new InlineObject().data(new AccountsNameVerificationData()
                    .schemeName(AccountsNameVerificationData.SchemeNameEnum.SORTCODEACCOUNTNUMBER)
                    .accountType(accountType)
                    .identification(defaultIdentification)
                    .name(name));
            var mapper = new ObjectMapper();
            String serializedBody = mapper.writeValueAsString(requestBody);

            var headers = NameVerificationRequestTools.getRequestHeaders(
                    orgId, tokenTool.fetchToken(), interactionId,
                    RequestSignatureTool.signPayload(serializedBody));

            RestAssured.baseURI = String.format("http://localhost:%s", serverPort);

            return RestAssured.given()
                    .headers(headers)
                    .body(serializedBody)
                    .request(Method.POST, "/api/v1.0/pay.uk/accounts/name-verification")
                    .then().extract().response();
        } catch (JsonProcessingException err) {
            throw new RuntimeException("could not send a test name verification request", err);
        }
    }
}
