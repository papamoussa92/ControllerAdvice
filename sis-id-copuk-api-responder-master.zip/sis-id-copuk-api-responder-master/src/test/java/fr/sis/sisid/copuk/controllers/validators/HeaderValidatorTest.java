package fr.sis.sisid.copuk.controllers.validators;

import fr.sis.sisid.copuk.OpenBankingConstants;
import fr.sis.sisid.copuk.controllers.errors.MissingHeaderException;
import fr.sis.sisid.copuk.tools.errors.MissingSignatureException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.util.MultiValueMap;
import org.springframework.util.MultiValueMapAdapter;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

class HeaderValidatorTest {

    private final String validOrgId= "192384";
    private HeaderValidator headerValidator;

    @BeforeEach
    void init() {
        headerValidator = new HeaderValidator(validOrgId);
    }

    @Test
    void testCheckValid() {

        MultiValueMap<String, String> headers1 = new MultiValueMapAdapter(Map.of(
                OpenBankingConstants.NON_REPUDIATION_HEADER, List.of("eyOK"),
                OpenBankingConstants.CORRELATION_ID_HEADER, List.of(UUID.randomUUID().toString()),
                OpenBankingConstants.ORGANISATION_HEADER, List.of(validOrgId)
        ));
        var headers = HttpHeaders.readOnlyHttpHeaders(headers1);



        assertDoesNotThrow(() -> headerValidator.check(headers));

    }

    @Test
    void testCheckMissing() {
        MultiValueMap<String, String> headers1 = new MultiValueMapAdapter(Map.of(
                OpenBankingConstants.NON_REPUDIATION_HEADER, List.of("eyOK"),
                OpenBankingConstants.CORRELATION_ID_HEADER, List.of(UUID.randomUUID().toString())
        ));
        var headers = HttpHeaders.readOnlyHttpHeaders(headers1);



        assertThrows(MissingHeaderException.class, () -> headerValidator.check(headers));
    }

    @Test
    void testCheckMissingSignature() {
        MultiValueMap<String, String> headers1 = new MultiValueMapAdapter(Map.of(
                OpenBankingConstants.CORRELATION_ID_HEADER, List.of(UUID.randomUUID().toString())
        ));
        var headers = HttpHeaders.readOnlyHttpHeaders(headers1);



        assertThrows(MissingSignatureException.class, () -> headerValidator.check(headers));
    }


}