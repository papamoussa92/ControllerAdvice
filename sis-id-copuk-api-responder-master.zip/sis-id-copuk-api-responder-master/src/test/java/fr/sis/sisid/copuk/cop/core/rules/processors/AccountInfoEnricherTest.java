package fr.sis.sisid.copuk.cop.core.rules.processors;

import fr.sis.sisid.copuk.cop.core.CopTestTools;
import fr.sis.sisid.copuk.cop.core.stubs.AccountInfoProviderStub;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import org.junit.jupiter.api.Test;
import reactor.test.StepVerifier;

class AccountInfoEnricherTest {

    @Test
    void enrichContextTest() {
        var accountInfoProvider = new AccountInfoProviderStub(CoreAccountInfo.builder().name("name").build());
        var copRequest = CoreCopRequest.builder().name("name").build();
        var accountInfoEnricher = new AccountInfoEnricher(accountInfoProvider);
        StepVerifier.create(
                accountInfoEnricher.enrichContext(CopTestTools.getVerificationContext(copRequest)))
                .expectNextMatches(
                        ctx -> ctx.getAccountInfo().isPresent() && ctx.getAccountInfo().get().getName().equals("name"))
                .expectComplete()
                .verify();
    }

    @Test
    void enrichContext_accountInfoPresentTest() {
        var accountInfoProvider = new AccountInfoProviderStub(CoreAccountInfo.builder().name("name").build());
        var copRequest = CoreCopRequest.builder().name("name").build();
        var verificationContext = CopTestTools.getVerificationContext(copRequest);
        verificationContext.setAccountInfo(CoreAccountInfo.builder().name("other name").build());
        var accountInfoEnricher = new AccountInfoEnricher(accountInfoProvider);
        StepVerifier.create(
                accountInfoEnricher.enrichContext(verificationContext))
                .expectNextMatches(
                        ctx -> ctx.getAccountInfo().isPresent()
                                && ctx.getAccountInfo().get().getName().equals("other name"))
                .expectComplete()
                .verify();
    }
}
