package fr.sis.sisid.copuk.validation;

import fr.sis.sisid.copuk.LifecycledContainer;
import io.cucumber.spring.CucumberContextConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.ArrayList;

import static fr.sis.sisid.copuk.SpringTestConfiguration.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@Testcontainers
@CucumberContextConfiguration
@Slf4j
@ActiveProfiles("validation")
public class ValidationConfiguration {

    @DynamicPropertySource
    static void registerPgProperties(DynamicPropertyRegistry registry) {
        var containers = new ArrayList<LifecycledContainer>();
        var c = initPGContainer(registry);
        containers.add(c);

        containers.add(initAuthServerKeyCloak(registry));
        containers.add(initClientRegistrationMockServer(registry));

        containers.stream().parallel().forEach(LifecycledContainer::create);

        containers.stream().parallel().forEach(LifecycledContainer::start);
        containers.forEach(LifecycledContainer::postConfigure);
    }

}
