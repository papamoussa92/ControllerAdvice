package fr.sis.sisid.copuk.api;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockserver.client.MockServerClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.jdbc.Sql;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import fr.sis.sisid.copuk.config.CacheConfig;
import fr.sis.sisid.copuk.copapi.model.InlineResponse200;
import fr.sis.sisid.copuk.copapi.model.ReasonCodes;
import fr.sis.sisid.copuk.entities.InvoiceDiscountAccountDAO;
import fr.sis.sisid.copuk.mockserver.MockUtils;
import fr.sis.sisid.copuk.tools.NameVerificationRequestTools;
import fr.sis.sisid.copuk.tools.TokenTool;

@Sql(scripts = "classpath:data/invoice.sql")
class InvoiceDiscountAccountIT extends SpringTestConfiguration {
    @Autowired
    @Qualifier("bnp-mockserver-client")
    MockServerClient payeeInfoMockClient;

    @LocalServerPort
    private int serverPort;

    @Autowired
    @Qualifier("registration-mockserver-client")
    MockServerClient registrationMockServer;

    @Value("${spring.security.oauth2.client.registration.copuk-auth.client-id}")
    private String clientId = "test-client";

    @Value("${app.organisation-id}")
    private String organisationId;

    @Autowired
    private TokenTool tokenTool;

    @Autowired
    private InvoiceDiscountAccountDAO invoiceDiscountrepository;

    @Autowired
    private CacheConfig cacheConfig;

    @BeforeEach
    void setup() {
        MockUtils.mockTC_UK_01(payeeInfoMockClient, "ABC Invoicing Re XYZ Trading", "123456", "74859698",
                "Organisation");
        MockUtils.mockSsa(registrationMockServer, clientId);
        cacheConfig.initializeCaches(null);
    }

    @Test
    void invoiceDiscountCloseMatch() {
        InlineResponse200 inlineResponse200 = NameVerificationRequestTools
                .performNameVerification("XYZ Trading SA", organisationId, tokenTool, serverPort)
                .as(InlineResponse200.class);
        Assertions.assertEquals(ReasonCodes.MBAM, inlineResponse200.getData().getVerificationReport().getReasonCode());
        Assertions.assertEquals("XYZ Trading", inlineResponse200.getData().getVerificationReport().getName());
    }

    @Test
    void invoiceDiscountMatch() {
        InlineResponse200 inlineResponse200 = NameVerificationRequestTools
                .performNameVerification("XYZ Trading ", organisationId, tokenTool, serverPort)
                .as(InlineResponse200.class);
        Assertions.assertTrue(inlineResponse200.getData().getVerificationReport().getMatched());
        Assertions.assertNull(inlineResponse200.getData().getVerificationReport().getReasonCode());
        Assertions.assertNull(inlineResponse200.getData().getVerificationReport().getName());
    }

    @Test
    void invoiceDiscountCacheTest() {
        // clear the db, request should hit the cache
        invoiceDiscountrepository.deleteAll();
        InlineResponse200 inlineResponse200 = NameVerificationRequestTools
                .performNameVerification("XYZ Trading ", organisationId, tokenTool, serverPort)
                .as(InlineResponse200.class);
        Assertions.assertTrue(inlineResponse200.getData().getVerificationReport().getMatched());
        Assertions.assertNull(inlineResponse200.getData().getVerificationReport().getReasonCode());
        Assertions.assertNull(inlineResponse200.getData().getVerificationReport().getName());
    }

}
