package fr.sis.sisid.copuk.api;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockserver.client.MockServerClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.jdbc.Sql;

import com.fasterxml.jackson.core.JsonProcessingException;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import fr.sis.sisid.copuk.config.CacheConfig;
import fr.sis.sisid.copuk.copapi.model.InlineResponse200;
import fr.sis.sisid.copuk.copapi.model.ReasonCodes;
import fr.sis.sisid.copuk.entities.AuditRepository;
import fr.sis.sisid.copuk.entities.NatureEnterpriseDAO;
import fr.sis.sisid.copuk.mockserver.MockUtils;
import fr.sis.sisid.copuk.tools.NameVerificationRequestTools;
import fr.sis.sisid.copuk.tools.TokenTool;

@Sql(scripts = "classpath:data/nature.sql")
class NatureEntrepriseIT extends SpringTestConfiguration {
    @Autowired
    @Qualifier("bnp-mockserver-client")
    MockServerClient payeeInfoMockClient;

    @Autowired
    AuditRepository auditRepository;

    @LocalServerPort
    private int serverPort;

    @Autowired
    @Qualifier("registration-mockserver-client")
    MockServerClient registrationMockServer;

    @Value("${spring.security.oauth2.client.registration.copuk-auth.client-id}")
    private String clientId = "test-client";

    @Value("${app.organisation-id}")
    private String organisationId;

    @Autowired
    private TokenTool tokenTool;

    @Autowired
    private NatureEnterpriseDAO natureEntrepriseRepository;

    @Autowired
    private CacheConfig cacheConfig;

    @BeforeEach
    void setup() {
        MockUtils.mockTC_UK_01(payeeInfoMockClient, "Fortis Technology", "123456", "74859698", "Organisation");
        MockUtils.mockSsa(registrationMockServer, clientId);
        // reset cache, as database gets populated AFTER the spring context is set up
        cacheConfig.initializeCaches(null);
    }

    @Test
    void natureEnterpriseFullMatching() throws JsonProcessingException {
        InlineResponse200 inlineResponse200 = NameVerificationRequestTools
                .performNameVerification("Fortis", organisationId, tokenTool, serverPort)
                .as(InlineResponse200.class);
        Assertions.assertFalse(inlineResponse200.getData().getVerificationReport().getMatched());
        Assertions.assertEquals(ReasonCodes.MBAM, inlineResponse200.getData().getVerificationReport().getReasonCode());
        Assertions.assertEquals("Fortis Technology", inlineResponse200.getData().getVerificationReport().getName());
    }

    @Test
    void natureEnterpriseCacheTest() throws JsonProcessingException {
        // clear db, the request should hit the cache
        natureEntrepriseRepository.deleteAll();
        InlineResponse200 inlineResponse200 = NameVerificationRequestTools
                .performNameVerification("Fortis", organisationId, tokenTool, serverPort)
                .as(InlineResponse200.class);
        Assertions.assertFalse(inlineResponse200.getData().getVerificationReport().getMatched());
        Assertions.assertEquals(ReasonCodes.MBAM, inlineResponse200.getData().getVerificationReport().getReasonCode());
        Assertions.assertEquals("Fortis Technology", inlineResponse200.getData().getVerificationReport().getName());
    }
}
