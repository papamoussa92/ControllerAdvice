package fr.sis.sisid.copuk.api;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

import org.apache.http.HttpHeaders;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockserver.client.MockServerClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.test.context.jdbc.Sql;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import fr.sis.sisid.copuk.copapi.model.OBExternalAccountType1Code;
import fr.sis.sisid.copuk.dto.NameMatchingStatsDTO;
import fr.sis.sisid.copuk.entities.AuditRepository;
import fr.sis.sisid.copuk.entities.NameMatchingLogRepository;
import fr.sis.sisid.copuk.mockserver.MockUtils;
import fr.sis.sisid.copuk.tools.NameVerificationRequestTools;
import fr.sis.sisid.copuk.tools.TokenTool;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Method;
import lombok.extern.slf4j.Slf4j;

@Slf4j
class AuditControllerIT extends SpringTestConfiguration {
    @Autowired
    @Qualifier("bnp-mockserver-client")
    MockServerClient payeeInfoMockClient;
    @Autowired
    AuditRepository auditRepository;
    @Autowired
    NameMatchingLogRepository nmlRepository;
    @LocalServerPort
    private int serverPort;

    @Autowired
    private TokenTool tokenTool;

    @Value("${app.organisation-id}")
    private String organisationId;

    @Value("${spring.security.oauth2.client.registration.copuk-auth.client-id}")
    private String clientId = "test-client";

    @Autowired
    @Qualifier("registration-mockserver-client")
    MockServerClient registrationMockServer;

    @AfterEach
    void cleanup() {
        this.nmlRepository.deleteAll();
        this.auditRepository.deleteAll();
    }

    private static Stream<Arguments> searchQueryArguments() {
        return Stream.of(
                Arguments.of("/audit/search", 3),
                Arguments.of("/audit/search?identifiant=53987060069514", 1),
                Arguments.of("/audit/search?name=compte1", 1),
                Arguments.of("/audit/search?name=compte1&identifiant=53987060069514", 1),
                Arguments.of("/audit/search?name=compte1&identifiant=53987060069514&dateStart="
                        + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) + "&dateEnd="
                        + LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")), 1),
                Arguments.of("/audit/search?d&dateEnd="
                        + LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")), 3),
                Arguments.of("audit/search?dateStart="
                        + LocalDate.now().minusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd")), 3));
    }

    @ParameterizedTest
    @MethodSource("searchQueryArguments")
    @Sql(scripts = "classpath:data/data.sql")
    void testSearchAuditWithoutParams(String path, int size) {
        Map<String, String> reqHeaders = new HashMap<>();
        reqHeaders.put(HttpHeaders.CONTENT_TYPE, "application/json");
        reqHeaders.put(HttpHeaders.ACCEPT, "application/json");
        RestAssured.baseURI = String.format("http://localhost:%s", serverPort);
        var response = RestAssured.given()
                .headers(reqHeaders)
                .request(Method.GET, path)
                .then().extract().response();

        List<?> audits = response.as(List.class);
        assertThat(audits)
                .isNotNull()
                .hasSize(size);
        auditRepository.deleteAll();
    }

    @Test
    @Sql(scripts = "classpath:data/data.sql")
    void testSearchAuditWhitoutDateEndLessTanDateStart() {
        Map<String, String> reqHeaders = new HashMap<>();
        reqHeaders.put(HttpHeaders.CONTENT_TYPE, "application/json");
        reqHeaders.put(HttpHeaders.ACCEPT, "application/json");
        RestAssured.baseURI = String.format("http://localhost:%s", serverPort);
        String dateDebut = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        String dateFin = LocalDate.now().minusDays(4).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        var response = RestAssured.given()
                .headers(reqHeaders)
                .request(Method.GET, "/audit/search?dateStart=" + dateDebut + "&dateEnd=" + dateFin)
                .then().extract().response();
        assertThat(response.statusCode()).isEqualTo(400);

        var response2 = RestAssured.given()
                .headers(reqHeaders)
                .request(Method.GET, "/audit/search?dateStart=" + "bad" + dateDebut + "&dateEnd=" + dateFin)
                .then().extract().response();
        assertThat(response2.statusCode()).isEqualTo(400);
    }

    @Test
    void queryInternalAuditTest()
            throws JsonMappingException, JsonProcessingException, ExecutionException, InterruptedException {
        this.nmlRepository.deleteAll();
        this.auditRepository.deleteAll();
        MockUtils.mockSsa(this.registrationMockServer, clientId);
        MockUtils.mockTC_UK_01(payeeInfoMockClient, "ACME limited", "123456", "74859698", "Organisation");
        for (int i = 0; i < 4; i++) { // 1
            NameVerificationRequestTools.performNameVerification("ACME limited", organisationId, tokenTool, serverPort);
        }
        for (int i = 0; i < 3; i++) { // MBAM
            NameVerificationRequestTools.performNameVerification("ACME llp", organisationId, tokenTool, serverPort);
        }
        for (int i = 0; i < 2; i++) { // ANNM
            NameVerificationRequestTools.performNameVerification("facebook inc", organisationId, tokenTool, serverPort);
        }
        for (int i = 0; i < 1; i++) { // BANM
            NameVerificationRequestTools.performNameVerification("ACME limited", organisationId, tokenTool, serverPort,
                    "71216ad2-f7b3-11ec-85e0-57cb18777a1f", OBExternalAccountType1Code.PERSONAL);
        }

        // we sleep here, because the logging is triggered AFTER the reply has been sent
        ScheduledExecutorService executorService = Executors.newScheduledThreadPool(1);
        var auditFuture = executorService.schedule(() -> {
                    RestAssured.baseURI = String.format("http://localhost:%s", serverPort);
                    return RestAssured.given()
                            .header("Accept", "application/json")
                            .param("from", ZonedDateTime.now().minusMinutes(5).toString())
                            .param("to", ZonedDateTime.now().toString())
                            .request(Method.GET, "/internal/audit")
                            .then().assertThat().statusCode(200)
                            .assertThat().contentType(ContentType.JSON)
                            .extract().as(NameMatchingStatsDTO.class);

                },
                100, TimeUnit.MILLISECONDS);

        var statsJson = auditFuture.get();
        // test json

        Assertions.assertThat(statsJson.getRegistrationId()).isEqualTo(organisationId);
        Assertions.assertThat(statsJson.getNbPersonalRequests()).isEqualTo(1l);
        Assertions.assertThat(statsJson.getNbBusinessRequests()).isEqualTo(9l);
        Assertions.assertThat(statsJson.getNbMatched()).isEqualTo(4l);
        Assertions.assertThat(statsJson.getNbANNM()).isEqualTo(2l);
        Assertions.assertThat(statsJson.getNbMBAM()).isEqualTo(3l);
        Assertions.assertThat(statsJson.getNbBANM()).isEqualTo(1l);
        // test csv
        var statsCsv = RestAssured.given()
                .accept("text/csv")
                .param("from", ZonedDateTime.now().minusMinutes(5).toString())
                .param("to", ZonedDateTime.now().toString())
                .request(Method.GET, "/internal/audit")
                .then().assertThat().statusCode(200)
                .assertThat().contentType("text/csv")
                .extract()
                .asString();
        log.info("csv : {}", statsCsv);

        CsvMapper mapper = new CsvMapper();
        CsvSchema csvSchema = mapper
                .schemaFor(NameMatchingStatsDTO.class)
                .withHeader();
        var parsedStats = mapper.readerFor(NameMatchingStatsDTO.class).with(csvSchema).readValue(statsCsv);
        Assertions.assertThat(parsedStats).isEqualTo(statsJson);

    }

}
