package fr.sis.sisid.copuk.mappers;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

import fr.sis.sisid.copuk.dto.NameMatchingStatsDTO;
import fr.sis.sisid.copuk.entities.AuditStatsResult;

class AuditStatsMapperTest {

    @Test
    void toDTOTest() {
        var input = AuditStatsResult.builder()
                .nbPersonalRequests(1l)
                .nbBusinessRequests(2l)
                .nbMatched(3l)
                .nbANNM(4l)
                .nbMBAM(5l)
                .nbBANM(6l)
                .nbPANM(7l)
                .nbBAMM(8l)
                .nbAC01(9l)
                .nbIVCR(10l)
                .nbACNS(11l)
                .nbOPTO(12l)
                .nbCASS(13l)
                .nbSCNS(14l)
                .nbOutsideOfSLA(15l)
                .build();

        String orgId = "org-id";

        var expected = NameMatchingStatsDTO.builder()
                .registrationId(orgId)
                .nbPersonalRequests(1l)
                .nbBusinessRequests(2l)
                .nbMatched(3l)
                .nbANNM(4l)
                .nbMBAM(5l)
                .nbBANM(6l)
                .nbPANM(7l)
                .nbBAMM(8l)
                .nbAC01(9l)
                .nbIVCR(10l)
                .nbACNS(11l)
                .nbOPTO(12l)
                .nbCASS(13l)
                .nbSCNS(14l)
                .nbOutsideOfSLA(15l)
                .build();
        var mapper = new AuditStatsMapper();
        Assertions.assertThat(mapper.toDTO(input, orgId)).isEqualTo(expected);
    }
}
