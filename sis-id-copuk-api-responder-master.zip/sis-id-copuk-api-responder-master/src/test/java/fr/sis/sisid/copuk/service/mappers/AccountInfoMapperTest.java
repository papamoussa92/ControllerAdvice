package fr.sis.sisid.copuk.service.mappers;

import fr.sis.sisid.copuk.config.AccountInfoProperties;
import fr.sis.sisid.copuk.ext.bnp.model.AccountTypeComponent;
import fr.sis.sisid.copuk.ext.bnp.model.CopReply;
import fr.sis.sisid.copuk.ext.bnp.model.PartyIdentification;
import fr.sis.sisid.copuk.ext.bnp.model.RequestStatus;
import fr.sis.sisid.copuk.model.AccountInfoErrorCode;
import fr.sis.sisid.copuk.model.AccountInfoRejection;
import fr.sis.sisid.copuk.model.AccountType;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import fr.sis.sisid.copuk.service.mapper.AccountInfoMapperImpl;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.List;
import java.util.stream.Stream;

class AccountInfoMapperTest {

    private AccountInfoMapperImpl mapper;

    private static final String accountOptOutCode = "ERR90";

    private static final String accountSwitchedCode = "ERR91";

    @BeforeEach
    public void init() {
        var properties = new AccountInfoProperties();
        properties.setAccountOptOut(accountOptOutCode);
        properties.setAccountSwitched(accountSwitchedCode);
        mapper = new AccountInfoMapperImpl(properties);
    }

    @Test
    void testToDomain() {
        CopReply input = new CopReply()
                .accountInformation(
                        new PartyIdentification()
                                .name("ACME Inc")
                                .currency(List.of("GBP"))
                                .accountType(AccountTypeComponent.ORGANISATION))
                .requestStatus(RequestStatus.ACCEPTED)
                .requestReasonStatus("Accepted");
        CoreAccountInfo expected = CoreAccountInfo.builder()
                .name("ACME Inc")
                .accountType(AccountType.BUSINESS)
                .currency("GBP")
                .build();
        Assertions.assertThat(mapper.toDomain(input)).isEqualTo(expected);
    }

    @Test
    void testToDomain_copReplyIsError() {
        var input = new CopReply()
                .requestStatus(RequestStatus.REJECTED)
                .requestReasonStatus("BUS01: Account data not found");
        AccountInfoRejection expected = AccountInfoRejection.builder()
                .reason("BUS01: Account data not found")
                .code(AccountInfoErrorCode.ACCOUNT_NOT_FOUND)
                .build();
        Assertions.assertThat(mapper.toDomain(input)).isEqualTo(expected);

    }

    @ParameterizedTest
    @MethodSource("parseErrorCodeTestArguments")
    void parseErrorCodeTest(String input, AccountInfoErrorCode expected) {
        Assertions.assertThat(mapper.parseErrorCode(input)).isEqualTo(expected);
    }

    private static Stream<Arguments> parseErrorCodeTestArguments() {
        return Stream.of(
                Arguments.of("BUS01: Account data not found", AccountInfoErrorCode.ACCOUNT_NOT_FOUND),
                Arguments.of("ERR17: This account type is not supported",
                        AccountInfoErrorCode.UNSUPPORTED_ACCOUNT_TYPE),
                Arguments.of("ERR10: This scheme name is not supported", AccountInfoErrorCode.UNSUPPORTED_SCHEME_NAME),
                Arguments.of("ERR11: The country is mandatory in this context", AccountInfoErrorCode.MISSING_COUNTRY),
                Arguments.of("ERR12: The clearing system identification is mandatory in this context",
                        AccountInfoErrorCode.MISSING_CLEARING_SYSTEM_ID),
                Arguments.of("ERR13: This clearing System Code is not supported",
                        AccountInfoErrorCode.UNSUPPORTED_CLEARING_SYSTEM_CODE),
                Arguments.of("ERR14: This member Id is unknown for this clearing system in this context",
                        AccountInfoErrorCode.UNKNOWN_MEMBER_ID),
                Arguments.of("ERR15: The country is not coherent", AccountInfoErrorCode.UNCOHERENT_COUNTRY),
                Arguments.of("ERR16: This country is out of scope", AccountInfoErrorCode.UNSUPPORTED_COUNTRY),
                Arguments.of("ERR18: This proprietary clearing system is not supported",
                        AccountInfoErrorCode.UNSUPPORTED_CLEARING_SYSTEM),
                Arguments.of("ERR19: The identification is not coherent with the member Id",
                        AccountInfoErrorCode.IDENTIFICATION_MEMBER_ID_MISMATCH),
                Arguments.of("ABAB25: Message with unknown error code", AccountInfoErrorCode.UNKNOWN_ERROR_CODE),
                Arguments.of("", AccountInfoErrorCode.UNKNOWN_ERROR_CODE),
                Arguments.of("Unknown error message with no error code", AccountInfoErrorCode.UNKNOWN_ERROR_CODE),
                Arguments.of(null, AccountInfoErrorCode.UNKNOWN_ERROR_CODE),
                Arguments.of(accountOptOutCode + ": account opted out", AccountInfoErrorCode.ACCOUNT_OPT_OUT),
                Arguments.of(accountSwitchedCode + ": account switched", AccountInfoErrorCode.ACCOUNT_SWITCHED));
    }

    @Test
    void parseErrorCodetest_customMappingsDisabled() {
        // account info mapper with no custom error codes bindings
        var accountInfoMapper = new AccountInfoMapperImpl(new AccountInfoProperties());
        Assertions.assertThat(accountInfoMapper.parseErrorCode(accountOptOutCode + ": account opt out"))
                .isEqualTo(AccountInfoErrorCode.UNKNOWN_ERROR_CODE);
        Assertions.assertThat(accountInfoMapper.parseErrorCode(accountSwitchedCode + ": acconut switched"))
                .isEqualTo(AccountInfoErrorCode.UNKNOWN_ERROR_CODE);
    }
}
