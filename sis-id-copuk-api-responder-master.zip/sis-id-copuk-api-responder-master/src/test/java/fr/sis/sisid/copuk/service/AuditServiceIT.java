package fr.sis.sisid.copuk.service;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.entities.Audit;
import fr.sis.sisid.copuk.entities.AuditRepository;
import fr.sis.sisid.copuk.entities.NameMatchingLogEntity;
import fr.sis.sisid.copuk.entities.NameMatchingLogRepository;
import fr.sis.sisid.copuk.model.AccountType;
import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.model.MatchingResult;
import fr.sis.sisid.copuk.namematching.model.NameMatchingLog;
import lombok.extern.slf4j.Slf4j;

@Slf4j
class AuditServiceIT extends SpringTestConfiguration {

    @Autowired
    private AuditService auditService;

    @Autowired
    private AuditRepository auditRepository;

    @Autowired
    private NameMatchingLogRepository nameMatchingRepository;

    @AfterEach
    @BeforeEach
    void cleanUp() {
        nameMatchingRepository.deleteAll();
        auditRepository.deleteAll();
    }

    @Test
    void saveContextTest() {
        log.debug("saveContextTest - start");
        var reqTimestamp = Timestamp.valueOf(LocalDateTime.of(2022, 7, 11, 17, 45, 0));
        var input = new VerificationContext("org", "saveContextTest", reqTimestamp.getTime());

        input.setRequest(CoreCopRequest.builder().accountType(AccountType.BUSINESS)
                .accountNumber("0123456789")
                .name("company name")
                .build());
        input.setReply(CoreCopReply.builder().matched(false).build());

        this.auditService.save(input).block();

        var exAudit = new Audit();
        exAudit.setDateAudit(null);
        exAudit.setCorrelationId("saveContextTest");
        var result = this.auditRepository.findOne(Example.of(exAudit));

        Assertions.assertThat(result).isPresent();
        Assertions.assertThat(result.get().getCorrelationId()).isEqualTo("saveContextTest");

    }

    @Test
    void saveContextTest_withNameMatching() {
        log.debug("saveContextTest_withNameMatching - start");
        var input = new VerificationContext("org", "saveContextTest_withNameMatching",
                System.currentTimeMillis());

        input.setRequest(CoreCopRequest.builder().accountType(AccountType.BUSINESS)
                .accountNumber("0123456789")
                .name("company name")
                .build());
        input.setReply(CoreCopReply.builder().matched(false).build());
        var matchingResult = new MatchingResult(BigDecimal.valueOf(0.47d), MatchingDecision.CLOSE_MATCH);

        List<NameMatchingLog> nmLog = new ArrayList<>();
        var log1 = new NameMatchingLog();
        log1.setInput("input 1");
        log1.setReference("reference 1");
        log1.setProcessedInput("processed input 1");
        log1.setProcessedReference("processed reference 1");
        log1.setRuleCode("rule code 1");
        log1.setScore(0.12d);
        log1.setDecision(MatchingDecision.NO_MATCH);
        nmLog.add(log1);

        var log2 = new NameMatchingLog();
        log2.setInput("input 2");
        log2.setReference("reference 2");
        log2.setProcessedInput("processed input 2");
        log2.setProcessedReference("processed reference 2");
        log2.setRuleCode("rule code 2");
        log2.setScore(0.47d);
        log2.setDecision(MatchingDecision.CLOSE_MATCH);
        nmLog.add(log2);

        matchingResult.setProcessorLog(nmLog);
        input.setNameMatchingResult(matchingResult);

        var audit = this.auditService.save(input).block();

        var nmLogExample = new NameMatchingLogEntity();
        nmLogExample.setRuleOrder((short) 0);
        nmLogExample.setAudit(audit);

        Optional<NameMatchingLogEntity> nmLogOpt = this.nameMatchingRepository.findOne(Example.of(nmLogExample));
        Assertions.assertThat(nmLogOpt).isPresent();
        Assertions.assertThat(nmLogOpt.get().getRuleCode()).isEqualTo("rule code 1");

        nmLogExample.setRuleOrder((short) 1);
        nmLogOpt = this.nameMatchingRepository.findOne(Example.of(nmLogExample));
        Assertions.assertThat(nmLogOpt).isPresent();
        Assertions.assertThat(nmLogOpt.get().getRuleCode()).isEqualTo("rule code 2");
    }

}
