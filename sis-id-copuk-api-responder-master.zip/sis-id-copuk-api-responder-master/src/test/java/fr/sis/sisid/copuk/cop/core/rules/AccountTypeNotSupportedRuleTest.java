package fr.sis.sisid.copuk.cop.core.rules;

import fr.sis.sisid.copuk.cop.core.CopTestTools;
import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.rules.processors.AccountInfoEnricher;
import fr.sis.sisid.copuk.cop.core.stubs.AccountInfoProviderStub;
import fr.sis.sisid.copuk.copapi.model.ReasonCodes;
import fr.sis.sisid.copuk.model.AccountInfoErrorCode;
import fr.sis.sisid.copuk.model.AccountInfoRejection;
import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import reactor.test.StepVerifier;

import java.util.stream.Stream;

@Slf4j
class AccountTypeNotSupportedRuleTest {

    private VerificationContext emptyContext;

    @BeforeEach
    public void setup() {
        this.emptyContext = CopTestTools.getVerificationContext(CoreCopRequest.builder().name("test").build());
    }

    @ParameterizedTest
    @MethodSource("testMatchesArguments")
    void testMatches(VerificationContext context, boolean shouldMatch) {
        var accountTypeNotSupportedRule = new AccountTypeNotSupportedRule(null);
        Assertions.assertThat(accountTypeNotSupportedRule.matches(context)).isEqualTo(shouldMatch);
    }

    private static Stream<Arguments> testMatchesArguments() {
        var copRequest = CoreCopRequest.builder().name("test").build();
        // has error, correct code -> true
        var contextErrCorrectCode = CopTestTools.getVerificationContext(copRequest);
        contextErrCorrectCode.setAccountInfoError(AccountInfoRejection.builder()
                .code(AccountInfoErrorCode.UNSUPPORTED_ACCOUNT_TYPE)
                .reason("ERR17: This account type is not supported")
                .build());
        // has error, wrong code -> false
        var contextErrWrongCode = CopTestTools.getVerificationContext(copRequest);
        contextErrWrongCode.setAccountInfoError(AccountInfoRejection.builder()
                .code(AccountInfoErrorCode.ACCOUNT_NOT_FOUND)
                .reason("BUS01: Account data not found")
                .build());
        // has no error -> false
        var contextNoError = CopTestTools.getVerificationContext(copRequest);
        // has error, correct code, a reply -> false
        var contextReply = CopTestTools.getVerificationContext(copRequest);
        contextReply.setAccountInfoError(AccountInfoRejection.builder()
                .code(AccountInfoErrorCode.UNSUPPORTED_ACCOUNT_TYPE)
                .reason("ERR17: This account type is not supported")
                .build());
        contextReply.setReply(CoreCopReply.builder().matched(false).build());

        return Stream.of(
                Arguments.of(contextErrCorrectCode, true),
                Arguments.of(contextErrWrongCode, false),
                Arguments.of(contextNoError, false),
                Arguments.of(contextReply, false));
    }

    @Test
    void testEnrichContext() {
        var accountInfo = AccountInfoRejection.builder()
                .code(AccountInfoErrorCode.UNSUPPORTED_ACCOUNT_TYPE).reason("ERR17: This account type is not supported")
                .build();
        var accountInfoEnricher = new AccountInfoEnricher(
                new AccountInfoProviderStub(accountInfo));
        var rule = new AccountTypeNotSupportedRule(accountInfoEnricher);
        StepVerifier.create(rule.enrichContext(this.emptyContext))
                .assertNext(ctx -> Assertions.assertThat(ctx.getAccountInfoError()).contains(accountInfo))
                .expectComplete()
                .verify();
    }

    @Test
    void testEnrichContext_replyPresent() {
        this.emptyContext.setReply(CoreCopReply.builder().matched(true).build());
        var rule = new AccountTypeNotSupportedRule(null);
        StepVerifier.create(rule.enrichContext(emptyContext))
                .expectNext(this.emptyContext)
                .expectComplete().verify();
    }

    @Test
    void testPRocess() {
        var rule = new AccountTypeNotSupportedRule(null);
        StepVerifier.create(rule.process(emptyContext))
                .assertNext(ctx -> {
                    Assertions.assertThat(ctx.getReply()).isPresent();
                    var reply = ctx.getReply().get();
                    Assertions.assertThat(reply.isMatched()).isFalse();
                    Assertions.assertThat(reply.getName().isEmpty());
                    Assertions.assertThat(reply.getReasonCode()).contains(ReasonCodes.ACNS);
                }).expectComplete().verify();
    }

}
