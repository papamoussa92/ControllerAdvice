package fr.sis.sisid.copuk.config;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;

import org.junit.jupiter.api.Test;
import org.springframework.core.io.ClassPathResource;

class WebClientConfigTest {

    @Test
    void testClientConnector() throws IOException {

        var clientKey = Files.readString(Path.of(new ClassPathResource("certs/bnp-client-key.pem").getURI()),
                Charset.defaultCharset());

        var clientCert = Files.readString(Path.of(new ClassPathResource("certs/bnp-client-cert.crt").getURI()));
        var clientCACert = Files.readString(Path.of(new ClassPathResource("certs/bnpCA.crt").getURI()));
        WebClientConfig config = new WebClientConfig();
        var result = config.httpConnector(clientKey, clientCert, clientCACert);

        assertNotNull(result);
    }

    @Test
    void testClientConnector_rsaKey() throws IOException {

        var clientKey = Files.readString(Path.of(new ClassPathResource("certs/test/test-rsa-key.pem").getURI()),
                Charset.defaultCharset());

        var clientCert = Files.readString(Path.of(new ClassPathResource("certs/bnp-client-cert.crt").getURI()));
        var clientCACert = Files.readString(Path.of(new ClassPathResource("certs/bnpCA.crt").getURI()));
        WebClientConfig config = new WebClientConfig();
        var result = config.httpConnector(clientKey, clientCert, clientCACert);

        assertNotNull(result);
    }

}