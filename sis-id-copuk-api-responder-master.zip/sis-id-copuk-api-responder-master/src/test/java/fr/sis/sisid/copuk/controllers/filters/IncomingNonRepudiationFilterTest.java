package fr.sis.sisid.copuk.controllers.filters;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JOSEObjectType;
import fr.sis.sisid.copuk.config.NonRepudiationProperties;
import fr.sis.sisid.copuk.controllers.validators.HeaderValidator;
import fr.sis.sisid.copuk.dto.SsaDTO;
import fr.sis.sisid.copuk.tokens.NonRepudiationTokenParameters;
import fr.sis.sisid.copuk.tokens.OpenBankingTokenFactory;
import fr.sis.sisid.copuk.tools.JwtTools;
import fr.sis.sisid.copuk.tools.RequestSignatureTool;
import fr.sis.sisid.copuk.tools.ResponseSigner;
import fr.sis.sisid.copuk.tools.errors.JOSEValidationException;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
@ExtendWith(MockitoExtension.class)
class IncomingNonRepudiationFilterTest {

    JwtTools jwtTools;

    NonRepudiationFilter filter;

    SsaDTO stubSSA;

    private static String RSA_SIGNING_KEY;

    private static final String REQUEST_PAYLOAD = "{\"Data\":{\"SchemeName\":\"SortCodeAccountNumber\",\"AccountType\":\"Business\",\"Identification\":\"40638412345678\",\"Name\":\"ACME INC\"}}";

    @Mock
    private WebClient webClientMock;
    @Mock
    private WebClient.RequestHeadersSpec requestHeadersMock;
    @Mock
    private WebClient.RequestHeadersUriSpec requestHeadersUriMock;
    @Mock
    private WebClient.ResponseSpec responseMock;

    @Autowired
    private HeaderValidator headerValidator;

    @Autowired
    private ResponseSigner responseSigner;

    private String jwks;

    private static  String openBankingBaseUrl = "https://keystore.openbankingtest.org.uk";

    private String openBankingCacheUrl = "http://localhost:8099/jwks";

    @BeforeAll
    public static void beforeAll() {
        RSA_SIGNING_KEY = RequestSignatureTool.getSigningKey();
    }

    @BeforeEach
    public void beforeEach() {
        this.jwtTools = new JwtTools(new ObjectMapper(), Stream.of("PS256", "RS256").collect(Collectors.toSet()));
        this.stubSSA = new SsaDTO();
        stubSSA.setJti("ssa-id");
        stubSSA.setSoftwareId("ssa-id");
        stubSSA.setOrgId("org-id");
        stubSSA.setSoftwareJwksEndpoint("https://jwks");
        jwks = """
                  {
                  "keys": [
                    {
                      "kty": "RSA",
                      "e": "AQAB",
                      "use": "sig",
                      "kid": "OXOKm9U8c48H09zw46P8O54l4QA=",
                      "alg": "PS256",
                      "n": "pZpBF_gunYuXkolDNRuaCScWMVtKE4iyDYnPgQQcWd1_a0PB9JrdE96lJhSjIkojeo4Lo5hW0bU7AeQ1iOnW5g-K1WjHXpbl9Iu2iW8S7ybHYdPbQKhA6ybbyK7XFK6cazU2TTtieUMtHP3rVei6C4SY0blEcOgOLGuXroEJKZ_nqy-9rDUuQxxyIKA7HYeK-Ub_fh2EyGlS-WoK_BJBSCBCEpI5N-ZZjJXRY55JItBAd4kyhiN4Bm8b95ajut8kyfmcbKu_VFx2gfwE3DKrWJZ4SbtJ28ZghK918eu0nEV14I6nItFU_M1IY0v3IgIIegjA6rl8Pqa5HdbVdM6hdw"
                    }
                  ]
                }
                """;
        webClientMock = mock(WebClient.class);

        var properties = new NonRepudiationProperties();
        properties.setAlgorithm("PS256");
        properties.setIatClaimName("http://openbanking.org.uk/iat");
        properties.setIssClaimName("http://openbanking.org.uk/iss");
        properties.setTanClaimName("http://openbanking.org.uk/tan");
        properties.setSupportedCty(Stream.of("json", "application/json").toList());
        properties.setSupportedTyp("JOSE");
        properties.setSupportedTan("openbanking.org.uk");
        this.filter = new NonRepudiationFilter("/api/v*/pay.uk", this.jwtTools, webClientMock,
                properties, headerValidator, responseSigner, openBankingBaseUrl, openBankingCacheUrl);
    }

    @Test
    void validateJWS() {
        when(webClientMock.get()).thenReturn(requestHeadersUriMock);
        when(requestHeadersUriMock.uri(URI.create("https://jwks"))).thenReturn(requestHeadersMock);
        when(requestHeadersMock.accept(any(MediaType.class))).thenReturn(requestHeadersMock);
        when(requestHeadersMock.retrieve()).thenReturn(responseMock);
        when(responseMock.toEntity(String.class)).thenReturn(Mono.just(new ResponseEntity(jwks, HttpStatus.OK)));
        Assertions.assertThatNoException().isThrownBy(() -> this.filter.validateJWS(
                REQUEST_PAYLOAD,
                OpenBankingTokenFactory.makeToken(nonRepudiationPropertiesBuilder().build()),
                stubSSA));
    }

    @ParameterizedTest(name = "wrong token : {0}")
    @MethodSource("validateJWS_invalidTokensArguments")
    void validateJWS_invalidTokens(String testName, String token) {
        when(webClientMock.get()).thenReturn(requestHeadersUriMock);
        when(requestHeadersUriMock.uri(URI.create("https://jwks"))).thenReturn(requestHeadersMock);
        when(requestHeadersMock.accept(any(MediaType.class))).thenReturn(requestHeadersMock);
        when(requestHeadersMock.retrieve()).thenReturn(responseMock);
        when(responseMock.toEntity(String.class)).thenReturn(Mono.just(new ResponseEntity(jwks, HttpStatus.OK)));
        StepVerifier.create(this.filter.validateJWS(
                REQUEST_PAYLOAD,
                token,
                stubSSA))
                .expectErrorMatches(error -> error instanceof JOSEValidationException)
                .verify();
    }

    private static Stream<Arguments> validateJWS_invalidTokensArguments() throws JOSEException {
        return Stream.of(
                Arguments.of("invalid typ",
                        OpenBankingTokenFactory
                                .makeToken(nonRepudiationPropertiesBuilder().objecType(JOSEObjectType.JWT).build())),
                Arguments.of("invalid cty",
                        OpenBankingTokenFactory
                                .makeToken(nonRepudiationPropertiesBuilder().contentType("text/html").build())),
                Arguments.of("invalid iat",
                        OpenBankingTokenFactory
                                .makeToken(nonRepudiationPropertiesBuilder().iat(2317276134l).build())),
                Arguments.of("invalid iss",
                        OpenBankingTokenFactory
                                .makeToken(nonRepudiationPropertiesBuilder().iss("wrong-iss").build())),
                Arguments.of("invalid tan",
                        OpenBankingTokenFactory
                                .makeToken(nonRepudiationPropertiesBuilder().iss("wrong-tan").build())),
                Arguments.of("invalid crit, too many crits",
                        OpenBankingTokenFactory
                                .makeToken(nonRepudiationPropertiesBuilder().crit(
                                        Stream.of("http://openbanking.org.uk/iat", "http://openbanking.org.uk/tan",
                                                "http://openbanking.org.uk/iss", "cty").collect(Collectors.toSet()))
                                        .build())),
                Arguments.of("invalid crit : missing crit",
                        OpenBankingTokenFactory
                                .makeToken(nonRepudiationPropertiesBuilder().crit(
                                        Stream.of("http://openbanking.org.uk/iat",
                                                "http://openbanking.org.uk/iss").collect(Collectors.toSet()))
                                        .build())),
                Arguments.of("invalid kid : missing kid",
                        OpenBankingTokenFactory
                                .makeToken(nonRepudiationPropertiesBuilder().kid(null).build())),
                Arguments.of("invalid iat : not a long",
                        "eyJiNjQiOmZhbHNlLCJodHRwOlwvXC9vcGVuYmFua2luZy5vcmcudWtcL2lhdCI6Ijk5OTk5OTk5OTkiLCJodHRwOlwvXC9vcGVuYmFua2luZy5vcmcudWtcL3RhbiI6Im9wZW5iYW5raW5nLm9yZy51ayIsImNyaXQiOlsiaHR0cDpcL1wvb3BlbmJhbmtpbmcub3JnLnVrXC9pYXQiLCJodHRwOlwvXC9vcGVuYmFua2luZy5vcmcudWtcL3RhbiIsImh0dHA6XC9cL29wZW5iYW5raW5nLm9yZy51a1wvaXNzIl0sImtpZCI6Ik9YT0ttOVU4YzQ4SDA5enc0NlA4TzU0bDRRQT0iLCJjdHkiOiJhcHBsaWNhdGlvblwvanNvbiIsInR5cCI6IkpPU0UiLCJodHRwOlwvXC9vcGVuYmFua2luZy5vcmcudWtcL2lzcyI6Im9yZy1pZFwvc3NhLWlkIiwiYWxnIjoiUFMyNTYifQ..YIXHl95hR41ffYSKS17X9Bz7qiS6UEFULz7f8IbnID5EDwi1FJIWm0faZR-VFvxAfDIaj_5NoYWistQIjg0NDOCy8diyqr9rU4fYVKsM3KLuTWgnvMKFROT4ILvBdh-CTLZocIqIcCbhzycSiYuvLjtwhA_QtTFqVjvEuQU5if1WYeoyBqIkcyd27yVkMdNJUGzHNL-WYt8RMrjizkPJ13isFoolCMC4XlyRL71wCHzQgDyFPQ5GMBXfdCFvTCDK9O7HlE1FaN0vew_b0nTFbUKJGHlBSU_7K9ii3czZhNCh5S-DDICYslo4mhUZFx4HZrYytR5cZQGQ636Kqg7geQ"));
    }

    private static NonRepudiationTokenParameters.NonRepudiationTokenParametersBuilder nonRepudiationPropertiesBuilder() {
        return NonRepudiationTokenParameters.builder()
                .rsaKey(RSA_SIGNING_KEY)
                .payload(REQUEST_PAYLOAD)
                .kid("OXOKm9U8c48H09zw46P8O54l4QA=")
                .iat(1654268519l)
                .tan("openbanking.org.uk")
                .iss("org-id/ssa-id");
    }

}
