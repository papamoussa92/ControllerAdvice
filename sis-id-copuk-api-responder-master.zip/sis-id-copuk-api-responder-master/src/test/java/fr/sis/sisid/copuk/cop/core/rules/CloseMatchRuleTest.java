package fr.sis.sisid.copuk.cop.core.rules;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.stream.Stream;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import fr.sis.sisid.copuk.cop.core.CopTestTools;
import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.rules.processors.CloseMatchReplyProcessor;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.model.MatchingResult;
import reactor.test.StepVerifier;

class CloseMatchRuleTest {

    @Test
    void enrichContextTest() {
        var input = CopTestTools.getVerificationContext("name");
        var nameMatchingEnricher = CopTestTools.getNameMatchingResultEnricher("name",
                new MatchingResult(new BigDecimal("0.73"), MatchingDecision.CLOSE_MATCH));
        var rule = new CloseMatchRule(nameMatchingEnricher, new CloseMatchReplyProcessor());
        StepVerifier.create(rule.enrichContext(input))
                .expectNextMatches(ctx -> ctx.getNameMatchingResult().isPresent())
                .expectComplete().verify();
    }

    @Test
    void enrichContext_replyPresentTest() {
        var input = CopTestTools.getVerificationContext("name");
        input.setReply(CoreCopReply.builder().build());
        var nameMatchingEnricher = CopTestTools.getNameMatchingResultEnricher("name",
                new MatchingResult(new BigDecimal("0.73"), MatchingDecision.CLOSE_MATCH));
        var rule = new CloseMatchRule(nameMatchingEnricher, new CloseMatchReplyProcessor());
        StepVerifier.create(rule.enrichContext(input))
                .expectNextMatches(ctx -> ctx.getNameMatchingResult().isEmpty())
                .expectComplete().verify();
    }

    @ParameterizedTest
    @MethodSource("matchesTestArguments")
    void matchesTest(VerificationContext input, boolean expected) {
        var rule = new CloseMatchRule(
                CopTestTools.getNameMatchingResultEnricher("name",
                        new MatchingResult(new BigDecimal("0.9"), MatchingDecision.MATCH)),
                new CloseMatchReplyProcessor());
        Assertions.assertThat(rule.matches(input)).isEqualTo(expected);
    }

    private static Stream<Arguments> matchesTestArguments() {
        VerificationContext nominalCase = CopTestTools.getVerificationContext("name");
        nominalCase.setNameMatchingResult(
                new MatchingResult(new BigDecimal("0.73"), MatchingDecision.CLOSE_MATCH));
        var matchCase = CopTestTools.getVerificationContext("name");
        matchCase.setNameMatchingResult(new MatchingResult(new BigDecimal("0.9"), MatchingDecision.MATCH));
        var noMatchCase = CopTestTools.getVerificationContext("name");
        noMatchCase.setNameMatchingResult(
                new MatchingResult(new BigDecimal("0.3"), MatchingDecision.NO_MATCH));
        var noResultCase = CopTestTools.getVerificationContext("name");
        var replyPresentCase = CopTestTools.getVerificationContext("name");
        replyPresentCase
                .setNameMatchingResult(new MatchingResult(new BigDecimal("0.9"), MatchingDecision.MATCH));
        replyPresentCase.setReply(CoreCopReply.builder().build());
        return Stream.of(
                Arguments.of(nominalCase, true),
                Arguments.of(matchCase, false),
                Arguments.of(noMatchCase, false),
                Arguments.of(noResultCase, false),
                Arguments.of(replyPresentCase, false));
    }

    @Test
    void processTest() {
        var input = CopTestTools.getVerificationContext("name");
        input.setAccountInfo(CoreAccountInfo.builder().name("other name").build());

        var rule = new CloseMatchRule(
                CopTestTools.getNameMatchingResultEnricher("other name",
                        new MatchingResult(new BigDecimal("0.73"), MatchingDecision.CLOSE_MATCH)),
                new CloseMatchReplyProcessor());
        StepVerifier.create(rule.process(input))
                .assertNext(ctx -> {
                    Assertions.assertThat(ctx.getReply()).isPresent();
                    Assertions.assertThat(ctx.getReply().get().isMatched()).isFalse();
                    Assertions.assertThat(ctx.getReply().get().getName()).isEqualTo(Optional.of("other name"));
                })
                .expectComplete().verify();
    }

}
