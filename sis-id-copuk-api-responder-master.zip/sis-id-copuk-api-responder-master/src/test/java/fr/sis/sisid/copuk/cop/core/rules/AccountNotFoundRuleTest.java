package fr.sis.sisid.copuk.cop.core.rules;

import fr.sis.sisid.copuk.cop.core.CopTestTools;
import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.rules.processors.AccountInfoEnricher;
import fr.sis.sisid.copuk.cop.core.stubs.AccountInfoProviderStub;
import fr.sis.sisid.copuk.copapi.model.ReasonCodes;
import fr.sis.sisid.copuk.model.AccountInfoErrorCode;
import fr.sis.sisid.copuk.model.AccountInfoRejection;
import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import reactor.test.StepVerifier;

import java.util.stream.Stream;

@Slf4j
class AccountNotFoundRuleTest {

    private VerificationContext emptyContext;

    @BeforeEach
    public void setup() {
        this.emptyContext = CopTestTools.getVerificationContext(CoreCopRequest.builder().name("test").build());
    }

    @ParameterizedTest
    @MethodSource("testMatchesArguments")
    void testMatches(VerificationContext context, boolean shouldMatch) {
        var accountNotFoundRule = new AccountNotFoundRule(null);
        Assertions.assertThat(accountNotFoundRule.matches(context)).isEqualTo(shouldMatch);
    }

    private static Stream<Arguments> testMatchesArguments() {
        var copRequest = CoreCopRequest.builder().name("test").build();

        // has error, has the correct error code
        var context = CopTestTools.getVerificationContext(copRequest);
        context.setAccountInfoError(
                AccountInfoRejection.builder()
                        .code(AccountInfoErrorCode.ACCOUNT_NOT_FOUND)
                        .reason("BUS01: Account data not found")
                        .build());
        // has error, but not the correct error code
        var contextWrongCode = CopTestTools.getVerificationContext(copRequest);
        contextWrongCode.setAccountInfoError(
                AccountInfoRejection.builder()
                        .code(AccountInfoErrorCode.UNSUPPORTED_ACCOUNT_TYPE)
                        .reason("ERR17: This account type is not supported")
                        .build());
        // has no error
        var contextNoError = CopTestTools.getVerificationContext(copRequest);
        // has error, has the correct error code, has a reply
        var contextReply = CopTestTools.getVerificationContext(copRequest);
        contextReply.setAccountInfoError(
                AccountInfoRejection.builder()
                        .code(AccountInfoErrorCode.ACCOUNT_NOT_FOUND)
                        .reason("BUS01: Account data not found")
                        .build());
        contextReply.setReply(CoreCopReply.builder().matched(false).build());

        return Stream.of(
                Arguments.of(context, true),
                Arguments.of(contextWrongCode, false),
                Arguments.of(contextNoError, false),
                Arguments.of(contextReply, false));
    }

    @Test
    void testEnrichContext() {
        var accountInfo = AccountInfoRejection.builder()
                .code(AccountInfoErrorCode.ACCOUNT_NOT_FOUND).reason("BUS01: Account data not found")
                .build();
        var accountInfoEnricher = new AccountInfoEnricher(
                new AccountInfoProviderStub(accountInfo));
        var rule = new AccountNotFoundRule(accountInfoEnricher);

        StepVerifier.create(rule.enrichContext(this.emptyContext))
                .assertNext(ctx -> {
                    Assertions.assertThat(ctx.getAccountInfoError()).isPresent();
                    Assertions.assertThat(ctx.getAccountInfoError()).contains(accountInfo);
                })
                .expectComplete()
                .verify();
    }

    @Test
    void testEnrichContext_replyPresent() {
        this.emptyContext.setReply(CoreCopReply.builder().matched(false).build());
        var rule = new AccountNotFoundRule(null);
        StepVerifier.create(rule.enrichContext(this.emptyContext))
                .expectNext(this.emptyContext)
                .expectComplete().verify();
    }

    @Test
    void testProcess() {
        var rule = new AccountNotFoundRule(null);
        StepVerifier.create(rule.process(this.emptyContext))
                .assertNext(ctx -> {
                    Assertions.assertThat(ctx.getReply()).isPresent();
                    var reply = ctx.getReply().get();
                    Assertions.assertThat(reply.isMatched()).isFalse();
                    Assertions.assertThat(reply.getName()).isEmpty();
                    Assertions.assertThat(reply.getReasonCode()).contains(ReasonCodes.AC01);
                }).expectComplete().verify();
    }

}
