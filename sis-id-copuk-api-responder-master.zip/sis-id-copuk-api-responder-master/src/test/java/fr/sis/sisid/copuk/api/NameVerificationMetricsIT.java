package fr.sis.sisid.copuk.api;

import java.time.Duration;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockserver.client.MockServerClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

import com.fasterxml.jackson.core.JsonProcessingException;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import fr.sis.sisid.copuk.api.NameVerificationMetricsIT.BrokenServiceConfiguration.BreakableService;
import fr.sis.sisid.copuk.cop.api.NameVerificationService;
import fr.sis.sisid.copuk.cop.core.NameVerificationServiceImpl;
import fr.sis.sisid.copuk.cop.core.rules.RulesList;
import fr.sis.sisid.copuk.mockserver.MockUtils;
import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import fr.sis.sisid.copuk.tools.NameVerificationRequestTools;
import fr.sis.sisid.copuk.tools.TokenTool;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Metrics;
import io.micrometer.prometheus.PrometheusMeterRegistry;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = "spring.profiles.active=breakable-service")
class NameVerificationMetricsIT extends SpringTestConfiguration {

    @Autowired
    private TokenTool tokenTool;

    @LocalServerPort
    private int serverPort;

    @Value("${spring.security.oauth2.client.registration.copuk-auth.client-id}")
    private String clientId = "test-client";

    @Value("${app.organisation-id}")
    private String orgId;

    @Autowired
    @Qualifier("registration-mockserver-client")
    MockServerClient registrationMockServer;

    @Autowired
    @Qualifier("bnp-mockserver-client")
    MockServerClient payeeInfoMockClient;

    @BeforeEach
    void setup() {
        MockUtils.mockSsa(registrationMockServer, clientId);
        MockUtils.mockTC_UK_01(payeeInfoMockClient, "toto", "123456", "74859698", "Organisation");
        Metrics.globalRegistry.clear();
        metricsRegistry.clear();
        breakableService.setBroken(false);
        breakableService.setSlow(false);
    }

    @Autowired
    private BreakableService breakableService;

    @Autowired
    private PrometheusMeterRegistry metricsRegistry;

    @Test
    void copReplyCounterIncrements() throws JsonProcessingException, InterruptedException {
        for (int i = 0; i < 7; i++) {
            NameVerificationRequestTools.performNameVerification("toto", orgId, tokenTool, serverPort);
        }

        for (int i = 0; i < 2; i++) {
            NameVerificationRequestTools.performNameVerification("unrelated name", orgId, tokenTool, serverPort);
        }

        breakableService.setBroken(true);
        for (int i = 0; i < 5; i++) {
            NameVerificationRequestTools.performNameVerification("toto", orgId, tokenTool, serverPort);
        }

        Counter matchesCopReplyCounter = metricsRegistry
                .get("fr.sis.sisid.copuk.copreply")
                .tag("matched", "true")
                .counter();
        Assertions.assertThat(matchesCopReplyCounter.count()).isEqualTo(7d);
        Counter nomatchCopReplyCounter = metricsRegistry
                .get("fr.sis.sisid.copuk.copreply")
                .tag("matched", "false")
                .counter();
        Assertions.assertThat(nomatchCopReplyCounter.count()).isEqualTo(2d);

        Counter errorsCopReplyCounter = metricsRegistry
                .get("fr.sis.sisid.copuk.copreply")
                .tag("error", "true")
                .counter();
        Assertions.assertThat(errorsCopReplyCounter.count()).isEqualTo(5d);
    }

    @Test
    void SlaRequestCounterIncrements() throws InterruptedException, ExecutionException {
        NameVerificationRequestTools.performNameVerification("toto", orgId, tokenTool, serverPort);
        NameVerificationRequestTools.performNameVerification("toto", orgId, tokenTool, serverPort);
        breakableService.setSlow(true);
        NameVerificationRequestTools.performNameVerification("toto", orgId, tokenTool, serverPort);

        ScheduledExecutorService executorService = Executors.newScheduledThreadPool(1);
        var notAboveSLACounterFuture = executorService.schedule(() -> metricsRegistry
                .get("fr.sis.sisid.copuk.copreply.above_sla")
                .tag("above_sla", "false")
                .counter(),
                100, TimeUnit.MILLISECONDS);

        Counter notAboveSLACounter = notAboveSLACounterFuture.get();
        Assertions.assertThat(notAboveSLACounter.count()).isEqualTo(2d);

        var aboveSLACouterFuture = executorService.schedule(() -> metricsRegistry
                .get("fr.sis.sisid.copuk.copreply.above_sla")
                .tag("above_sla", "true")
                .counter(), 100, TimeUnit.MILLISECONDS);

        Counter aboveSLACounter = aboveSLACouterFuture.get();
        Assertions.assertThat(aboveSLACounter.count()).isEqualTo(1d);
    }

    @TestConfiguration
    @Profile("breakable-service")
    public static class BrokenServiceConfiguration {

        @Bean
        @Primary
        public NameVerificationService auditService(RulesList rulesList) {
            return new BreakableService(rulesList);
        }

        public static class BreakableService extends NameVerificationServiceImpl {

            public BreakableService(RulesList rulesList) {
                super(rulesList);
            }

            @Setter
            private boolean isBroken = false;

            @Setter
            private boolean isSlow = false;

            @Override
            public Mono<CoreCopReply> getCop(CoreCopRequest request) {
                if (isBroken) {
                    return Mono.error(new RuntimeException("test related error"));
                }
                if (isSlow) {
                    // delay by 2s, sla is 1.5s
                    return Mono.delay(Duration.ofMillis(2000)).flatMap(s -> super.getCop(request));
                }
                return super.getCop(request);

            }

        }

    }

}
