package fr.sis.sisid.copuk.cop.core.rules.processors;

import fr.sis.sisid.copuk.cop.core.CopTestTools;
import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.rules.VerificationRuleException;
import fr.sis.sisid.copuk.copapi.model.ReasonCodes;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import reactor.test.StepVerifier;

import java.util.Optional;

class CloseMatchReplyProcessorTest {

    @Test
    void enrichContextTest() {
        VerificationContext input = CopTestTools.getVerificationContext(
                CoreCopRequest.builder().build());
        input.setAccountInfo(CoreAccountInfo.builder().name("test name").build());
        var closeMatchReplyProcessor = new CloseMatchReplyProcessor();
        StepVerifier.create(closeMatchReplyProcessor.enrichContext(input))
                .assertNext(ctx -> {
                    Optional<CoreCopReply> reply = ctx.getReply();
                    Assertions.assertThat(reply).isPresent();
                    Assertions.assertThat(reply.get().isMatched()).isFalse();
                    Assertions.assertThat(reply.get().getName()).isEqualTo(Optional.of("test name"));
                    Assertions.assertThat(reply.get().getReasonCode()).isEqualTo(Optional.of(ReasonCodes.MBAM));
                })
                .expectComplete()
                .verify();
    }

    @Test
    void enrichContext_noAccountInfoTest() {
        VerificationContext input = CopTestTools.getVerificationContext(
                CoreCopRequest.builder().build());
        var closeMatchReplyProcessor = new CloseMatchReplyProcessor();
        StepVerifier.create(closeMatchReplyProcessor.enrichContext(input))
                .expectError(VerificationRuleException.class).verify();
    }
}
