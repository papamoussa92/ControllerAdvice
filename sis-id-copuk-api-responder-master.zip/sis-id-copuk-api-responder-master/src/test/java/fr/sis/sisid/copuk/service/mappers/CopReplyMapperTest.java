package fr.sis.sisid.copuk.service.mappers;

import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import fr.sis.sisid.copuk.copapi.model.InlineResponse200;
import fr.sis.sisid.copuk.copapi.model.InlineResponse200Data;
import fr.sis.sisid.copuk.copapi.model.InlineResponse200DataVerificationReport;
import fr.sis.sisid.copuk.mappers.CopReplyMapper;
import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.service.mapper.CopReplyMapperImpl;

class CopReplyMapperTest {

    private CopReplyMapper mapper;

    @BeforeEach
    public void init() {
        mapper = new CopReplyMapperImpl();
    }

    @Test
    void testToDTO() {
        CoreCopReply input = CoreCopReply.builder()
                .matched(true)
                .name(Optional.of("ACME Inc"))
                .build();
        InlineResponse200 expected = new InlineResponse200()
                .data(new InlineResponse200Data()
                        .verificationReport(new InlineResponse200DataVerificationReport()
                                .matched(true)
                                .name("ACME Inc")));
        Assertions.assertThat(mapper.toDTO(input)).isEqualTo(expected);
    }
}
