package fr.sis.sisid.copuk.cop.core.rules;

import fr.sis.sisid.copuk.cop.core.CopTestTools;
import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.rules.processors.NameMatchesReplyProcessor;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.model.MatchingResult;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import reactor.test.StepVerifier;

import java.math.BigDecimal;
import java.util.stream.Stream;

class ExternalNameMatchesRuleTest {

    @Test
    void enrichContextTest() {
        var input = CopTestTools.getVerificationContext("name");
        var nameMatchingEnricher = CopTestTools.getNameMatchingResultEnricher("name",
                new MatchingResult(new BigDecimal("0.9"), MatchingDecision.MATCH));
        var rule = new ExternalNameMatchesRule(nameMatchingEnricher, new NameMatchesReplyProcessor());
        StepVerifier.create(rule.enrichContext(input))
                .expectNextMatches(ctx -> ctx.getNameMatchingResult().isPresent())
                .expectComplete().verify();
    }

    @Test
    void enrichContext_replyPresentTest() {
        var input = CopTestTools.getVerificationContext("name");
        input.setReply(CoreCopReply.builder().build());
        var nameMatchingEnricher = CopTestTools.getNameMatchingResultEnricher("name",
                new MatchingResult(new BigDecimal("0.9"), MatchingDecision.MATCH));
        var rule = new ExternalNameMatchesRule(nameMatchingEnricher, new NameMatchesReplyProcessor());
        StepVerifier.create(rule.enrichContext(input))
                .expectNextMatches(ctx -> ctx.getNameMatchingResult().isEmpty())
                .expectComplete().verify();
    }

    @ParameterizedTest
    @MethodSource("matchesTestArguments")
    void matchesTest(VerificationContext input, boolean expected) {
        var rule = new ExternalNameMatchesRule(
                CopTestTools.getNameMatchingResultEnricher("name",
                        new MatchingResult(new BigDecimal("0.9"), MatchingDecision.MATCH)),
                new NameMatchesReplyProcessor());
        Assertions.assertThat(rule.matches(input)).isEqualTo(expected);
    }

    private static Stream<Arguments> matchesTestArguments() {
        VerificationContext nominalCase = CopTestTools.getVerificationContext("name");
        nominalCase
                .setNameMatchingResult(new MatchingResult(new BigDecimal("0.9"), MatchingDecision.MATCH));
        var closeMatchCase = CopTestTools.getVerificationContext("name");
        closeMatchCase.setNameMatchingResult(
                new MatchingResult(new BigDecimal("0.6"), MatchingDecision.CLOSE_MATCH));
        var noMatchCase = CopTestTools.getVerificationContext("name");
        noMatchCase.setNameMatchingResult(
                new MatchingResult(new BigDecimal("0.1"), MatchingDecision.NO_MATCH));
        var noResultCase = CopTestTools.getVerificationContext("name");
        var replyPresentCase = CopTestTools.getVerificationContext("name");
        replyPresentCase
                .setNameMatchingResult(new MatchingResult(new BigDecimal("0.9"), MatchingDecision.MATCH));
        replyPresentCase.setReply(CoreCopReply.builder().build());
        return Stream.of(
                Arguments.of(nominalCase, true),
                Arguments.of(closeMatchCase, false),
                Arguments.of(noMatchCase, false),
                Arguments.of(noResultCase, false),
                Arguments.of(replyPresentCase, false));
    }

    @Test
    void processTest() {
        var input = CopTestTools.getVerificationContext("name");
        input.setAccountInfo(CoreAccountInfo.builder().name("other name").build());

        var rule = new ExternalNameMatchesRule(
                CopTestTools.getNameMatchingResultEnricher("name",
                        new MatchingResult(new BigDecimal("0.9"), MatchingDecision.MATCH)),
                new NameMatchesReplyProcessor());
        StepVerifier.create(rule.process(input))
                .assertNext(ctx -> {
                    Assertions.assertThat(ctx.getReply()).isPresent();
                    Assertions.assertThat(ctx.getReply().get().isMatched()).isTrue();
                    Assertions.assertThat(ctx.getReply().get().getName()).isEmpty();
                })
                .expectComplete().verify();
    }

}
