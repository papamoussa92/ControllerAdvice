package fr.sis.sisid.copuk.bdd;

import org.assertj.core.api.Assertions;
import org.mockserver.client.MockServerClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import fr.sis.sisid.copuk.ext.bnp.api.PayeeInformationClient;
import fr.sis.sisid.copuk.ext.bnp.model.CopReply;
import fr.sis.sisid.copuk.ext.bnp.model.CopRequest;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
public class BnppApiRespondsSteps {

    @Autowired
    PayeeInformationClient payeeInfoClient;

    private Mono<ResponseEntity<CopReply>> apiResponse;

    @Autowired
    @Qualifier("bnp-mockserver-client")
    MockServerClient payeeInfoMockClient;

    @Given("the BNPP Account API runs")
    public void the_bnpp_account_api_runs() {
        Assertions.assertThat(this.payeeInfoClient).isNotNull();
    }

    @When("I send a POST request to \\{bnpp_account_endpoint}\\/anything")
    public void i_send_a_post_request_to_anything() {
        var request = new CopRequest();
        apiResponse = this.payeeInfoClient.providePayeeInformation(request);
    }

    @Then("http response code should be {int}")
    public void http_response_code_should_be(Integer statusCode) {
        try {
            this.apiResponse.block();
        } catch (WebClientResponseException err) {
            Assertions.assertThat(err.getRawStatusCode()).isEqualTo(statusCode);
            return;
        }
    }

}
