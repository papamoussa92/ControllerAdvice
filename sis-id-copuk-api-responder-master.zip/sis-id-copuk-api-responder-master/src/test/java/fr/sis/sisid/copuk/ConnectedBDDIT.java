package fr.sis.sisid.copuk;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.jdbc.Sql;

import lombok.extern.slf4j.Slf4j;

@Slf4j
class ConnectedBDDIT extends SpringTestConfiguration {

    @Test
    void testBD() {
        log.info("###########################################");
        log.info(dbContainer.getDatabaseName());
        log.info(dbContainer.getDriverClassName());
        log.info(dbContainer.getLogs());

        log.info("###########################################");
        Assertions.assertThat(dbContainer.isRunning()).isTrue();
    }

    @Test
    @Sql(scripts = "classpath:data/data.sql")
    void testPostgreSQLModule() throws SQLException {
        try (Connection connection = DriverManager
                .getConnection(dbContainer.getJdbcUrl(), dbContainer.getUsername(), dbContainer.getPassword());
                PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM audit")) {
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                log.info("##################### Start display data timestamps from database ###################");
                while (resultSet.next()) {
                    log.info(resultSet.getString("id"));
                    log.info(resultSet.getString("date_audit"));
                    log.info(resultSet.getString("account_currency"));
                    Assertions.assertThat(resultSet.getString("correlation_id")).isNotNull();
                }
                log.info("##################### End display data timestamps ###################");
            }
        }
    }
}
