package fr.sis.sisid.copuk.cop.core.rules;

import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import fr.sis.sisid.copuk.cop.core.CopTestTools;
import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.rules.processors.AccountInfoEnricher;
import fr.sis.sisid.copuk.cop.core.rules.processors.NameMatchesReplyProcessor;
import fr.sis.sisid.copuk.cop.core.stubs.AccountInfoProviderStub;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import lombok.extern.slf4j.Slf4j;
import reactor.test.StepVerifier;

@Slf4j
class NameMatchesRuleTest {

    static Long now = 1231564448L;

    @ParameterizedTest
    @MethodSource("testMatchesArguments")
    void testMatches(VerificationContext ctx, boolean shouldMatch) {
        var nameMatchesRule = new NameMatchesRule(null, null);
        Assertions.assertEquals(shouldMatch, nameMatchesRule.matches(ctx));
    }

    private static Stream<Arguments> testMatchesArguments() {
        var copRequest = CoreCopRequest.builder().name("test name").build();
        var emptyContext = CopTestTools.getVerificationContext(copRequest);
        var replyAlreadySet = CopTestTools.getVerificationContext(copRequest);
        replyAlreadySet.setReply(CoreCopReply.builder().name(Optional.empty()).matched(true).build());
        var requestNameNull = CopTestTools.getVerificationContext(CoreCopRequest.builder().build());
        var namesDoNotMatch = CopTestTools.getVerificationContext(copRequest);
        namesDoNotMatch.setAccountInfo(CoreAccountInfo.builder().name("anoter name").build());
        var namesMatch = CopTestTools.getVerificationContext(copRequest);
        namesMatch.setAccountInfo(CoreAccountInfo.builder().name("test name").build());
        return Stream.of(
                Arguments.of(emptyContext, false),
                Arguments.of(replyAlreadySet, false),
                Arguments.of(requestNameNull, false),
                Arguments.of(namesDoNotMatch, false),
                Arguments.of(namesMatch, true));
    }

    @ParameterizedTest
    @MethodSource("testEnrichContextArguments")
    void testEnrichContext(VerificationContext ctx, VerificationContext expectedContext,
            CoreAccountInfo accountInfoToStub) {

        var nameMatchesRule = new NameMatchesRule(
                new AccountInfoEnricher(new AccountInfoProviderStub(accountInfoToStub)) {
                    @Override
                    protected Long currentTime() {
                        return now;
                    }
                },
                new NameMatchesReplyProcessor());
        StepVerifier.create(nameMatchesRule.enrichContext(ctx))
                .expectNext(expectedContext)
                .expectComplete()
                .verify();
    }

    private static Stream<Arguments> testEnrichContextArguments() {
        var accountInfo = CoreAccountInfo.builder().name("test name").currency("GBP").build();
        var copRequest = CoreCopRequest.builder().name("test name").build();
        Long startTime = System.currentTimeMillis();
        String xFapiInteractionId = UUID.randomUUID().toString();
        var emptyContext = new VerificationContext("org123", xFapiInteractionId, startTime, copRequest);
        var emptyContextWithAccountInfo = new VerificationContext("org123", xFapiInteractionId, startTime,
                copRequest);
        emptyContextWithAccountInfo.setAccountInfo(accountInfo);
        emptyContextWithAccountInfo.setCibApiStartTime(now);
        emptyContextWithAccountInfo.setCibApiEndTime(now);
        var replyAlreadySet = CopTestTools.getVerificationContext(copRequest);
        replyAlreadySet.setReply(CoreCopReply.builder().name(Optional.of("test name")).build());

        return Stream.of(
                Arguments.of(emptyContext, emptyContextWithAccountInfo, accountInfo),
                Arguments.of(replyAlreadySet, replyAlreadySet, null));
    }

    @ParameterizedTest
    @MethodSource("testProcessArguments")
    void testProcess(VerificationContext ctx, VerificationContext expectedCtx) {
        var nameMatchesRule = new NameMatchesRule(null, new NameMatchesReplyProcessor());
        StepVerifier.create(nameMatchesRule.process(ctx))
                .expectNext(expectedCtx)
                .expectComplete()
                .verify();
    }

    private static Stream<Arguments> testProcessArguments() {
        Long startTime = System.currentTimeMillis();
        String xFapiInteractionId = UUID.randomUUID().toString();
        var contextWAccountInfo = new VerificationContext("org123", xFapiInteractionId, startTime,
                CoreCopRequest.builder().name("test name").build());
        contextWAccountInfo.setAccountInfo(CoreAccountInfo.builder().name("test name").build());

        var contextWithReply = new VerificationContext("org123", xFapiInteractionId, startTime,
                CoreCopRequest.builder().name("test name").build());
        contextWithReply.setAccountInfo(CoreAccountInfo.builder().name("test name").build());
        contextWithReply
                .setReply(CoreCopReply.builder().matched(true).build());

        return Stream.of(
                Arguments.of(contextWAccountInfo, contextWithReply));
    }
}
