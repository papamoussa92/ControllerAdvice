package fr.sis.sisid.copuk.cop.core.rules;

import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.rules.processors.AccountInfoEnricher;
import fr.sis.sisid.copuk.cop.core.stubs.AccountInfoProviderStub;
import fr.sis.sisid.copuk.copapi.model.ReasonCodes;
import fr.sis.sisid.copuk.model.AccountInfoErrorCode;
import fr.sis.sisid.copuk.model.AccountInfoRejection;
import fr.sis.sisid.copuk.model.AccountType;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import reactor.test.StepVerifier;

class AccountSwitchedRuleTest {

    AccountInfoRejection accountInfoError = AccountInfoRejection.builder()
            .code(AccountInfoErrorCode.ACCOUNT_OPT_OUT)
            .reason("ERR91: switched")
            .build();

    VerificationContext verificationContext = new VerificationContext(
            "org1", UUID.randomUUID().toString(), System.currentTimeMillis(),
            CoreCopRequest.builder()
                    .name("some account")
                    .sortCode("123456")
                    .accountNumber("0123456789")
                    .accountType(AccountType.BUSINESS)
                    .build());

    @ParameterizedTest
    @MethodSource("testMatchesArguments")
    void testMatches(VerificationContext context, boolean shouldMatch) {
        var rule = new AccountSwitchedRule(null);
        Assertions.assertThat(rule.matches(context)).isEqualTo(shouldMatch);
    }

    private static Stream<Arguments> testMatchesArguments() {
        var copRequest = CoreCopRequest.builder()
                .name("some account")
                .sortCode("123456")
                .accountNumber("0123456789")
                .accountType(AccountType.BUSINESS)
                .build();

        var contextSwitched = new VerificationContext("org1", UUID.randomUUID().toString(),
                System.currentTimeMillis(), copRequest);
        contextSwitched.setAccountInfoError(AccountInfoRejection.builder()
                .code(AccountInfoErrorCode.ACCOUNT_SWITCHED)
                .reason("ERR91: acconut switched")
                .build());

        var contextUnknownError = new VerificationContext("org1", UUID.randomUUID().toString(),
                System.currentTimeMillis(), copRequest);
        contextUnknownError.setAccountInfoError(
                AccountInfoRejection.builder()
                        .code(AccountInfoErrorCode.UNKNOWN_ERROR_CODE)
                        .reason("a random error")
                        .build());

        var contextNoError = new VerificationContext("org1", UUID.randomUUID().toString(),
                System.currentTimeMillis(), copRequest);
        contextNoError.setAccountInfo(
                CoreAccountInfo.builder()
                        .name("some account")
                        .build());

        var contextWithReply = new VerificationContext("org1", UUID.randomUUID().toString(),
                System.currentTimeMillis(), copRequest);
        contextWithReply.setAccountInfoError(
                AccountInfoRejection.builder()
                        .code(AccountInfoErrorCode.ACCOUNT_SWITCHED)
                        .reason("ERR91: account switched")
                        .build());
        contextWithReply.setReply(
                CoreCopReply.builder()
                        .matched(false)
                        .reasonCode(Optional.of(ReasonCodes.ACNS))
                        .build());
        return Stream.of(
                Arguments.of(contextSwitched, true),
                Arguments.of(contextUnknownError, false),
                Arguments.of(contextNoError, false),
                Arguments.of(contextWithReply, false));
    }

    @Test
    void testEnrichContext() {
        var accEnricher = new AccountInfoEnricher(
                new AccountInfoProviderStub(accountInfoError));
        var rule = new AccountSwitchedRule(accEnricher);
        StepVerifier.create(rule.enrichContext(verificationContext))
                .assertNext(ctx -> {
                    Assertions.assertThat(ctx.getAccountInfoError()).contains(accountInfoError);
                })
                .expectComplete()
                .verify();
    }

    @Test
    void testProcess() {
        var accEnricher = new AccountInfoEnricher(
                new AccountInfoProviderStub(accountInfoError));
        var rule = new AccountSwitchedRule(accEnricher);

        StepVerifier.create(rule.process(verificationContext))
                .assertNext(ctx -> {
                    Assertions.assertThat(ctx.getReply()).isPresent();
                    var reply = ctx.getReply().get();
                    Assertions.assertThat(reply.getName()).isEmpty();
                    Assertions.assertThat(reply.isMatched()).isFalse();
                    Assertions.assertThat(reply.getReasonCode()).contains(ReasonCodes.CASS);
                })
                .expectComplete()
                .verify();
    }

}
