package fr.sis.sisid.copuk.entities;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@Slf4j
class CountryIT extends SpringTestConfiguration {

    @Autowired
    private DictionaryRepository countryRepository;

    @Test
    void insertTest(){
        DictionaryEntity country = new DictionaryEntity();
        country.setCountry("Aus");
        Set<FormEntity> formEntityList = new HashSet<>();
        FormEntity formEntity = new FormEntity();
        formEntity.setName("Australia");
        formEntity.setSpellings(List.of("AU", "AUS"));
        formEntity.setDictionary(country);
        formEntityList.add(formEntity);
        country.setForms(formEntityList);
        var countryResponse =  countryRepository.save(country);
        countryResponse.getForms().stream().forEach( formEntity1 -> {
            assertTrue(formEntity1.getSpellings().contains("AU"));
        });

        countryRepository.findAll().stream().forEach(countryEntity -> {
            assertFalse(countryEntity.getForms().isEmpty());
        });

    };
}
