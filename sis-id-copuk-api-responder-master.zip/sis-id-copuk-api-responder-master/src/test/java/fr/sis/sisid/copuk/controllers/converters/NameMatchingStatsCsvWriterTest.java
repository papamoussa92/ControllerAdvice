package fr.sis.sisid.copuk.controllers.converters;

import fr.sis.sisid.copuk.dto.NameMatchingStatsDTO;
import org.junit.jupiter.api.Test;
import org.mockito.internal.matchers.Any;
import org.springframework.core.ResolvableType;
import org.springframework.http.MediaType;
import org.springframework.mock.http.server.reactive.MockServerHttpResponse;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class NameMatchingStatsCsvWriterTest {
    MediaType csvMediaType = MediaType.valueOf("text/csv");

    @Test
    void testCanWrite() {
        NameMatchingStatsCsvWriter csvWriter = new NameMatchingStatsCsvWriter();

        assertFalse(csvWriter.canWrite(ResolvableType.forClass(Any.class), MediaType.APPLICATION_JSON));
        assertFalse(csvWriter.canWrite(ResolvableType.forClass(NameMatchingStatsDTO.class), MediaType.APPLICATION_JSON));
        assertFalse(csvWriter.canWrite(ResolvableType.forClass(Any.class), csvMediaType));
        assertTrue(csvWriter.canWrite(ResolvableType.forClass(NameMatchingStatsDTO.class), csvMediaType));
    }


    @Test
    void testCsvWriting() {
        NameMatchingStatsCsvWriter csvWriter = new NameMatchingStatsCsvWriter();

        NameMatchingStatsDTO nameMatchingStatsDTO = new NameMatchingStatsDTO();
        nameMatchingStatsDTO.setNbMatched(4L);
        nameMatchingStatsDTO.setNbBusinessRequests(6L);
        var o = Mono.just(nameMatchingStatsDTO);
        MockServerHttpResponse message = new MockServerHttpResponse();
        var result = csvWriter.write(o, ResolvableType.forClass(NameMatchingStatsDTO.class), csvMediaType, message, null);


        StepVerifier.create(result)
                        .expectNext()
                .verifyComplete();

        message.setComplete();
        StepVerifier.create(message.getBodyAsString())
                .expectNext("""
                        "Registration ID","Requests with a personal account marker","Requests with a business account marker",1,ANNM,MBAM,BANM,PANM,BAMM,AC01,IVCR,ACNS,OPTO,CASS,SNCS,"Responses outside of response time SLA"
                        ,,6,4,,,,,,,,,,,,
                        """)
                .verifyComplete();

    }

}