package fr.sis.sisid.copuk;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.testcontainers.containers.PostgreSQLContainer;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;

class CopukResponderApplicationIT {

    private static PostgreSQLContainer<?> container;

    @BeforeAll
    public static void dbSetup() {
        container = new PostgreSQLContainer<>("postgres:14");
        container.start();
    }

    @AfterAll
    public static void dbCleanup() {
        container.stop();
    }

    @Test
    void applicationStarts() {

        int port = 8000 + (int) (Math.random() * 1000);
        CopukResponderApplication.main(new String[] {
                "--server.port=" + port,
                "--spring.datasource.url=" + container.getJdbcUrl(),
                "--spring.datasource.username=" + container.getUsername(),
                "--spring.datasource.password=" + container.getPassword()
        });
        RestAssured.given().get("http://localhost:" + port + "/management/health")
                .then().assertThat()
                .statusCode(200)
                .contentType(ContentType.JSON)
                .body("status", Matchers.equalTo("UP"));
    }
}
