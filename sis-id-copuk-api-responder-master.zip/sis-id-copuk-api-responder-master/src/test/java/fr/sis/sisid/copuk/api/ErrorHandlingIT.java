package fr.sis.sisid.copuk.api;

import java.io.IOException;
import java.util.ArrayList;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockserver.client.MockServerClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;

import com.fasterxml.jackson.core.JsonProcessingException;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import fr.sis.sisid.copuk.cop.spi.AccountInfoProvider;
import fr.sis.sisid.copuk.copapi.model.OBErrorResponse1;
import fr.sis.sisid.copuk.mockserver.MockUtils;
import fr.sis.sisid.copuk.model.AccountInfoReply;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import fr.sis.sisid.copuk.tools.NameVerificationRequestTools;
import fr.sis.sisid.copuk.tools.TokenTool;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = "spring.profiles.active=broken-service")
class ErrorHandlingIT extends SpringTestConfiguration {

    @Autowired
    private TokenTool tokenTool;

    @LocalServerPort
    private int serverPort;

    @Value("${spring.security.oauth2.client.registration.copuk-auth.client-id}")
    private String clientId = "test-client";

    @Value("${app.organisation-id}")
    private String orgId;

    @Autowired
    @Qualifier("registration-mockserver-client")
    MockServerClient registrationMockServer;

    @Autowired
    @Qualifier("bnp-mockserver-client")
    MockServerClient payeeInfoMockClient;

    @BeforeEach
    void setup() {
        MockUtils.mockSsa(registrationMockServer, clientId);
        MockUtils.mockTC_UK_01(payeeInfoMockClient, "toto", "123456", "12345678", "Organisation");
    }

    @Test
    void uncheckedErrorInAService() throws JsonProcessingException {
        var response = NameVerificationRequestTools.performNameVerification("toto inc", orgId, tokenTool, serverPort);
        log.info(response.getBody().asPrettyString());
        Assertions.assertThat(response.getStatusCode()).isEqualTo(500);
        var errorResponse = response.getBody().as(OBErrorResponse1.class);
        Assertions.assertThat(errorResponse.getCode()).isEqualTo("500");
        Assertions.assertThat(errorResponse.getErrors()).isNotEmpty();
        var error = new ArrayList<>(errorResponse.getErrors()).get(0);
        Assertions.assertThat(error.getErrorCode()).isEqualTo("UK.OBIE.UnexpectedError");

    }

    @TestConfiguration
    @Profile("broken-service")
    public static class BrokenServiceConfiguration {

        @Bean
        @Primary
        public AccountInfoProvider payeeInformationService() {
            return new AccountInfoProvider() {

                @Override
                public Mono<AccountInfoReply> getAccountInfo(CoreCopRequest copRequest) {
                    // throw on purpose
                    return Mono.error(new IOException("An unexpected arror occured"));
                }

            };
        }
    }

}
