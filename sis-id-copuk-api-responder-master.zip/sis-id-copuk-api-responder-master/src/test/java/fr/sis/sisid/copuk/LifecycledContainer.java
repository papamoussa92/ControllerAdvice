package fr.sis.sisid.copuk;

import org.testcontainers.containers.GenericContainer;

/**
 * Wrapper around testcontainers to manage their creation start and configuration in parallel
 *
 * @param <T> Type of the testcontainer to manage lifecycle for
 */
public interface LifecycledContainer<T extends GenericContainer> {

    /**
     * Instantiation for the underlying testcontainer
     * @return the testcontainer
     */
    T create();

    /**
     * Delegate to testcontainer start
     */
    default void start() {
        getContainer().start();
    }

    /**
     * Method to run custom configuration once the testcontainer is started.
     */
    void postConfigure();

    /**
     * Access method to the testcontainer instantiated in the create method
     * @return the internal testcontainer. May not be started yet.
     */
    T getContainer();
}
