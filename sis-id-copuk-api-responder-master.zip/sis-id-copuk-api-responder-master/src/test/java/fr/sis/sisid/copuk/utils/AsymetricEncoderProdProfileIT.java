package fr.sis.sisid.copuk.utils;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import fr.sis.sisid.copuk.dto.AsymetricEncoder;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import java.util.Optional;

class AsymetricEncoderProdProfileIT extends SpringTestConfiguration {

    @Autowired
    private AsymetricEncoder asymetricEncoder;

    @Value("${app.identifiant-ssa-public-key}")
    private String publicKey;

    @Value("${app.identifiant-ssa-private-key}")
    private String privateKey;

    @Test
    void encodingWithAlgoSSA() {
        String originalIdentifiant = "12345674859698";
        String identifianCipher = asymetricEncoder.encryptToBase64(originalIdentifiant);
        var docoder = new AsymetricEncoder(Optional.of(privateKey), publicKey);
        String identifiant = docoder.decryptFromBase64(identifianCipher);
        Assertions.assertEquals(originalIdentifiant, identifiant);
    }
}
