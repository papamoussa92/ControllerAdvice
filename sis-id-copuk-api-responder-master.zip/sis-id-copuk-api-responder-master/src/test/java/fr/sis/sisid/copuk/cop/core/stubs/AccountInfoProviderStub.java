package fr.sis.sisid.copuk.cop.core.stubs;

import fr.sis.sisid.copuk.cop.spi.AccountInfoProvider;
import fr.sis.sisid.copuk.model.AccountInfoRejection;
import fr.sis.sisid.copuk.model.AccountInfoReply;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import reactor.core.publisher.Mono;

public class AccountInfoProviderStub implements AccountInfoProvider {

    private AccountInfoReply accountInfo;

    public AccountInfoProviderStub(CoreAccountInfo accountInfo) {
        this.accountInfo = accountInfo;
    }

    public AccountInfoProviderStub(AccountInfoRejection accountInfoRejection) {
        this.accountInfo = accountInfoRejection;
    }

    @Override
    public Mono<AccountInfoReply> getAccountInfo(CoreCopRequest copRequest) {
        return Mono.just(this.accountInfo);
    }

}
