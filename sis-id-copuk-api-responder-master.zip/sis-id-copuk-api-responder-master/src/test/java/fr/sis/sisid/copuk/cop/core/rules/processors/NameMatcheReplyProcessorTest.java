package fr.sis.sisid.copuk.cop.core.rules.processors;

import java.util.Optional;

import fr.sis.sisid.copuk.cop.core.CopTestTools;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import reactor.test.StepVerifier;

class NameMatcheReplyProcessorTest {

    @Test
    void enrichContextTest() {
        VerificationContext input = CopTestTools.getVerificationContext(
                CoreCopRequest.builder().build());
        var nameMatchesReplyProcessor = new NameMatchesReplyProcessor();
        StepVerifier.create(nameMatchesReplyProcessor.enrichContext(input))
                .assertNext(ctx -> {
                    Optional<CoreCopReply> reply = ctx.getReply();
                    Assertions.assertThat(reply).isPresent();
                    Assertions.assertThat(reply.get().isMatched()).isTrue();
                    Assertions.assertThat(reply.get().getName()).isEmpty();
                })
                .expectComplete()
                .verify();
    }

}
