package fr.sis.sisid.copuk.validation;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.sis.sisid.copuk.OpenBankingConstants;
import fr.sis.sisid.copuk.copapi.model.AccountsNameVerificationData;
import fr.sis.sisid.copuk.copapi.model.InlineObject;
import fr.sis.sisid.copuk.copapi.model.InlineResponse200;
import fr.sis.sisid.copuk.copapi.model.Links;
import fr.sis.sisid.copuk.copapi.model.OBExternalAccountType1Code;
import fr.sis.sisid.copuk.copapi.model.ReasonCodes;
import fr.sis.sisid.copuk.mockserver.MockUtils;
import fr.sis.sisid.copuk.model.AccountType;
import fr.sis.sisid.copuk.tools.NameVerificationRequestTools;
import fr.sis.sisid.copuk.tools.RequestSignatureTool;
import fr.sis.sisid.copuk.tools.TokenTool;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.mockserver.client.MockServerClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.UUID;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@Slf4j
public class AccountMatchesSteps {

    @Autowired
    @Qualifier("registration-mockserver-client")
    MockServerClient registrationMockServer;
    @Value("${server.port}")
    private int serverPort;
    @Autowired
    private ObjectMapper objectMapper;
    private Response response;
    private InlineResponse200 inlineResponse200;
    private String rawResponse;
    private String jwsSignature;

    @Value("${app.organisation-id}")
    private String organisationId;

    @Autowired
    private TokenTool tokenTool;

    @Value("${spring.security.oauth2.client.registration.copuk-auth.client-id}")
    private String clientId = "test-client";

    @Value("${non-repudiation.public-key}")
    private String requestSignaturePublicKey;

    private String validToken;

    @Before
    public void setup() {
        this.validToken = tokenTool.fetchToken();
        log.info("Retrieving token {}", validToken);
        MockUtils.mockSsa(registrationMockServer, clientId);
    }

    @After
    public void resetNameMatching() {
        this.response = null;
        this.rawResponse = null;
        this.inlineResponse200 = null;
        this.jwsSignature = null;
    }

    @Given("the Payee with name {string}, sortCode {string}, accountNumber {string} is a valid BNPP {string} customer")
    public void the_payee_with_name_sort_code_account_number_is_a_valid_bnpp_customer(String payeeName,
            String sortCode, String accountNumber, String accountType) {
        log.info("Expecting preconfigured {} account {} {} with account name {} in CIB",accountType, sortCode, accountNumber, payeeName);
    }

    @When("a Requester queries a {string} account with name {string} and identification {string}")
    public void a_requester_queries_with_name_and_identification_payee_account_number(String accountType,
            String payeeName,
            String identificationNumber) throws JsonProcessingException {
        log.info("Receiving a CoP request for {} and {} account number {}", accountType, payeeName, identificationNumber);

        OBExternalAccountType1Code requestAccountType = switch (AccountType.valueOf(accountType)) {
            case BUSINESS -> OBExternalAccountType1Code.BUSINESS;
            case PRIVATE -> OBExternalAccountType1Code.PERSONAL;
        };

        var requestBody = new InlineObject().data(new AccountsNameVerificationData()
                .schemeName(AccountsNameVerificationData.SchemeNameEnum.SORTCODEACCOUNTNUMBER)
                .accountType(requestAccountType)
                .identification(identificationNumber)
                .name(payeeName));
        var serializedReqBody = objectMapper.writeValueAsString(requestBody);

        var headers = NameVerificationRequestTools.getRequestHeaders(organisationId, validToken,
                UUID.randomUUID().toString(), RequestSignatureTool.signPayload(serializedReqBody));

        RestAssured.baseURI = String.format("http://localhost:%s", serverPort);
        this.response = RestAssured.given()
                .headers(headers)
                .body(serializedReqBody)
                .request(Method.POST, "/api/v1.0/pay.uk/accounts/name-verification")
                .then().extract().response();

        log.info("Response status {}", this.response.getStatusCode());
        this.rawResponse = this.response.print();
        log.info("Response {}", this.rawResponse);
        this.jwsSignature = this.response.getHeader(OpenBankingConstants.NON_REPUDIATION_HEADER);
        this.inlineResponse200 = this.response.as(InlineResponse200.class);
    }

    @Then("the Responder responds with matched to {string} and HTTP status code {int}")
    public void the_responder_responds_with_matched_to_true_and_http_status_code(String match, Integer statusCode) {
        Assertions.assertThat(this.response.getStatusCode()).isEqualTo(statusCode);
        Assertions.assertThat(this.inlineResponse200.getData().getVerificationReport().getMatched())
                .isEqualTo(Boolean.parseBoolean(match));
        Assertions.assertThatNoException().isThrownBy(() -> RequestSignatureTool.validateSignature(this.rawResponse,
                this.jwsSignature, this.requestSignaturePublicKey));
        Assertions.assertThat(this.response.jsonPath().<Links>get("Links")).isNull();
        Assertions.assertThat(this.response.jsonPath().<Object>get("Meta")).isNull();
    }

    @Then("the verification report mentions the name {string}")
    public void the_verification_report_mentions_the_name(String name) {
        Assertions.assertThat(this.inlineResponse200.getData().getVerificationReport().getName()).isEqualTo(name);
    }

    @Then("the verification report has the reason code {string}")
    public void the_verification_report_has_the_reason_code(String reasonCode) {
        Assertions.assertThat(this.inlineResponse200.getData().getVerificationReport().getReasonCode())
                .isEqualTo(ReasonCodes.valueOf(reasonCode));
    }

    @Then("reason code is absent")
    public void reasonCodeIsAbsent() {
        Assertions.assertThat(this.inlineResponse200.getData().getVerificationReport().getReasonCode())
                .isNull();
    }
    @Then("the verification report does not mention a name")
    public void doYouMeanIsAbsent() {
        Assertions.assertThat(this.inlineResponse200.getData().getVerificationReport().getName())
                .isNull();
    }
}
