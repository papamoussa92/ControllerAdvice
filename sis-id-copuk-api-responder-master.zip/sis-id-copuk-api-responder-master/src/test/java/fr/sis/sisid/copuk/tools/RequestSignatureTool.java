package fr.sis.sisid.copuk.tools;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.jwk.JWK;
import fr.sis.sisid.copuk.OpenBankingConstants;
import fr.sis.sisid.copuk.tokens.NonRepudiationTokenParameters;
import fr.sis.sisid.copuk.tokens.OpenBankingTokenFactory;
import org.junit.jupiter.api.Assertions;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.ParseException;
import java.util.Set;

public class RequestSignatureTool {

    public static String signPayload(String payload) {
        try {
            var params = NonRepudiationTokenParameters.builder()
                    .rsaKey(getSigningKey())
                    .payload(payload)
                    .kid("OXOKm9U8c48H09zw46P8O54l4QA=")
                    .iat(1654268519l)
                    .tan("openbanking.org.uk")
                    .iss("0014H00003ARnTmQAL/UVpTUUTzBFoQHpISL2ii91").build();
            return OpenBankingTokenFactory.makeToken(params);

        } catch (JOSEException e) {
            throw new RuntimeException("Could not sign payload", e);
        }
    }

    public static void validateSignature(String rawResponse, String signature, String strPublicKey)
            throws JOSEException, ParseException {
        var publicKey =  JWK.parseFromPEMEncodedObjects(strPublicKey).toRSAKey().toRSAPublicKey();
        var verifier = new RSASSAVerifier(publicKey, Set.of(OpenBankingConstants.CUSTOM_IAT_CLAIM, OpenBankingConstants.CUSTOM_ISS_CLAIM, OpenBankingConstants.CUSTOM_TAN_CLAIM));
        var jose = JWSObject.parse(signature, new Payload(rawResponse));
        if(!jose.verify(verifier)) {
            throw new JOSEException("Signature verification failed");
        }
    }

    public static String getSigningKey() {
        try {
            return Files
                    .readString(Path.of(new ClassPathResource("certs/signing/signing-cert.pem").getURI().getPath()));
        } catch (IOException e) {
            e.printStackTrace();
            Assertions.fail("Could not get signing key from test resources");
            return null;
        }
    }

}
