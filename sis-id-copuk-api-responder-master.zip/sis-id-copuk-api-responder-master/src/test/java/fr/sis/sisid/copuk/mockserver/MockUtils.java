package fr.sis.sisid.copuk.mockserver;

import org.mockserver.client.MockServerClient;
import org.mockserver.matchers.MatchType;
import org.mockserver.model.Header;
import org.mockserver.model.HttpRequest;
import org.mockserver.model.HttpResponse;
import org.mockserver.model.JsonBody;
import org.mockserver.model.MediaType;
import org.mockserver.model.NottableString;

import fr.sis.sisid.copuk.tools.TestTools;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class MockUtils {

    /**
     * Nominal case ( account found, request is valid )
     *
     * @param mockServerClient
     * @param accountName
     * @param sortCode
     */
    public static void mockTC_UK_01(MockServerClient mockServerClient, String accountName, String sortCode,
            String accountNumber, String accountType) {
        if (!TestTools.shouldMock()) {
            return;
        }
        mockServerClient.reset();
        log.info("mockTC_UK_01 - start");
        mockSecurity(mockServerClient);
        mockServerClient.when(
                HttpRequest
                        .request("/v1/confirmation-of-payee")
                        .withMethod("POST")
                        .withHeader(new Header("Authorization", ".*"))
                        .withBody(JsonBody.json("""
                                {
                                  "account": {
                                    "identification": {
                                      "other":{
                                        "identification":"%s"
                                      }
                                    }
                                  }
                                }
                                """.formatted(sortCode + accountNumber), MatchType.ONLY_MATCHING_FIELDS)))
                .respond(HttpResponse
                        .response("""
                                 {
                                      "accountInformation": {
                                         "name": "%s",
                                         "currency": [
                                         "GBP"
                                         ],
                                         "accountType": "%s"
                                         },
                                      "requestStatus": "ACCEPTED",
                                      "requestReasonStatus": "Accepted"
                                   }
                                """.formatted(accountName, accountType))
                        .withStatusCode(200)
                        .withContentType(MediaType.APPLICATION_JSON));
    }

    /**
     * Account type not supported
     * @param mockServerClient
     */
    public static void mockTC_UK_05(MockServerClient mockServerClient, String accountType) {
        if (!TestTools.shouldMock()) {
            return;
        }
        mockServerClient.reset();
        mockSecurity(mockServerClient);
        log.info("mockTC_UK_05 - start");
        mockServerClient.when(HttpRequest.request("/v1/confirmation-of-payee")
                .withMethod("POST")
                .withHeader(new Header("Authorization", "^Bearer [a-zA-Z\\-_0-9\\.]*"))
                .withBody(JsonBody.json("""
                        {
                          "account": {
                            "accountType": "%s"
                          }
                        }
                        """.formatted(accountType), MatchType.ONLY_MATCHING_FIELDS)))
                .respond(HttpResponse
                        .response("""
                                {
                                    "requestStatus": "REJECTED",
                                    "requestReasonStatus": "ERR17: This account type is not supported"
                                }
                                """)
                        .withStatusCode(200)
                        .withContentType(MediaType.APPLICATION_JSON));

    }

    public static void mockTC_UK_07(MockServerClient mockServerClient, String accountName) {
        if (!TestTools.shouldMock()) {
            return;
        }
        mockServerClient.reset();
        log.info("mockTC_UK_01 - start");
        mockSecurity(mockServerClient);
        mockServerClient.when(
                HttpRequest
                        .request("/v1/confirmation-of-payee")
                        .withMethod("POST")
                        .withHeader(new Header("Authorization", ".*")))

                .respond(HttpResponse
                        .response("""
                                 {
                                      "accountInformation": {
                                         "name": "Bayerische Motoren Werke Ltd",
                                         "currency": [
                                         "GBP"
                                         ],
                                         "accountType": "Organisation"
                                         },
                                      "requestStatus": "ACCEPTED",
                                      "requestReasonStatus": "Accepted"
                                   }
                                """.formatted(accountName))
                        .withStatusCode(200)
                        .withContentType(MediaType.APPLICATION_JSON));
    }

    public static void mock404(MockServerClient mockServerClient) {
        if (!TestTools.shouldMock()) {
            return;
        }
        mockServerClient.reset();
        mockServerClient.when(HttpRequest.request("*")).respond(HttpResponse.response().withStatusCode(404));
    }

    public static void mockBnp500(MockServerClient mockServerClient) {
        if (!TestTools.shouldMock()) {
            return;
        }
        mockServerClient.reset();
        mockServerClient.when(HttpRequest.request("/v1/confirmation-of-payee"))
                .respond(HttpResponse.response("""
                                     . . .
                                      \\|/
                                    `--+--'
                                      /|\\
                                     ' | '
                                       |
                                       |
                                   ,--'#`--.
                                   |#######|
                                _.-'#######`-._
                             ,-'###############`-.
                           ,'#####################`,
                          /#########################\\
                         |###########################|
                        |#############################|
                        |#############################|
                        |#############################|
                        |#############################|
                         |###########################|
                          \\#########################/
                           `.#####################,'
                             `._###############_,'
                                `--..#####..--'

                                        """)
                        .withStatusCode(500));
    }

    public static void mockBnpRejected(MockServerClient mockServerClient, String errorCode, String reason) {
        if (!TestTools.shouldMock()) {
            return;
        }
        mockServerClient.reset();
        log.info("mockBnpRejected : start");
        mockSecurity(mockServerClient);
        mockServerClient.when(
                HttpRequest
                        .request("/v1/confirmation-of-payee")
                        .withMethod("POST")
                        .withHeader(new Header("Authorization", "^Bearer [a-zA-Z\\-_0-9\\.]*")))
                .respond(HttpResponse
                        .response("""
                                {
                                    "requestStatus": "REJECTED",
                                    "requestReasonStatus": "%s: %s"
                                }
                                """.formatted(errorCode, reason))
                        .withStatusCode(200)
                        .withContentType(MediaType.APPLICATION_JSON));
    }

    private static void mockSecurity(MockServerClient mockServerClient) {
        log.debug("Bnp mockserver will return HTTP401 when no Bearer token is present");
        mockServerClient
                .when(
                        HttpRequest.request()
                                .withHeader(NottableString.not("Authorization"), NottableString.string(".*")))
                .withPriority(Integer.MAX_VALUE)
                .respond(HttpResponse.response().withStatusCode(401));
    }

    public static void mockSsa(MockServerClient mockServerClient, String clientId) {
        if (!TestTools.shouldMock()) {
            return;
        }
        log.debug("Mocking ssa at client registration {}", clientId);
        mockServerClient.reset();
        int mockServerPort = mockServerClient.getPort();
        String mockServerAddress = mockServerClient.remoteAddress().getHostString();
        // mock ssa dto request
        mockServerClient
                .when(HttpRequest.request("/internal/client/" + clientId + "/ssa")
                        .withMethod("GET"))
                .respond(HttpResponse.response("""
                        {
                          "jti": "5d5c08e08c6a41e9",
                          "orgId": "0014H00003ARnTmQAL",
                          "softwareJwksEndpoint": "http://%s:%d/jwks",
                          "softwareId":"UVpTUUTzBFoQHpISL2ii91"
                        }
                        """.formatted(mockServerAddress, mockServerPort))
                        .withStatusCode(200)
                        .withContentType(MediaType.APPLICATION_JSON));
        // mock jwks as well to avoid having to stub or to make another mockserver
        mockServerClient.when(HttpRequest.request("/jwks").withMethod("GET"))
                .respond(HttpResponse
                        .response(
                                """
                                        {
                                          "keys": [
                                            {
                                              "kty": "RSA",
                                              "e": "AQAB",
                                              "use": "sig",
                                              "kid": "OXOKm9U8c48H09zw46P8O54l4QA=",
                                              "alg": "PS256",
                                              "n": "pZpBF_gunYuXkolDNRuaCScWMVtKE4iyDYnPgQQcWd1_a0PB9JrdE96lJhSjIkojeo4Lo5hW0bU7AeQ1iOnW5g-K1WjHXpbl9Iu2iW8S7ybHYdPbQKhA6ybbyK7XFK6cazU2TTtieUMtHP3rVei6C4SY0blEcOgOLGuXroEJKZ_nqy-9rDUuQxxyIKA7HYeK-Ub_fh2EyGlS-WoK_BJBSCBCEpI5N-ZZjJXRY55JItBAd4kyhiN4Bm8b95ajut8kyfmcbKu_VFx2gfwE3DKrWJZ4SbtJ28ZghK918eu0nEV14I6nItFU_M1IY0v3IgIIegjA6rl8Pqa5HdbVdM6hdw"
                                            }
                                          ]
                                        }
                                        """)
                        .withStatusCode(200)
                        .withContentType(MediaType.APPLICATION_JSON));
    }

    public static void mockCibHead(MockServerClient client) {
        client.reset();
        client.when(HttpRequest.request("/v1/confirmation-of-payee")
                .withMethod("HEAD")
                .withHeader(new Header("Authorization", "^Bearer [a-zA-Z\\-_0-9\\.]*")))
                .respond(HttpResponse.response().withStatusCode(404));
        client.when(HttpRequest.request().withPath(NottableString.not("/v1/confirmation-of-payee")))
                .respond(HttpResponse.response().withStatusCode(500));
    }

}
