package fr.sis.sisid.copuk.api;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Stream;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockserver.client.MockServerClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import fr.sis.sisid.copuk.mockserver.MockUtils;
import fr.sis.sisid.copuk.tools.NameVerificationRequestTools;
import fr.sis.sisid.copuk.tools.TokenTool;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = "app.rate-limit.enabled=true")
class RateLimitIT extends SpringTestConfiguration {

    @Autowired
    private TokenTool tokenTool;

    @LocalServerPort
    private int serverPort;

    @Value("${spring.security.oauth2.client.registration.copuk-auth.client-id}")
    private String clientId = "test-client";

    @Value("${app.organisation-id}")
    private String orgId;

    @Autowired
    @Qualifier("registration-mockserver-client")
    MockServerClient registrationMockServer;

    @Autowired
    @Qualifier("bnp-mockserver-client")
    MockServerClient payeeInfoMockClient;

    @BeforeEach
    void setup() {
        MockUtils.mockSsa(registrationMockServer, clientId);
        MockUtils.mockTC_UK_01(payeeInfoMockClient, "toto", "123456", "74859698", "Organisation");
    }

    @Test
    void testRateLimit() throws InterruptedException, ExecutionException {
        Stream.of(
                NameVerificationRequestTools.performNameVerification("toto", orgId, tokenTool, serverPort),
                NameVerificationRequestTools.performNameVerification("toto", orgId, tokenTool, serverPort),
                NameVerificationRequestTools.performNameVerification("toto", orgId, tokenTool, serverPort))
                .forEach(response -> Assertions.assertThat(response).returns(200, r -> r.getStatusCode()).returns(null,
                        r -> r.getHeader("reply-after")));
        var rateLimited = NameVerificationRequestTools.performNameVerification("toto", orgId, tokenTool, serverPort);
        Assertions.assertThat(rateLimited.getStatusCode()).isEqualTo(429);
        Assertions.assertThat(rateLimited.getHeader("retry-after")).isNotBlank();
        int retryAfter = Integer.parseInt(rateLimited.getHeader("retry-after"));
        log.info("retry after : {}", retryAfter);
        var retryAfterFuture = Executors.newScheduledThreadPool(1).schedule(() -> {
            var thirdResponse = NameVerificationRequestTools.performNameVerification("toto", orgId, tokenTool,
                    serverPort);
            Assertions.assertThat(thirdResponse.getStatusCode()).isEqualTo(200);
            Assertions.assertThat(thirdResponse.getHeader("retry-after")).isBlank();
        }, retryAfter + 1, TimeUnit.SECONDS);
        retryAfterFuture.get();
    }

}
