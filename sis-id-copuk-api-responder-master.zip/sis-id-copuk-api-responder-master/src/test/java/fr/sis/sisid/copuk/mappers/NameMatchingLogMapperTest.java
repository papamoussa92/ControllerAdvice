package fr.sis.sisid.copuk.mappers;

import java.math.BigDecimal;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

import fr.sis.sisid.copuk.entities.Audit;
import fr.sis.sisid.copuk.entities.NameMatchingLogEntity;
import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.model.NameMatchingLog;

class NameMatchingLogMapperTest {

    @Test
    void toEntityTest() {
        var input = new NameMatchingLog();
        input.setInput("input name");
        input.setReference("reference name");
        input.setProcessedInput("processed input name");
        input.setProcessedReference("processed reference name");
        input.setRuleCode("RL000");
        input.setScore(0.45);
        input.setDecision(MatchingDecision.CLOSE_MATCH);

        var audit = new Audit();
        audit.setId(12l);

        int order = 4;

        var expected = new NameMatchingLogEntity();
        expected.setAudit(audit);
        expected.setDecision(MatchingDecision.CLOSE_MATCH);
        expected.setInputName("input name");
        expected.setReferenceName("reference name");
        expected.setProcessedInput("processed input name");
        expected.setProcessedReference("processed reference name");
        expected.setRuleCode("RL000");
        expected.setRuleOrder((short) 4);
        expected.setScore(BigDecimal.valueOf(0.45));
        expected.setDateAudit(audit.getDateAudit());

        var mapper = new NameMatchingLogMapper();

        Assertions.assertThat(mapper.toEntity(input, audit, order)).isEqualTo(expected);
    }
}
