package fr.sis.sisid.copuk.client;

import org.springframework.http.ResponseEntity;

import fr.sis.sisid.copuk.dto.SsaDTO;
import lombok.AllArgsConstructor;
import lombok.Setter;
import reactor.core.publisher.Mono;

@AllArgsConstructor
public class ClientRegistrationClientStub implements ClientRegistrationClient {

    @Setter
    private Mono<ResponseEntity<SsaDTO>> stubbedResponse;

    @Override
    public Mono<ResponseEntity<SsaDTO>> getSSA(String clientId) {
        return this.stubbedResponse;
    }

}
