package fr.sis.sisid.copuk.cop.core;

import java.util.UUID;

import fr.sis.sisid.copuk.cop.core.rules.processors.AccountInfoEnricher;
import fr.sis.sisid.copuk.cop.core.rules.processors.NameMatchingResultEnricher;
import fr.sis.sisid.copuk.cop.core.stubs.AccountInfoProviderStub;
import fr.sis.sisid.copuk.cop.core.stubs.NameMatchingProviderStub;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import fr.sis.sisid.copuk.namematching.model.MatchingResult;

public class CopTestTools {

    public static NameMatchingResultEnricher getNameMatchingResultEnricher(String name, MatchingResult result) {
        var nameMatchingProvider = getNameMatchingProvider(result);
        return new NameMatchingResultEnricher(getAccountInfoEnricher(name), nameMatchingProvider);
    }

    public static AccountInfoEnricher getAccountInfoEnricher(String name) {
        return new AccountInfoEnricher(getAccountInfoProvider(name));
    }

    public static VerificationContext getVerificationContext(String name) {
        return new VerificationContext("org1", UUID.randomUUID().toString(), System.currentTimeMillis(),
                CoreCopRequest.builder().name("name").build());
    }

    public static VerificationContext getVerificationContext(CoreCopRequest request) {
        return new VerificationContext("org1", UUID.randomUUID().toString(), System.currentTimeMillis(),
                request);
    }

    public static AccountInfoProviderStub getAccountInfoProvider(String name) {
        return new AccountInfoProviderStub(CoreAccountInfo.builder().name(name).build());
    }

    public static NameMatchingProviderStub getNameMatchingProvider(MatchingResult result) {
        return new NameMatchingProviderStub(result);
    }
}
