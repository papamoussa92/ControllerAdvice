package fr.sis.sisid.copuk.api;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.server.LocalServerPort;

import static org.hamcrest.Matchers.*;

class WellKnownControllerIT extends SpringTestConfiguration {

    @LocalServerPort
    private int serverPort;

    @Value("${app.open-id-config-version}")
    private String openIdConfigVersion;

    @Test
    void wellKnownOpenIdEndpointAnswers() {
        RestAssured.given().get("http://localhost:" + serverPort + "/api/v1.0/.well-known/openid-configuration")
                .then().assertThat()
                .statusCode(200)
                .contentType(ContentType.JSON)
                // version string is recommended by pay uk tech guide
                .body("version", equalTo(openIdConfigVersion))
                // validate required fields are present
                // issuer
                .body("issuer", not(blankOrNullString()))
                // authorization_endpoint
                .body("authorization_endpoint", not(blankOrNullString()))
                .body("registration_endpoint", not(blankOrNullString()))
                // token_endpoint
                .body("token_endpoint", not(blankOrNullString()))
                // jwks_uri
                .body("jwks_uri", not(blankOrNullString()))
                // response_types_supported
                .body("response_types_supported", not(empty()))
                .body("response_types_supported", everyItem(not(blankOrNullString())))
                // subject_types_supported
                .body("subject_types_supported", not(empty()))
                .body("subject_types_supported", everyItem(not(blankOrNullString())))
                // id_token_signing_alg_values_supported
                .body("id_token_signing_alg_values_supported", not(empty()))
                .body("id_token_signing_alg_values_supported", everyItem(not(blankOrNullString())));
    }
}
