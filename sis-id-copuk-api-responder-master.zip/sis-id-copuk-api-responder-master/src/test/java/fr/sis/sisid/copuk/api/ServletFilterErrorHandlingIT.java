package fr.sis.sisid.copuk.api;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockserver.client.MockServerClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Profile;
import org.springframework.core.Ordered;
import org.springframework.web.filter.OncePerRequestFilter;

import com.fasterxml.jackson.core.JsonProcessingException;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import fr.sis.sisid.copuk.copapi.model.OBErrorResponse1;
import fr.sis.sisid.copuk.mockserver.MockUtils;
import fr.sis.sisid.copuk.tools.NameVerificationRequestTools;
import fr.sis.sisid.copuk.tools.TokenTool;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

@Slf4j
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = "spring.profiles.active=broken-filter")
class ServletFilterErrorHandlingIT extends SpringTestConfiguration {

    @Autowired
    private TokenTool tokenTool;

    @LocalServerPort
    private int serverPort;

    @Value("${spring.security.oauth2.client.registration.copuk-auth.client-id}")
    private String clientId = "test-client";

    @Value("${app.organisation-id}")
    private String orgId;

    @Autowired
    @Qualifier("registration-mockserver-client")
    MockServerClient registrationMockServer;

    @Autowired
    @Qualifier("bnp-mockserver-client")
    MockServerClient payeeInfoMockClient;

    @BeforeEach
    void setup() {
        MockUtils.mockSsa(registrationMockServer, clientId);
        MockUtils.mockTC_UK_01(payeeInfoMockClient, "toto", "123456", "12345678", "Organisation");
    }

    @Test
    void uncheckedErrorInAFilter() throws JsonProcessingException {
        var response = NameVerificationRequestTools.performNameVerification("toto inc", orgId, tokenTool, serverPort);
        log.info(response.getBody().asPrettyString());
        Assertions.assertThat(response.getStatusCode()).isEqualTo(500);
        var errorResponse = response.getBody().as(OBErrorResponse1.class);
        Assertions.assertThat(errorResponse.getCode()).isEqualTo("500");
        Assertions.assertThat(errorResponse.getErrors()).isNotEmpty();
        var error = new ArrayList<>(errorResponse.getErrors()).get(0);
        Assertions.assertThat(error.getErrorCode()).isEqualTo("UK.OBIE.UnexpectedError");

    }

    @TestConfiguration
    @Profile("broken-filter")
    public static class BrokenFilterConfiguration {

        @Bean
        public WebFilter brokenFilter() {
            log.info("Registering a test servlet filter");
            WebFilter brokenFilter = (exchange, chain) -> {
                log.warn("Throwing test filter error");
                throw new ClassCastException("Something unexpected happened in a filter");
            };

            return brokenFilter;
        }
    }

}
