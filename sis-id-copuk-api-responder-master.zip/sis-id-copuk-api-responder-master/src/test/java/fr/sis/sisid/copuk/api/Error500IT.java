package fr.sis.sisid.copuk.api;

import static org.assertj.core.api.Assertions.assertThat;

import java.io.IOException;
import java.time.LocalDate;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpHeaders;
import org.junit.jupiter.api.Test;
import org.mockserver.client.MockServerClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.test.context.jdbc.Sql;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.copapi.model.OBErrorResponse1;
import fr.sis.sisid.copuk.dto.NameMatchingStatsDTO;
import fr.sis.sisid.copuk.entities.Audit;
import fr.sis.sisid.copuk.entities.AuditRepository;
import fr.sis.sisid.copuk.service.AuditService;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import reactor.core.publisher.Mono;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = "spring.profiles.active=broken-service")
class Error500IT extends SpringTestConfiguration {

    @Autowired
    @Qualifier("bnp-mockserver-client")
    MockServerClient payeeInfoMockClient;
    @Autowired
    AuditRepository auditRepository;
    @LocalServerPort
    private int serverPort;

    @Test
    @Sql(scripts = "classpath:data/data.sql")
    void testSearchAuditWhitoutDateEndLessTanDateStart() {
        Map<String, String> reqHeaders = new HashMap<>();
        reqHeaders.put(HttpHeaders.CONTENT_TYPE, "application/json");
        reqHeaders.put(HttpHeaders.ACCEPT, "application/json");
        RestAssured.baseURI = String.format("http://localhost:%s", serverPort);
        String dateDebut = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        String dateFin = LocalDate.now().minusDays(4).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        var response = RestAssured.given()
                .headers(reqHeaders)
                .request(Method.GET, "/audit/search?dateStart=" + dateDebut + "&dateEnd=" + dateFin)
                .then().extract().response();
        OBErrorResponse1 obErrorResponse1 = response.as(OBErrorResponse1.class);
        assertThat(response.statusCode()).isEqualTo(500);
        assertThat(obErrorResponse1.getCode()).isEqualTo("500");
    }

    @TestConfiguration
    @Profile("broken-service")
    public static class BrokenServiceConfiguration {

        @Bean
        @Primary
        public AuditService auditService() {
            return new AuditService() {

                @Override
                public Mono<List<Audit>> searchByKey(String accountNumber, String accountName, String dateDebut,
                        String dateFin) {
                    return Mono.error(new IOException("An unexpected error occured"));
                }

                @Override public Mono<Audit> save(VerificationContext verificationContext) {
                    return null;
                }

                @Override
                public Mono<NameMatchingStatsDTO> getStats(ZonedDateTime from, ZonedDateTime to) {
                    return null;
                }
            };
        }
    }
}
