package fr.sis.sisid.copuk.api;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockserver.client.MockServerClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;

import com.fasterxml.jackson.core.JsonProcessingException;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import fr.sis.sisid.copuk.mockserver.MockUtils;
import fr.sis.sisid.copuk.tools.NameVerificationRequestTools;
import fr.sis.sisid.copuk.tools.TokenTool;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class BnpUnavailableIT extends SpringTestConfiguration {

    @Autowired
    private TokenTool tokenTool;

    @LocalServerPort
    private int serverPort;

    @Value("${spring.security.oauth2.client.registration.copuk-auth.client-id}")
    private String clientId = "test-client";

    @Value("${app.organisation-id}")
    private String orgId;

    @Autowired
    @Qualifier("registration-mockserver-client")
    MockServerClient registrationMockServer;

    @Autowired
    @Qualifier("bnp-mockserver-client")
    MockServerClient payeeInfoMockClient;

    @BeforeEach
    void setup() {
        MockUtils.mockSsa(registrationMockServer, clientId);
        MockUtils.mockBnp500(payeeInfoMockClient);
    }

    @Test
    void bnpUnavailable() throws JsonProcessingException {
        var response = NameVerificationRequestTools.performNameVerification("toto inc", orgId, tokenTool, serverPort);
        Assertions.assertThat(response.getStatusCode()).isEqualTo(503);
    }

}
