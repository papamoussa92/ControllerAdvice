package fr.sis.sisid.copuk.bdd;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import io.cucumber.spring.CucumberContextConfiguration;

@CucumberContextConfiguration
public class BDDConfiguration extends SpringTestConfiguration {
}
