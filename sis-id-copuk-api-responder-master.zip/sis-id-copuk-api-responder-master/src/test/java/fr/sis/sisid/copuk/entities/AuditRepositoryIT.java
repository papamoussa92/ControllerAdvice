package fr.sis.sisid.copuk.entities;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import fr.sis.sisid.copuk.service.AuditService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.validation.BindException;
import reactor.test.StepVerifier;

import java.sql.Timestamp;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import static org.junit.Assert.assertEquals;

class AuditRepositoryIT extends SpringTestConfiguration {
    @Autowired
    AuditRepository auditRepository;

    @Autowired
    AuditService auditService;

    @Test
    void testSave() {
        Audit audit = Audit.builder().correlationId("fapi").dateAudit(new Timestamp(System.currentTimeMillis())).build();

        Audit audit1 = this.auditRepository.save(audit);
        assertEquals("fapi", audit1.getCorrelationId());
    }

    @Test
    @Sql(scripts = "classpath:data/data.sql")
    void testSearch() throws ParseException, BindException {
        String dateDebut = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        String dateFin = LocalDate.now().plusDays(1).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        StepVerifier.create(this.auditService.searchByKey("5398706006951", "compte1", dateDebut, dateFin))
                .expectNextMatches(audits -> !audits.isEmpty())
                .expectComplete().verify();
    }
}
