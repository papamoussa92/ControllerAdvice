package fr.sis.sisid.copuk.controllers.filters;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.databind.ObjectMapper;

import fr.sis.sisid.copuk.client.ClientRegistrationClientStub;
import fr.sis.sisid.copuk.controllers.errors.NonRepudiationException;
import fr.sis.sisid.copuk.dto.SsaDTO;
import fr.sis.sisid.copuk.tools.JwtTools;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class SsaProviderTest {

    private static final String VALID_AUTHORIZATION_HEADER = "Bearer eyJhbGciOiJQUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJlajRVVTVfQzFJenZBemxHZmJ3NnZmZjBDRlU0eWpQZWN5YVE0dC1UVnY4In0.eyJleHAiOjE2NTQ1MDMwMDgsImlhdCI6MTY1NDUwMjEwOCwianRpIjoiZThjYmVmZTYtZTRkMy00MzNlLTgyNzUtOTUyZTY5OTAwMmNiIiwiaXNzIjoiaHR0cHM6Ly9jb3B1ay1hdXRob3Jpc2F0aW9uLWludC5zaXMtaWQ0YmFua3MuY29tL3JlYWxtcy9jb3B1ayIsInN1YiI6IjBmYzJmMzljLTBlYjYtNDE4Ny04NTZkLThkOWUzYzZmMTZkZCIsInR5cCI6IkJlYXJlciIsImF6cCI6IjE2MWM3MGMwLWUwNWQtNDNmZS1iNDU0LTA3M2I1NDI2ODhkNyIsInNjb3BlIjoibmFtZS12ZXJpZmljYXRpb24ifQ.BaCsA1me_6Hz6HJok97hO7iVstD62JZBu6BAVMg7nqKb5Nupss-R3J8ycWO6ECAA8kLyhJeSWdeyrtnGS5NimTyuJIYW3wRAQ0PvanJURQlOIrfCSPU2r9emL8MFarJAR7_AvcCoWfHw9DQoEb_UrUsIV2lhNyZ6uRH4fR2mPhnyCZu1s0glKUKPX1d1omdDdCfqZXz4ma1VGPh7QCRVChzBwQxDhu84EOmjn2hhrgUi2tnkfazYaDv6F96oFymnIQyrGXkDh9JZCMyD4PuwuNeLaD2ZSakpwSlB3xm07FsbzgEQsjoLZ1PUti8x63iu7bzgzNoYA1ES2dWVGmkCGw";
    private static final String CLIENT_ID = "161c70c0-e05d-43fe-b454-073b542688d7";

    JwtTools jwtTools;

    ClientRegistrationClientStub registrationClient;

    SsaDTO stubSSA;

    SsaProvider ssaProvider;

    @BeforeEach
    public void beforeEach() {
        this.jwtTools = new JwtTools(new ObjectMapper(), Stream.of("PS256", "RS256").collect(Collectors.toSet()));
        this.stubSSA = new SsaDTO();
        stubSSA.setJti("ssa-id");
        stubSSA.setSoftwareId("ssa-id");
        stubSSA.setOrgId("org-id");
        stubSSA.setSoftwareJwksEndpoint("https://jwks");
        this.registrationClient = new ClientRegistrationClientStub(Mono.just(ResponseEntity.ok(stubSSA)));
        this.ssaProvider = new SsaProvider(jwtTools, registrationClient);
    }

    @Test
    void testExtractClientId_noHeader() {
        StepVerifier.create(this.ssaProvider.extractClientId(null))
                .expectError(NonRepudiationException.class)
                .verify();
    }

    @Test
    void testExtractClientId() {
        StepVerifier.create(this.ssaProvider.extractClientId(VALID_AUTHORIZATION_HEADER))
                .assertNext(clientId -> Assertions.assertThat(clientId).isEqualTo(CLIENT_ID))
                .expectComplete()
                .verify();
    }

    @Test
    void testExtractClientId_invalidToken() {
        StepVerifier.create(this.ssaProvider.extractClientId("aaaaaa"))
                .expectError(NonRepudiationException.class)
                .verify();
    }

    @Test
    void testExtractClientId_noAzpClaim() {
        StepVerifier.create(this.ssaProvider.extractClientId(
                "Bearer eyJhbGciOiJQUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImVqNFVVNV9DMUl6dkF6bEdmYnc2dmZmMENGVTR5alBlY3lhUTR0LVRWdjgifQ.eyJleHAiOjE2NTQ1MDMwMDgsImlhdCI6MTY1NDUwMjEwOCwianRpIjoiZThjYmVmZTYtZTRkMy00MzNlLTgyNzUtOTUyZTY5OTAwMmNiIiwiaXNzIjoiaHR0cHM6Ly9jb3B1ay1hdXRob3Jpc2F0aW9uLWludC5zaXMtaWQ0YmFua3MuY29tL3JlYWxtcy9jb3B1ayIsInN1YiI6IjBmYzJmMzljLTBlYjYtNDE4Ny04NTZkLThkOWUzYzZmMTZkZCIsInR5cCI6IkJlYXJlciIsInNjb3BlIjoibmFtZS12ZXJpZmljYXRpb24iLCJhenAiOiIifQ.jiMSE1eJy7Yq4m7kWmsWNN2WE15dLBp5tmujwYbEvf5Uw8M8H1rwWe7mSqoDPaRxYbNXzFBj3x_ulTgoev6QAD5vab-QKKP8Ln_R36M63jr5jyh7Lha4lSj9M3btVohdk1INIwIFhYBz5MzOSg-btww9OYKEmD1x8RLWKWK8Nn-kkawtouar4jig554c8w4QpBPflbidlJuv1crW4sfhw6D3ZexV6M2rehmtK-PeWaud14DX69TiJdftiLHJZUgFDQ81x3_CjSVY0ViMGFFtNYviT4n8LRq85AsOGxuo2yVoLIbtB_EAutSIBxzbZeXo2jcBUtbtQ76BO8c1Ic4lvQ"))
                .expectError(NonRepudiationException.class)
                .verify();
    }

    @Test
    void testGetClientSsa_ssaNotFound() {
        this.registrationClient.setStubbedResponse(Mono.just(ResponseEntity.notFound().build()));
        StepVerifier.create(this.ssaProvider.getClientSsa(CLIENT_ID))
                .expectError(NonRepudiationException.class)
                .verify();
    }

    @Test
    void testGetClientSsa_invalidSsa() {
        var stubSsa = new SsaDTO();
        this.registrationClient.setStubbedResponse(Mono.just(ResponseEntity.ok(stubSsa)));
        StepVerifier.create(this.ssaProvider.getClientSsa(CLIENT_ID))
                .expectErrorMatches(err -> err instanceof NonRepudiationException)
                .verify();
    }

    @Test
    void testGetClientSsa() {
        var ssa = this.ssaProvider.getClientSsa(CLIENT_ID).block();
        Assertions.assertThat(ssa).isNotNull();
        Assertions.assertThat(ssa.getJti()).isNotBlank();
        Assertions.assertThat(ssa.getOrgId()).isNotBlank();
        Assertions.assertThat(ssa.getSoftwareJwksEndpoint()).isNotBlank();
    }
}
