package fr.sis.sisid.copuk.client;

import javax.net.ssl.SSLHandshakeException;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockserver.client.MockServerClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.security.oauth2.client.AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.InMemoryReactiveOAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServerOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import fr.sis.sisid.copuk.ext.bnp.api.PayeeInformationClient;
import fr.sis.sisid.copuk.ext.bnp.model.AccountIdentificationChoice;
import fr.sis.sisid.copuk.ext.bnp.model.CashAccount;
import fr.sis.sisid.copuk.ext.bnp.model.CopRequest;
import fr.sis.sisid.copuk.ext.bnp.model.GenericIdentification;
import fr.sis.sisid.copuk.mockserver.MockUtils;
import lombok.extern.slf4j.Slf4j;
import reactor.test.StepVerifier;

@Slf4j
class PayeeInformationsSrvClientIT extends SpringTestConfiguration {

    @Autowired
    @Qualifier("bnp-mockserver-client")
    MockServerClient payeeInfoMockClient;

    @Autowired
    ClientHttpConnector httpConnector;

    @Autowired
    ReactiveClientRegistrationRepository clientRegistrationRepository;

    @Autowired
    @Qualifier("bnpWebClient")
    WebClient bnpWebClient;

    @Value("${app.bnp.payee-information-srv.url}")
    String payeeInformationSrvUrl;

    @BeforeEach
    void setup() {
        MockUtils.mockTC_UK_01(payeeInfoMockClient, "test", "123456", "12345678", "Organisation");
    }

    @Test
    void authenticatedClientGetsAResponse() {
        PayeeInformationClient bnpClient = new PayeeInformationSrvClient(bnpWebClient);
        StepVerifier.create(bnpClient.providePayeeInformation(
                new CopRequest().account(new CashAccount().identification(new AccountIdentificationChoice()
                        .other(new GenericIdentification().identification("12345612345678")))).country("GB")))
                .assertNext(response -> Assertions.assertThat(response.getStatusCodeValue()).isEqualTo(200))
                .expectComplete()
                .verify();
    }

    @Test
    void clientWithNoCertGetsSSLError() {
        // webclient with no oauth filter nor a client cert
        var unauthenticatedWebClient = WebClient.builder()
                .baseUrl(payeeInformationSrvUrl)
                .build();
        PayeeInformationClient bnpClient = new PayeeInformationSrvClient(unauthenticatedWebClient);
        try {
            bnpClient.providePayeeInformation(new CopRequest().country("GB")).block();
        } catch (WebClientRequestException err) {
            Assertions.assertThat(err.getCause()).isInstanceOf(SSLHandshakeException.class);
            return;
        }
        Assertions.fail("Expected an ssl error");
    }

    @Test
    void unauthenticatedClientGets401() {
        // webclient with cert client but no oauth filter
        var unauthenticatedWebClient = WebClient.builder()
                .clientConnector(httpConnector)
                .baseUrl(payeeInformationSrvUrl)
                .build();
        PayeeInformationClient bnpClient = new PayeeInformationSrvClient(unauthenticatedWebClient);
        try {
            bnpClient.providePayeeInformation(new CopRequest().country("GB")).block();
        } catch (WebClientResponseException err) {
            Assertions.assertThat(err.getRawStatusCode()).isEqualTo(401);
            return;
        }
        Assertions.fail("Expected a 401 http error");
    }

    @Test
    void authenticatedClientWithNoMtlsGetsError() {
        // webclient with cert client, but oauth filter has no cert client
        var authzClientsManager = new AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager(
                clientRegistrationRepository,
                new InMemoryReactiveOAuth2AuthorizedClientService(clientRegistrationRepository));
        ServerOAuth2AuthorizedClientExchangeFilterFunction oauth = new ServerOAuth2AuthorizedClientExchangeFilterFunction(
                authzClientsManager);
        oauth.setDefaultClientRegistrationId("bnp");
        var misconfiguredClient = WebClient.builder()
                .clientConnector(httpConnector)
                .filter(oauth)
                .baseUrl(payeeInformationSrvUrl)
                .build();
        PayeeInformationClient bnpClient = new PayeeInformationSrvClient(misconfiguredClient);
        try {
            bnpClient.providePayeeInformation(new CopRequest().country("GB")).block();
        } catch (WebClientRequestException err) {
            Assertions.assertThat(err.getCause()).isInstanceOf(SSLHandshakeException.class);
            return;
        }
        Assertions.fail("Expected an SSL error");
    }

    @Test
    void headRequestTest() {
        MockUtils.mockCibHead(payeeInfoMockClient);
        PayeeInformationClient bnpClient = new PayeeInformationSrvClient(bnpWebClient);
        StepVerifier.create(bnpClient.headRequest())
                .expectErrorMatches(err -> err instanceof WebClientResponseException.NotFound)
                .verify();
    }
}
