package fr.sis.sisid.copuk.api;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.google.common.collect.Streams;
import fr.sis.sisid.copuk.SpringTestConfiguration;
import fr.sis.sisid.copuk.config.AsymetricEncoderConfig;
import fr.sis.sisid.copuk.copapi.model.InlineResponse200;
import fr.sis.sisid.copuk.dto.AsymetricEncoder;
import fr.sis.sisid.copuk.entities.Audit;
import fr.sis.sisid.copuk.entities.AuditRepository;
import fr.sis.sisid.copuk.entities.NameMatchingLogRepository;
import fr.sis.sisid.copuk.mockserver.MockUtils;
import fr.sis.sisid.copuk.tools.NameVerificationRequestTools;
import fr.sis.sisid.copuk.tools.TokenTool;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.bouncycastle.cms.CMSException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockserver.client.MockServerClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;

import java.util.Collection;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import static org.assertj.core.api.Assertions.assertThat;
@Slf4j
class AccountNameVerificationApiControllerIT extends SpringTestConfiguration {

    @Autowired
    @Qualifier("bnp-mockserver-client")
    MockServerClient payeeInfoMockClient;

    @Autowired
    AuditRepository auditRepository;

    @Autowired
    NameMatchingLogRepository nameMatchingLogRepository;

    @LocalServerPort
    private int serverPort;

    @Autowired
    private AsymetricEncoder asymetricEncoder;

    @Autowired
    private TokenTool tokenTool;

    @Autowired
    @Qualifier("registration-mockserver-client")
    MockServerClient registrationMockServer;

    @Value("${spring.security.oauth2.client.registration.copuk-auth.client-id}")
    private String clientId = "test-client";

    @Value("${app.organisation-id}")
    private String organisationId;

    private String validToken;

    @BeforeEach
    void setup() {
        this.validToken = tokenTool.fetchToken();
        log.info("Retrieving token {}", validToken);
        MockUtils.mockTC_UK_01(payeeInfoMockClient, "company limited", "123456", "74859698", "Organisation");
        this.nameMatchingLogRepository.deleteAll();
        this.auditRepository.deleteAll();
        MockUtils.mockSsa(registrationMockServer, clientId);
    }

    @Test
    void testProcess() throws JsonProcessingException, CMSException, ExecutionException, InterruptedException {
        String xFapiInteractId = UUID.randomUUID().toString();
        var body = NameVerificationRequestTools.performNameVerification("compte", organisationId, tokenTool, serverPort,
                xFapiInteractId);
        var inlineResponse200 = body.as(InlineResponse200.class);
        assertThat(inlineResponse200).isNotNull();
        // check store in db

        // Check if record un t able audit, allowing a delay after response for writing to the audit table
        ScheduledExecutorService executorService = Executors.newScheduledThreadPool(1);
        var auditStream = executorService.schedule(() -> this.auditRepository.findAll(),
                100, TimeUnit.MILLISECONDS
        ).get().stream();

        var audit = Streams.findLast(auditStream).orElse(null);
        assertThat(audit.getCorrelationId()).isEqualTo(xFapiInteractId);
        assertThat(audit.getInputAccountName()).isEqualTo("compte");
        assertThat(audit.getAccountNameFromCibApi()).isEqualTo("company limited");
        assertThat(audit.getPayeeAccountType()).isEqualTo("BUSINESS");
        assertThat(audit.getIdentification()).isNotNull();
    }

    @Test
    void testMultiThread() throws InterruptedException, ExecutionException, TimeoutException {
        String xFapiInteractId = UUID.randomUUID().toString();
        String xFapiInteractId1 = UUID.randomUUID().toString();
        String xFapiInteractId2 = UUID.randomUUID().toString();

        Callable firstReq = () -> NameVerificationRequestTools.performNameVerification("compte", organisationId,
                tokenTool, serverPort, xFapiInteractId);

        Callable secondReq = () -> NameVerificationRequestTools.performNameVerification("compte2", organisationId,
                tokenTool, serverPort, xFapiInteractId1);

        Callable thirdReq = () -> NameVerificationRequestTools.performNameVerification("compte3", organisationId,
                tokenTool, serverPort, xFapiInteractId2);

        ScheduledExecutorService executorService = Executors.newScheduledThreadPool(3);
        Collection<Callable<Response>> calls = List.of(firstReq, secondReq, thirdReq);

        List<Future<Response>> taskFutureList = executorService.invokeAll(calls);

        for (Future<Response> future : taskFutureList) {
            future.get(3, TimeUnit.SECONDS);
        }

        // Check if record un t able audit, allowing a delay after response for writing to the audit table
        List<Audit> list_audit = executorService.schedule(() -> this.auditRepository.findAll(),
                100, TimeUnit.MILLISECONDS
        ).get().stream().sorted(
                (a1, a2) -> a1.getDateAudit().before(a2.getDateAudit()) ? -1 : 1).toList();
        // Collections.reverse(list_audit);
        List<String> correlationId = list_audit.stream().limit(3).map(Audit::getCorrelationId).toList();
        assertThat(correlationId).contains(xFapiInteractId, xFapiInteractId1, xFapiInteractId2);
        assertThat(correlationId.stream().distinct().count()).isEqualTo(3);
        List<String> nameComptes = list_audit.stream().limit(3).map(Audit::getInputAccountName).toList();
        assertThat(nameComptes.stream().distinct().count()).isEqualTo(3);
    }

}
