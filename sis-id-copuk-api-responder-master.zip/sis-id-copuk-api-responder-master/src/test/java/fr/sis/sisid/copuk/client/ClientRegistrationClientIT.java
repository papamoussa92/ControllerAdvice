package fr.sis.sisid.copuk.client;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockserver.client.MockServerClient;
import org.mockserver.model.HttpRequest;
import org.mockserver.model.HttpResponse;
import org.mockserver.model.MediaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import lombok.extern.slf4j.Slf4j;
import reactor.test.StepVerifier;

@Slf4j
class ClientRegistrationClientIT extends SpringTestConfiguration {

    private static final String CLIENT_ID = "07b333d1-ef0b-4cef-b8d9-84dc545f7dd2";

    @Autowired
    @Qualifier("registration-mockserver-client")
    MockServerClient registrationMockClient;

    @Autowired
    private ClientRegistrationClient registrationClient;

    @BeforeEach
    public void mockGetSSA() {
        this.registrationMockClient.reset();
        this.registrationMockClient.when(
                HttpRequest.request("/internal/client/" + CLIENT_ID + "/ssa")
                        .withMethod("GET"))
                .respond(
                        HttpResponse.response(
                                """
                                        {
                                            "jti": "0648d48a-e286-11ec-af8f-8390da2c6d37",
                                            "orgId": "0fff8b86-e286-11ec-b8dc-cf5b826aa923",
                                            "softwareJwksEndpoint": "http://jwks"
                                        }
                                        """)
                                .withStatusCode(200)
                                .withContentType(MediaType.APPLICATION_JSON));
    }

    @Test
    void testGetSSA() {
        StepVerifier.create(this.registrationClient.getSSA(CLIENT_ID))
                .assertNext(response -> Assertions.assertThat(response.getStatusCodeValue()).isEqualTo(200))
                .expectComplete()
                .verify();
    }

    @Test
    void testGetSSA_404() {
        StepVerifier.create(this.registrationClient.getSSA("unknkown-client-id"))
                .assertNext(response -> Assertions.assertThat(response.getStatusCodeValue()).isEqualTo(404))
                .expectComplete()
                .verify();
    }
}
