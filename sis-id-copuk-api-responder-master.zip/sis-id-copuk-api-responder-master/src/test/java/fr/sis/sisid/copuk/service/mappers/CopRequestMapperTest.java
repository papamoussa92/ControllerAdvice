package fr.sis.sisid.copuk.service.mappers;

import fr.sis.sisid.copuk.copapi.model.AccountsNameVerificationData;
import fr.sis.sisid.copuk.copapi.model.InlineObject;
import fr.sis.sisid.copuk.copapi.model.OBExternalAccountType1Code;
import fr.sis.sisid.copuk.ext.bnp.model.AccountIdentificationChoice;
import fr.sis.sisid.copuk.ext.bnp.model.AccountTypeComponent;
import fr.sis.sisid.copuk.ext.bnp.model.CashAccount;
import fr.sis.sisid.copuk.ext.bnp.model.ClearingSystemIdentificationChoice;
import fr.sis.sisid.copuk.ext.bnp.model.ClearingSystemMemberIdentification;
import fr.sis.sisid.copuk.ext.bnp.model.CopRequest;
import fr.sis.sisid.copuk.ext.bnp.model.FinancialInstitutionIdentification;
import fr.sis.sisid.copuk.ext.bnp.model.GenericIdentification;
import fr.sis.sisid.copuk.mappers.CopRequestMapper;
import fr.sis.sisid.copuk.model.AccountType;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import fr.sis.sisid.copuk.service.mapper.CopRequestMapperImpl;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import java.util.Arrays;

class CopRequestMapperTest {

    private CopRequestMapper mapper;

    @Value("${paramsGBDSC.codedentificationChoice}")
    private String codedentificationChoice;

    @Value("${currencyGBP.currency}")
    private String currency;

    @Value("${countryCodeGB.countryCode}")
    private String countryCode;

    @BeforeEach
    public void init() {
        mapper = new CopRequestMapperImpl();
    }

    @Test
    void testToDomain() {
        var inputData = new AccountsNameVerificationData()
                .schemeName(AccountsNameVerificationData.SchemeNameEnum.SORTCODEACCOUNTNUMBER)
                .accountType(OBExternalAccountType1Code.BUSINESS)
                .identification("40638412345678")
                .name("ACME Inc")
                .secondaryIdentification("");
        var input = new InlineObject().data(inputData);
        var expected = CoreCopRequest.builder()
                .accountNumber("12345678")
                .sortCode("406384")
                .name("ACME Inc")
                .xFapiInteractionId("abx-123")
                .accountType(AccountType.BUSINESS)
                .build();
        StepVerifier
                .create(this.mapper.toDomain(Mono.just(input), "abx-123"))
                .expectNext(expected)
                .verifyComplete();
    }

    @Test
    void testToDTO() {
        var inputData = CoreCopRequest.builder()
                .name("ACME Inc")
                .accountNumber("12345678")
                .sortCode("406384")
                .xFapiInteractionId("abx-123")
                .accountType(AccountType.PRIVATE)
                .build();
        var expected = new CopRequest()
                .country(countryCode)
                .financialInstitution(new FinancialInstitutionIdentification()
                        .clearingSystemMemberIdentification(
                                new ClearingSystemMemberIdentification()
                                        .memberIdentification("406384")
                                        .clearingSystemIdentification(
                                                new ClearingSystemIdentificationChoice()
                                                        .code(codedentificationChoice))))
                .account(new CashAccount()
                        .identification(new AccountIdentificationChoice()
                                .other(new GenericIdentification().identification("40638412345678")))
                        .currency(Arrays.asList(currency))
                        .accountType(AccountTypeComponent.PRIVATE));
        Assertions.assertThat(this.mapper.toDTO(inputData)).isEqualTo(expected);
    }
}
