package fr.sis.sisid.copuk.cop.core.rules;

import fr.sis.sisid.copuk.cop.core.CopTestTools;
import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.rules.processors.AccountInfoEnricher;
import fr.sis.sisid.copuk.cop.core.stubs.AccountInfoProviderStub;
import fr.sis.sisid.copuk.copapi.model.ReasonCodes;
import fr.sis.sisid.copuk.model.AccountInfoErrorCode;
import fr.sis.sisid.copuk.model.AccountInfoRejection;
import fr.sis.sisid.copuk.model.AccountType;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.model.MatchingResult;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import reactor.test.StepVerifier;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.stream.Stream;

class AccountTypeMismatchRuleTest {

    private VerificationContext emptyContext;

    @BeforeEach
    public void setup() {
        this.emptyContext = CopTestTools.getVerificationContext(CoreCopRequest.builder().name("test").build());
    }

    @ParameterizedTest
    @MethodSource("testMatchesArguments")
    void testMatches(VerificationContext context, boolean shouldMatch) {
        var accountTypeMismatchRule = new AccountTypeMismatchRule();
        Assertions.assertThat(accountTypeMismatchRule.matches(context)).isEqualTo(shouldMatch);
    }

    @Test
    void testEnrichContext() {
        var accountInfo = AccountInfoRejection.builder()
                .code(AccountInfoErrorCode.UNSUPPORTED_ACCOUNT_TYPE).reason("ERR17: This account type is not supported")
                .build();
        var accountInfoEnricher = new AccountInfoEnricher(
                new AccountInfoProviderStub(accountInfo));
        var rule = new AccountTypeMismatchRule(accountInfoEnricher);
        StepVerifier.create(rule.enrichContext(this.emptyContext))
                .assertNext(ctx -> Assertions.assertThat(ctx.getAccountInfoError()).contains(accountInfo))
                .expectComplete()
                .verify();
    }

    @Test
    void testEnrichContext_replyPresent() {
        this.emptyContext.setReply(CoreCopReply.builder().matched(true).build());
        var rule = new AccountTypeMismatchRule(null);
        StepVerifier.create(rule.enrichContext(emptyContext))
                .expectNext(this.emptyContext)
                .expectComplete().verify();
    }

    @ParameterizedTest
    @MethodSource("testProcessArguments")
    void testProcess(VerificationContext context, boolean matched, ReasonCodes reasonCode, String name) {
        var accountTypeMismatchRule = new AccountTypeMismatchRule();
        Assertions.assertThat(accountTypeMismatchRule.process(context).block().getReply().get().isMatched())
                .isEqualTo(matched);
        Assertions.assertThat(accountTypeMismatchRule.process(context).block().getReply().get().getReasonCode().orElse(null))
                .isEqualTo(reasonCode);
        Assertions.assertThat(accountTypeMismatchRule.process(context).block().getReply().get().getName().orElse(null))
                .isEqualTo(name);
    }

    @Test
    void testProcessEmptyContext() {
        var copRequest = CoreCopRequest.builder().name("test").build();
        var basicContext = CopTestTools.getVerificationContext(copRequest);
        basicContext.setAccountInfo(null);

        var accountTypeMismatchRule = new AccountTypeMismatchRule();

        Assertions.assertThat(accountTypeMismatchRule.process(basicContext).block()).isEqualTo(basicContext);
    }

    private static Stream<Arguments> testMatchesArguments() {
        var emptyContext = CopTestTools.getVerificationContext((CoreCopRequest) null);

        var copRequest = CoreCopRequest.builder().name("test").build();
        var basicContext = CopTestTools.getVerificationContext(copRequest);
        basicContext.setAccountInfo(null);

        var personalRequest = CoreCopRequest.builder().name("name1").accountType(AccountType.PRIVATE).build();
        var matchingContext = CopTestTools.getVerificationContext(personalRequest);
        matchingContext.setAccountInfo(
                CoreAccountInfo.builder().name("name1").accountType(AccountType.BUSINESS).build());

        var businessRequest = CoreCopRequest.builder().name("name1").accountType(AccountType.BUSINESS).build();
        var matchingContext2 = CopTestTools.getVerificationContext(businessRequest);
        matchingContext2.setAccountInfo(
                CoreAccountInfo.builder().name("name1").accountType(AccountType.PRIVATE).build());

        var notMatchingContext = CopTestTools.getVerificationContext(personalRequest);
        notMatchingContext.setAccountInfo(
                CoreAccountInfo.builder().name("name1").accountType(AccountType.PRIVATE).build());

        var notMatchingContext2 = CopTestTools.getVerificationContext(businessRequest);
        notMatchingContext2.setAccountInfo(
                CoreAccountInfo.builder().name("name1").accountType(AccountType.BUSINESS).build());

        return Stream.of(
                Arguments.of(emptyContext, false),
                Arguments.of(basicContext, false),
                Arguments.of(matchingContext, true),
                Arguments.of(matchingContext2, true),
                Arguments.of(notMatchingContext, false),
                Arguments.of(notMatchingContext2, false)
        );
    }

    private static Stream<Arguments> testProcessArguments() {
        var copRequest = CoreCopRequest.builder().name("test").build();
        var noMatch = CopTestTools.getVerificationContext(copRequest);
        noMatch.setAccountInfo(null);
        noMatch.setReply(CoreCopReply.builder()
                .matched(false).build());

        var match = CopTestTools.getVerificationContext(copRequest);
        match.setAccountInfo(null);
        match.setReply(CoreCopReply.builder()
                .matched(true).name(Optional.of("real")).build());

        var matchBusiness = CopTestTools.getVerificationContext(copRequest);
        matchBusiness.setAccountInfo(CoreAccountInfo.builder()
                .accountType(AccountType.BUSINESS)
                .name("real business")
                .build());
        matchBusiness.setReply(CoreCopReply.builder()
                .matched(true).build());

        var matchPersonal = CopTestTools.getVerificationContext(copRequest);
        matchPersonal.setAccountInfo(CoreAccountInfo.builder()
                .accountType(AccountType.PRIVATE)
                .name("real person")
                .build());
        matchPersonal.setReply(CoreCopReply.builder()
                .matched(true).build());

        var closeMatchBusiness = CopTestTools.getVerificationContext(copRequest);
        closeMatchBusiness.setAccountInfo(CoreAccountInfo.builder()
                .accountType(AccountType.BUSINESS)
                .name("real business")
                .build());
        closeMatchBusiness.setReply(CoreCopReply.builder()
                .matched(false)
                .build());
        closeMatchBusiness.setNameMatchingResult(new MatchingResult(BigDecimal.ONE, MatchingDecision.CLOSE_MATCH));

        var closeMatchPersonal = CopTestTools.getVerificationContext(copRequest);
        closeMatchPersonal.setAccountInfo(CoreAccountInfo.builder()
                .accountType(AccountType.PRIVATE)
                .name("real person")
                .build());
        closeMatchPersonal.setReply(CoreCopReply.builder()
                .matched(false).build());
        closeMatchPersonal.setNameMatchingResult(new MatchingResult(BigDecimal.ONE, MatchingDecision.CLOSE_MATCH));




        return Stream.of(
                Arguments.of(noMatch, false, null, null),
                Arguments.of(match, false, null, null),
                Arguments.of(matchBusiness, false, ReasonCodes.BANM, null),
                Arguments.of(matchPersonal, false, ReasonCodes.PANM, null),
                Arguments.of(closeMatchBusiness, false, ReasonCodes.BAMM, "real business"),
                Arguments.of(closeMatchPersonal, false, ReasonCodes.PAMM, "real person")
        );
    }

}