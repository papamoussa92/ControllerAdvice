package fr.sis.sisid.copuk.tools;

import org.testcontainers.shaded.org.apache.commons.lang.StringUtils;

public class TestTools {

    public static boolean shouldMock() {
        return Boolean.parseBoolean(StringUtils.defaultIfBlank(System.getProperty("enable.mockserver"), "true"));
    }
}
