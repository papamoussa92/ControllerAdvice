package fr.sis.sisid.copuk.cop.core.rules;

import java.util.UUID;
import java.util.stream.Stream;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.rules.processors.AccountInfoEnricher;
import fr.sis.sisid.copuk.cop.core.stubs.AccountInfoProviderStub;
import fr.sis.sisid.copuk.copapi.model.ReasonCodes;
import fr.sis.sisid.copuk.model.AccountInfoErrorCode;
import fr.sis.sisid.copuk.model.AccountInfoRejection;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import reactor.test.StepVerifier;

class SortCodeNotSupportedRuleTest {
    private VerificationContext invalidSort;

    @BeforeEach
    public void setup() {
        this.invalidSort = new VerificationContext("org1", UUID.randomUUID().toString(),
                System.currentTimeMillis(),
                CoreCopRequest.builder().name("sortUnknown").accountNumber("30611274476788").build());
    }

    @ParameterizedTest
    @MethodSource("testMatchesArguments")
    void testMatches(VerificationContext context, boolean shouldMatch) {
        var sortCodeNotSupportedRule = new SortCodeNotSupportedRule(null);
        Assertions.assertThat(sortCodeNotSupportedRule.matches(context)).isEqualTo(shouldMatch);
    }

    private static Stream<Arguments> testMatchesArguments() {
        var copRequest = CoreCopRequest.builder().name("Unknow sort code").sortCode("30611274476788").build();
        // has error, correct code -> true
        var contextErrCorrectCode13 = new VerificationContext("org1", UUID.randomUUID().toString(),
                System.currentTimeMillis(), copRequest);
        contextErrCorrectCode13.setAccountInfoError(AccountInfoRejection.builder()
                .code(AccountInfoErrorCode.UNSUPPORTED_CLEARING_SYSTEM_CODE)
                .reason("This is an anormal sort number")
                .build());

        var contextErrCorrectCode14 = new VerificationContext("org1", UUID.randomUUID().toString(),
                System.currentTimeMillis(), copRequest);
        contextErrCorrectCode14.setAccountInfoError(AccountInfoRejection.builder()
                .code(AccountInfoErrorCode.UNKNOWN_MEMBER_ID)
                .reason("This is an anormal sort number")
                .build());

        var contextErrCorrectCode18 = new VerificationContext("org1", UUID.randomUUID().toString(),
                System.currentTimeMillis(), copRequest);
        contextErrCorrectCode18.setAccountInfoError(AccountInfoRejection.builder()
                .code(AccountInfoErrorCode.UNSUPPORTED_CLEARING_SYSTEM)
                .reason("This is an anormal sort number")
                .build());

        var contextErrCorrectCode19 = new VerificationContext("org1", UUID.randomUUID().toString(),
                System.currentTimeMillis(), copRequest);
        contextErrCorrectCode19.setAccountInfoError(AccountInfoRejection.builder()
                .code(AccountInfoErrorCode.IDENTIFICATION_MEMBER_ID_MISMATCH)
                .reason("This is an anormal sort number")
                .build());

        // has error, wrong code -> false
        var contextErrWrongCode = new VerificationContext("org1", UUID.randomUUID().toString(),
                System.currentTimeMillis(), copRequest);
        contextErrWrongCode.setAccountInfoError(AccountInfoRejection.builder()
                .code(AccountInfoErrorCode.ACCOUNT_NOT_FOUND)
                .reason("BUS01: Account data not found")
                .build());
        return Stream.of(
                Arguments.of(contextErrCorrectCode13, true),
                Arguments.of(contextErrCorrectCode14, true),
                Arguments.of(contextErrCorrectCode18, true),
                Arguments.of(contextErrCorrectCode19, true),
                Arguments.of(contextErrWrongCode, false));
    }

    @Test
    void testEnrichContextWithBasSort() {
        var accountInfo = AccountInfoRejection.builder()
                .code(AccountInfoErrorCode.UNSUPPORTED_CLEARING_SYSTEM_CODE).reason("This sort is not supported")
                .build();
        var accountInfoEnricher = new AccountInfoEnricher(
                new AccountInfoProviderStub(accountInfo));
        var rule = new SortCodeNotSupportedRule(accountInfoEnricher);
        StepVerifier.create(rule.enrichContext(this.invalidSort))
                .assertNext(ctx -> Assertions.assertThat(ctx.getAccountInfoError()).contains(accountInfo))
                .expectComplete()
                .verify();
    }

    @Test
    void testProcess() {
        var accountInfo = AccountInfoRejection.builder()
                .code(AccountInfoErrorCode.UNSUPPORTED_CLEARING_SYSTEM_CODE).reason("This sort number is not supported")
                .build();
        var accountInfoEnricher = new AccountInfoEnricher(
                new AccountInfoProviderStub(accountInfo));
        var rule = new SortCodeNotSupportedRule(accountInfoEnricher);

        StepVerifier.create(rule.process(this.invalidSort))
                .assertNext(ctx -> {
                    Assertions.assertThat(ctx.getReply()).isPresent();
                    var reply = ctx.getReply().get();
                    Assertions.assertThat(reply.isMatched()).isFalse();
                    Assertions.assertThat(reply.getName().isEmpty());
                    Assertions.assertThat(reply.getReasonCode()).contains(ReasonCodes.SCNS);
                }).expectComplete().verify();
    }
}
