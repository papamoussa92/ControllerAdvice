package fr.sis.sisid.copuk.validation;

import io.cucumber.core.options.Constants;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.platform.suite.api.ConfigurationParameter;
import org.junit.platform.suite.api.SelectClasspathResource;
import org.junit.platform.suite.api.Suite;

import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Functional tests to be run against target CIB API with preconfiguer data.
 * Only run when a maven "validation" profile is activated
 * To run, add BNPP CIB client key and certificates in classpath : certs/copuk-stg-ev.key and certs/stg-ev_sis-id4banks_com.crt
 */
@Tag("validation")
@Suite
@SelectClasspathResource("validation")
@ConfigurationParameter(key = Constants.PLUGIN_PUBLISH_QUIET_PROPERTY_NAME, value = "true")
@ConfigurationParameter(key = Constants.PLUGIN_PROPERTY_NAME, value = "html:target/validation_report.html")
@ConfigurationParameter(key = Constants.GLUE_PROPERTY_NAME, value = "fr.sis.sisid.copuk.validation")
@ConfigurationParameter(key = Constants.FEATURES_PROPERTY_NAME, value = "classpath:validation")
class BusinessValidationTestCase extends ValidationConfiguration {

    @Test
    void testRunning() {
        assertTrue(true, "Running validation on target API");
    }

}
