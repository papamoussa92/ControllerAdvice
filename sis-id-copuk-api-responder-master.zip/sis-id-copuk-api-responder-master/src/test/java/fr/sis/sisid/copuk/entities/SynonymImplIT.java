package fr.sis.sisid.copuk.entities;

import java.util.Collections;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.jdbc.Sql;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import fr.sis.sisid.copuk.config.CacheConfig;
import fr.sis.sisid.copuk.namematching.model.CompanySynonyms;
import fr.sis.sisid.copuk.namematching.processors.synonym.SynonymRepo;

class SynonymImplIT extends SpringTestConfiguration {

    @Autowired
    private SynonymRepo synonyms;

    @Autowired
    private CompanySynonymSearchDao synonymRepository;

    @Autowired
    private CacheConfig cacheConfig;

    @BeforeEach
    void setup() {
        cacheConfig.initializeCaches(null);
    }

    @Test
    @Sql(scripts = "classpath:data/fuzzy.sql")
    void findByCompanyNameTest() {
        List<CompanySynonyms> actuals = this.synonyms.findByCompanyName(Collections.singleton("FACEBOOK"));
        Assertions.assertThat(actuals)
                .hasSize(3)
                .allMatch(synonym -> synonym.getAccountName().equals("Facebook Company"));
        actuals = this.synonyms.findByCompanyName(List.of("ALPHA", "COMPANY"));
        Assertions.assertThat(actuals)
                .hasSize(4)
                .allMatch(synonym -> synonym.getAccountName().equals("Alpha Beta company"));
    }

    @Test
    @Sql(scripts = "classpath:data/fuzzy.sql")
    void findByCompanyNameTest_cache() {
        this.synonymRepository.deleteAll();
        List<CompanySynonyms> actuals = this.synonyms.findByCompanyName(Collections.singleton("FACEBOOK"));
        Assertions.assertThat(actuals)
                .hasSize(3)
                .allMatch(synonym -> synonym.getAccountName().equals("Facebook Company"));
    }

}
