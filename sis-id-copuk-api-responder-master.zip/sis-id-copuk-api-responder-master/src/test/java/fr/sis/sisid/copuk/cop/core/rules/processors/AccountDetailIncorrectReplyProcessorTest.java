package fr.sis.sisid.copuk.cop.core.rules.processors;

import java.util.Optional;
import java.util.UUID;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.copapi.model.ReasonCodes;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import reactor.test.StepVerifier;

class AccountDetailIncorrectReplyProcessorTest {
    @Test
    void enrichContextTest() {
        VerificationContext input = new VerificationContext("org1", UUID.randomUUID().toString(),
                System.currentTimeMillis(),
                CoreCopRequest.builder().build());
        input.setAccountInfo(CoreAccountInfo.builder().name("compte exist").build());
        var accountDetailIncorrectReplyProcessor = new AccountDetailIncorrectReplyProcessor();
        StepVerifier.create(accountDetailIncorrectReplyProcessor.enrichContext(input))
                .assertNext(ctx -> {
                    Optional<CoreCopReply> reply = ctx.getReply();
                    Assertions.assertThat(reply).isPresent();
                    Assertions.assertThat(reply.get().isMatched()).isFalse();
                    Assertions.assertThat(reply.get().getName()).isEmpty();
                    Assertions.assertThat(reply.get().getReasonCode()).isEqualTo(Optional.of(ReasonCodes.ANNM));
                })
                .expectComplete()
                .verify();
    }
}
