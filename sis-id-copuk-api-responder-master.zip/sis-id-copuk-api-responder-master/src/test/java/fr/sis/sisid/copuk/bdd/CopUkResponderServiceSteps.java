package fr.sis.sisid.copuk.bdd;

import static io.restassured.RestAssured.given;
import static org.apache.http.HttpHeaders.ACCEPT;
import static org.apache.http.HttpHeaders.CONTENT_TYPE;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.IOException;

import org.assertj.core.api.Assertions;
import org.mockserver.client.MockServerClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.util.MultiValueMap;

import com.nimbusds.jose.JOSEException;

import fr.sis.sisid.copuk.OpenBankingConstants;
import fr.sis.sisid.copuk.mockserver.MockUtils;
import fr.sis.sisid.copuk.tokens.NonRepudiationTokenParameters;
import fr.sis.sisid.copuk.tokens.OpenBankingTokenFactory;
import fr.sis.sisid.copuk.tools.RequestSignatureTool;
import fr.sis.sisid.copuk.tools.TokenTool;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CopUkResponderServiceSteps {

    private String path;
    private String body;
    private Response response;

    private final MultiValueMap<String, String> headers = new HttpHeaders();

    @Value("${server.port}")
    private int serverPort;

    @Autowired
    @Qualifier("bnp-mockserver-client")
    MockServerClient payeeInfoMockClient;

    @Autowired
    private TokenTool tokenTool;

    @Value("${non-repudiation.public-key}")
    private String requestSignaturePublicKey;

    @Before("@mock-TC_UK_ERROR")
    public void setupExpectations() {
        MockUtils.mockBnp500(payeeInfoMockClient);
    }

    @Before("@mock-TC_UK_01")
    public void setupValidExpectations() {
        MockUtils.mockTC_UK_01(payeeInfoMockClient, "dolore qui nostrud", "753987", "06006952", "Organisation");
    }

    @Before("@mock-TC_UK_UNKNOWN")
    public void mockUnknownError() {
        MockUtils.mockBnpRejected(payeeInfoMockClient, "ERR99", "Unsupported err code");
    }

    @Given("I make a name verification request to a url {string}")
    public void i_make_a_name_verification_request_to_a_url(String url) {
        RestAssured.baseURI = String.format("http://localhost:%s", serverPort);
        path = url;
    }

    @Given("I set a financial id header {string}")
    public void i_set_a_financial_id_header(String headerValue) {
        headers.set(OpenBankingConstants.ORGANISATION_HEADER, headerValue);
    }

    @Given("I set a Authorization header {string}")
    public void i_set_a_Authorizationheader(String headerValue) {
        headers.set("Authorization", headerValue);
    }

    @Given("I set a valid Authorization header")
    public void i_set_a_Authorizationheader() {
        i_set_a_Authorizationheader("Bearer " + tokenTool.fetchToken());
    }

    @Given("I set an invalid Authorization header")
    public void i_set_invalid_Authorizationheader() {
        i_set_a_Authorizationheader("Bearer thatwontwork");
    }

    @Given("I set an expired Authorization header")
    public void i_set_expired_Authorizationheader() {
        String expiredToken = "eyJhbGciOiJQUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJVVUQzLXpmaWR2NjlDNU5RQ3Q2dFdBajNBNk5zQ3gwVkQ1MWRGRVhVVjZJIn0.eyJleHAiOjE2NTMyOTQxNzUsImlhdCI6MTY1MzI5MzI3NSwianRpIjoiZDFlYTUxNDItZmI0Ni00M2EwLWE4NWEtNzA4OTM4ZmY2Y2I1IiwiaXNzIjoiaHR0cDovL2NvcHVrLWF1dGhvcmlzYXRpb24tc2VydmVyOjkwODAvcmVhbG1zL2NvcHVrIiwic3ViIjoiMTBhZjI4NzctNjc0My00ZmNlLTlmMmEtMWE0MmZmODJkYmE5IiwidHlwIjoiQmVhcmVyIiwiYXpwIjoiNGQ5N2MwYTgtNzllMS00MTVlLTg5NTUtYmQwMjQwZjQ1NmJlIiwic2NvcGUiOiJuYW1lLXZlcmlmaWNhdGlvbiBvcGVuaWQifQ.gtSTYgvoTwil7WrMqGtAQsGnJtOyx0K-qG_dpQqmBlt2swtTpvA20hyjFRSFTCkodJX_KnemergDCWocbaLQzKwWVPwpwJdQjOdjHrosJcoAhi1Q4w1Hqs65XpY5O4701zfKEARUhtdDPyoyVjQ2K9v0f_pGmeKq0x0MN_sKju-Qg3qX14rYAp9Du0qunuOZZ8zrnZqSfxTjgENA0qRC8fMg0H6yMVxhlY4uPxhdT_1qDr4uOf3OwBpLYUvNl3NCrxKcmhKn79V1GoAMSWbA51mFF0n1Ngu_eB9RUMZtXj0twpbAOFA6vtLeCr0sWttABi8TERixf76z9iKjXb3oaw";
        i_set_a_Authorizationheader("Bearer " + expiredToken);
    }

    @Given("I set a non repudiation header {string}")
    public void i_set_a_non_repudiation_header(String headerValue) {
        headers.set(OpenBankingConstants.NON_REPUDIATION_HEADER, headerValue);
    }

    @Given("I set a correlation id header {string}")
    public void i_set_a_correlation_id_header(String headerValue) {
        headers.set(OpenBankingConstants.CORRELATION_ID_HEADER, headerValue);
    }

    @Given("I set a content type header {string}")
    public void i_set_a_content_type_header(String headerValue) {
        headers.set(CONTENT_TYPE, headerValue);
    }

    @Given("I set a accept header {string}")
    public void i_set_a_accept_header(String headerValue) {
        headers.set(ACCEPT, headerValue);
    }

    @Given("I set a body {string}")
    public void i_set_a_body(String body) {
        this.body = body;
    }

    @Given("I set a valid non-repudiation header")
    public void i_set_a_valid_non_repudiation_header() throws IOException, JOSEException {
        var signature = OpenBankingTokenFactory.makeToken(this.nonRepudiationBuilder().build());

        headers.set(OpenBankingConstants.NON_REPUDIATION_HEADER, signature);
    }

    @Given("I set an invalid non-repudiation header")
    public void i_set_an_invalid_non_repudiation_header() throws IOException, JOSEException {
        var token = OpenBankingTokenFactory.makeToken(this.nonRepudiationBuilder().kid("bad_kid").build());
        headers.set(OpenBankingConstants.NON_REPUDIATION_HEADER, token);
    }

    @Given("I set a non-repudiation header missing iss claim")
    public void i_set_a_non_repudiation_header_missing_claim() throws IOException, JOSEException {
        var token = OpenBankingTokenFactory.makeToken(this.nonRepudiationBuilder().iss(null).build());
        headers.set(OpenBankingConstants.NON_REPUDIATION_HEADER, token);
    }

    @Given("I set a malformed non-repudiation header")
    public void i_set_a_malformed_repudiation_header() {
        headers.set(OpenBankingConstants.NON_REPUDIATION_HEADER, "bad_signature");
    }

    @Given("I set a non-repudiation header with invalid claim")
    public void i_set_a_non_repudiation_header_invalid_claim() throws IOException, JOSEException {
        var token = OpenBankingTokenFactory.makeToken(this.nonRepudiationBuilder().tan("invalid_anchor").build());
        headers.set(OpenBankingConstants.NON_REPUDIATION_HEADER, token);
    }

    @Given("I set a non-repudiation header without a kid")
    public void i_set_a_non_repudiation_header_without_a_kid() throws IOException, JOSEException {
        var token = OpenBankingTokenFactory.makeToken(this.nonRepudiationBuilder().kid(null).build());
        headers.set(OpenBankingConstants.NON_REPUDIATION_HEADER, token);
    }

    @Given("I set a incorrect Authorization header")
    public void i_set_an_incorrect_authorisation_header() throws IOException, JOSEException {
        headers.set("Authorization", "Bearerbad_token");
    }

    @When("I send a {string} request")
    public void i_send_a_request(String method) {
        var requestSpec = given()
                .headers(headers);
        if (!"GET".equals(method)) {
            requestSpec = requestSpec.body(body);
        }
        response = requestSpec
                .request(method, path)
                .then().extract().response();
    }

    @Then("I should receive http response code {int}")
    public void i_should_receive_http_response_code(Integer statusCode) {
        assertEquals(statusCode, response.getStatusCode());
    }

    @Then("I should receive error code {string}")
    public void i_should_receive_error_code(String errorCode) {
        var result = response.getBody().jsonPath();

        assertEquals(errorCode, result.getString("Code"));

    }

    @Then("I should receive custom error code {string}")
    public void i_should_receive_custom_error_code(String errorCode) {
        var result = response.getBody().jsonPath();

        org.hamcrest.MatcherAssert.assertThat(result.getList("Errors.ErrorCode"),
                org.hamcrest.Matchers.hasItem(errorCode));
    }

    @Then("I should have an error path of {string}")
    public void i_should_have_an_error_path_of(String path) {
        var result = response.getBody().jsonPath();

        org.hamcrest.MatcherAssert.assertThat(result.getList("Errors.Path"),
                org.hamcrest.Matchers.hasItem(path));
    }

    @Then("I should have a valid jws signature")
    public void i_should_have_a_valid_jws_signature() {
        var rawResponse = this.response.print();
        var jwsSignature = this.response.getHeader(OpenBankingConstants.NON_REPUDIATION_HEADER);
        Assertions.assertThat(rawResponse).isNotBlank();
        Assertions.assertThat(jwsSignature).isNotBlank();
        Assertions.assertThatNoException().isThrownBy(
                () -> RequestSignatureTool.validateSignature(rawResponse, jwsSignature, requestSignaturePublicKey));
    }

    private NonRepudiationTokenParameters.NonRepudiationTokenParametersBuilder nonRepudiationBuilder() {
        return NonRepudiationTokenParameters.builder()
                .rsaKey(RequestSignatureTool.getSigningKey())
                .payload(this.body)
                .kid("OXOKm9U8c48H09zw46P8O54l4QA=")
                .iat(1654268519l)
                .tan("openbanking.org.uk")
                .iss("0014H00003ARnTmQAL/UVpTUUTzBFoQHpISL2ii91");
    }

}
