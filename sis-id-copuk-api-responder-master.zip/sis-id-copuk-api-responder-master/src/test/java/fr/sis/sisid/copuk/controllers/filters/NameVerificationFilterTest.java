package fr.sis.sisid.copuk.controllers.filters;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpMethod;
import org.springframework.http.server.PathContainer;
import org.springframework.http.server.RequestPath;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.web.server.MethodNotAllowedException;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.mockito.Mockito.*;

class NameVerificationFilterTest {

    private RequestPath path;
    private NameVerificationFilter nameVerificationFilter;
    private WebFilterChain alternativeChain;
    private WebFilterChain nameVerificationChain;
    private ServerWebExchange webExchange;
    private ServerHttpRequest request;

    @BeforeEach
    void init() {
        nameVerificationChain = mock(WebFilterChain.class);
        alternativeChain = mock(WebFilterChain.class);
        nameVerificationFilter = new NameVerificationFilter("/api/v*/pay.uk") {
            @Override protected Mono<Void> nameVerificationFilter(ServerWebExchange exchange, WebFilterChain chain) {
                return nameVerificationChain.filter(exchange);
            }
        };
        webExchange = mock(ServerWebExchange.class);
        request = mock(ServerHttpRequest.class);
        path = mock(RequestPath.class);
        when(request.getPath()).thenReturn(path);

        when(webExchange.getRequest()).thenReturn(request);
    }

    @Test
    void testPatternNotMatchingFilter() {
        PathContainer pathContainer = PathContainer.parsePath("/api");
        when(path.pathWithinApplication()).thenReturn(pathContainer);
        when(request.getMethod()).thenReturn(HttpMethod.POST);

        nameVerificationFilter.filter(webExchange, alternativeChain);

        // No match
        verify(alternativeChain).filter(webExchange);
        verifyNoInteractions(nameVerificationChain);

    }

    @Test
    void testPatternMatchingFilter() {
        PathContainer pathContainer = PathContainer.parsePath("/api/v1.0/pay.uk/accounts/name-verifivcation");
        when(path.pathWithinApplication()).thenReturn(pathContainer);
        when(request.getMethod()).thenReturn(HttpMethod.POST);

        nameVerificationFilter.filter(webExchange, alternativeChain);

        // No match
        verify(nameVerificationChain).filter(webExchange);
        verifyNoInteractions(alternativeChain);

    }

    @Test
    void testMethodInvalidMatchingFilter() {
        PathContainer pathContainer = PathContainer.parsePath("/api/v1.0/pay.uk/accounts/name-verifivcation");
        when(path.pathWithinApplication()).thenReturn(pathContainer);
        when(request.getMethod()).thenReturn(HttpMethod.GET);

        StepVerifier.create(nameVerificationFilter.filter(webExchange, alternativeChain))
                        .expectError(MethodNotAllowedException.class);


        // No match
        verifyNoInteractions(nameVerificationChain);
        verifyNoInteractions(alternativeChain);

    }

}