package fr.sis.sisid.copuk.api;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.PlainHeader;
import com.nimbusds.jose.PlainObject;
import fr.sis.sisid.copuk.SpringTestConfiguration;
import fr.sis.sisid.copuk.copapi.model.AccountsNameVerificationData;
import fr.sis.sisid.copuk.copapi.model.InlineObject;
import fr.sis.sisid.copuk.copapi.model.OBExternalAccountType1Code;
import fr.sis.sisid.copuk.mockserver.MockUtils;
import fr.sis.sisid.copuk.tools.NameVerificationRequestTools;
import fr.sis.sisid.copuk.tools.TokenTool;
import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockserver.client.MockServerClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;

import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class AlgNoneNameVerificationIT extends SpringTestConfiguration {

    @LocalServerPort
    private int serverPort;

    @Value("${spring.security.oauth2.client.registration.copuk-auth.client-id}")
    private String clientId = "test-client";

    @Value("${app.organisation-id}")
    private String orgId;

    @Autowired
    @Qualifier("registration-mockserver-client")
    MockServerClient registrationMockServer;

    @Autowired
    @Qualifier("bnp-mockserver-client")
    MockServerClient payeeInfoMockClient;

    @Autowired
    private TokenTool tokenTool;

    @BeforeEach
    void setup() {
        MockUtils.mockSsa(registrationMockServer, clientId);
        MockUtils.mockTC_UK_01(payeeInfoMockClient, "some account", "123456", "74859698", "BUSINESS");
    }

    @Test
    void algNoneNameVerification() throws JsonProcessingException {
        var requestBody = new InlineObject().data(new AccountsNameVerificationData()
                .schemeName(AccountsNameVerificationData.SchemeNameEnum.SORTCODEACCOUNTNUMBER)
                .accountType(OBExternalAccountType1Code.BUSINESS)
                .identification("12345674859698")
                .name("some account"));

        var mapper = new ObjectMapper();
        String serializedBody = mapper.writeValueAsString(requestBody);

        var headers = NameVerificationRequestTools.getRequestHeaders(
                orgId, tokenTool.fetchToken(), "71216ad2-f7b3-11ec-85e0-57cb18777a1f",
                algNoneSignature(serializedBody));

        RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
        RestAssured.baseURI = String.format("http://localhost:%s", serverPort);

        Response response = RestAssured.given()
                .headers(headers)
                .body(serializedBody)
                .request(Method.POST, "/api/v1.0/pay.uk/accounts/name-verification")
                .then().extract().response();
        Assertions.assertThat(response.getStatusCode()).isEqualTo(400);
    }

    String algNoneSignature(String content) {
        Payload payload = new Payload(content);
        PlainHeader header = new PlainHeader.Builder()
                .type(JOSEObjectType.JOSE)
                .contentType("application/json")
                .customParam("http://openbanking.org.uk/iat", 1654268519)
                .customParam("http://openbanking.org.uk/tan", "openbanking.org.uk")
                .customParam("http://openbanking.org.uk/iss", "0014H00003ARnTmQAL/UVpTUUTzBFoQHpISL2ii91")
                .criticalParams(
                        Stream.of(
                                "http://openbanking.org.uk/iat",
                                "http://openbanking.org.uk/tan",
                                "http://openbanking.org.uk/iss")
                                .collect(Collectors.toSet()))
                .build();
        PlainObject token = new PlainObject(header, payload);
        String signature = token.serialize().split("\\.")[0] + "..";
        log.info("alg:none signature : {}", signature);
        return signature;
    }

}
