package fr.sis.sisid.copuk.tools;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Slf4j
@Component
public class TokenTool {

    @Value("${spring.security.oauth2.client.provider.copuk-auth.token-uri}")
    private String authTokenUri;

    @Value("${spring.security.oauth2.client.registration.copuk-auth.client-secret}")
    private String clientSecret = "8VkxWMzycKI40P5gyQWNnr9YUNciwmL4";
    @Value("${spring.security.oauth2.client.registration.copuk-auth.client-id}")
    private String clientId = "test-client";
    @Autowired
    ClientHttpConnector httpConnector;
    public String fetchToken() {
        WebClient webClient = WebClient.builder()
                .clientConnector(httpConnector)
                .build();
        Mono<String> resource = webClient.post()
                .uri(authTokenUri)
                .body(BodyInserters.fromFormData("grant_type", "client_credentials")
                        .with("client_id", clientId)
                        .with("client_secret", clientSecret)
                )
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .bodyToMono(JsonNode.class)
                .map(tokenResponse -> tokenResponse.get("access_token").textValue());

        return resource.block();
    }
}
