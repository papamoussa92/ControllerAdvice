package fr.sis.sisid.copuk.controllers.filters;

import org.junit.jupiter.api.Test;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DefaultDataBuffer;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import org.springframework.http.server.reactive.ServerHttpRequest;
import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class RequestBodyDecoratorTest {

    @Test
    void testBodyAsString() {
        DefaultDataBufferFactory factory = DefaultDataBufferFactory.sharedInstance;
        Charset charset = StandardCharsets.UTF_8;
        DefaultDataBuffer db1 = factory.wrap(ByteBuffer.wrap("line1".getBytes(charset)));
        DefaultDataBuffer db2 = factory.wrap(ByteBuffer.wrap("line2".getBytes(charset)));
        Flux<DataBuffer> bodyBuffer = Flux.just(db1, db2);
        var request = mock(ServerHttpRequest.class);

        when(request.getBody()).thenReturn(bodyBuffer);

        RequestBodyDecorator requestBodyDecorator = new RequestBodyDecorator(request);




        assertEquals("line1line2", requestBodyDecorator.getBodyAsString().block());
        Flux<DataBuffer> body = requestBodyDecorator.getBody();
        StepVerifier.create(body)
                        .expectNextMatches(d -> "line1".equals(d.toString(charset)))
                        .expectNextMatches(d -> "line2".equals( d.toString(charset)))
                                .verifyComplete();




    }
}