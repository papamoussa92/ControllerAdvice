package fr.sis.sisid.copuk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.BindMode;
import org.testcontainers.containers.MockServerContainer;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.containers.wait.strategy.Wait;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;

import dasniko.testcontainers.keycloak.KeycloakContainer;
import fr.sis.sisid.copuk.tools.TestTools;
import io.cucumber.spring.CucumberContextConfiguration;
import lombok.extern.slf4j.Slf4j;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT)
@Testcontainers
@Slf4j
public class SpringTestConfiguration {
    private static final String POSTGRES_VERSION = "postgres:14";
    public static final String MOCKSERVER_VERSION = "mockserver/mockserver:5.13.2";
    public static final String KEYCLOAK_VERSION = "quay.io/keycloak/keycloak:18.0.0";
    public static PostgreSQLContainer<?> dbContainer;

    /**
     * Enables persistence of containers after test have been run.
     * Beware, the property "testcontainers.reuse.enable=true" also needs to be included in $HOME/.testcontainers.properties
     */
    private static final boolean REUSE_CONTAINERS = true;

    @Autowired
    ClientHttpConnector httpConnector;

    @DynamicPropertySource
    static void registerPgProperties(DynamicPropertyRegistry registry) {
        var containers = new ArrayList<LifecycledContainer>();
        var c = initPGContainer(registry);
        containers.add(c);

        if (TestTools.shouldMock()) {
            containers.add(initMockServerContainer(registry));
            containers.add(initBNPPKeyCloak(registry));
            containers.add(initAuthServerKeyCloak(registry));
            containers.add(initClientRegistrationMockServer(registry));
        }

        containers.stream().parallel().forEach(LifecycledContainer::create);
        dbContainer = c.getContainer();

        containers.stream().parallel().forEach(LifecycledContainer::start);
        containers.forEach(LifecycledContainer::postConfigure);
    }

    public static LifecycledContainer<PostgreSQLContainer> initPGContainer(DynamicPropertyRegistry registry) {
        return new LifecycledContainer<>() {

            private PostgreSQLContainer postgreSQLContainer;

            @Override
            public PostgreSQLContainer create() {
                postgreSQLContainer = new PostgreSQLContainer<>(POSTGRES_VERSION);
                postgreSQLContainer.withReuse(REUSE_CONTAINERS)
                        .withLabel("reuse.UUID", "1daab0d0-e277-11ec-93f9-77a3bb971fdc");
                return postgreSQLContainer;
            }

            @Override
            public void postConfigure() {
                log.info("######### BD is running ");
                log.info(postgreSQLContainer.getJdbcUrl());
                log.info("######### BD is running ");
                log.info("Url {},User {}, Password {}", postgreSQLContainer.getJdbcUrl(),
                        postgreSQLContainer.getUsername(), postgreSQLContainer.getPassword());
                registry.add("DB_URL", () -> postgreSQLContainer.getJdbcUrl());
                registry.add("DB_USERNAME", () -> postgreSQLContainer.getUsername());
                registry.add("DB_PASSWORD", () -> postgreSQLContainer.getPassword());
            }

            @Override
            public PostgreSQLContainer getContainer() {
                return postgreSQLContainer;
            }
        };
    }

    public static LifecycledContainer<MockServerContainer> initMockServerContainer(DynamicPropertyRegistry registry) {
        return new LifecycledContainer<>() {

            MockServerContainer mockServerContainer;

            @Override
            public MockServerContainer create() {
                // mockserver test container setup
                // mockserver configuration, passed through environment variables
                Map<String, String> mockserverProperties = new HashMap<>();
                // CA private key
                mockserverProperties.put("MOCKSERVER_CERTIFICATE_AUTHORITY_PRIVATE_KEY", "/config/bnpCA-key.pem");
                // CA cert
                mockserverProperties.put("MOCKSERVER_CERTIFICATE_AUTHORITY_X509_CERTIFICATE", "/config/bnpCA-cert.pem");
                // server cert, must be for domain "docker" in CI env, for domain "localhost"
                // for local env
                mockserverProperties.put("MOCKSERVER_TLS_X509_CERTIFICATE_PATH", "/config/bnp-docker-server.pem");
                // server provate key
                mockserverProperties.put("MOCKSERVER_TLS_PRIVATE_KEY_PATH", "/config/bnp-server-key.pem");
                // let the server parse certs at boot
                mockserverProperties.put("MOCKSERVER_PROACTIVELY_INITIALISE_TLS", "true");
                // enable mtls
                mockserverProperties.put("MOCKSERVER_TLS_MUTUAL_AUTHENTICATION_REQUIRED", "true");

                mockServerContainer = new MockServerContainer(DockerImageName.parse(MOCKSERVER_VERSION))
                        // mount volume with all the certs
                        .withClasspathResourceMapping("certs/mockserver", "/config", BindMode.READ_ONLY)
                        .withEnv(mockserverProperties)
                        .withReuse(REUSE_CONTAINERS)
                        .withLabel("reuse.UUID", "0bee9154-e277-11ec-a6fa-4bc0b95612f7")
                        // disable waiting for mockserver test container healthcheck at /status
                        // test container does not trust our test CA
                        .waitingFor(Wait.forListeningPort());
                return mockServerContainer;

            }

            @Override
            public void postConfigure() {
                String mockserverAddress = "https://" + mockServerContainer.getContainerIpAddress() + ":"
                        + mockServerContainer.getServerPort();

                registry.add("app.bnp.payee-information-srv.url", () -> mockserverAddress);
                registry.add("mockserver.ip", mockServerContainer::getContainerIpAddress);
                registry.add("mockserver.port", mockServerContainer::getServerPort);
            }

            @Override
            public MockServerContainer getContainer() {
                return mockServerContainer;
            }
        };
    }

    public static LifecycledContainer<KeycloakContainer> initBNPPKeyCloak(DynamicPropertyRegistry registry) {
        return new LifecycledContainer<>() {

            KeycloakContainer keycloakContainer;

            @Override
            public KeycloakContainer create() {
                // keycloak test container setup
                Map<String, String> keycloakProperties = new HashMap<>();
                keycloakProperties.put("KC_HTTPS_TRUST_STORE_FILE", "/etc/x509/https/truststore-bnp.jks");
                keycloakProperties.put("KC_HTTPS_TRUST_STORE_PASSWORD", "copuk!");
                keycloakProperties.put("KC_HTTPS_CLIENT_AUTH", "required");

                keycloakContainer = new KeycloakContainer(KEYCLOAK_VERSION).withRealmImportFile(
                                "/keycloak/realm-bnp.json")
                        .useTls("/keycloak/bnp-docker-server.pem", "/keycloak/bnp-server.pem")
                        .withReuse(REUSE_CONTAINERS)
                        .withLabel("reuse.UUID", "1684ff40-e277-11ec-bf03-078ab6398fc0")
                        .withClasspathResourceMapping("/keycloak/truststore-bnp.jks",
                                "/etc/x509/https/truststore-bnp.jks", BindMode.READ_ONLY)
                        .withEnv(keycloakProperties);
                return keycloakContainer;
            }

            @Override
            public void postConfigure() {
                String tokenUri = "%srealms/bnp/protocol/openid-connect/token".formatted(
                        keycloakContainer.getAuthServerUrl());
                log.info("Keycloak test container is up, token uri is : {}", tokenUri);
                registry.add("spring.security.oauth2.client.provider.bnp.token-uri", () -> tokenUri);
            }

            @Override
            public KeycloakContainer getContainer() {
                return keycloakContainer;
            }
        };
    }

    public static LifecycledContainer<KeycloakContainer> initAuthServerKeyCloak(DynamicPropertyRegistry registry) {
        return new LifecycledContainer<>() {

            KeycloakContainer keycloakContainer;

            @Override
            public KeycloakContainer create() {
                // keycloak test container setup
                Map<String, String> keycloakProperties = new HashMap<>();
                keycloakProperties.put("KC_HTTPS_TRUST_STORE_FILE", "/etc/x509/https/truststore-bnp.jks");
                keycloakProperties.put("KC_HTTPS_TRUST_STORE_PASSWORD", "copuk!");
                keycloakContainer = new KeycloakContainer(KEYCLOAK_VERSION)
                        .withRealmImportFile("/keycloak/copuk-realm.json")
                        .withClasspathResourceMapping("/keycloak/truststore-bnp.jks",
                                "/etc/x509/https/truststore-bnp.jks", BindMode.READ_ONLY)
                        .withEnv(keycloakProperties)
                        .withReuse(REUSE_CONTAINERS)
                        .withLabel("reuse.UUID", "b8881a08-e276-11ec-82e7-e75dc45fe342");

                return keycloakContainer;
            }

            @Override
            public void postConfigure() {
                String authTokenUri = "%srealms/copuk/protocol/openid-connect/token".formatted(
                        keycloakContainer.getAuthServerUrl());
                String certsUri = "%srealms/copuk/protocol/openid-connect/certs".formatted(
                        keycloakContainer.getAuthServerUrl());
                String issuerUri = "%srealms/copuk".formatted(
                        keycloakContainer.getAuthServerUrl());
                registry.add("spring.security.oauth2.resourceserver.jwt.jwk-set-uri", () -> certsUri);
                registry.add("spring.security.oauth2.resourceserver.jwt.issuer-uri", () -> issuerUri);
                registry.add("spring.security.oauth2.client.provider.copuk-auth.token-uri", () -> authTokenUri);
            }

            @Override
            public KeycloakContainer getContainer() {
                return keycloakContainer;
            }
        };
    }

    public static LifecycledContainer<MockServerContainer> initClientRegistrationMockServer(
            DynamicPropertyRegistry registry) {
        return new LifecycledContainer<>() {

            private MockServerContainer container;

            @Override
            public MockServerContainer create() {
                container = new MockServerContainer(DockerImageName.parse(MOCKSERVER_VERSION))
                        .withReuse(REUSE_CONTAINERS)
                        .withLabel("reuse.UUID", "4c46e862-e283-11ec-b6c9-fb20b82c2872");
                return container;
            }

            @Override
            public void postConfigure() {
                registry.add("app.client-registration-url",
                        () -> "http://" + container.getContainerIpAddress() + ":" + container.getServerPort());
                registry.add("mockserver.registration.ip", () -> container.getContainerIpAddress());
                registry.add("mockserver.registration.port", () -> container.getServerPort());
            }

            @Override
            public MockServerContainer getContainer() {
                return container;
            }
        };
    }

}
