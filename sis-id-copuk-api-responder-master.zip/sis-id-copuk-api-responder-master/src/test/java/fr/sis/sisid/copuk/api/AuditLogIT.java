package fr.sis.sisid.copuk.api;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import fr.sis.sisid.copuk.copapi.model.InlineResponse200;
import fr.sis.sisid.copuk.copapi.model.OBErrorResponse1;
import fr.sis.sisid.copuk.copapi.model.OBExternalAccountType1Code;
import fr.sis.sisid.copuk.copapi.model.ReasonCodes;
import fr.sis.sisid.copuk.dto.AsymetricEncoder;
import fr.sis.sisid.copuk.entities.Audit;
import fr.sis.sisid.copuk.entities.AuditRepository;
import fr.sis.sisid.copuk.entities.NameMatchingLogRepository;
import fr.sis.sisid.copuk.mockserver.MockUtils;
import fr.sis.sisid.copuk.tools.NameVerificationRequestTools;
import fr.sis.sisid.copuk.tools.TokenTool;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.api.Assertions;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockserver.client.MockServerClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.web.server.LocalServerPort;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Optional;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasSize;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@Slf4j
class AuditLogIT extends SpringTestConfiguration {

    @Autowired
    private AsymetricEncoder asymetricEncoder;


    @Autowired
    private AuditRepository auditRepository;

    @Autowired
    private NameMatchingLogRepository nmlRepository;

    @Autowired
    private TokenTool tokenTool;

    @LocalServerPort
    private int serverPort;

    @Value("${spring.security.oauth2.client.registration.copuk-auth.client-id}")
    private String clientId = "test-client";

    @Value("${app.organisation-id}")
    private String orgId;

    @Autowired
    @Qualifier("registration-mockserver-client")
    MockServerClient registrationMockServer;

    @Autowired
    @Qualifier("bnp-mockserver-client")
    MockServerClient payeeInfoMockClient;

    @Value("${app.identifiant-ssa-private-key}")
    private String privateKey;

    @Value("${app.identifiant-ssa-public-key}")
    private String publicKey;

    @BeforeEach
    void setup() {
        MockUtils.mockSsa(registrationMockServer, clientId);
        MockUtils.mockTC_UK_01(payeeInfoMockClient, "Nestlé SA", "1234567", "4859698", "Organisation");
        nmlRepository.deleteAll();
        auditRepository.deleteAll();
    }

    @Test
    void nameVerificationRequestGetsLogged() throws Exception {
        Timestamp testStart = new Timestamp(System.currentTimeMillis());
        // perform a name verification request
        String accountName = "Nestle SARL";
        var response = NameVerificationRequestTools.performNameVerification(accountName, orgId, tokenTool,
                serverPort);
        InlineResponse200 parsedResponse = response.getBody().as(InlineResponse200.class);
        Assertions.assertThat(parsedResponse.getData().getVerificationReport().getMatched()).isFalse();
        Assertions.assertThat(parsedResponse.getData().getVerificationReport().getReasonCode())
                .isEqualTo(ReasonCodes.MBAM);
        // make sure it gets logged
        // we sleep here, because the logging is triggered AFTER the reply has been sent
        ScheduledExecutorService executorService = Executors.newScheduledThreadPool(1);
        var auditFuture = executorService.schedule(() -> auditRepository.findAll(),
                100, TimeUnit.MILLISECONDS);

        var auditLines = auditFuture.get();
        assertThat(auditLines, hasSize(1));

        var auditLine = auditLines.get(0);
        Assertions.assertThat(auditLine)
                .doesNotReturn(null, Audit::getDateAudit)
                .returns(NameVerificationRequestTools.getInteractionId(), Audit::getCorrelationId)
                .returns(accountName, Audit::getInputAccountName)
                .returns("Nestlé SA", Audit::getAccountNameFromCibApi)
                .returns(false, Audit::getMatched)
                .returns(true, audit -> Matchers.greaterThan(BigDecimal.ZERO).matches(audit.getScore()))
                .returns(true, audit -> Matchers.greaterThan(BigDecimal.ZERO).matches(audit.getMatchThreshold()))
                .returns(true, audit -> Matchers.greaterThan(BigDecimal.ZERO).matches(audit.getClosematchThreshold()))
                .doesNotReturn(null, Audit::getConfigurationVersion)
                .doesNotReturn(null, Audit::getEngineVersion)
                .returns(NameVerificationRequestTools.getDefaultIdentification(),
                        audit -> {
                            var docoder = new AsymetricEncoder(Optional.of(privateKey), publicKey);
                           return docoder.decryptFromBase64(audit.getIdentification());
                        })
                .returns(OBExternalAccountType1Code.BUSINESS.name(), Audit::getPayeeAccountType)
                .returns("OK", Audit::getStatusHttpCode)
                .returns(null, Audit::getOpenBankingErrorCode)
                .returns("GBP", Audit::getAccountCurrency)
                .returns("MBAM", Audit::getMatchingReasonCode)
                .returns(true, audit -> Matchers.greaterThan(testStart).matches(audit.getCopRequestTimestamp()))
                .returns(true,
                        audit -> Matchers.greaterThan(auditLine.getCopRequestTimestamp())
                                .matches(audit.getCopResponseTimestamp()))
                .returns(true, audit -> Matchers.greaterThan(testStart).matches(audit.getCibApiRequestTimestamp()))
                .returns(true,
                        audit -> Matchers.greaterThan(audit.getCibApiRequestTimestamp())
                                .matches(audit.getCibApiResponseTimestamp()))
                .returns(clientId, Audit::getClientId)
                .returns(orgId, Audit::getOrganizationId)
                .returns("CLOSE-MATCH", Audit::getRules);

        var nmlOpt = this.nmlRepository.findAll().stream().filter(nml -> nml.getRuleCode().equals("MR-003")).findFirst();
        Assertions.assertThat(nmlOpt).isPresent();
    }

    @Test
    void nameVerificationRequestGetsLoggedWithAuthorisationError() throws Exception {
        // perform a name verification request
        String accountName = "Nestle SARL";

        var brokenTokenTool = mock(TokenTool.class);
        when(brokenTokenTool.fetchToken()).thenReturn("badtoken");

        var response = NameVerificationRequestTools.performNameVerification(accountName, orgId, brokenTokenTool,
                serverPort);
        OBErrorResponse1 parsedResponse = response.getBody().as(OBErrorResponse1.class);
        assertEquals("401", parsedResponse.getCode());

        // make sure it gets logged
        // we sleep here, because the logging is triggered AFTER the reply has been sent
        ScheduledExecutorService executorService = Executors.newScheduledThreadPool(1);
        var auditFuture = executorService.schedule(() -> auditRepository.findAll(),
                100, TimeUnit.MILLISECONDS);

        var auditLines = auditFuture.get();
        assertThat(auditLines, hasSize(1));

        var auditLine = auditLines.get(0);

        Assertions.assertThat(auditLine)
                .doesNotReturn(null, Audit::getDateAudit)
                .returns(NameVerificationRequestTools.getInteractionId(), Audit::getCorrelationId)
                .returns(null, Audit::getInputAccountName)
                .returns(null, Audit::getAccountNameFromCibApi)
                .returns(false, Audit::getMatched)
                .returns(null, Audit::getScore)
                .returns(true, audit -> Matchers.greaterThan(BigDecimal.ZERO).matches(audit.getMatchThreshold()))
                .returns(true, audit -> Matchers.greaterThan(BigDecimal.ZERO).matches(audit.getClosematchThreshold()))
                .doesNotReturn(null, Audit::getConfigurationVersion)
                .doesNotReturn(null, Audit::getEngineVersion)
                .returns(null, Audit::getIdentification)
                .returns(null, Audit::getPayeeAccountType)
                .returns("UNAUTHORIZED", Audit::getStatusHttpCode)
                .returns(null, Audit::getOpenBankingErrorCode)
                .returns(null, Audit::getAccountCurrency)
                .returns(null, Audit::getMatchingReasonCode)
                .doesNotReturn(null, Audit::getCopRequestTimestamp)
                .doesNotReturn(null, Audit::getCopResponseTimestamp)
                .returns(true,
                        audit -> Matchers.greaterThan(audit.getCopRequestTimestamp())
                                .matches(audit.getCopResponseTimestamp()))
                .returns(null, Audit::getCibApiRequestTimestamp)
                .returns(null, Audit::getCibApiResponseTimestamp)
                .returns(null, Audit::getClientId)
                .returns(null, Audit::getOrganizationId)
                .returns(null, Audit::getRules);

        var nmlOpt = this.nmlRepository.findAll().stream().filter(nml -> nml.getRuleCode().equals("RL003")).findFirst();
        Assertions.assertThat(nmlOpt).isEmpty();
    }

}
