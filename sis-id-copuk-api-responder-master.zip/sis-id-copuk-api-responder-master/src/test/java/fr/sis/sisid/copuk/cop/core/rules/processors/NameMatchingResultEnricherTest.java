package fr.sis.sisid.copuk.cop.core.rules.processors;

import fr.sis.sisid.copuk.cop.core.CopTestTools;
import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.stubs.AccountInfoProviderStub;
import fr.sis.sisid.copuk.cop.core.stubs.NameMatchingProviderStub;
import fr.sis.sisid.copuk.cop.spi.AccountInfoProvider;
import fr.sis.sisid.copuk.model.AccountInfoErrorCode;
import fr.sis.sisid.copuk.model.AccountInfoRejection;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.model.MatchingResult;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import reactor.test.StepVerifier;

import java.math.BigDecimal;

class NameMatchingResultEnricherTest {

    NameMatchingResultEnricher nameMatchingEnricher;

    NameMatchingProviderStub nameMatchingProvider;

    @BeforeEach
    void setup() {
        AccountInfoProvider accountInfoProvider = new AccountInfoProviderStub(
                CoreAccountInfo.builder().name("name").build());
        AccountInfoEnricher accountInfoEnricher = new AccountInfoEnricher(accountInfoProvider);
        this.nameMatchingProvider = new NameMatchingProviderStub(
                new MatchingResult(new BigDecimal("0.7"), MatchingDecision.CLOSE_MATCH));
        this.nameMatchingEnricher = new NameMatchingResultEnricher(
                accountInfoEnricher, nameMatchingProvider);
    }

    @Test
    void enrichContextTest() {
        VerificationContext input = CopTestTools.getVerificationContext(CoreCopRequest.builder().name("other name").build());

        StepVerifier.create(nameMatchingEnricher.enrichContext(input))
                .expectNextMatches(ctx -> ctx.getNameMatchingResult().isPresent()
                        && ctx.getNameMatchingResult().get().getScore().getDecision()
                                .equals(MatchingDecision.CLOSE_MATCH))
                .expectComplete().verify();
        Assertions.assertThat(nameMatchingProvider.getInput()).isEqualTo("other name");
        Assertions.assertThat(nameMatchingProvider.getTarget()).isEqualTo("name");
    }

    @Test
    void enrichContext_resultPresentTest() {
        VerificationContext input = CopTestTools.getVerificationContext(CoreCopRequest.builder().name("other name").build());
        input.setNameMatchingResult(new MatchingResult(new BigDecimal("0.2"), MatchingDecision.NO_MATCH));
        StepVerifier.create(nameMatchingEnricher.enrichContext(input))
                .expectNextMatches(ctx -> ctx.getNameMatchingResult().get().getScore().getDecision()
                        .equals(MatchingDecision.NO_MATCH))
                .expectComplete().verify();
    }

    @Test
    void enrichContext_doesNothingWhenNoAccountInfo() {
        AccountInfoProvider errorAccountInfoProvider = new AccountInfoProviderStub(
                AccountInfoRejection.builder().code(AccountInfoErrorCode.ACCOUNT_NOT_FOUND).build());
        AccountInfoEnricher errorAccountInfoEnricher = new AccountInfoEnricher(errorAccountInfoProvider);
        var errorNameMatchingEnricher = new NameMatchingResultEnricher(
                errorAccountInfoEnricher, nameMatchingProvider);
        VerificationContext input = CopTestTools.getVerificationContext(CoreCopRequest.builder().name("other name").build());

        StepVerifier.create(errorNameMatchingEnricher.enrichContext(input))
                .assertNext(ctx -> {
                    ctx.getNameMatchingResult().isEmpty();
                }).expectComplete().verify();
    }
}
