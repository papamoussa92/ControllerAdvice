package fr.sis.sisid.copuk.mockserver;

import org.mockserver.client.MockServerClient;
import org.slf4j.event.Level;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class MockConfig {

    @Value("${mockserver.ip:localhost}")
    String mockServerIp;

    @Value("${mockserver.port:1085}")
    Integer mockServerPort;

    @Value("${mockserver.registration.port:1084}")
    Integer registrationMockserverPort;

    @Value("${mockserver.registration.ip:localhost}")
    String registrationMockServerIp;

    @Bean("bnp-mockserver-client")
    public MockServerClient bnpMockServerClient() {
        log.debug("setting up a bnp mockServerClient");
        org.mockserver.configuration.Configuration mockserverClientConfig = org.mockserver.configuration.Configuration
                .configuration()
                // mockserver client shoud use mtls
                .controlPlaneTLSMutualAuthenticationRequired(true)
                // CA
                .controlPlaneTLSMutualAuthenticationCAChain("certs/mockserver/bnpCA-cert.pem")
                // key
                .controlPlanePrivateKeyPath("certs/mockserver/bnp-responder-client-key-PKCS_8.pem")
                // cert
                .controlPlaneX509CertificatePath("certs/mockserver/bnp-responder-client.pem")
                .logLevel(Level.INFO);
        var mockserverClient = new MockServerClient(mockserverClientConfig, mockServerIp, mockServerPort)
                .withSecure(true);
        return mockserverClient;
    }

    @Bean("registration-mockserver-client")
    public MockServerClient registrationMockServerClient() {
        log.debug("setting up a registration mockServerClient");
        return new MockServerClient(registrationMockServerIp, registrationMockserverPort);
    }

}
