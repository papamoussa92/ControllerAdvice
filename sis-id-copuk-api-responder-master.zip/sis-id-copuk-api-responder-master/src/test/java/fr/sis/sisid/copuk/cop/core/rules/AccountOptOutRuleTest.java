package fr.sis.sisid.copuk.cop.core.rules;

import fr.sis.sisid.copuk.cop.core.CopTestTools;
import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.rules.processors.AccountInfoEnricher;
import fr.sis.sisid.copuk.cop.core.stubs.AccountInfoProviderStub;
import fr.sis.sisid.copuk.copapi.model.ReasonCodes;
import fr.sis.sisid.copuk.model.AccountInfoErrorCode;
import fr.sis.sisid.copuk.model.AccountInfoRejection;
import fr.sis.sisid.copuk.model.AccountType;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import reactor.test.StepVerifier;

import java.util.Optional;
import java.util.stream.Stream;

class AccountOptOutRuleTest {

    AccountInfoRejection accountInfoError = AccountInfoRejection.builder()
            .code(AccountInfoErrorCode.ACCOUNT_OPT_OUT)
            .reason("ERR90: opt out")
            .build();

    VerificationContext verificationContext = CopTestTools.getVerificationContext(
            CoreCopRequest.builder()
                    .name("some account")
                    .sortCode("123456")
                    .accountNumber("0123456789")
                    .accountType(AccountType.BUSINESS)
                    .build());

    @ParameterizedTest
    @MethodSource("testMatchesArguments")
    void testMatches(VerificationContext context, boolean shouldMatch) {
        var rule = new AccountOptOutRule(null);
        Assertions.assertThat(rule.matches(context)).isEqualTo(shouldMatch);
    }

    private static Stream<Arguments> testMatchesArguments() {
        var copRequest = CoreCopRequest.builder()
                .name("some account")
                .sortCode("123456")
                .accountNumber("0123456789")
                .accountType(AccountType.BUSINESS)
                .build();
        var contextOptOut = CopTestTools.getVerificationContext(copRequest);
        contextOptOut.setAccountInfoError(AccountInfoRejection.builder()
                .code(AccountInfoErrorCode.ACCOUNT_OPT_OUT)
                .reason("ERR90: account opt out")
                .build());

        var contextUnknownError = CopTestTools.getVerificationContext(copRequest);
        contextUnknownError.setAccountInfoError(
                AccountInfoRejection.builder()
                        .code(AccountInfoErrorCode.UNKNOWN_ERROR_CODE)
                        .reason("a random error")
                        .build());

        var contextNoError = CopTestTools.getVerificationContext(copRequest);
        contextNoError.setAccountInfo(
                CoreAccountInfo.builder()
                        .name("some account")
                        .build());

        var contextWithReply = CopTestTools.getVerificationContext(copRequest);
        contextWithReply.setAccountInfoError(
                AccountInfoRejection.builder()
                        .code(AccountInfoErrorCode.ACCOUNT_OPT_OUT)
                        .reason("ERR90: account opt out")
                        .build());
        contextWithReply.setReply(
                CoreCopReply.builder()
                        .matched(false)
                        .reasonCode(Optional.of(ReasonCodes.ACNS))
                        .build());
        return Stream.of(
                Arguments.of(contextOptOut, true),
                Arguments.of(contextUnknownError, false),
                Arguments.of(contextNoError, false),
                Arguments.of(contextWithReply, false));
    }

    @Test
    void testEnrichContext() {
        var accEnricher = new AccountInfoEnricher(
                new AccountInfoProviderStub(accountInfoError));
        var rule = new AccountOptOutRule(accEnricher);
        StepVerifier.create(rule.enrichContext(verificationContext))
                .assertNext(ctx -> {
                    Assertions.assertThat(ctx.getAccountInfoError()).contains(accountInfoError);
                })
                .expectComplete()
                .verify();
    }

    @Test
    void testProcess() {
        var accEnricher = new AccountInfoEnricher(
                new AccountInfoProviderStub(accountInfoError));
        var rule = new AccountOptOutRule(accEnricher);

        StepVerifier.create(rule.process(verificationContext))
                .assertNext(ctx -> {
                    Assertions.assertThat(ctx.getReply()).isPresent();
                    var reply = ctx.getReply().get();
                    Assertions.assertThat(reply.getName()).isEmpty();
                    Assertions.assertThat(reply.isMatched()).isFalse();
                    Assertions.assertThat(reply.getReasonCode()).contains(ReasonCodes.OPTO);
                })
                .expectComplete()
                .verify();
    }
}
