#!/bin/sh

exec java ${JAVA_OPTS} -XX:+AlwaysPreTouch -Djava.security.egd=file:/dev/./urandom -cp /app/resources/:/app/classes/:/app/libs/* "fr.sis.sisid.copuk.CopukResponderApplication"  "$@"
