--liquibase formatted sql
--changeset company_synonyms:20220620100--00
--set search_path to fuzzy search;
CREATE TABLE company_synonyms
(
    id SERIAL PRIMARY KEY,
    account_name  varchar ,
    trading_name varchar
);