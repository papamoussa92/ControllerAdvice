--liquibase formatted sql
--changeset audit:20220609100--00
--set search_path to responder;
ALTER TABLE AUDIT RENAME COLUMN engin_version TO engine_version;
ALTER TABLE AUDIT  ALTER COLUMN status_http_code TYPE VARCHAR ;
ALTER TABLE AUDIT  ALTER COLUMN correlation_id TYPE VARCHAR ;
ALTER TABLE AUDIT  ALTER COLUMN open_banking_error_code TYPE VARCHAR ;
ALTER TABLE AUDIT  ALTER COLUMN identification TYPE VARCHAR ;
