--liquibase formatted sql
--changeset sis-id:z_202209151501__partition-audit-tables
--set search_path responder;

drop table if exists name_matching_log;
drop table if exists audit;

create table audit
(
    id serial not null,
    correlation_id varchar not null ,
    date_audit timestamp not null default current_timestamp,
    input_account_name varchar(100),
    account_name_from_cib_api varchar(100),
    score numeric(9,8),
    match_threshold numeric(4,2),
    closematch_threshold numeric(4,2),
    configuration_version varchar(100),
    engine_version varchar(100),
    identification varchar,
    payee_account_type varchar(100),
    status_http_code varchar,
    open_banking_error_code varchar,
    matched boolean,
    rules text,
    account_currency varchar(3),
    matching_reason_code varchar(10),
    cop_request_timestamp timestamp,
    cop_response_timestamp  timestamp,
    cib_api_request_timestamp timestamp,
    cib_api_response_timestamp timestamp,
    client_id varchar,
    org_id varchar,
    constraint audit_pkey primary key ( id, date_audit )    
) partition by range (date_audit);

create table audit_2022 partition of audit for values from ('2022-01-01') TO ('2023-01-01');

create table audit_2023 partition of audit for values from ('2023-01-01') TO ('2024-01-01');

create table audit_2024 partition of audit for values from ('2024-01-01') TO ('2025-01-01');

create table audit_2025 partition of audit for values from ('2025-01-01') TO ('2026-01-01');

create table audit_2026 partition of audit for values from ('2026-01-01') TO ('2027-01-01');

create table audit_2027 partition of audit for values from ('2027-01-01') TO ('2028-01-01');

create table audit_2028 partition of audit for values from ('2028-01-01') TO ('2029-01-01');

create table audit_2029 partition of audit for values from ('2029-01-01') TO ('2030-01-01');

create index audit_date_audit_idx on audit ( date_audit );

create table name_matching_log ( 
  id serial,
  input_name varchar,
  reference_name varchar,
  processed_input varchar,
  processed_reference varchar,
  rule_code varchar,
  score numeric,
  decision varchar,
  audit_id serial not null,
  rule_order smallint,
  date_audit timestamp not null default current_timestamp,
  constraint name_matching_log_pkey primary key ( id,  date_audit )
) partition by range ( date_audit );

create table name_matching_log_2022 partition of name_matching_log for values from ('2022-01-01') TO ('2023-01-01');

create table name_matching_log_2023 partition of name_matching_log for values from ('2023-01-01') TO ('2024-01-01');

create table name_matching_log_2024 partition of name_matching_log for values from ('2024-01-01') TO ('2025-01-01');

create table name_matching_log_2025 partition of name_matching_log for values from ('2025-01-01') TO ('2026-01-01');

create table name_matching_log_2026 partition of name_matching_log for values from ('2026-01-01') TO ('2027-01-01');

create table name_matching_log_2027 partition of name_matching_log for values from ('2027-01-01') TO ('2028-01-01');

create table name_matching_log_2028 partition of name_matching_log for values from ('2028-01-01') TO ('2029-01-01');

create table name_matching_log_2029 partition of name_matching_log for values from ('2029-01-01') TO ('2030-01-01');

create index name_matching_log_audit_idx on name_matching_log ( date_audit );

