--liquibase formatted sql
--changeset mpl:z_202209121445__audit-fields
--set search_path to responder;

-- audit fields on company_synonyms
alter table company_synonyms add column creation_date timestamp with time zone;
alter table company_synonyms add column last_updated timestamp with time zone;
-- audit fields on nature_enterprise
alter table nature_enterprise add column creation_date timestamp with time zone;
alter table nature_enterprise add column last_updated timestamp with time zone;
-- audit fields on prefix
alter table prefix add column creation_date timestamp with time zone;
alter table prefix add column last_updated timestamp with time zone;

-- on create procedure : sets both creation and update timestamp
create or replace function audit_on_create() returns trigger
as
$body$
begin
  new.creation_date = now();
  new.last_updated = now();
  return new;
end
$body$
language plpgsql;

-- on update procedure : only sets the update timestamp
create or replace function audit_on_update() returns trigger
as
$body$
begin
  new.last_updated = now();
  return new;
end
$body$
language plpgsql;

-- registers triggers on update and create for the registered_clients, eiscdid and sort_code_bank_code tables
create trigger company_synonyms_create_trigger
before insert on company_synonyms
for each row execute procedure audit_on_create();

create trigger nature_enterprise_create_trigger
before insert on nature_enterprise
for each row execute procedure audit_on_create();

create trigger prefix_create_trigger
before insert on prefix
for each row execute procedure audit_on_create();

create trigger company_synonyms_update_trigger
before update on company_synonyms
for each row execute procedure audit_on_update();

create trigger nature_enterprise_update_trigger
before update on nature_enterprise
for each row execute procedure audit_on_update();

create trigger prefix_update_trigger
before update on prefix
for each row execute procedure audit_on_update();
