--liquibase formatted sql
--changeset prefix:20220718100--00
--set search_path prefix;
CREATE TABLE prefix
(
    id SERIAL PRIMARY KEY,
    prefix  varchar
);