--liquibase formatted sql
--changeset COUNTRY:20220919103--00
--set search_path to responder;
CREATE TABLE dictionary
(
    id SERIAL PRIMARY KEY,
    country varchar,
    type varchar
);
CREATE TABLE form
(
    id SERIAL PRIMARY KEY,
    name varchar,
    spelling json,
    dictionary_id integer not null references dictionary ( id )
);


INSERT INTO DICTIONARY(id, country, type) VALUES (1, null, 'GEOGRAPHY');
INSERT INTO DICTIONARY(id, country, type) VALUES (2, 'PL', 'LEGAL_FORM');
INSERT INTO DICTIONARY(id, country, type) VALUES (3, 'fr', 'LEGAL_FORM');
INSERT INTO DICTIONARY(id, country, type) VALUES (4, 'UK', 'LEGAL_FORM');
INSERT INTO DICTIONARY(id, country, type) VALUES (5, 'EU', 'LEGAL_FORM');
INSERT INTO DICTIONARY(id, country, type) VALUES (6, 'BE', 'LEGAL_FORM');
INSERT INTO DICTIONARY(id, country, type) VALUES (7, 'se', 'LEGAL_FORM');
INSERT INTO DICTIONARY(id, country, type) VALUES (8, 'de', 'LEGAL_FORM');
INSERT INTO DICTIONARY(id, country, type) VALUES (9, 'NO', 'LEGAL_FORM');
INSERT INTO DICTIONARY(id, country, type) VALUES (10, 'US', 'LEGAL_FORM');
INSERT INTO DICTIONARY(id, country, type) VALUES (11, 'nl', 'LEGAL_FORM');


INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (1,'China','["CN","CHN"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (2,'Ireland','["IE","IRL"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (3,'Italy','["IT","ITA"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (4,'Romania','["RO","ROU"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (5,'Switzerland','["CH","CHE"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (6,'international','["international"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (7,'Mexico','["MX","MEX"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (8,'Norway','["NO","NOR"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (9,'Japan','["JP","JPN"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (10,'Canada','["CA","CAN"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (11,'Belgium','["BE","BEL"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (12,'Germany','["DE","DEU"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (13,'Israel','["IL","ISR"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (14,'United States of America (the)','["US","USA"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (15,'Finland','["FI","FIN"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (16,'Luxembourg','["LU","LUX"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (17,'Sweden','["SE","SWE"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (18,'Netherlands (the)','["NL","NLD"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (19,'Australia','["AU","AUS"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (20,'Korea (the Republic of)','["KR","KOR"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (21,'Russian Federation (the)','["RU","RUS"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (22,'United Kingdom of Great Britain and Northern Ireland (the)','["GB","GBR","UK"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (23,'Portugal','["PT","PRT"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (24,'France','["FR","FRA"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (25,'Malta','["MT","MLT"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (26,'Taiwan (Province of China)','["TW","TWN"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (27,'Hong Kong','["HK","HKG"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (28,'Brazil','["BR","BRA"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (29,'New Zealand','["NZ","NZL"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (30,'Czechia','["CZ","CZE"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (31,'Spain','["ES","ESP"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (32,'Austria','["AT","AUT"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (33,'Poland','["PL","POL"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (34,'Denmark','["DK","DNK"]',1);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (35,'spółka akcyjna','["S.A."]',2);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (36,'spółka z ograniczoną odpowiedzialnością','["sp. z o.o.","sp zoo"]',2);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (37,'prosta spółka akcyjna','["P.S.A."]',2);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (38,'societe anonyme','["sa"]',3);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (39,'societe anonyme responsabilite limitee','["sarl"]',3);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (40,'société d investissemnt à capital variable','["SICAV"]',3);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (41,'societe anonyme actions simplifiées','["sas"]',3);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (42,'limited liability partnership','["llp"]',4);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (43,'unlimited company','["uc","anghyfyngedig"]',4);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (44,'community interest company','["cic"]',4);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (45,'charitable incorporated organisation','["cio","scio"]',4);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (46,'industrial and provident society','["ips","coop","cooperative"]',4);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (47,'scottish limited partnership','["slp"]',4);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (48,'public limited company','["plc","ccc","cwmni cyfyngedig cyhoeddus"]',4);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (49,'private limited company','["ltd","limited","cyfyngedig","cyf"]',4);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (50,'limited partnership','["lp","limited partnership"]',4);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (51,'general partnership','["gp"]',4);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (52,'ole proprietorship','["sp"]',4);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (53,'societas europaea','["SE"]',5);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (54,'société privée à responsabilité limitée','["SPRL","BVBA"]',6);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (55,'société responsabilité limitée','["SRL","BV"]',6);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (56,'publikt aktiebolag','["ab (publ)"]',7);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (57,'kommanditbolag','["kb"]',7);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (58,'aktiebolag','["ab"]',7);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (59,'handelsbolag','["hb"]',7);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (60,'kommanditgesellschaft','["kg","& co kg","& compagnie kg","gmbh & co.kg"]',8);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (61,'gesellschaft buergerlichen rechts','["gbr"]',8);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (62,'kommanditgesellschaft auf aktien','["kgaa","& Compagnie kgaa","& co kgaa"]',8);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (63,'gesellschaft mit beschränkter haftung','["gmbh","mbh"]',8);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (64,'aktiengesellschaft','["ag","aktiengesellschaft"]',8);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (65,'Aksjeselskap','["AS"]',9);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (66,'special purpose company','["spc"]',10);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (67,'limited liability company','["lc","llc"]',10);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (68,'corporation','["corporation","corp","and co","& co","inc","incorporated","and company","co","spa","societa per azioni","and co ltd","and co limited","& co ltd","& co limited","and company ltd","and company limited","& company ltd","& company limited"]',10);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (69,'naamloze vennootschap','["nv"]',11);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (70,'besloten vennootschap','["bv"]',11);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (71,'commanditaire vennootschap','["cv"]',11);
INSERT INTO FORM(id  ,name,    spelling,    dictionary_id) VALUES (72,'vennootschap onder firma','["vof"]',11);

alter sequence dictionary_id_seq restart with 12;
alter sequence form_id_seq restart with 73;