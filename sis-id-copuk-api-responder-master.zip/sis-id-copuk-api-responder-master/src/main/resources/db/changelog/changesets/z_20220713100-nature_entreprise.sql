--liquibase formatted sql
--changeset nature_enterprise:20220713100--00
--set search_path nature enterprise;
CREATE TABLE nature_enterprise
(
    id SERIAL PRIMARY KEY,
    nature  varchar
);