--liquibase formatted sql
--changeset mpl:20220711134300__name-matching-log
--set search_path to responder;

create table name_matching_log ( 
  id serial primary key,
  input_name varchar,
  reference_name varchar,
  processed_input varchar,
  processed_reference varchar,
  rule_code varchar,
  score numeric,
  decision varchar,
  audit_id serial references audit (id),
  rule_order smallint
);