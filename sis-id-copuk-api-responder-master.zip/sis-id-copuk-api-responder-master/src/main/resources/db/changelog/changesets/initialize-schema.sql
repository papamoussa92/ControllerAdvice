--liquibase formatted sql
--changeset audit:20220519100--00
--set search_path to responder;
CREATE TABLE AUDIT
(
    id SERIAL PRIMARY KEY,
    correlation_id   varchar(30) not null ,
    date_audit TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    input_account_name varchar(100),
    account_name_from_cib_api varchar(100),
    score numeric(9,8),
    match_threshold numeric(4,2),
    closematch_threshold numeric(4,2),
    configuration_version varchar(100),
    engin_version varchar(100),
    identification   varchar(30),
    payee_account_type varchar(100),
    status_http_code varchar(10),
    open_banking_error_code varchar(10),
    matched boolean,
    rules text,
    account_currency varchar(3),
    matching_reason_code varchar(10),
    cop_request_timestamp TIMESTAMP,
    cop_response_timestamp  timestamp,
    cib_api_request_timestamp timestamp,
    cib_api_response_timestamp timestamp
);