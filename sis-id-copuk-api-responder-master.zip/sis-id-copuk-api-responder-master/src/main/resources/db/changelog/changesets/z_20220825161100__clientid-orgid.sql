--liquibase formatted sql
--changeset mpl:z_20220825161100__clientid-orgid
--set search_path to responder;

alter table audit add column client_id varchar;
alter table audit add column org_id varchar;
