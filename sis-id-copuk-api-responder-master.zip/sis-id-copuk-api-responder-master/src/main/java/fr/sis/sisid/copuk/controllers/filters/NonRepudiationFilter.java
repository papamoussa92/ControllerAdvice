package fr.sis.sisid.copuk.controllers.filters;

import com.nimbusds.oauth2.sdk.util.StringUtils;
import fr.sis.sisid.copuk.OpenBankingConstants;
import fr.sis.sisid.copuk.client.ClientRegistrationClient;
import fr.sis.sisid.copuk.config.NonRepudiationProperties;
import fr.sis.sisid.copuk.controllers.errors.NonRepudiationException;
import fr.sis.sisid.copuk.controllers.validators.HeaderValidator;
import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.dto.SsaDTO;
import fr.sis.sisid.copuk.tools.JoseHeaderValidator;
import fr.sis.sisid.copuk.tools.JoseRequiredHeaderValidator;
import fr.sis.sisid.copuk.tools.JwtTools;
import fr.sis.sisid.copuk.tools.ResponseSigner;
import fr.sis.sisid.copuk.tools.errors.JOSEValidationException;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
@Component
@Order(-502)
public class NonRepudiationFilter extends NameVerificationFilter {

    private final JwtTools jwtTools;

    private final WebClient webClient;

    private final NonRepudiationProperties properties;

    private final HeaderValidator headerValidator;

    private final ResponseSigner responseSigner;

    private final String openBankingBaseUrl;

    private final String openBankingCacheUrl;

    public NonRepudiationFilter(@Value("${copuk.api.path-pattern:/api/v*/pay.uk}") String payUkPathPattern,
                                JwtTools jwtTools,
                                @Qualifier("jwksWebClient") WebClient webClient,
                                NonRepudiationProperties properties,
                                HeaderValidator headerValidator,
                                ResponseSigner responseSigner, @Value("${open-banking.base-url}") String openBankingBaseUrl, @Value("${open-banking.caching-url}") String openBankingCacheUrl) {
        super(payUkPathPattern);
        this.jwtTools = jwtTools;
        this.webClient = webClient;
        this.properties = properties;
        this.headerValidator = headerValidator;
        this.responseSigner = responseSigner;
        this.openBankingBaseUrl = openBankingBaseUrl;
        this.openBankingCacheUrl = openBankingCacheUrl;
    }

    @Override
    public Mono<Void> nameVerificationFilter(ServerWebExchange exchange, WebFilterChain chain) {
        log.debug("Validating non repudiation header... ");
        ServerHttpRequest request = exchange.getRequest();
        String jwsSignature = request.getHeaders().getFirst(OpenBankingConstants.NON_REPUDIATION_HEADER);

        headerValidator.check(request.getHeaders());

        RequestBodyDecorator requestWithBody = new RequestBodyDecorator(request);
        ResponseBodyDecorator responseBodyDecorator = new ResponseBodyDecorator(exchange.getResponse());
        BodyWebExchangeDecorator exchangeWrapper = new BodyWebExchangeDecorator(exchange, requestWithBody,
                responseBodyDecorator);

        responseBodyDecorator.beforeCommit(() -> addContextToHttpResponseHeaders(responseBodyDecorator));

        return requestWithBody.getBodyAsString()
                .flatMap(
                        body -> Mono.deferContextual(
                                ctx -> Mono
                                        .just(ctx.get(VerificationContext.class).getSsa()
                                                .orElseThrow(() -> new NonRepudiationException(
                                                        "Could not retrieve the SSA")))
                                        .flatMap(ssa -> this.validateJWS(body, jwsSignature, ssa))
                                        .flatMap(e -> {
                                            log.info("Successful incoming non-repudiation");
                                            return chain.filter(exchangeWrapper);
                                        })
                                        .doOnError(error -> log.error("Failed non-repudiation", error))
                                        .doFinally(r -> log.info("End incoming non-repudiation"))));

    }

    /**
     * Validates the non repudiation JWS with information from the SSA
     *
     * @param payload The full request body payload
     * @param ssa     The content of the Software statement assertion
     * @throws JOSEValidationException thrown if the validation fails
     */
    public Mono<Boolean> validateJWS(String payload, String jwsDetachedSignature, SsaDTO ssa)
            throws JOSEValidationException {
        // list of validators to run against the non repudiation token
        List<JoseHeaderValidator<?>> validators = new LinkedList<>();
        // typ is optional, must be JOSE if present
        validators
                .add(new JoseHeaderValidator<>("typ",
                        (String typ) -> StringUtils.isBlank(typ) || properties.getSupportedTyp().equals(typ.trim())));
        // cty is optional, must be json or application/json if present
        validators.add(new JoseHeaderValidator<>("cty",
                (String cty) -> StringUtils.isBlank(cty) || properties.getSupportedCty().contains(cty.trim())));
        // custom iat claim must be in the past
        validators.add(new JoseRequiredHeaderValidator<>(properties.getIatClaimName(),
                (Long iat) -> iat != null && Instant.ofEpochSecond(iat).isBefore(Instant.now())));
        // custom iss claim must match <org-id>/<ssa-id>
        validators.add(new JoseRequiredHeaderValidator<>(properties.getIssClaimName(),
                (String iss) -> StringUtils.isNotBlank(iss)
                        && (ssa.getOrgId().trim() + "/" + ssa.getSoftwareId().trim()).equals(iss.trim())));
        // custom tan claim must be openbanking.org.uk
        validators.add(new JoseRequiredHeaderValidator<>(properties.getTanClaimName(),
                (String tan) -> StringUtils.isNotBlank(tan) && properties.getSupportedTan().equals(tan.trim())));
        // crit header must contain all the custom header claims
        Set<String> customHeaders = Stream
                .of(properties.getIatClaimName(), properties.getIssClaimName(), properties.getTanClaimName())
                .collect(Collectors.toSet());
        validators.add(new JoseRequiredHeaderValidator<>("crit",
                (Collection<String> crit) -> crit != null && customHeaders.containsAll(new HashSet<>(crit))
                        && new HashSet<>(crit).containsAll(customHeaders)));
        // kid header claim must be set
        validators.add(new JoseRequiredHeaderValidator<>("kid", StringUtils::isNotBlank));

        // build a decoder / validator
        var decoder = jwtTools.getJoseDecoder(
                // use jwks from the ssa to validate the non-repudiation token's signature
                ssa.getSoftwareJwksEndpoint().replace(openBankingBaseUrl, openBankingCacheUrl),
                this.webClient,
                validators);
        // validate the non repudiation token
        return decoder.validate(jwsDetachedSignature, payload);
    }

    private Mono<Void> addContextToHttpResponseHeaders(final ServerHttpResponse response) {

        return Mono.deferContextual(ctx -> {
            log.debug("Writing non-repudiation header ... ");
            var responseBody = ((ResponseBodyDecorator) response).getBodyAsString();
            try {
                var signature = this.responseSigner.signPayload(responseBody, Instant.now());
                response.getHeaders().add(OpenBankingConstants.NON_REPUDIATION_HEADER, signature);
            } catch (Exception err) {
                // if signing the response fails, return it anyways without a signature
                log.error(err.getMessage(), err);
            }
            return Mono.empty();
        }).then();
    }

}
