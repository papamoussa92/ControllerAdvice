package fr.sis.sisid.copuk.cop.core.rules;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.rules.processors.CloseMatchReplyProcessor;
import fr.sis.sisid.copuk.cop.core.rules.processors.NameMatchingResultEnricher;
import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import reactor.core.publisher.Mono;

/**
 * Name matching done through service provider
 * Names are a close match
 */
@AllArgsConstructor(onConstructor = @__(@Autowired))
@NoArgsConstructor
@Component
public class CloseMatchRule implements VerificationRule {

    private NameMatchingResultEnricher nameMatchingResultEnricher;

    private CloseMatchReplyProcessor closeMatchReplyProcessor;

    @Override
    public boolean matches(VerificationContext context) {
        if (context.getNameMatchingResult().isEmpty() || context.getReply().isPresent()) {
            return false;
        }
        return Objects.equals(context.getNameMatchingResult().map(mr -> mr.getScore().getDecision()).orElse(null),
                MatchingDecision.CLOSE_MATCH);
    }

    @Override
    public Mono<VerificationContext> enrichContext(VerificationContext context) {
        if (context.getReply().isPresent()) {
            return Mono.just(context);
        }
        return this.nameMatchingResultEnricher.enrichContext(context);
    }

    @Override
    public Mono<VerificationContext> process(VerificationContext context) {
        return this.closeMatchReplyProcessor.enrichContext(context);
    }

    @Override
    public String getRuleCode() {
        return "CLOSE-MATCH";
    }

}
