package fr.sis.sisid.copuk.model;

import fr.sis.sisid.copuk.copapi.model.AccountsNameVerificationData;
import fr.sis.sisid.copuk.copapi.model.OBExternalAccountType1Code;
import lombok.Data;


@Data
public class AccountsNameVerificationDataDTO {
    private AccountsNameVerificationData.SchemeNameEnum schemeName;
    private OBExternalAccountType1Code accountType;
    private String name;
    private String secondaryIdentification;
}
