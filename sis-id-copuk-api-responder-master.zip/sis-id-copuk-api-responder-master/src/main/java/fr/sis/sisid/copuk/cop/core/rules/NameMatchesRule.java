package fr.sis.sisid.copuk.cop.core.rules;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.nimbusds.oauth2.sdk.util.StringUtils;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.rules.processors.AccountInfoEnricher;
import fr.sis.sisid.copuk.cop.core.rules.processors.NameMatchesReplyProcessor;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import reactor.core.publisher.Mono;

/**
 * Happy path rule : 
 *  - the requested name matches the one on the account
 */
@AllArgsConstructor(onConstructor = @__(@Autowired))
@NoArgsConstructor
@Component
public class NameMatchesRule implements VerificationRule {

    private AccountInfoEnricher accountInfoEnricher;

    private NameMatchesReplyProcessor nameMatchesReplyProcessor;

    @Override
    public boolean matches(VerificationContext context) {
        if (context.getAccountInfo().isEmpty()) {
            return false;
        }
        if (context.getReply().isPresent()) {
            return false;
        }
        // match if requested name and account name are equal
        return context.getAccountInfo().map(CoreAccountInfo::getName)
                .map(accountName -> StringUtils.isNotBlank(accountName) &&
                        StringUtils.isNotBlank(context.getRequest().getName()) &&
                        accountName.equalsIgnoreCase(context.getRequest().getName()))
                .orElse(false);
    }

    @Override
    public Mono<VerificationContext> enrichContext(VerificationContext context) {
        // do not fetch account info if it has already been fetched
        if (context.getReply().isPresent()) {
            return Mono.just(context);
        }
        // fetch account info
        return this.accountInfoEnricher.enrichContext(context);
    }

    @Override
    public Mono<VerificationContext> process(VerificationContext context) {
        // build a reply stating the name matches
        return this.nameMatchesReplyProcessor.enrichContext(context);
    }

    @Override
    public String getRuleCode() {
        return "NAME-MATCHES";
    }

}
