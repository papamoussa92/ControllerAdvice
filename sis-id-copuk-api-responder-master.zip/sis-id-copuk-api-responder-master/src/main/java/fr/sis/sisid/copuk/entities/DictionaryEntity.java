package fr.sis.sisid.copuk.entities;

import lombok.*;

import javax.persistence.*;
import java.util.Set;

@Entity
@Table(name = "dictionary")
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString(callSuper = true, exclude = "forms")
@EqualsAndHashCode(callSuper = true, exclude = "forms")
public class DictionaryEntity extends BaseEntity {

    private String country;

    @OneToMany(cascade = {CascadeType.ALL}, mappedBy = "dictionary", fetch = FetchType.EAGER, orphanRemoval = true)
    private Set<FormEntity> forms;

    @Column(name = "type")
    @Enumerated(EnumType.STRING)
    private DictionaryType type;
}
