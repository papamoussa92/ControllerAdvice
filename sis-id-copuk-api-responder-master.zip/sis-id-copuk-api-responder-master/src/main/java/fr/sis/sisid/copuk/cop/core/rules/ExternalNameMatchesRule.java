package fr.sis.sisid.copuk.cop.core.rules;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.rules.processors.NameMatchesReplyProcessor;
import fr.sis.sisid.copuk.cop.core.rules.processors.NameMatchingResultEnricher;
import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import reactor.core.publisher.Mono;

/**
 * Name matching done through service provider,
 * names are an exact match
 */
@AllArgsConstructor(onConstructor = @__(@Autowired))
@NoArgsConstructor
@Component
public class ExternalNameMatchesRule implements VerificationRule {

    private NameMatchingResultEnricher nameMatchingResultEnricher;

    private NameMatchesReplyProcessor nameMatchesReplyProcessor;

    @Override
    public boolean matches(VerificationContext context) {
        if (context.getNameMatchingResult().isEmpty() || context.getReply().isPresent()) {
            return false;
        }
        return Objects.equals(MatchingDecision.MATCH,
                context.getNameMatchingResult().map(mr -> mr.getScore().getDecision()).orElse(null));
    }

    @Override
    public Mono<VerificationContext> enrichContext(VerificationContext context) {
        if (context.getReply().isPresent()) {
            return Mono.just(context);
        }
        return this.nameMatchingResultEnricher.enrichContext(context);
    }

    @Override
    public Mono<VerificationContext> process(VerificationContext context) {
        // build a reply stating the name
        return this.nameMatchesReplyProcessor.enrichContext(context);
    }

    @Override
    public String getRuleCode() {
        return "EXTERNAL-NAME-MATCHES";
    }

}
