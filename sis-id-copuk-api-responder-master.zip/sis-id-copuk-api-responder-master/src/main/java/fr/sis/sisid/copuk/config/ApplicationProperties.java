package fr.sis.sisid.copuk.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Properties for the Responder Application loaded by Spring Boot
 * <p>
 * Properties are configured in the {@code application.yml} file.
 */
@ConfigurationProperties(prefix = "application", ignoreUnknownFields = false)
public class ApplicationProperties {
}
