package fr.sis.sisid.copuk.cop.core.rules;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import lombok.AllArgsConstructor;
import reactor.core.publisher.Mono;

/**
 * Fallback rule, to build an error response in case no other rule matched
 */
@AllArgsConstructor(onConstructor = @__(@Autowired))
@Component
public class DefaultRule implements VerificationRule {

    @Override
    public boolean matches(VerificationContext context) {
        // apply if no reply has been set
        return context.getReply().isEmpty();
    }

    @Override
    public Mono<VerificationContext> enrichContext(VerificationContext context) {
        return Mono.just(context);
    }

    @Override
    public Mono<VerificationContext> process(VerificationContext context) {
        // build an error response
        return Mono.error(
                new VerificationRuleException("Triggered default verification rule, something unexpected happened"));
    }

    @Override
    public String getRuleCode() {
        return "DEFAULT";
    }

}
