package fr.sis.sisid.copuk.mappers;

import org.springframework.stereotype.Component;

import fr.sis.sisid.copuk.dto.NameMatchingStatsDTO;
import fr.sis.sisid.copuk.entities.AuditStatsResult;

@Component
public class AuditStatsMapper {

    public NameMatchingStatsDTO toDTO(AuditStatsResult auditStats, String orgId) {
        return NameMatchingStatsDTO.builder()
                .registrationId(orgId)
                .nbPersonalRequests(auditStats.getNbPersonalRequests())
                .nbBusinessRequests(auditStats.getNbBusinessRequests())
                .nbMatched(auditStats.getNbMatched())
                .nbANNM(auditStats.getNbANNM())
                .nbMBAM(auditStats.getNbMBAM())
                .nbBANM(auditStats.getNbBANM())
                .nbPANM(auditStats.getNbPANM())
                .nbBAMM(auditStats.getNbBAMM())
                .nbAC01(auditStats.getNbAC01())
                .nbIVCR(auditStats.getNbIVCR())
                .nbACNS(auditStats.getNbACNS())
                .nbOPTO(auditStats.getNbOPTO())
                .nbCASS(auditStats.getNbCASS())
                .nbSCNS(auditStats.getNbSCNS())
                .nbOutsideOfSLA(auditStats.getNbOutsideOfSLA())
                .build();
    }
}
