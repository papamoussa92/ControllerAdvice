package fr.sis.sisid.copuk.cop.core;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import fr.sis.sisid.copuk.cop.api.NameVerificationService;
import fr.sis.sisid.copuk.cop.core.rules.RulesList;
import fr.sis.sisid.copuk.cop.core.rules.VerificationRule;
import fr.sis.sisid.copuk.cop.core.rules.VerificationRuleException;
import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@NoArgsConstructor
@Component
@Slf4j
public class NameVerificationServiceImpl implements NameVerificationService {

    private RulesList rulesList;

    @Autowired
    public NameVerificationServiceImpl(RulesList rulesList) {
        this.rulesList = rulesList;
    }

    @Override
    public Mono<CoreCopReply> getCop(CoreCopRequest request) {
        try {

            var monoCtx = Mono.deferContextual(ctx -> Mono.just(ctx.get(VerificationContext.class)));
            for (VerificationRule rule : rulesList.getRules()) {
                // 1. call enrich context
                monoCtx = monoCtx.flatMap(rule::enrichContext);
                monoCtx = monoCtx.flatMap(ctx -> {
                    // 2. if no match, do not apply the rule
                    if (!rule.matches(ctx)) {
                        log.info("{} ✖ Rule not a match", rule.getClass().getName());
                        return Mono.just(ctx);
                    }
                    log.info("{}  ✔  Rule  matched", rule.getClass().getName());
                    // 3. if match, apply the rule
                    return rule.process(ctx).map(processedCtx -> {
                        processedCtx.setRuleCode(rule.getRuleCode());
                        return processedCtx;
                    });
                });
            }
            // A reply should have been generated, which we return
            return monoCtx.flatMap(ctx -> {
                if (ctx.getReply().isEmpty()) {
                    return Mono.error(new VerificationRuleException("No COP reply"));
                }
                return Mono.just(ctx.getReply().get());

            });
        } catch (Throwable err) {
            return Mono.error(err);
        }

    }

}
