package fr.sis.sisid.copuk.service;

import java.time.ZonedDateTime;
import java.util.List;

import org.springframework.validation.BindException;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.dto.NameMatchingStatsDTO;
import fr.sis.sisid.copuk.entities.Audit;
import reactor.core.publisher.Mono;

public interface AuditService {

    Mono<List<Audit>> searchByKey(String accountNumber, String accountName, String dateDebut, String dateFin)
            throws BindException;

    /**
     * Queries usage stats for a time period from the audit table 
     * @param from
     * @param to
     * @return
     */
    public Mono<NameMatchingStatsDTO> getStats(ZonedDateTime from, ZonedDateTime to);

    Mono<Audit> save(VerificationContext verificationContext);
}
