package fr.sis.sisid.copuk.controllers;

import fr.sis.sisid.copuk.dto.NameMatchingStatsDTO;
import fr.sis.sisid.copuk.entities.Audit;
import fr.sis.sisid.copuk.service.AuditService;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import javax.validation.constraints.Pattern;
import java.time.ZonedDateTime;
import java.util.List;

@Slf4j


@RestController
@AllArgsConstructor(onConstructor = @__(@Autowired))
@NoArgsConstructor
@Validated
public class AuditController {
    private AuditService auditService;

    @GetMapping(value = { "/audit/search" }, produces = { "application/json", "test/csv" })
    public @ResponseBody Mono<ResponseEntity<List<Audit>>> getAudit(
            @Parameter(in = ParameterIn.QUERY, description = "The concatenated sort-code and account number", required = false) @Pattern(regexp = "^[0-9]{14}$", message="mauvais format de l'identifiant") @RequestParam(value = "identifiant", required = false) String identifiant,
            @Parameter(in = ParameterIn.QUERY, description = "Account name to be searched", required = false) @RequestParam(value = "name", required = false) String name,
            @Parameter(in = ParameterIn.QUERY, description = "The start date/time for the range to include in the search. Any ISO format.", required = false) @DateTimeFormat(pattern = "yyyy-mm-dd") @RequestParam(value = "dateStart", required = false) String dateStart,
            @Parameter(in = ParameterIn.QUERY, description = "The end date/time for the range to include in the search. Any ISO format.", required = false) @DateTimeFormat(pattern = "yyyy-mm-dd") @RequestParam(value = "dateEnd", required = false) String dateEnd)
            throws BindException {
        return auditService.searchByKey(identifiant, name, dateStart, dateEnd)
                .flatMap(audit -> Mono.just(ResponseEntity.ok(audit)));
    }

    /**
     * Queries the name verification usage stats for a time period in CSV or JSON format
     * @param from
     * @param to
     * @return
     */
    @GetMapping(value = "/internal/audit", produces = { "text/csv", "application/json" })
    public @ResponseBody Mono<ResponseEntity<NameMatchingStatsDTO>> queryInternalAudit(
            @RequestParam("from") @DateTimeFormat(iso = ISO.DATE_TIME) ZonedDateTime from,
            @RequestParam("to") @DateTimeFormat(iso = ISO.DATE_TIME) ZonedDateTime to) {
        return this.auditService.getStats(from, to).flatMap(stats -> Mono.just(ResponseEntity.ok(stats)));
    }
}
