package fr.sis.sisid.copuk.mappers;

import java.math.BigDecimal;

import org.springframework.stereotype.Component;

import fr.sis.sisid.copuk.entities.Audit;
import fr.sis.sisid.copuk.entities.NameMatchingLogEntity;
import fr.sis.sisid.copuk.namematching.model.NameMatchingLog;

@Component
public class NameMatchingLogMapper {

    public NameMatchingLogEntity toEntity(NameMatchingLog dto, Audit audit, int order) {
        NameMatchingLogEntity entity = new NameMatchingLogEntity();
        entity.setAudit(audit);
        entity.setDecision(dto.getDecision());
        entity.setInputName(dto.getInput());
        entity.setProcessedInput(dto.getProcessedInput());
        entity.setProcessedReference(dto.getProcessedReference());
        entity.setReferenceName(dto.getReference());
        entity.setRuleCode(dto.getRuleCode());
        entity.setRuleOrder((short) order);
        entity.setScore(BigDecimal.valueOf(dto.getScore()));
        entity.setDateAudit(audit.getDateAudit());
        return entity;
    }

}
