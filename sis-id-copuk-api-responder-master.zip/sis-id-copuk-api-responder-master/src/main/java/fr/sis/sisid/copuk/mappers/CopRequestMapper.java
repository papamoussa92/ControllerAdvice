package fr.sis.sisid.copuk.mappers;

import fr.sis.sisid.copuk.copapi.model.InlineObject;
import fr.sis.sisid.copuk.ext.bnp.model.CopRequest;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import reactor.core.publisher.Mono;

public interface CopRequestMapper {
    Mono<CoreCopRequest> toDomain(Mono<InlineObject> dto, String xFapiFinancialId);

    CopRequest toDTO(CoreCopRequest domainObject);
}
