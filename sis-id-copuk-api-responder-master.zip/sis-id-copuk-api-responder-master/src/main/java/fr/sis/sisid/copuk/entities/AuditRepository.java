package fr.sis.sisid.copuk.entities;

import java.time.ZonedDateTime;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface AuditRepository extends JpaRepository<Audit, Long> {

    @Query(nativeQuery = true, name = "get_audit_stats")
    AuditStatsResult getAuditStats(@Param("from") ZonedDateTime from, @Param("to") ZonedDateTime to,
            @Param("sla_seconds") double slaSeconds);
}
