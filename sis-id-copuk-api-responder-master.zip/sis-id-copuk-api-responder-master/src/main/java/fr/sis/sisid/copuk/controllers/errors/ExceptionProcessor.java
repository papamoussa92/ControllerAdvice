package fr.sis.sisid.copuk.controllers.errors;

import com.nimbusds.jose.JOSEException;
import fr.sis.sisid.copuk.OpenBankingConstants;
import fr.sis.sisid.copuk.tools.ResponseSigner;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;

import java.time.Instant;

/**
 * Utility to execute the correct response builder depending on the class of exception
 */
@Slf4j
class ExceptionProcessor {
    Mono<ServerResponse> response;
    boolean match = false;
    Throwable throwable;
    private final ResponseSigner responseSigner;

    public ExceptionProcessor(Throwable throwable, ResponseSigner responseSigner) {
        this.throwable = throwable;
        this.responseSigner = responseSigner;
    }

    public <T> ExceptionMatcher<T> when(Class<T> matchClass) {
        if (!match && matchClass.isAssignableFrom(throwable.getClass())) {
            match = true;

            return new ExceptionMatcher<>(this, matchClass.cast(this.throwable));
        }
        return new ExceptionMatcher<>(this);
    }

    public Mono<ServerResponse> elseDefaults(HttpStatus status, ResponseBuilder<Throwable> defaultResponseBuilder) {
        if (response == null) {
            return new ExceptionMatcher<>( this, this.throwable).status(status)
                    .body(defaultResponseBuilder).response;
        }
        return response;
    }

    public void processBody(String serializedBody, ServerResponse.BodyBuilder bodyBuilder) {
        try {
            var signature = this.responseSigner.signPayload(serializedBody, Instant.now());
            bodyBuilder.header(OpenBankingConstants.NON_REPUDIATION_HEADER, signature);
        } catch (JOSEException e) {
            log.warn("Unable to sign response", e);
        }
    }

    public interface ResponseBuilder<T> {
        String build(T exception, HttpStatus status);
    }

    public interface StatusCodeBuilder<T> {
        HttpStatus build(T exception);
    }

}
