package fr.sis.sisid.copuk.cop.core.rules.processors;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import fr.sis.sisid.copuk.namematching.NameMatchingProvider;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

/**
 * Adds a name matching result to the verification context
 * Account information is needed for this to work, the account information
 * gets fetched by this context enricher as well, if not present already.
 */
@Component
@AllArgsConstructor
@NoArgsConstructor
@Slf4j
public class NameMatchingResultEnricher implements VerificationContextProcessor {

    @Autowired
    private AccountInfoEnricher accountInfoEnricher;

    @Autowired
    private NameMatchingProvider nameMatchingProvider;

    @Override
    public Mono<VerificationContext> enrichContext(VerificationContext context) {
        if (context.getNameMatchingResult().isPresent()) {
            return Mono.just(context);
        }
        // get account info ( required to get a name matching result )
        return accountInfoEnricher.enrichContext(context)
                // return empty mono when no account info, like when the account info provider
                // returns an error
                .filter(ctx -> ctx.getAccountInfo().isPresent())
                .zipWhen(
                        // get name matching result
                        contextWAccInfo -> nameMatchingProvider.nameMatch(
                                contextWAccInfo.getRequest().getName(),
                                contextWAccInfo.getAccountInfo().map(CoreAccountInfo::getName).orElse(null)),
                        // add name matching result to the context
                        (contextWAccInfo, nameMatchingResult) -> {
                            log.debug("matching result : {}", nameMatchingResult);
                            contextWAccInfo.setNameMatchingResult(nameMatchingResult);
                            if (contextWAccInfo.getAccountInfo().isPresent()) {
                                contextWAccInfo.getAccountInfo().get()
                                        .setName(nameMatchingProvider.getProcessedAccountName(
                                                contextWAccInfo.getAccountInfo().get().getName(),
                                                nameMatchingResult.getNamePairProcessorType()));
                            }
                            return contextWAccInfo;
                        })
                // default to the initial context
                .switchIfEmpty(Mono.just(context));
    }

}
