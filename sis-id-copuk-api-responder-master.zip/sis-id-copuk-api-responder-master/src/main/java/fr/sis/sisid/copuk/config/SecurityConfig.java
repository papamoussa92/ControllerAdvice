package fr.sis.sisid.copuk.config;

import fr.sis.sisid.copuk.controllers.errors.CopukExceptionHandler;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.security.web.server.ServerAuthenticationEntryPoint;
import org.springframework.security.web.server.authorization.ServerAccessDeniedHandler;
import org.springframework.security.web.server.context.NoOpServerSecurityContextRepository;

/**
 * Spring security config
 */
@EnableWebFluxSecurity
@Slf4j
public class SecurityConfig {

    @Value("${copuk.api.path-pattern:/api/v*/pay.uk}")
    private String payUkPathPattern;
    @Autowired CopukExceptionHandler copukExceptionHandler;

    @Bean
    public SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http) {

        ServerAuthenticationEntryPoint authErrorHandler = (exchange, ex) -> copukExceptionHandler.handle(exchange, ex);
        ServerAccessDeniedHandler accessDeniedHandler = (exchange, denied) -> copukExceptionHandler.handle(exchange, denied);

        http
                .securityContextRepository(NoOpServerSecurityContextRepository.getInstance())
                .authorizeExchange(authorize ->
                        authorize.pathMatchers("/api/v1.0/.well-known/**", "/management/**", "/audit/**",
                                        "/internal/**")
                                .permitAll()
                                .pathMatchers(payUkPathPattern)
                                .hasAuthority("SCOPE_name-verification")
                                .anyExchange()
                                .authenticated()
                )
                .csrf()
                .disable() //NOSONAR java:S4502 security hotspot reviewed. CSRF token not applicable for server-to-server stateless API
                .oauth2ResourceServer()
                .authenticationEntryPoint(authErrorHandler)
                .accessDeniedHandler(accessDeniedHandler)
                .jwt();
        return http.build();
    }

}
