package fr.sis.sisid.copuk.mappers;

import fr.sis.sisid.copuk.copapi.model.AccountsNameVerificationData;
import fr.sis.sisid.copuk.model.AccountsNameVerificationDataDTO;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface AccountsNameVerificationDataMapper {
    public AccountsNameVerificationDataDTO toDto(AccountsNameVerificationData accountsNameVerificationData);
}
