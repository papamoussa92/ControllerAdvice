package fr.sis.sisid.copuk.service.mapper;

import com.nimbusds.oauth2.sdk.util.StringUtils;
import fr.sis.sisid.copuk.config.AccountInfoProperties;
import fr.sis.sisid.copuk.ext.bnp.model.AccountTypeComponent;
import fr.sis.sisid.copuk.ext.bnp.model.CopReply;
import fr.sis.sisid.copuk.ext.bnp.model.RequestStatus;
import fr.sis.sisid.copuk.mappers.AccountInfoMapper;
import fr.sis.sisid.copuk.model.AccountInfoErrorCode;
import fr.sis.sisid.copuk.model.AccountInfoRejection;
import fr.sis.sisid.copuk.model.AccountInfoReply;
import fr.sis.sisid.copuk.model.AccountType;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Component
@Slf4j
public class AccountInfoMapperImpl implements AccountInfoMapper {

    /*
     * Custom response code mappings: code to enum value
     */
    private final Map<String, AccountInfoErrorCode> customMappings;

    @Autowired
    public AccountInfoMapperImpl(AccountInfoProperties accountInfoProperties) {
        this.customMappings = new HashMap<>();
        if (StringUtils.isNotBlank(accountInfoProperties.getAccountOptOut())) {
            this.customMappings.put(
                    accountInfoProperties.getAccountOptOut(), AccountInfoErrorCode.ACCOUNT_OPT_OUT);
        }
        if (StringUtils.isNotBlank(accountInfoProperties.getAccountSwitched())) {
            this.customMappings.put(
                    accountInfoProperties.getAccountSwitched(),
                    AccountInfoErrorCode.ACCOUNT_SWITCHED);
        }
    }

    public AccountInfoReply toDomain(CopReply dto) {
        if (!RequestStatus.ACCEPTED.equals(dto.getRequestStatus())) {
            return AccountInfoRejection.builder()
                    .reason(dto.getRequestReasonStatus())
                    .code(this.parseErrorCode(dto.getRequestReasonStatus()))
                    .build();
        }
        return CoreAccountInfo.builder().name(Strings.trimToNull(dto.getAccountInformation().getName()))
                .accountType(mapAccountTypeComponent(dto.getAccountInformation().getAccountType()))
                .currency(dto.getAccountInformation().getCurrency().stream().collect(Collectors.joining(","))).build();
    }

    public AccountInfoErrorCode parseErrorCode(String reasonMessage) {
        if (StringUtils.isBlank(reasonMessage)) {
            return AccountInfoErrorCode.UNKNOWN_ERROR_CODE;
        }
        final String regex = "^([a-zA-Z]{3,4}\\d{2}):";
        final Pattern pattern = Pattern.compile(regex, Pattern.MULTILINE);
        final Matcher matcher = pattern.matcher(reasonMessage);
        String code = "";
        if (matcher.find()) {
            code = matcher.group(1);
        }
        var responseCode = AccountInfoErrorCode.fromCode(code);
        // if the response code is unknown, try to match it against custom mappings
        if (AccountInfoErrorCode.UNKNOWN_ERROR_CODE.equals(responseCode) &&
                this.customMappings.containsKey(code)) {
            responseCode = this.customMappings.get(code);
        }
        return responseCode;
    }

    private AccountType mapAccountTypeComponent(AccountTypeComponent accountType) {
        return switch (accountType) {
        case ORGANISATION ->  AccountType.BUSINESS;
        case PRIVATE -> AccountType.PRIVATE;
        };
    }
}
