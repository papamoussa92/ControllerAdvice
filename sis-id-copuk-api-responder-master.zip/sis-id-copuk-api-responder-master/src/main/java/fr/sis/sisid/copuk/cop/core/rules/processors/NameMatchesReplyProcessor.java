package fr.sis.sisid.copuk.cop.core.rules.processors;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.model.CoreCopReply;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

/**
 * Adds a cop reply to the context, stating that the name matches
 * the account information
 *
 */
@Component
public class NameMatchesReplyProcessor implements VerificationContextProcessor {

    @Override
    public Mono<VerificationContext> enrichContext(VerificationContext context) {
        context.setReply(CoreCopReply.builder()
                        .matched(true)
                        .build());
        return Mono.just(context);
    }

}
