package fr.sis.sisid.copuk.controllers;

import java.io.Serial;
import java.util.ArrayList;
import java.util.List;

import fr.sis.sisid.copuk.OpenBankingConstants;
import lombok.Getter;

@Getter
public class FapiHeaderException extends RuntimeException {

    @Serial
    private static final long serialVersionUID = -6973818780619647269L;
    private final String fapiFinancialId;
    private final String fapiInteractionId;
    private final boolean validFapiFinancialId;
    private final boolean validFapiInteractionId;


    public FapiHeaderException(String fapiFinancialId, boolean validFapiFinancialId, String fapiInteractionId,
            boolean validFapiInteractionId) {
        super("Invalid fapi header");
        this.fapiFinancialId = fapiFinancialId;
        this.validFapiFinancialId = validFapiFinancialId;
        this.fapiInteractionId = fapiInteractionId;
        this.validFapiInteractionId = validFapiInteractionId;
    }

    @Override
    public String toString() {
        return "FapiHeaderException{" +
                "fapiFinancialId='" + fapiFinancialId + '\'' +
                ", fapiInteractionId='" + fapiInteractionId + '\'' +
                ", validFapiFinancialId=" + validFapiFinancialId +
                ", validFapiInteractionId=" + validFapiInteractionId +
                '}';
    }

    public List<String> errorHeaders() {
        List<String> list = new ArrayList<>();
        if(!validFapiFinancialId) {
            list.add(OpenBankingConstants.ORGANISATION_HEADER);
        }
        if(!validFapiInteractionId) {
            list.add(OpenBankingConstants.CORRELATION_ID_HEADER);
        }
        return list;
    }
}
