package fr.sis.sisid.copuk.cop.core.rules;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import reactor.core.publisher.Mono;

/**
 * Rule applied to a COP context
 * It fetches additional information, then can be applied to a COP context
 * to build a COP reply
 */
public interface VerificationRule {

    /**
     * Whether or not to apply this rule
     * @param context
     * @return
     */
    boolean matches(VerificationContext context);

    /**
     * Adds additional informations to the context,
     * required to decide if this rule matches or to apply it
     * @param context
     * @return
     */
    Mono<VerificationContext> enrichContext(VerificationContext context);

    /**
     * Apply this rule to the context
     * @param context
     * @return
     */
    Mono<VerificationContext> process(VerificationContext context);

    public String getRuleCode();

}
