package fr.sis.sisid.copuk.entities;

import java.util.List;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import fr.sis.sisid.copuk.namematching.processors.prefix.InvoiceDiscountAccount;

@Component
public class InvoiceDiscountAccountImpl implements InvoiceDiscountAccount {
    private final InvoiceDiscountAccountDAO invoiceDiscountAccountDAO;

    public InvoiceDiscountAccountImpl(InvoiceDiscountAccountDAO invoiceDiscountAccountDAO) {
        this.invoiceDiscountAccountDAO = invoiceDiscountAccountDAO;
    }

    @Override
    @Cacheable("invoice-discount")
    public List<String> getPrefixes() {
        return invoiceDiscountAccountDAO.findAll().stream().map(InvoiceDiscountAccountEntity::getPrefix).toList();
    }

    @CacheEvict("invoice-discount")
    public void clearCache() {
        // nothing to do
    }
}
