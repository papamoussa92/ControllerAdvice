package fr.sis.sisid.copuk.entities;

import java.io.Serial;
import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.ColumnResult;
import javax.persistence.ConstructorResult;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.SqlResultSetMapping;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "audit")
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor

@SqlResultSetMapping(name = "AuditStatsResult", classes = {
        @ConstructorResult(targetClass = AuditStatsResult.class, columns = {
                @ColumnResult(name = "nb_personal_requests", type = Long.class),
                @ColumnResult(name = "nb_business_requests", type = Long.class),
                @ColumnResult(name = "nb_matched", type = Long.class),
                @ColumnResult(name = "nb_annm", type = Long.class),
                @ColumnResult(name = "nb_mbam", type = Long.class),
                @ColumnResult(name = "nb_banm", type = Long.class),
                @ColumnResult(name = "nb_panm", type = Long.class),
                @ColumnResult(name = "nb_bamm", type = Long.class),
                @ColumnResult(name = "nb_ac01", type = Long.class),
                @ColumnResult(name = "nb_ivcr", type = Long.class),
                @ColumnResult(name = "nb_acns", type = Long.class),
                @ColumnResult(name = "nb_opto", type = Long.class),
                @ColumnResult(name = "nb_cass", type = Long.class),
                @ColumnResult(name = "nb_scns", type = Long.class),
                @ColumnResult(name = "nb_outside_of_sla", type = Long.class),
        }) })
@NamedNativeQuery(name = "get_audit_stats", query = """
        with audit_period as (
            select
              *
            from
              audit ait

            where
                  ait.date_audit < :to
              and ait.date_audit >= :from
        )
        select
          (select count (audit_period.id) from audit_period where audit_period.payee_account_type = 'PRIVATE') as nb_personal_requests,
          (select count (audit_period.id) from audit_period where audit_period.payee_account_type = 'BUSINESS') as nb_business_requests,
          (select count (audit_period.id) from audit_period where audit_period.status_http_code = 'OK' and audit_period.matched is true) as nb_matched,
          (select count (audit_period.id) from audit_period where audit_period.status_http_code = 'OK' and audit_period.matching_reason_code = 'ANNM') as nb_annm,
          (select count (audit_period.id) from audit_period where audit_period.status_http_code = 'OK' and audit_period.matching_reason_code = 'MBAM') as nb_mbam,
          (select count (audit_period.id) from audit_period where audit_period.status_http_code = 'OK' and audit_period.matching_reason_code = 'BANM') as nb_banm,
          (select count (audit_period.id) from audit_period where audit_period.status_http_code = 'OK' and audit_period.matching_reason_code = 'PANM') as nb_panm,
          (select count (audit_period.id) from audit_period where audit_period.status_http_code = 'OK' and audit_period.matching_reason_code = 'BAMM') as nb_bamm,
          (select count (audit_period.id) from audit_period where audit_period.status_http_code = 'OK' and audit_period.matching_reason_code = 'AC01') as nb_ac01,
          (select count (audit_period.id) from audit_period where audit_period.status_http_code = 'OK' and audit_period.matching_reason_code = 'IVCR') as nb_ivcr,
          (select count (audit_period.id) from audit_period where audit_period.status_http_code = 'OK' and audit_period.matching_reason_code = 'ACNS') as nb_acns,
          (select count (audit_period.id) from audit_period where audit_period.status_http_code = 'OK' and audit_period.matching_reason_code = 'OPTO') as nb_opto,
          (select count (audit_period.id) from audit_period where audit_period.status_http_code = 'OK' and audit_period.matching_reason_code = 'CASS') as nb_cass,
          (select count (audit_period.id) from audit_period where audit_period.status_http_code = 'OK' and audit_period.matching_reason_code = 'SCNS') as nb_scns,
          (select count (audit_period.id) from audit_period where audit_period.cop_response_timestamp - audit_period.cop_request_timestamp > make_interval( secs => :sla_seconds)) as nb_outside_of_sla
          limit 1

        """, resultSetMapping = "AuditStatsResult")
public class Audit implements Serializable {

    @Serial
    private static final long serialVersionUID = 8095360595306637706L;

    @Id
    @Column(name = "id", columnDefinition = "SERIAL")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "date_audit")
    @Builder.Default
    private Timestamp dateAudit = new Timestamp(System.currentTimeMillis());

    @Column(name = "correlation_id", unique = true, nullable = false, length = 30)
    private String correlationId;

    @Column(name = "input_account_name")
    private String inputAccountName;

    @Column(name = "account_name_from_cib_api")
    private String accountNameFromCibApi;

    @Column(name = "score", precision = 9, scale = 8)
    private BigDecimal score;

    @Column(name = "match_threshold", precision = 4, scale = 2)
    private BigDecimal matchThreshold;

    @Column(name = "closematch_threshold", precision = 4, scale = 2)
    private BigDecimal closematchThreshold;

    @Column(name = "configuration_version")
    private String configurationVersion;

    @Column(name = "engine_version")
    private String engineVersion;

    @Column(name = "identification")
    private String identification;

    @Column(name = "payee_account_type")
    private String payeeAccountType;

    @Column(name = "status_http_code")
    private String statusHttpCode;

    @Column(name = "open_banking_error_code")
    private String openBankingErrorCode;

    @Column(name = "matched")
    private Boolean matched;

    @Column(name = "rules")
    private String rules;

    @Column(name = "account_currency")
    private String accountCurrency;

    @Column(name = "matching_reason_code")
    private String matchingReasonCode;

    @Column(name = "cop_request_timestamp")
    private Timestamp copRequestTimestamp;

    @Column(name = "cop_response_timestamp")
    private Timestamp copResponseTimestamp;

    @Column(name = "cib_api_request_timestamp")
    private Timestamp cibApiRequestTimestamp;

    @Column(name = "cib_api_response_timestamp")
    private Timestamp cibApiResponseTimestamp;

    @Column(name = "org_id")
    private String organizationId;

    @Column(name = "client_id")
    private String clientId;

}
