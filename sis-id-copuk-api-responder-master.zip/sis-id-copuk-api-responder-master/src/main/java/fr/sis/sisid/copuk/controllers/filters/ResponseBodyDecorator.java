package fr.sis.sisid.copuk.controllers.filters;

import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.reactivestreams.Publisher;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.http.server.reactive.ServerHttpResponseDecorator;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.channels.Channels;

/**
 * Wrapper around a response to retrieve its entire body as a string
 */
@Slf4j
public class ResponseBodyDecorator extends ServerHttpResponseDecorator {
    String data;
    public ResponseBodyDecorator(ServerHttpResponse delegate) {
        super(delegate);
    }

    @Override public @NonNull Mono<Void> writeWith(@NonNull Publisher<? extends DataBuffer> body) {
        return super.writeWith(Flux.from(body)
                .doOnNext(buffer -> {
                    var bodyStream = new ByteArrayOutputStream();
                    try {
                        Channels.newChannel(bodyStream).write(buffer.asByteBuffer().asReadOnlyBuffer());
                        data = bodyStream.toString();
                    } catch (IOException e) {
                        log.warn("Could not buffer the response", e);
                    }
                }));
    }

    public String getBodyAsString() {
        return data;
    }
}
