package fr.sis.sisid.copuk.model;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Builder
public class CoreAccountInfo implements AccountInfoReply {

    private String name;

    private AccountType accountType;

    private String currency;
}
