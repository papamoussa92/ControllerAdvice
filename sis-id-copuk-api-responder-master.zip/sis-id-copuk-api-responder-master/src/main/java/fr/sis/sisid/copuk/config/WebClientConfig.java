package fr.sis.sisid.copuk.config;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import javax.net.ssl.SSLException;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

import org.apache.logging.log4j.util.Strings;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.springframework.beans.factory.BeanInitializationException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.security.oauth2.client.AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.ClientCredentialsReactiveOAuth2AuthorizedClientProvider;
import org.springframework.security.oauth2.client.InMemoryReactiveOAuth2AuthorizedClientService;
import org.springframework.security.oauth2.client.ReactiveOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.endpoint.WebClientReactiveClientCredentialsTokenResponseClient;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.InMemoryReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServerOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.web.reactive.function.client.WebClient;

import fr.sis.sisid.copuk.tools.MtlsTools;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.ssl.ClientAuth;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import lombok.extern.slf4j.Slf4j;
import reactor.netty.http.client.HttpClient;
import reactor.netty.tcp.SslProvider.SslContextSpec;
import reactor.netty.transport.logging.AdvancedByteBufFormat;

@Configuration
@Slf4j
public class WebClientConfig {

    /**
     * Bnp client key
     */
    @Value("${app.bnp.payee-information-srv.client-key.path}")
    private Resource bnpClientKeyResource;

    /**
     * Bnp client cert
     */
    @Value("${app.bnp.payee-information-srv.client-cert.path}")
    private Resource bnpClientCertResource;

    /**
     * Bnp CA cert (.crt)
     */
    @Value("${app.bnp.payee-information-srv.ca-cert.path}")
    private Resource bnpClientCACertResource;

    /**
     * Bnp payee information endpoint
     */
    @Value("${app.bnp.payee-information-srv.url}")
    String payeeInformationSrvUrl;

    /**
     * Open banking certificate authority
     */
    @Value("${app.stub.jwks.certificate.text:#{null}}")
    String openBankingCA;

    /**
     * OAuth client setup
     * @param tokenUri The endpoint to retrieve token from
     * @param clientId the unique TPP client id
     * @param clientSecret The registered TPP client secret to authenticate with
     * @return client registration repository
     */
    @Bean
    ReactiveClientRegistrationRepository getRegistration(
            @Value("${spring.security.oauth2.client.provider.bnp.token-uri}") String tokenUri,
            @Value("${spring.security.oauth2.client.registration.bnp.client-id}") String clientId,
            @Value("${spring.security.oauth2.client.registration.bnp.client-secret}") String clientSecret) {
        ClientRegistration registration = ClientRegistration
                // name of this oauth client
                .withRegistrationId("bnp")
                .tokenUri(tokenUri)
                .clientId(clientId)
                .clientSecret(clientSecret)
                .authorizationGrantType(AuthorizationGrantType.CLIENT_CREDENTIALS)
                .build();
        return new InMemoryReactiveClientRegistrationRepository(registration);
    }

    @Bean
    public ReactiveOAuth2AuthorizedClientManager authorizedClients(
            ReactiveClientRegistrationRepository clientRegistrationRepository, ClientHttpConnector httpConnector,
            WebClient.Builder webClientBuilder) {
        var authzClientsManager = new AuthorizedClientServiceReactiveOAuth2AuthorizedClientManager(
                clientRegistrationRepository,
                new InMemoryReactiveOAuth2AuthorizedClientService(clientRegistrationRepository));
        var authzCliProvider = new ClientCredentialsReactiveOAuth2AuthorizedClientProvider();
        var tokenResponseClient = new WebClientReactiveClientCredentialsTokenResponseClient();
        var mtlsWebClient = webClientBuilder
                .clientConnector(httpConnector)
                .build();
        tokenResponseClient.setWebClient(mtlsWebClient);
        authzCliProvider.setAccessTokenResponseClient(tokenResponseClient);
        authzClientsManager.setAuthorizedClientProvider(authzCliProvider);
        return authzClientsManager;
    }

    /**
     * Creates an http connector to be used for https client requests.
     * The parameters for certificates are optional and will revert to classpath resources if not provided.
     *
     * @param bnpClientKey The full PEM file text. Will use the path provided in property app.bnp.payee-information-srv.client-key.path otherwise.
     * @param bnpClientCert The full client CRT file text. Will use the path provided in property app.bnp.payee-information-srv.client-cert.path otherwise.
     * @param bnpClientCACert The full client CRT file text. Will use the path provided in property app.bnp.payee-information-srv.ca-cert.path otherwise.
     * @return a client connector ready for client SSL which can be be passed to a WebClient
     * @throws BeanInitializationException if configuration is invalid, the connector singleton will fail to initialize
     */
    @Bean
    public ClientHttpConnector httpConnector(
            @Value("${app.bnp.payee-information-srv.client-key.txt:#{null}}") String bnpClientKey,
            @Value("${app.bnp.payee-information-srv.client-cert.txt:#{null}}") String bnpClientCert,
            @Value("${app.bnp.payee-information-srv.ca-cert.txt:#{null}}") String bnpClientCACert)
            throws BeanInitializationException {
        try {
            String pkcs8Pem;
            if (Strings.isEmpty(bnpClientKey)) {
                pkcs8Pem = Files.readString(Path.of(bnpClientKeyResource.getURI()));
            } else {
                pkcs8Pem = bnpClientKey;
                log.warn("Using default bnp client key");
            }

            byte[] clientCertBytes;
            if (Strings.isEmpty(bnpClientCert)) {
                clientCertBytes = Files.readString(Path.of(bnpClientCertResource.getURI())).getBytes();
            } else {
                clientCertBytes = bnpClientCert.getBytes();
                log.warn("Using default bnp client cert");
            }

            byte[] clientCACertBytes;
            if (Strings.isEmpty(bnpClientCert)) {
                clientCACertBytes = Files.readString(Path.of(bnpClientCACertResource.getURI())).getBytes();
            } else {
                clientCACertBytes = bnpClientCACert.getBytes();
                log.warn("Using default bnp client CA cert");
            }

            // client key
            PEMParser pemParser = new PEMParser(new StringReader(pkcs8Pem));
            JcaPEMKeyConverter converter = new JcaPEMKeyConverter();

            Object pemKey = pemParser.readObject();
            PrivateKey clientKey;
            if (pemKey instanceof PrivateKeyInfo privateKeyInfo) {
                clientKey = converter.getPrivateKey(privateKeyInfo);
            } else if (pemKey instanceof PEMKeyPair pemKeyPair) {
                clientKey = converter.getPrivateKey(pemKeyPair.getPrivateKeyInfo());
            } else {
                throw new BeanInitializationException("Could not cast the client key");
            }

            // client cert
            CertificateFactory cf = CertificateFactory.getInstance("X.509");
            X509Certificate clientCrt = (X509Certificate) cf.generateCertificate(new ByteArrayInputStream(
                    clientCertBytes));
            // client certificate authority cert²
            X509Certificate caCert = (X509Certificate) cf.generateCertificate(new ByteArrayInputStream(
                    clientCACertBytes));

            // tie it all up together
            SslContext sslContext = SslContextBuilder
                    .forClient().clientAuth(ClientAuth.REQUIRE)
                    .trustManager(getCertificatesToTrust(caCert))
                    .keyManager(clientKey, clientCrt)
                    .build();

            HttpClient httpClient = HttpClient.create()
                    .wiretap(log.getName(), LogLevel.DEBUG, AdvancedByteBufFormat.TEXTUAL)
                    .secure((SslContextSpec sslContextSpec) -> sslContextSpec.sslContext(sslContext));
            return new ReactorClientHttpConnector(httpClient);
        } catch (CertificateException | IOException | KeyStoreException | NoSuchAlgorithmException e) {
            throw new BeanInitializationException(e.getMessage(), e);
        }
    }

    /**
     * Adds a certificate authority to the list of trusted certificates
     * @param bnpCACert
     * @return
     * @throws KeyStoreException
     * @throws NoSuchAlgorithmException
     */
    private List<X509Certificate> getCertificatesToTrust(X509Certificate bnpCACert)
            throws KeyStoreException, NoSuchAlgorithmException {
        TrustManagerFactory trustManagerFactory = TrustManagerFactory
                .getInstance(TrustManagerFactory.getDefaultAlgorithm());
        trustManagerFactory.init((KeyStore) null);
        List<TrustManager> trustManagers = Arrays.asList(trustManagerFactory.getTrustManagers());
        List<X509Certificate> certificates = trustManagers.stream()
                .filter(X509TrustManager.class::isInstance)
                .map(X509TrustManager.class::cast)
                .map(trustManager -> Arrays.asList(trustManager.getAcceptedIssuers()))
                .flatMap(Collection::stream)
                .collect(Collectors.toList());
        certificates.add(bnpCACert);
        return certificates;
    }

    /**
     * Webclient to call the bnp payee information endpoint
     * Authenticated through oauth2 client credentials
     * @param authorizedClientsManager The OAuth 2 client manager to retrieve token
     * @return web client to connect to BNPP account lookup API
     */
    @Bean(name = "bnpWebClient")
    public WebClient bnpWebClient(
            ReactiveOAuth2AuthorizedClientManager authorizedClientsManager, ClientHttpConnector httpConnector,
            WebClient.Builder builder) {
        // oauth client setup
        ServerOAuth2AuthorizedClientExchangeFilterFunction oauth = new ServerOAuth2AuthorizedClientExchangeFilterFunction(
                authorizedClientsManager);
        // oauth client name, referenced in the configuration
        oauth.setDefaultClientRegistrationId("bnp");
        log.info("BNP payee information accessible at {}", this.payeeInformationSrvUrl);
        return builder
                .clientConnector(httpConnector)
                .filter(oauth)
                .baseUrl(payeeInformationSrvUrl)
                .build();
    }

    @Bean(name = "jwksWebClient")
    public WebClient jwksWebClient(WebClient.Builder builder) {
        X509Certificate obCA;
        SslContext obSslContext;
        try {
            obCA = MtlsTools.parsePEMCert(openBankingCA);
            obSslContext = SslContextBuilder.forClient().trustManager(getCertificatesToTrust(obCA)).build();
        } catch (CertificateException | SSLException | KeyStoreException | NoSuchAlgorithmException e) {
            throw new BeanInitializationException("Could not initialize the jwks web client", e);
        }

        return builder.clientConnector(
                new ReactorClientHttpConnector(
                        HttpClient.create()
                                .secure(sslContext -> sslContext.sslContext(obSslContext).build())))
                .build();
    }

}
