package fr.sis.sisid.copuk.service.mapper;

import org.springframework.stereotype.Component;

import fr.sis.sisid.copuk.copapi.model.InlineResponse200;
import fr.sis.sisid.copuk.copapi.model.InlineResponse200Data;
import fr.sis.sisid.copuk.copapi.model.InlineResponse200DataVerificationReport;
import fr.sis.sisid.copuk.mappers.CopReplyMapper;
import fr.sis.sisid.copuk.model.CoreCopReply;

@Component
public class CopReplyMapperImpl implements CopReplyMapper {

    public InlineResponse200 toDTO(CoreCopReply domainObject) {
        return new InlineResponse200()
                .data(new InlineResponse200Data()
                        .verificationReport(new InlineResponse200DataVerificationReport()
                                .matched(domainObject.isMatched())
                                .name(domainObject.getName().orElse(null))
                                .reasonCode(domainObject.getReasonCode().orElse(null))));
    }
}
