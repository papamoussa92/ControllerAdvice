package fr.sis.sisid.copuk.config;

import com.nimbusds.jose.JOSEException;
import fr.sis.sisid.copuk.tools.ResponseSigner;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
public class EncodeConfig {
    /**
     * Signs a non-repudiation signature for a response to a name verification request
     *
     * @param nonRepudiationProperties Group of properties from the yml file
     * @return the utility to produce the response signature
     * @throws JOSEException if something goes wrong with the signature
     */
    @Bean
    public ResponseSigner responseSigner(NonRepudiationProperties nonRepudiationProperties) throws JOSEException {
        return ResponseSigner.builder()
                .privateKey(nonRepudiationProperties.getPrivateKey())
                .algorithm(nonRepudiationProperties.getAlgorithm())
                .typHeaderValue(nonRepudiationProperties.getSupportedTyp())
                .keyId(nonRepudiationProperties.getKeyId())
                .ctyHeaderValue(nonRepudiationProperties.getSupportedCty().get(0))
                .iatHeaderName(nonRepudiationProperties.getIatClaimName())
                .issHeaderName(nonRepudiationProperties.getIssClaimName())
                .tanHeaderName(nonRepudiationProperties.getTanClaimName())
                .tanHeaderValue(nonRepudiationProperties.getSupportedTan())
                .orgId(nonRepudiationProperties.getOrgId())
                .build();

    }
}
