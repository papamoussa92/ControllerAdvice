package fr.sis.sisid.copuk.cop.core.rules.processors;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.copapi.model.ReasonCodes;
import fr.sis.sisid.copuk.model.CoreCopReply;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Optional;

@Component
public class AccountDetailIncorrectReplyProcessor implements VerificationContextProcessor {

    @Override
    public Mono<VerificationContext> enrichContext(VerificationContext context) {
        context.setReply(CoreCopReply.builder()
                        .matched(false)
                        .name(Optional.empty())
                        .reasonCode(Optional.of(ReasonCodes.ANNM))
                        .build());
        return Mono.just(context);
    }

}