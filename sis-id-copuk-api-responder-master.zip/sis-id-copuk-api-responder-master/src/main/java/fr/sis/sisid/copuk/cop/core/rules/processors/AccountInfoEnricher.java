package fr.sis.sisid.copuk.cop.core.rules.processors;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.spi.AccountInfoProvider;
import fr.sis.sisid.copuk.model.AccountInfoRejection;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

/**
 * Provides the verification context with account information,
 * fetched from another service
 */
@Component
@AllArgsConstructor(onConstructor = @__(@Autowired))
@NoArgsConstructor
public class AccountInfoEnricher implements VerificationContextProcessor {

    private AccountInfoProvider accountInfoProvider;

    @Override
    public Mono<VerificationContext> enrichContext(VerificationContext context) {
        if (context.getAccountInfo().isPresent() || context.getAccountInfoError().isPresent()) {
            return Mono.just(context);
        }

        context.setCibApiStartTime(currentTime());

        return accountInfoProvider
                .getAccountInfo(context.getRequest())
                .flatMap(accInfoReply -> {
                    if (accInfoReply instanceof CoreAccountInfo accInfo) {
                        context.setAccountInfo(accInfo);
                    } else if (accInfoReply instanceof AccountInfoRejection accInfoRejection) {
                        context.setAccountInfoError(accInfoRejection);
                    }
                    return Mono.just(context);
                }).doOnNext(s -> context.setCibApiEndTime(currentTime()));
    }

    protected Long currentTime() {
        return System.currentTimeMillis();
    }

}
