package fr.sis.sisid.copuk.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import fr.sis.sisid.copuk.dto.SsaDTO;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Component
@Slf4j
public class ClientRegistrationClientImpl implements ClientRegistrationClient {

    @Value("${app.client-registration-url}")
    private String clientRegistrationUrl;

    @Override
    public Mono<ResponseEntity<SsaDTO>> getSSA(String clientId) {
        log.debug("Querying client {} SSA ...  on {}", clientId, clientRegistrationUrl);

        return WebClient.create(clientRegistrationUrl)
                .get()
                .uri("/internal/client/{client-id}/ssa", clientId)
                .retrieve()
                .onStatus(HttpStatus.NOT_FOUND::equals, r -> Mono.empty())
                .toEntity(SsaDTO.class)
                .log();
    }

}
