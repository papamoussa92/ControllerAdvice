package fr.sis.sisid.copuk.cop.core.rules;

import java.io.Serial;

public class VerificationRuleException extends RuntimeException {

    @Serial private static final long serialVersionUID = 1675477392707349333L;

    public VerificationRuleException(String message) {
        super(message);
    }


}
