package fr.sis.sisid.copuk.config;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@ConfigurationProperties("non-repudiation")
@Data
public class NonRepudiationProperties {

    private String iatClaimName;

    private String issClaimName;

    private String tanClaimName;

    private List<String> supportedCty;

    private String supportedTyp;

    private String supportedTan;

    private String algorithm;

    private String orgId;

    private String keyId;

    private String privateKey;
}
