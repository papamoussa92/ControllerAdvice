package fr.sis.sisid.copuk.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@ConfigurationProperties(value = "app.bnp.custom-code-mappings")
@Data
public class AccountInfoProperties {

    private String accountOptOut;

    private String accountSwitched;
}
