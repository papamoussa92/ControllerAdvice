package fr.sis.sisid.copuk.controllers;

import fr.sis.sisid.copuk.dto.OpenIdConfigDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;

/**
 * .well-known/openid-configuration endpoint, to facilitate deployment
 * before open-id gets implemented on the roject
 * 
 * cf https://openid.net/specs/openid-connect-discovery-1_0.html#ProviderMetadata
 */
@RestController
@Slf4j
@RequestMapping("/api/v1.0")
public class WellKnownController {

    @Value("${app.responder-url}")
    private String responderUrl;

    @Value("${app.open-id-config-version}")
    private String openIdConfigVersion;

    @Value("${app.auth-server-url}")
    private String authServerBaseUrl;

    @Value("${app.jwks-uri}")
    private String jwksUri;

    @Value("${app.registration-endpoint}")
    private String registrationEndpoint;

    @GetMapping("/.well-known/openid-configuration")
    public OpenIdConfigDTO getOpenIdConfiguration() {
        log.info("getOpenIdConfiguration- start");
        final String CRYPTO = "PS256";
        return OpenIdConfigDTO.builder()
                .version(openIdConfigVersion)
                .issuer(responderUrl)
                .registrationEndpoint(registrationEndpoint)
                .authorizationEndpoint(authServerBaseUrl + "/protocol/openid-connect/auth")
                .tokenEndpoint(authServerBaseUrl + "/protocol/openid-connect/token")
                .jwksUri(jwksUri)
                .scopesSupported(Arrays.asList("openid", "name-verification"))
                .requestParameterSupported(false)
                .requestUriParameterSupported(false)
               // .claimsSupported(Arrays.asList("openbanking_intent_id"))
                .claimsParameterSupported(true)
                .responseTypesSupported(Arrays.asList("code id_token"))
                .grantTypesSupported(Arrays.asList("client_credentials"))
                .subjectTypesSupported(Arrays.asList("public"))
                .idTokenSigningAlgValuesSupported(Arrays.asList(CRYPTO))
                .tokenEndpointAuthSigningAlgValuesSupported(Arrays.asList(CRYPTO))
                .tokenEndpointAuthMethodsSupported(Arrays.asList("private_key_jwt"))
                //.claimTypesSupported(Arrays.asList("normal"))
                .requestObjectEncryptionAlgValuesSupported(Arrays.asList(CRYPTO))
                .requestObjectSigningAlgValuesSupported(Arrays.asList(CRYPTO))
                .build();

    }
}
