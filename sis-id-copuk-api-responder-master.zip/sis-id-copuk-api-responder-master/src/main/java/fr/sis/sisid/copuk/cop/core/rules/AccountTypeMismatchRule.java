package fr.sis.sisid.copuk.cop.core.rules;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.rules.processors.AccountInfoEnricher;
import fr.sis.sisid.copuk.copapi.model.ReasonCodes;
import fr.sis.sisid.copuk.model.AccountType;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import reactor.core.publisher.Mono;

/**
 * Payee information was requested for an unsupported ( non-business ) account type
 */
@AllArgsConstructor(onConstructor = @__(@Autowired))
@Component
@NoArgsConstructor
public class AccountTypeMismatchRule implements VerificationRule {

    private AccountInfoEnricher accountInfoEnricher;

    @Override
    public boolean matches(VerificationContext context) {
        return context.getAccountInfo().isPresent()
                && context.getRequest() != null
                && context.getAccountInfo().flatMap(accountInfo -> Optional.of(accountInfo.getAccountType()))
                        .orElse(null) != context.getRequest().getAccountType();
    }

    @Override
    public Mono<VerificationContext> enrichContext(VerificationContext context) {
        if (context.getReply().isPresent()) {
            return Mono.just(context);
        }
        return this.accountInfoEnricher.enrichContext(context);
    }

    @Override
    public Mono<VerificationContext> process(VerificationContext context) {
        if (context.getReply().isEmpty()) {
            return Mono.just(context);
        }

        // Change the reply, if match or close match since the account type is incorrect
        if (context.getReply().map(CoreCopReply::isMatched).orElse(false) || context.getNameMatchingResult()
                .map(res -> res.getScore().getDecision()).orElse(MatchingDecision.NO_MATCH) == MatchingDecision.MATCH) {

            var reasonCode = context.getAccountInfo()
                    .map(accountInfo -> accountInfo.getAccountType() == AccountType.BUSINESS ? ReasonCodes.BANM
                            : ReasonCodes.PANM);

            context.setReply(CoreCopReply.builder()
                    .matched(false)
                    .reasonCode(reasonCode)
                    .build());
        } else if (context.getNameMatchingResult().map(res -> res.getScore().getDecision())
                .orElse(MatchingDecision.NO_MATCH) == MatchingDecision.CLOSE_MATCH) {
            var reasonCode = context.getAccountInfo()
                    .map(accountInfo -> accountInfo.getAccountType() == AccountType.BUSINESS ? ReasonCodes.BAMM
                            : ReasonCodes.PAMM);

            context.setReply(CoreCopReply.builder()
                    .matched(false)
                    .reasonCode(reasonCode)
                    .name(Optional.of(context.getAccountInfo().map(CoreAccountInfo::getName).orElse("")))
                    .build());
        }

        return Mono.just(context);
    }

    @Override
    public String getRuleCode() {
        return "ACCOUNT-TYPE-MISMATCH";
    }

}
