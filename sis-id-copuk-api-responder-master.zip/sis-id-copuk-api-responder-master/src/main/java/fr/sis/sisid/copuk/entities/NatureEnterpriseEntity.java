package fr.sis.sisid.copuk.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.io.Serial;

@Entity
@Table(name = "nature_enterprise")
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class NatureEnterpriseEntity {
    @Serial
    private static final long serialVersionUID = 8095360595306637730L;

    @Id
    @Column(name = "id", columnDefinition = "SERIAL")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nature")
    private String nature;
}
