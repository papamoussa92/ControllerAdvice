package fr.sis.sisid.copuk.controllers.filters;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.nimbusds.oauth2.sdk.util.StringUtils;

import fr.sis.sisid.copuk.client.ClientRegistrationClient;
import fr.sis.sisid.copuk.controllers.errors.NonRepudiationException;
import fr.sis.sisid.copuk.dto.SsaDTO;
import fr.sis.sisid.copuk.tools.JwtStringClaims;
import fr.sis.sisid.copuk.tools.JwtTools;
import fr.sis.sisid.copuk.tools.errors.JwtDeserializationException;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Component
@AllArgsConstructor
public class SsaProvider {

    private JwtTools jwtTools;

    private ClientRegistrationClient registrationClient;

    /**
     * Get the client id out of the Authorization header
     * @param authorizationHeader
     * @return
     * @throws NonRepudiationException
     */
    public Mono<String> extractClientId(String authorizationHeader) {
        if (StringUtils.isBlank(authorizationHeader)) {
            return Mono.error(new NonRepudiationException("Empty authorization header"));
        }
        String bearerToken = authorizationHeader.replaceFirst("Bearer ", "");

        String clientId = null;
        try {
            // client id is written as an azp claim
            clientId = this.jwtTools.getClaims(bearerToken, JwtStringClaims.AUTHORIZED_PARTY);
        } catch (JwtDeserializationException err) {
            log.warn(err.getMessage(), err);
        }
        if (StringUtils.isBlank(clientId)) {
            return Mono.error(new NonRepudiationException("Bearer token has no AZP claim"));
        }
        return Mono.just(clientId);
    }

    /**
     * Gets and validates the ssa for a client
     * @param clientId
     * @return
     */
    public Mono<SsaDTO> getClientSsa(String clientId) {
        // query the registration service for the ssa registered to this client
        return this.registrationClient.getSSA(clientId)
                .doOnError(err -> {
                    throw new NonRepudiationException("Failed to fetch client SSA", err);
                }).flatMap(ssaResponse -> {
                    if (ssaResponse == null || !HttpStatus.OK.equals(ssaResponse.getStatusCode())) {
                        return Mono
                                .error(new NonRepudiationException("Could not retrieve client SSA, HTTP %s".formatted(
                                        ssaResponse == null ? null : ssaResponse.getStatusCode())));
                    }
                    SsaDTO ssa = ssaResponse.getBody();
                    if (ssa == null || StringUtils.isBlank(ssa.getJti()) || StringUtils.isBlank(ssa.getOrgId())
                            || StringUtils.isBlank(ssa.getSoftwareJwksEndpoint())) {
                        return Mono.error(new NonRepudiationException("SSA is invalid"));
                    }
                    return Mono.just(ssa);
                });
    }

}
