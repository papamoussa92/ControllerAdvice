package fr.sis.sisid.copuk.controllers.errors;

import java.io.Serial;

import lombok.Getter;

public class ClientRateLimitedException extends RuntimeException {

    @Serial
    private static final long serialVersionUID = 2242497057173530080L;

    @Getter
    private final long remainingSeconds;

    @Getter
    private final String clientId;

    public ClientRateLimitedException(String clientId, long remainingSeconds) {
        super(clientId + " has been rate limited, and will be able to perform more queries in " + remainingSeconds
                + " seconds.");
        this.clientId = clientId;
        this.remainingSeconds = remainingSeconds;
    }

}
