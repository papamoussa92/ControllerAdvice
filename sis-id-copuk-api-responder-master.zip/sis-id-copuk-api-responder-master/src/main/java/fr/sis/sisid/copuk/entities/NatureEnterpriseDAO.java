package fr.sis.sisid.copuk.entities;

import org.springframework.data.jpa.repository.JpaRepository;

public interface NatureEnterpriseDAO extends JpaRepository<NatureEnterpriseEntity, Long> {
}
