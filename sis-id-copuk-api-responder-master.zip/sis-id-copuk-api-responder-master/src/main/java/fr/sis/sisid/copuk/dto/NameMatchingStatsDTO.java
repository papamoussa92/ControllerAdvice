package fr.sis.sisid.copuk.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class NameMatchingStatsDTO {

    @JsonProperty(index = 0, value = "Registration ID")
    private String registrationId;

    @JsonProperty(index = 1, value = "Requests with a personal account marker")
    private Long nbPersonalRequests;

    @JsonProperty(index = 2, value = "Requests with a business account marker")
    private Long nbBusinessRequests;

    @JsonProperty(index = 3, value = "1")
    private Long nbMatched;

    @JsonProperty(index = 4, value = "ANNM")
    private Long nbANNM;

    @JsonProperty(index = 5, value = "MBAM")
    private Long nbMBAM;

    @JsonProperty(index = 6, value = "BANM")
    private Long nbBANM;

    @JsonProperty(index = 7, value = "PANM")
    private Long nbPANM;

    @JsonProperty(index = 8, value = "BAMM")
    private Long nbBAMM;

    @JsonProperty(index = 9, value = "AC01")
    private Long nbAC01;

    @JsonProperty(index = 10, value = "IVCR")
    private Long nbIVCR;

    @JsonProperty(index = 11, value = "ACNS")
    private Long nbACNS;

    @JsonProperty(index = 12, value = "OPTO")
    private Long nbOPTO;

    @JsonProperty(index = 13, value = "CASS")
    private Long nbCASS;

    @JsonProperty(index = 14, value = "SNCS")
    private Long nbSCNS;

    @JsonProperty(index = 15, value = "Responses outside of response time SLA")
    private Long nbOutsideOfSLA;
}
