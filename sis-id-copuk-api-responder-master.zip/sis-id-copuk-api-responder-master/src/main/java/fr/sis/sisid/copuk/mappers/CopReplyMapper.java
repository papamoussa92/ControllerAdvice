package fr.sis.sisid.copuk.mappers;

import fr.sis.sisid.copuk.copapi.model.InlineResponse200;
import fr.sis.sisid.copuk.model.CoreCopReply;

public interface CopReplyMapper {
    InlineResponse200 toDTO(CoreCopReply domainObject);
}
