package fr.sis.sisid.copuk.service;

import fr.sis.sisid.copuk.cop.spi.AccountInfoProvider;
import fr.sis.sisid.copuk.copapi.OpenBankingErrorCode;
import fr.sis.sisid.copuk.copapi.model.OBError1;
import fr.sis.sisid.copuk.copapi.model.OBErrorResponse1;
import fr.sis.sisid.copuk.exceptions.OBErrorResponseException;
import fr.sis.sisid.copuk.ext.bnp.api.PayeeInformationClient;
import fr.sis.sisid.copuk.mappers.CopRequestMapper;
import fr.sis.sisid.copuk.model.AccountInfoReply;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import fr.sis.sisid.copuk.service.mapper.AccountInfoMapperImpl;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

/**
 * Calls the BNPP payee informaation API to provide bank account info
 */
@AllArgsConstructor(onConstructor = @__(@Autowired))
@NoArgsConstructor
@Component
@Slf4j
public class PayeeInformationServiceImpl implements AccountInfoProvider {

    private PayeeInformationClient payeeInfoClient;

    private CopRequestMapper copRequestMapper;

    private AccountInfoMapperImpl accountInfoMapper;

    @Override
    public Mono<AccountInfoReply> getAccountInfo(CoreCopRequest copRequest) {
        var copRequestDTO = this.copRequestMapper.toDTO(copRequest);

        return this.payeeInfoClient.providePayeeInformation(copRequestDTO)
                .doOnError(throwable -> log.error("Failed on BNPP API Call", throwable))
                .doOnError(err -> {
                    var errorResponse = new OBErrorResponse1()
                            .code("503")
                            .message("Service unavailable");
                    errorResponse.addErrorsItem(new OBError1()
                            .errorCode(OpenBankingErrorCode.UNEXPECTED_ERROR.getCode())
                            .message("The resource server is unreachable"));
                    throw new OBErrorResponseException(errorResponse, 503);
                })
                .flatMap(responseEntity -> Mono.just(responseEntity.getBody()))
                .flatMap(copReply -> Mono.just(this.accountInfoMapper.toDomain(copReply)));
    }

}
