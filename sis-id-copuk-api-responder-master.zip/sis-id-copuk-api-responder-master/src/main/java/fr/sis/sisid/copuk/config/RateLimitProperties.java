package fr.sis.sisid.copuk.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@ConfigurationProperties(value = "app.rate-limit")
@Data
public class RateLimitProperties {

    /**
     * Rate limiting on/off switch
     */
    private boolean enabled;

    /**
     * Maximum number of requests per client per second
     */
    private int requestsPerSecond;

    /**
     * Maximum number of requests per client per minute
     */
    private int requestsPerMinute;

    /**
     * Maximum number of requests per client per hour
     */
    private int requestsPerHour;

    /**
     * MAximum number of requests per client per hour
     */
    private int requestsPerDay;
}
