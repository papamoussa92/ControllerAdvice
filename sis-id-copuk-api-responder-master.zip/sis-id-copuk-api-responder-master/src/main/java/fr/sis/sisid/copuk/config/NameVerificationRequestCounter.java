package fr.sis.sisid.copuk.config;

import fr.sis.sisid.copuk.copapi.model.InlineResponse200;
import fr.sis.sisid.copuk.copapi.model.InlineResponse200DataVerificationReport;
import io.micrometer.core.instrument.ImmutableTag;
import io.micrometer.core.instrument.Tag;
import io.micrometer.prometheus.PrometheusMeterRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

@Component
public class NameVerificationRequestCounter {

    @Autowired
    private PrometheusMeterRegistry metricsRegistry;

    @Async
    public void countNameVerificationRequest(boolean isError, ResponseEntity<InlineResponse200> response) {
        List<Tag> copReplyCounterTags;
        var verificationReportOpt = Optional.ofNullable(response)
                .flatMap(res -> Optional.ofNullable(response.getBody()))
                .flatMap(responseBody -> Optional.ofNullable(responseBody.getData().getVerificationReport()));
        if (isError || verificationReportOpt.isEmpty()) {
            copReplyCounterTags = getErrorTags();
        } else {
            copReplyCounterTags = getSuccessfullTags(verificationReportOpt.get());
        }
        this.metricsRegistry.counter("fr.sis.sisid.copuk.copreply",
                copReplyCounterTags)
                .increment();
    }

    private List<Tag> getErrorTags() {
        List<Tag> copReplyCounterTags = new LinkedList<>();
        copReplyCounterTags.add(new ImmutableTag("error", "true"));
        copReplyCounterTags.add(new ImmutableTag("reason-code", "null"));
        copReplyCounterTags.add(new ImmutableTag("matched", "null"));
        return copReplyCounterTags;
    }

    private List<Tag> getSuccessfullTags(InlineResponse200DataVerificationReport report) {
        List<Tag> copReplyCounterTags = new LinkedList<>();
        String reasonCode = "null";
        if (report.getReasonCode() != null) {
            reasonCode = report.getReasonCode().name();
        }
        copReplyCounterTags.add(new ImmutableTag("error", "false"));
        copReplyCounterTags.add(new ImmutableTag("reason-code", reasonCode));
        copReplyCounterTags.add(new ImmutableTag("matched", report.getMatched().toString()));
        return copReplyCounterTags;
    }
}
