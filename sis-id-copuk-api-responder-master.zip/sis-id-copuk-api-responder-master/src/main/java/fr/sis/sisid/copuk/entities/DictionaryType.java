package fr.sis.sisid.copuk.entities;

public enum DictionaryType {
    LEGAL_FORM,
    GEOGRAPHY,
    NOT_DEFINIED;
}
