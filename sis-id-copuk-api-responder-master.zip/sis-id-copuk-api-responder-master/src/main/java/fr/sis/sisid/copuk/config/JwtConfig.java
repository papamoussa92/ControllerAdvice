package fr.sis.sisid.copuk.config;

import java.util.Collections;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fasterxml.jackson.databind.ObjectMapper;

import fr.sis.sisid.copuk.tools.JwtTools;

@Configuration
public class JwtConfig {

    @Bean
    public JwtTools jwtTools(ObjectMapper objectMapper,
            NonRepudiationProperties properties) {
        return new JwtTools(objectMapper, Collections.singleton(properties.getAlgorithm()));
    }
}
