package fr.sis.sisid.copuk.controllers.errors;

import static fr.sis.sisid.copuk.copapi.OpenBankingErrorCode.FIELD_MISSING;
import static fr.sis.sisid.copuk.copapi.OpenBankingErrorCode.HEADER_INVALID;
import static fr.sis.sisid.copuk.copapi.OpenBankingErrorCode.INVALID_FIELD;
import static fr.sis.sisid.copuk.copapi.OpenBankingErrorCode.RESOURCE_NOT_FOUND;
import static fr.sis.sisid.copuk.copapi.OpenBankingErrorCode.SIGNATURE_INVALID;
import static fr.sis.sisid.copuk.copapi.OpenBankingErrorCode.SIGNATURE_INVALID_CLAIM;
import static fr.sis.sisid.copuk.copapi.OpenBankingErrorCode.SIGNATURE_MALFORMED;
import static fr.sis.sisid.copuk.copapi.OpenBankingErrorCode.SIGNATURE_MISSING;
import static fr.sis.sisid.copuk.copapi.OpenBankingErrorCode.SIGNATURE_MISSING_CLAIM;
import static fr.sis.sisid.copuk.copapi.OpenBankingErrorCode.UNEXPECTED_ERROR;
import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.FORBIDDEN;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.HttpStatus.METHOD_NOT_ALLOWED;
import static org.springframework.http.HttpStatus.NOT_ACCEPTABLE;
import static org.springframework.http.HttpStatus.SERVICE_UNAVAILABLE;
import static org.springframework.http.HttpStatus.UNAUTHORIZED;
import static org.springframework.http.HttpStatus.resolve;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.codec.HttpMessageWriter;
import org.springframework.http.codec.ServerCodecConfigurer;
import org.springframework.lang.NonNull;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.support.WebExchangeBindException;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.server.ServerResponse;
import org.springframework.web.server.MethodNotAllowedException;
import org.springframework.web.server.NotAcceptableStatusException;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.ServerWebInputException;
import org.springframework.web.server.UnsupportedMediaTypeStatusException;
import org.springframework.web.server.WebExceptionHandler;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.exc.ValueInstantiationException;
import com.nimbusds.jose.proc.BadJOSEException;

import fr.sis.sisid.copuk.OpenBankingConstants;
import fr.sis.sisid.copuk.controllers.FapiHeaderException;
import fr.sis.sisid.copuk.copapi.model.OBError1;
import fr.sis.sisid.copuk.copapi.model.OBErrorResponse1;
import fr.sis.sisid.copuk.exceptions.OBErrorResponseException;
import fr.sis.sisid.copuk.tools.ResponseSigner;
import fr.sis.sisid.copuk.tools.errors.InvalidJOSEClaimException;
import fr.sis.sisid.copuk.tools.errors.InvalidJOSESignatureException;
import fr.sis.sisid.copuk.tools.errors.MalformedJOSESignatureException;
import fr.sis.sisid.copuk.tools.errors.MissingJOSEClaimException;
import fr.sis.sisid.copuk.tools.errors.MissingSignatureException;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

import javax.validation.ValidationException;

/**
 * Handler to provide custom implementation Responder API technical HTTP errors.
 * The handling of errors complies with the Pay.UK specification 2.3
 */
@Slf4j
@Order(-502)
@Component
public class CopukExceptionHandler implements WebExceptionHandler {

    private final List<HttpMessageWriter<?>> messageWriters;
    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private ResponseSigner responseSigner;

    public CopukExceptionHandler(ServerCodecConfigurer serverCodecConfigurer) {
        messageWriters = serverCodecConfigurer.getWriters();
    }

    @Override
    public @NonNull Mono<Void> handle(ServerWebExchange exchange, @NonNull Throwable throwable) {
        if (exchange.getResponse().isCommitted()) {
            return Mono.error(throwable);
        }

        ServerResponse.Context responseContext = new CopukResponseContext(messageWriters, null);
        return buildServerResponse(throwable).flatMap(response -> {
            exchange.getResponse().setStatusCode(response.statusCode());
            return response.writeTo(exchange, responseContext);
        });

    }

    public Mono<ServerResponse> buildServerResponse(Throwable t) {
        log.error("Handling error", t);
        return new ExceptionProcessor(t, responseSigner)
                .when(AuthenticationException.class).status(UNAUTHORIZED)
                .body((e, status) -> buildResponse(buildStandardErrors(HEADER_INVALID.getCode(), "Access denied",
                        HttpHeaders.AUTHORIZATION), status))
                .when(AccessDeniedException.class).status(UNAUTHORIZED)
                .body((e, status) -> buildResponse(buildStandardErrors(HEADER_INVALID.getCode(), "Access denied",
                        HttpHeaders.AUTHORIZATION), status))
                .when(MissingHeaderException.class).status(BAD_REQUEST)
                .body((e, status) -> buildResponse(e.getErrors(), status))
                .when(InvalidHeaderException.class).status(FORBIDDEN)
                .body((e, status) -> buildResponse(e.getErrors(), status))
                .when(MissingSignatureException.class).status(BAD_REQUEST).body((e, status) -> buildResponse(
                        buildStandardErrors(SIGNATURE_MISSING.getCode(), e.getMessage(),
                                OpenBankingConstants.NON_REPUDIATION_HEADER),
                        status))
                .when(MalformedJOSESignatureException.class).status(BAD_REQUEST).body((e, status) -> buildResponse(
                        buildStandardErrors(SIGNATURE_MALFORMED.getCode(), e.getMessage(),
                                OpenBankingConstants.NON_REPUDIATION_HEADER),
                        status))
                .when(InvalidJOSESignatureException.class).status(BAD_REQUEST).body((e, status) -> buildResponse(
                        buildStandardErrors(SIGNATURE_INVALID.getCode(), e.getMessage(),
                                OpenBankingConstants.NON_REPUDIATION_HEADER),
                        status))
                .when(MissingJOSEClaimException.class).status(BAD_REQUEST).body((e, status) -> buildResponse(
                        buildStandardErrors(SIGNATURE_MISSING_CLAIM.getCode(), e.getMessage(), e.getHeaderName()),
                        status))
                .when(InvalidJOSEClaimException.class).status(BAD_REQUEST).body((e, status) -> buildResponse(
                        buildStandardErrors(SIGNATURE_INVALID_CLAIM.getCode(), e.getMessage(), e.getHeaderName()),
                        status))
                .when(NonRepudiationException.class).status(UNAUTHORIZED)
                .body((e, status) -> buildResponse(buildStandardErrors(HEADER_INVALID.getCode(), e.getMessage()),
                        status))
                .when(BadJOSEException.class).status(BAD_REQUEST)
                .body((e, status) -> buildResponse(buildStandardErrors(HEADER_INVALID.getCode(), e.getMessage()),
                        status))
                .when(FapiHeaderException.class).status(FORBIDDEN).body((e, status) -> buildResponse(
                        e.errorHeaders().stream()
                                .map(header -> buildStandardError(HEADER_INVALID.getCode(), e.getMessage(), header))
                                .toList(),
                        status))
                .when(UnsupportedMediaTypeStatusException.class).status(BAD_REQUEST).body((e, status) -> buildResponse(
                        buildStandardErrors(HEADER_INVALID.getCode(), e.getReason(), "content-type"), status))
                .when(MethodNotAllowedException.class).status(METHOD_NOT_ALLOWED).body((e, status) -> buildResponse(
                        buildStandardErrors(RESOURCE_NOT_FOUND.getCode(), ((MethodNotAllowedException) t).getReason()),
                        status))
                .when(NotAcceptableStatusException.class).status(NOT_ACCEPTABLE)
                .body((e, status) -> buildResponse(
                        buildStandardErrors(HEADER_INVALID.getCode(), e.getReason(), "accept"), status))
                .when(WebExchangeBindException.class).status(BAD_REQUEST)
                .body((e, status) -> buildResponse(buildContentError(e), status))
                .when(BindException.class).status(BAD_REQUEST)
                .body((e, status) -> buildResponse(buildInvalidInputError(e), status))
                .when(ServerWebInputException.class).status(BAD_REQUEST)
                .body((e, status) -> buildResponse(buildInvalidInputError(e), status))
                .when(WebClientRequestException.class).status(SERVICE_UNAVAILABLE).body((e, status) -> buildResponse(
                        buildStandardErrors(UNEXPECTED_ERROR.getCode(), "Account lookup service unavailable"), status))
                .when(JsonParseException.class).status(BAD_REQUEST).body((e, status) -> buildResponse(
                        buildStandardErrors(INVALID_FIELD.getCode(), "Account lookup service unavailable"), status))
                .when(OBErrorResponseException.class).status(e -> resolve(e.getStatusCode()))
                .body((e, status) -> buildResponse(e.getErrorDTO()))
                .when(ClientRateLimitedException.class).status(HttpStatus.TOO_MANY_REQUESTS)
                .body((e, status) -> buildResponse(new OBErrorResponse1().code(429 + "").message("Too many requests")))
                .when(ValidationException.class).status(BAD_REQUEST)
                .body((e, status) -> buildResponse(buildStandardErrors(INVALID_FIELD.getCode(), "Mauvais format request"), status))
                .elseDefaults(INTERNAL_SERVER_ERROR,
                        (e, status) -> buildResponse(buildStandardErrors(UNEXPECTED_ERROR.getCode(), t.getMessage()),
                                status));

    }

    private String buildResponse(List<OBError1> obErrors, HttpStatus status) {
        var errorResponse = new OBErrorResponse1();
        errorResponse.code(String.valueOf(status.value()));
        errorResponse.setErrors(obErrors);
        return buildResponse(errorResponse);
    }

    private String buildResponse(OBErrorResponse1 errorResponse) {
        String errorBody;
        try {

            errorBody = objectMapper.writeValueAsString(errorResponse);
        } catch (JsonProcessingException e) {
            log.warn("Failed to format error response", e);
            errorBody = """
                    {
                      "Code": "500",
                      "Message": "Unexpected error"
                    }
                    """;
        }
        return errorBody;
    }

    private OBError1 buildStandardError(String errorCode, String reason, String path) {
        OBError1 obError1 = new OBError1();
        obError1.setMessage(reason);
        obError1.setErrorCode(errorCode);
        obError1.setPath(path);
        return obError1;
    }

    private List<OBError1> buildStandardErrors(String errorCode, String reason, String path) {
        return List.of(buildStandardError(errorCode, reason, path));
    }

    private List<OBError1> buildStandardErrors(String errorCode, String reason) {
        OBError1 obError1 = new OBError1();
        obError1.setMessage(reason);
        obError1.setErrorCode(errorCode);
        return List.of(obError1);
    }

    private List<OBError1> buildContentError(WebExchangeBindException e) {
        return e.getAllErrors().stream().map(error -> {
            if (error instanceof FieldError fe) {

                String field = Stream.of(fe.getField().split("\\.")).map(StringUtils::capitalize)
                        .collect(Collectors.joining("."));
                return (fe.getRejectedValue() == null || Strings.isBlank(fe.getRejectedValue().toString()))
                        ? new OBError1().errorCode(FIELD_MISSING.getCode()).message("Missing %s".formatted(field))
                                .path(field)
                        : new OBError1().errorCode(INVALID_FIELD.getCode())
                                .message("Invalid value for %s".formatted(field)).path(field);
            } else {
                return new OBError1().errorCode(INVALID_FIELD.getCode())
                        .message("Invalid %s".formatted(error.getObjectName())).path(error.getObjectName());
            }
        }).toList();

    }

    private List<OBError1> buildInvalidInputError(ServerWebInputException webInputException) {
        OBError1 result;

        if (Stream.iterate(webInputException, Objects::nonNull, Throwable::getCause)
                .anyMatch(ValueInstantiationException.class::isInstance)) {
            var path = Stream.iterate(webInputException, Objects::nonNull, Throwable::getCause)
                    .filter(ValueInstantiationException.class::isInstance).findFirst()
                    .map(ValueInstantiationException.class::cast).map(ValueInstantiationException::getPath)
                    .orElse(List.of()).stream().map(JsonMappingException.Reference::getFieldName)
                    .collect(Collectors.joining("."));
            result = new OBError1().errorCode(INVALID_FIELD.getCode()).message("Unexpected value").path(path);
        } else {
            result = new OBError1().errorCode(INVALID_FIELD.getCode()).message(webInputException.getReason());
        }

        return List.of(result);
    }

    private List<OBError1> buildInvalidInputError(BindException bindException) {
        return bindException.getAllErrors().stream().map(e -> new OBError1().message(e.getObjectName())).toList();
    }
}