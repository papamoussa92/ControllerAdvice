package fr.sis.sisid.copuk.service;

import java.time.Duration;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.stereotype.Service;

import fr.sis.sisid.copuk.config.RateLimitProperties;
import io.github.bucket4j.Bandwidth;
import io.github.bucket4j.Bucket;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class RateLimitServiceImpl implements RateLimitService {

    private final Map<String, Bucket> cache;

    private RateLimitProperties rateLimitProperties;

    public RateLimitServiceImpl(RateLimitProperties rateLimitProperties) {
        this.rateLimitProperties = rateLimitProperties;
        this.cache = new ConcurrentHashMap<>();
    }

    @Override
    public RateLimitResponse isRateLimited(String clientId) {
        if (!rateLimitProperties.isEnabled()) {
            // bypass rate limiting all together
            return new RateLimitResponse(false, 0);
        }
        var rlResult = cache.computeIfAbsent(clientId, this::initBucket).tryConsumeAndReturnRemaining(1l);
        return new RateLimitResponse(!rlResult.isConsumed(), rlResult.getNanosToWaitForRefill() / 1000000000l);
    }

    public Bucket initBucket(String clientId) {
        return Bucket.builder()
                .addLimit(Bandwidth.simple(rateLimitProperties.getRequestsPerSecond(), Duration.ofSeconds(1)))
                .addLimit(Bandwidth.simple(rateLimitProperties.getRequestsPerMinute(), Duration.ofMinutes(1)))
                .addLimit(Bandwidth.simple(rateLimitProperties.getRequestsPerHour(), Duration.ofHours(1)))
                .addLimit(Bandwidth.simple(rateLimitProperties.getRequestsPerDay(), Duration.ofDays(1)))
                .build();
    }

}
