package fr.sis.sisid.copuk.cop.core.rules;

import java.util.List;

import javax.annotation.PostConstruct;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationContext;

@Data
@AllArgsConstructor
@Slf4j
public class RulesList {

    /**
     * List of verification rules to apply in order to process cop requests
     */
    private List<? extends VerificationRule> rules;

    public RulesList(ApplicationContext context, List<Class<? extends VerificationRule>> rulesBeans) {
        rules = rulesBeans.stream().map(context::getBean).toList();
    }

    @PostConstruct
    public void logRules() {
        log.info("Loaded name verification rules : ");
        for (VerificationRule rule : this.rules) {
            log.info("\t- {}", rule.getClass().getCanonicalName());
        }
    }
}
