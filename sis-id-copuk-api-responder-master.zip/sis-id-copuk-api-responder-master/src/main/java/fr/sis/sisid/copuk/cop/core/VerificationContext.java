package fr.sis.sisid.copuk.cop.core;

import java.util.Optional;

import javax.validation.constraints.NotNull;

import org.springframework.http.HttpStatus;

import fr.sis.sisid.copuk.dto.SsaDTO;
import fr.sis.sisid.copuk.model.AccountInfoRejection;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import fr.sis.sisid.copuk.namematching.model.MatchingResult;
import lombok.EqualsAndHashCode;
import lombok.Setter;
import reactor.util.context.Context;
import reactor.util.context.ContextView;

/**
 * Holds information relevant to the confirmation of payee
 */
@Setter
@EqualsAndHashCode
public class VerificationContext {

    private final String xFapiInteractionId;

    private final String xFapiFinancialId;
    private final Long startTime;

    /**
     * Id of the requester's registered client
     */
    private String clientId;

    /**
     * Initial confirmation request
     */
    private CoreCopRequest request;

    /**
     * Account information, fetched from a 3rd party if needed
     */
    @NotNull
    private CoreAccountInfo accountInfo;

    /**
     * Error received when fetching account info
     */
    @NotNull
    private AccountInfoRejection accountInfoError;

    /**
     * Confirmation of payee response, built by verification rules
     */
    private CoreCopReply reply;

    /**
     * Outcome of the external name matching service
     */
    @NotNull
    private MatchingResult nameMatchingResult;

    /**
     * The full HTTP request body returned
     */
    private String requestBody;

    /**
     * The full HTTP response body returned
     */
    private String responseBody;

    private Long cibApiStartTime;

    private Long cibApiEndTime;

    /**
     * Subset of the informations in the requester's registered client
     */
    private SsaDTO ssaDTO;

    /**
     * The HTTP code returned to the requester
     */
    private HttpStatus httpStatusCode;

    /**
     * Reference of the Cop rule that generated a response in this context
     */
    private String ruleCode;

    public VerificationContext(String xFapiFinancialId, String xFapiInteractionId, Long startTime) {
        this.xFapiFinancialId = xFapiFinancialId;
        this.xFapiInteractionId = xFapiInteractionId;
        this.startTime = startTime;
    }

    public VerificationContext(String xFapiFinancialId, String xFapiInteractionId, Long startTime,
            CoreCopRequest request) {
        this(xFapiFinancialId, xFapiInteractionId, startTime);
        this.request = request;
    }

    public static VerificationContext reply(ContextView ctx, CoreCopReply reply) {
        VerificationContext verificationContext = ctx.get(VerificationContext.class);
        verificationContext.reply = reply;
        return verificationContext;
    }

    public static VerificationContext request(Context ctx, CoreCopRequest copRequest) {
        VerificationContext verificationContext = ctx.get(VerificationContext.class);
        verificationContext.request = copRequest;
        return verificationContext;
    }

    public static VerificationContext response(ContextView ctx, String serializedResponse) {
        VerificationContext verificationContext = ctx.get(VerificationContext.class);
        verificationContext.responseBody = serializedResponse;
        return verificationContext;
    }

    public String getXFapiInteractionId() {
        return xFapiInteractionId;
    }

    public String getXFapiFinancialId() {
        return xFapiFinancialId;
    }

    public CoreCopRequest getRequest() {
        return request;
    }

    public Optional<CoreAccountInfo> getAccountInfo() {
        return Optional.ofNullable(accountInfo);
    }

    public Optional<AccountInfoRejection> getAccountInfoError() {
        return Optional.ofNullable(accountInfoError);
    }

    public Optional<CoreCopReply> getReply() {
        return Optional.ofNullable(reply);
    }

    public Optional<MatchingResult> getNameMatchingResult() {
        return Optional.ofNullable(nameMatchingResult);
    }

    public Optional<String> getRequestBody() {
        return Optional.ofNullable(requestBody);
    }

    public Optional<String> getResponseBody() {
        return Optional.ofNullable(responseBody);
    }

    public Long getStartTime() {
        return startTime;
    }

    public Optional<Long> getCibApiStartTime() {
        return Optional.ofNullable(cibApiStartTime);
    }

    public Optional<Long> getCibApiEndTime() {
        return Optional.ofNullable(cibApiEndTime);
    }

    public Optional<HttpStatus> getHttpStatusCode() {
        return Optional.ofNullable(httpStatusCode);
    }

    public Optional<SsaDTO> getSsa() {
        return Optional.ofNullable(this.ssaDTO);
    }

    public Optional<String> getClientId() {
        return Optional.ofNullable(this.clientId);
    }

    public Optional<String> getRulecode() {
        return Optional.ofNullable(this.ruleCode);
    }

}
