package fr.sis.sisid.copuk.entities;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DictionaryRepository extends JpaRepository<DictionaryEntity, Long> {
    List<DictionaryEntity> findByType(DictionaryType type);
}
