package fr.sis.sisid.copuk.controllers.filters;

import java.util.Optional;
import java.util.UUID;

import fr.sis.sisid.copuk.model.CoreCopRequest;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilterChain;

import fr.sis.sisid.copuk.OpenBankingConstants;
import fr.sis.sisid.copuk.config.SlaRequestCounter;
import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.service.AuditService;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Component
@Order(-1000)
public class ContextFilter extends NameVerificationFilter {

    public static final String CORRELATION_ID = "CORRELATION_ID";

    @Autowired
    private AuditService auditService;

    @Autowired
    private SsaProvider ssaProvider;

    @Autowired
    private SlaRequestCounter slaRequestCounter;

    public ContextFilter(@Value("${copuk.api.path-pattern:/api/v*/pay.uk}") String payUkPathPattern) {
        super(payUkPathPattern);
    }

    @Override
    public Mono<Void> nameVerificationFilter(ServerWebExchange exchange, WebFilterChain chain) {
        try {
            long start = System.currentTimeMillis();

            String xFapiFinancialId = exchange.getRequest().getHeaders()
                    .getFirst(OpenBankingConstants.ORGANISATION_HEADER);
            String xFapiInteractionId = exchange.getRequest().getHeaders()
                    .getFirst(OpenBankingConstants.CORRELATION_ID_HEADER);
            String correlationId;
            if (Strings.isBlank(xFapiInteractionId)) {
                correlationId = UUID.randomUUID().toString();
            } else {
                correlationId = StringUtils.truncate(xFapiInteractionId, 50);
            }
            String authHeader = exchange.getRequest().getHeaders().getFirst("Authorization");
            MDC.put(CORRELATION_ID, correlationId);
            log.info("Start Time execution for name verification {} ms", start);

            var verificationContext = new VerificationContext(xFapiFinancialId, correlationId, start);
            return
            // extract client id from the authorization header
            this.enrichContextWithClientIdAndSsa(verificationContext, authHeader)
                    // go forth with the other filters
                    .flatMap(vctx -> chain.filter(exchange)
                            .contextWrite(ctx -> {
                                MDC.put(CORRELATION_ID, correlationId);
                                return ctx.put(VerificationContext.class, verificationContext);
                            }).doFinally(e -> {
                                try {
                                    // log this request and its outcome
                                    this.logContext(verificationContext, start, exchange.getResponse().getStatusCode());
                                } finally {
                                    MDC.clear();
                                }
                            }));
        } catch (Exception e) {
            log.error("Exit process verification name", e);
            throw e;
        } finally {
            MDC.clear();
        }
    }

    /**
     * Adds client id and the client SSA to the verification context.
     * Falls back to the original verification context on error
     * @param verificationContext
     * @param authHeader
     * @return
     */
    private Mono<VerificationContext> enrichContextWithClientIdAndSsa(VerificationContext verificationContext,
            String authHeader) {
        return this.ssaProvider.extractClientId(authHeader)
                .flatMap(clientId -> {
                    // pass client id to the context
                    verificationContext.setClientId(clientId);
                    // use the client id to get the SSA
                    return this.ssaProvider.getClientSsa(clientId)
                            .map(ssa -> {
                                // add the ssa to the context
                                verificationContext.setSsaDTO(ssa);
                                return verificationContext;
                            });
                })
                // if the above flatmap fails (eg extracting client id or fetchnig the SSA),
                // fallback with the verification context so that it still can be persisted
                .onErrorResume(err -> Mono.just(verificationContext));
    }

    /**
     * Logs the name verificatino ocutcome to stdout and into the audit repository
     * @param verificationContext
     * @param start
     * @param statusCode
     */
    private void logContext(VerificationContext verificationContext, long start, HttpStatus statusCode) {
        long time = System.currentTimeMillis() - start;

        verificationContext.setHttpStatusCode(statusCode);

        log.debug(
                "End execution of name verification, time:{}, duration:{}, status: {}, request:{}, {} ",
                start, time, statusCode,
                verificationContext.getRequestBody(),
                verificationContext.getXFapiFinancialId());

        log.info("Finally request {}", Optional.of(verificationContext).map(VerificationContext::getRequest).map(CoreCopRequest::toString).orElse(null));
        log.info("Finally reply {}", toStringDefault(verificationContext.getReply()));
        log.info("Finally name matching {}",
                toStringDefault(verificationContext.getNameMatchingResult()));

        var ismatch = Optional.of(verificationContext)
                .flatMap(VerificationContext::getReply).map(
                        CoreCopReply::isMatched)
                .orElse(Boolean.FALSE);
        var reasonCode = Optional.of(verificationContext)
                .flatMap(VerificationContext::getReply)
                .flatMap(CoreCopReply::getReasonCode);
        log.info("Matching {} with reason code {}",
                Boolean.TRUE.equals(ismatch) ? " ✅ " : " ⛔ ",
                reasonCode);
        log.info("HTTP Status {}", statusCode);

        auditService.save(verificationContext);
        slaRequestCounter.countResponsesAboveSLA(time);
    }

    private <T> String toStringDefault(Optional<T> o) {
        if (o.isEmpty()) {
            return "<NA>";
        } else
            return o.get().toString();
    }

}
