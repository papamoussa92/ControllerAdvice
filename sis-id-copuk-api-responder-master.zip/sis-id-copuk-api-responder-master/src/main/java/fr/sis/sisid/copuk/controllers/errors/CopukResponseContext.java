package fr.sis.sisid.copuk.controllers.errors;

import org.springframework.http.codec.HttpMessageWriter;
import org.springframework.lang.NonNull;
import org.springframework.web.reactive.function.server.ServerResponse;
import org.springframework.web.reactive.result.view.ViewResolver;

import java.util.List;

class CopukResponseContext implements ServerResponse.Context {

    List<HttpMessageWriter<?>> messageWriters;
    List<ViewResolver> viewResolvers;

    public CopukResponseContext(List<HttpMessageWriter<?>> messageWriters, List<ViewResolver> viewResolvers) {
        this.messageWriters = messageWriters;
        this.viewResolvers = viewResolvers;
    }

    @Override public @NonNull List<HttpMessageWriter<?>> messageWriters() {
        return messageWriters;
    }

    @Override public @NonNull List<ViewResolver> viewResolvers() {
        return viewResolvers;
    }
}
