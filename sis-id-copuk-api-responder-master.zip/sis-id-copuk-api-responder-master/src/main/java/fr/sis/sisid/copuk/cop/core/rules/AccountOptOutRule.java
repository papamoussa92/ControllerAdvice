package fr.sis.sisid.copuk.cop.core.rules;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.rules.processors.AccountInfoEnricher;
import fr.sis.sisid.copuk.copapi.model.ReasonCodes;
import fr.sis.sisid.copuk.model.AccountInfoErrorCode;
import fr.sis.sisid.copuk.model.CoreCopReply;
import lombok.AllArgsConstructor;
import reactor.core.publisher.Mono;

@Component
@AllArgsConstructor(onConstructor = @__(@Autowired))
public class AccountOptOutRule implements VerificationRule {

    private AccountInfoEnricher accountInfoEnricher;

    @Override
    public boolean matches(VerificationContext context) {
        if (context.getReply().isPresent() || context.getAccountInfoError().isEmpty()) {
            return false;
        }
        return context.getAccountInfoError().map(t -> t.getCode() == AccountInfoErrorCode.ACCOUNT_OPT_OUT)
                .orElse(false);
    }

    @Override
    public Mono<VerificationContext> enrichContext(VerificationContext context) {
        if (context.getReply().isPresent()) {
            return Mono.just(context);
        }
        return this.accountInfoEnricher.enrichContext(context);
    }

    @Override
    public Mono<VerificationContext> process(VerificationContext context) {
        context.setReply(
                CoreCopReply.builder()
                        .matched(false)
                        .reasonCode(Optional.of(ReasonCodes.OPTO))
                        .build());
        return Mono.just(context);
    }

    @Override
    public String getRuleCode() {
        return "ACCOUNT-OPT-OUT";
    }

}
