package fr.sis.sisid.copuk.dto;

import java.util.LinkedList;
import java.util.List;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.Builder;
import lombok.Data;

/**
 * 
 * Public openid configuration
 *
 */
@Data
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class OpenIdConfigDTO {

    @Builder.Default
    private String version = "";
    @Builder.Default
    private String issuer = "";
    private String registrationEndpoint;
    @Builder.Default
    private String authorizationEndpoint = "";
    @Builder.Default
    private String tokenEndpoint = "";
    @Builder.Default
    private String jwksUri = "";
    @Builder.Default
    private List<String> scopesSupported = new LinkedList<>();
    @Builder.Default
    private List<String> claimsSupported = new LinkedList<>();
    @Builder.Default
    private List<String> responseTypesSupported = new LinkedList<>();
    @Builder.Default
    private List<String> responseModesSupported = new LinkedList<>();
    @Builder.Default
    private List<String> grantTypesSupported = new LinkedList<>();
    @Builder.Default
    private List<String> subjectTypesSupported = new LinkedList<>();
    @Builder.Default
    private List<String> idTokenSigningAlgValuesSupported = new LinkedList<>();
    @Builder.Default
    private List<String> tokenEndpointAuthSigningAlgValuesSupported = new LinkedList<>();
    @Builder.Default
    private List<String> tokenEndpointAuthMethodsSupported = new LinkedList<>();
    @Builder.Default
    private List<String> claimTypesSupported = new LinkedList<>();
    @Builder.Default
    private boolean claimsParameterSupported = false;
    @Builder.Default
    private boolean requestParameterSupported = false;
    @Builder.Default
    private List<String> requestObjectSigningAlgValuesSupported = new LinkedList<>();
    @Builder.Default
    private List<String> requestObjectEncryptionAlgValuesSupported = new LinkedList<>();
    @Builder.Default
    private List<String> requestObjectEncryptionEncValuesSupported = new LinkedList<>();
    @Builder.Default
    private boolean requestUriParameterSupported = false;
    @Builder.Default
    private boolean tlsClientCertificateBoundAccessTokens = false;

}
