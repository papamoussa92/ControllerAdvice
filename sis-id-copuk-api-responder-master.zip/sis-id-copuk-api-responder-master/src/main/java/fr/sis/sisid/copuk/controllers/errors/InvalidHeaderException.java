package fr.sis.sisid.copuk.controllers.errors;

import fr.sis.sisid.copuk.copapi.model.OBError1;
import lombok.Getter;
import org.springframework.web.server.ServerWebInputException;

import java.util.List;

@Getter
public class InvalidHeaderException extends ServerWebInputException {
    private final transient List<OBError1> errors;
    public InvalidHeaderException(List<OBError1> errors) {
        super("Invalid headers");
        this.errors = errors;
    }
}
