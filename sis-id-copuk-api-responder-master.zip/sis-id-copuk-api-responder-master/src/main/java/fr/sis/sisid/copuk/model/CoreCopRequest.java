package fr.sis.sisid.copuk.model;

import lombok.*;

@Getter
@Setter
@EqualsAndHashCode
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CoreCopRequest {

    private String accountNumber;

    private String sortCode;

    private String name;

    private AccountType accountType;

    private String xFapiInteractionId;

    @Override
    public String toString() {
        String sb = "class CoreCopRequest {\n" +
                "name: " + this.getName() + "\n" +
                "accountType: " + this.getAccountType() + "\n" +
                "xFapiInteractionId: " + this.getXFapiInteractionId() + "\n" +
                "}";
        return sb;
    }
}
