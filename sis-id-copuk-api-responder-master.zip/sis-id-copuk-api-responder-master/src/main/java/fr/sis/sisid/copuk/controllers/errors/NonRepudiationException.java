package fr.sis.sisid.copuk.controllers.errors;

import java.io.Serial;

public class NonRepudiationException extends RuntimeException {

    @Serial
    private static final long serialVersionUID = -6127674851761758115L;

    public NonRepudiationException(String msg) {
        super(msg);
    }

    public NonRepudiationException(String msg, Throwable err) {
        super(msg, err);
    }
}
