package fr.sis.sisid.copuk.entities;

import org.springframework.data.jpa.repository.JpaRepository;

public interface InvoiceDiscountAccountDAO extends JpaRepository<InvoiceDiscountAccountEntity, Long> {
}
