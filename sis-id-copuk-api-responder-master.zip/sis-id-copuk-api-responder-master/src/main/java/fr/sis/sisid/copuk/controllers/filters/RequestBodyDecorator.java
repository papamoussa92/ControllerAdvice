package fr.sis.sisid.copuk.controllers.filters;

import org.apache.logging.log4j.util.Strings;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DefaultDataBufferFactory;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpRequestDecorator;
import org.springframework.lang.NonNull;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/**
 * Wrapper around a request to retrieve its entire body as a string
 */
public class RequestBodyDecorator extends ServerHttpRequestDecorator {
    private List<String> data;

    public RequestBodyDecorator(ServerHttpRequest delegate) {
        super(delegate);
    }

    @Override
    public @NonNull Flux<DataBuffer> getBody() {
        return Flux.fromStream(data.stream().map(s -> {
            DefaultDataBufferFactory factory = DefaultDataBufferFactory.sharedInstance;
            return factory.wrap(s.getBytes(Charset.defaultCharset()));
        }));
    }

    public Mono<String> getBodyAsString() {
        data = new ArrayList<>();
        return super.getBody().map(b -> {
            String s = b.toString(Charset.defaultCharset());
            data.add(s);
            return s;
        }).reduce(Strings::concat);
    }
}
