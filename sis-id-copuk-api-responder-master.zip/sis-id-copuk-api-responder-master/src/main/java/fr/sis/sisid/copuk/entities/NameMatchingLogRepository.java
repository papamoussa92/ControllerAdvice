package fr.sis.sisid.copuk.entities;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface NameMatchingLogRepository extends JpaRepository<NameMatchingLogEntity, Long> {

}
