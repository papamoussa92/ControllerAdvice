package fr.sis.sisid.copuk.service;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import fr.sis.sisid.copuk.config.AsymetricEncoderConfig;
import fr.sis.sisid.copuk.dto.AsymetricEncoder;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindException;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.dto.NameMatchingStatsDTO;
import fr.sis.sisid.copuk.dto.SsaDTO;
import fr.sis.sisid.copuk.entities.Audit;
import fr.sis.sisid.copuk.entities.AuditRepository;
import fr.sis.sisid.copuk.entities.NameMatchingLogRepository;
import fr.sis.sisid.copuk.mappers.AuditStatsMapper;
import fr.sis.sisid.copuk.mappers.NameMatchingLogMapper;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import fr.sis.sisid.copuk.namematching.model.MatchingResult;
import fr.sis.sisid.copuk.namematching.model.NameMatchingLog;
import fr.sis.sisid.copuk.namematching.scorer.ScoredDecision;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Service
@Transactional
@Slf4j
public class AuditServiceImpl implements AuditService {
    @Autowired
    private AsymetricEncoder asymetricEncoder;

    @Autowired
    private EntityManager entityManager;

    @Autowired
    private AuditRepository auditRepository;

    @Autowired
    private NameMatchingLogMapper nmlMapper;

    @Autowired
    private NameMatchingLogRepository nmlRepository;

    @Autowired
    private AuditStatsMapper auditStatsMapper;

    @Value("${app.organisation-id}")
    private String orgId;

    @Value("${app.sla-seconds:1.5}")
    private double slaSeconds;

    @Value("${rosette.threshold.match}")
    private BigDecimal matchThreshold;

    @Value("${rosette.threshold.close-match}")
    private BigDecimal closeMatchThreshold;

    @Value("${spring.application.version}")
    private String engineVersion;

    @Value("${configuration.version}")
    private String configurationVersion;

    @Override
    public Mono<List<Audit>> searchByKey(String accountNumber, String accountName, String dateDebut, String dateFin)
            throws BindException {
        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Audit> cq = cb.createQuery(Audit.class);
        Root<Audit> audit = cq.from(Audit.class);
        // Constructing list of parameters
        List<Predicate> predicates = new ArrayList<>();

        checkDateParams(dateDebut, dateFin);

        if (StringUtils.isNotEmpty(accountNumber)) {
            predicates.add(cb.like(audit.get("identification"), "%" + accountNumber + "%"));
        }
        if (StringUtils.isNotEmpty(accountName)) {
            predicates.add(cb.like(audit.get("inputAccountName"), "%" + accountName + "%"));
        }

        Path<Timestamp> dateAudit = audit.get("dateAudit");
        if (StringUtils.isNotEmpty(dateDebut) && StringUtils.isNotEmpty(dateFin)) {
            predicates.add(cb
                    .and(cb.between(dateAudit, getDateTimeStamps(dateDebut), getDateTimeStamps(dateFin))));
        }

        if (StringUtils.isNotEmpty(dateDebut) && StringUtils.isEmpty(dateFin)) {
            predicates.add(cb.and(cb.greaterThan(dateAudit, getDateTimeStamps(dateDebut))));
        }

        if (StringUtils.isEmpty(dateDebut) && StringUtils.isNotEmpty(dateFin)) {
            predicates.add(cb.and(cb.lessThan(dateAudit, getDateTimeStamps(dateFin))));
        }

        cq.select(audit).where(predicates.toArray(new Predicate[] {}));
        // execute query and do something with result
        List<Audit> audits = entityManager.createQuery(cq).getResultList();
        return Mono.just(audits);
    }

    private void checkDateParams(String dateDebut, String dateFin) throws BindException {
        if (StringUtils.isNotEmpty(dateDebut) && StringUtils.isNotEmpty(dateFin)
                && getDateTimeStamps(dateDebut).after(getDateTimeStamps(dateFin))) {
            throw new BindException("Date End is before date start", "");
        }

    }

    public Timestamp getDateTimeStamps(String date) throws BindException {
        try {
            return new Timestamp(DateUtils.parseDate(date, "yyyy-MM-dd").getTime());
        } catch (Exception e) {
            log.error("error parsing date", e);
            throw new BindException("Can not parse this date", "");
        }

    }

    @Override
    public Mono<NameMatchingStatsDTO> getStats(ZonedDateTime from, ZonedDateTime to) {
        var stats = this.auditRepository.getAuditStats(from, to, slaSeconds);
        return Mono.just(this.auditStatsMapper.toDTO(stats, this.orgId));
    }

    @Override
    public Mono<Audit> save(VerificationContext verificationContext) {
        Optional<VerificationContext> optionalContext = Optional.of(verificationContext);

        Optional<CoreCopRequest> coreCopRequest = optionalContext.map(VerificationContext::getRequest);
        var identification = coreCopRequest.map(CoreCopRequest::getSortCode)
                .map(sc -> Strings.concat(sc, coreCopRequest.map(CoreCopRequest::getAccountNumber).orElse("")))
                .orElse(null);
        var name = coreCopRequest.map(CoreCopRequest::getName).orElse(null);
        var accountType = coreCopRequest.map(CoreCopRequest::getAccountType).map(Enum::name).orElse(null);
        var accountNameFromCibApi = optionalContext.map(VerificationContext::getAccountInfo).map(u -> u.orElse(
                CoreAccountInfo.builder().build())).map(CoreAccountInfo::getName).orElse(null);
        var currency = optionalContext.map(VerificationContext::getAccountInfo).map(u -> u.orElse(
                CoreAccountInfo.builder().build())).map(CoreAccountInfo::getCurrency).orElse(null);
        var score = optionalContext.map(VerificationContext::getNameMatchingResult).flatMap(u -> u).map(
                MatchingResult::getScore).map(ScoredDecision::getScore).orElse(null);
        var ismatch = optionalContext.flatMap(VerificationContext::getReply).map(CoreCopReply::isMatched)
                .orElse(Boolean.FALSE);
        var reasonCode = Optional.of(verificationContext).flatMap(VerificationContext::getReply)
                .flatMap(CoreCopReply::getReasonCode);
        Audit audit = Audit.builder()
                .correlationId(verificationContext.getXFapiInteractionId())
                .identification(identification != null ? asymetricEncoder.encryptToBase64(identification) : null)
                .inputAccountName(name)
                .accountNameFromCibApi(accountNameFromCibApi)
                .payeeAccountType(accountType)
                .accountCurrency(currency)
                .copRequestTimestamp(new Timestamp(verificationContext.getStartTime()))
                .copResponseTimestamp(new Timestamp(System.currentTimeMillis()))
                .matched(ismatch)
                .matchingReasonCode(reasonCode.isEmpty() ? null : reasonCode.get().name())
                .dateAudit(new Timestamp(System.currentTimeMillis()))
                .score(score)
                .configurationVersion(configurationVersion)
                .engineVersion(engineVersion)
                .closematchThreshold(closeMatchThreshold)
                .matchThreshold(matchThreshold)
                .statusHttpCode(verificationContext.getHttpStatusCode().map(HttpStatus::name).orElse(null))
                .cibApiRequestTimestamp(verificationContext.getCibApiStartTime().map(Timestamp::new).orElse(null))
                .cibApiResponseTimestamp(verificationContext.getCibApiEndTime().map(Timestamp::new).orElse(null))
                .clientId(verificationContext.getClientId().orElse(null))
                .organizationId(verificationContext.getSsa().map(SsaDTO::getOrgId).orElse(null))
                .rules(verificationContext.getRulecode().orElse(null))
                .build();
        audit = this.auditRepository.save(audit);
        if (verificationContext.getNameMatchingResult().isPresent()) {
            ArrayList<NameMatchingLog> nmLogArray = new ArrayList<>(
                    verificationContext.getNameMatchingResult().map(MatchingResult::getProcessorLog).orElse(null));
            log.debug("[n={}] log items to persist", nmLogArray.size());
            for (int i = 0; i < nmLogArray.size(); i++) {
                var nmlEntity = this.nmlMapper.toEntity(nmLogArray.get(i), audit, i);
                this.nmlRepository.save(nmlEntity);
            }
        }
        return Mono.just(audit);
    }

}
