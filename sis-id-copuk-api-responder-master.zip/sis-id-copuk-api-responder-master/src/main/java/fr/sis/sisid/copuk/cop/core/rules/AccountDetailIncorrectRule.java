package fr.sis.sisid.copuk.cop.core.rules;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.rules.processors.AccountDetailIncorrectReplyProcessor;
import fr.sis.sisid.copuk.cop.core.rules.processors.NameMatchingResultEnricher;
import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import reactor.core.publisher.Mono;

@AllArgsConstructor(onConstructor = @__(@Autowired))
@NoArgsConstructor
@Component
public class AccountDetailIncorrectRule implements VerificationRule {
    private NameMatchingResultEnricher nameMatchingResultEnricher;

    private AccountDetailIncorrectReplyProcessor accountDetailIncorrectReplyProcessor;

    @Override
    public boolean matches(VerificationContext context) {
        if (context.getNameMatchingResult().isEmpty() || context.getReply().isPresent()) {
            return false;
        }
        return context.getNameMatchingResult().map(res -> res.getScore().getDecision() == MatchingDecision.NO_MATCH)
                .orElse(false);
    }

    @Override
    public Mono<VerificationContext> enrichContext(VerificationContext context) {
        if (context.getReply().isPresent()) {
            return Mono.just(context);
        }
        return this.nameMatchingResultEnricher.enrichContext(context);
    }

    @Override
    public Mono<VerificationContext> process(VerificationContext context) {
        return this.accountDetailIncorrectReplyProcessor.enrichContext(context);
    }

    @Override
    public String getRuleCode() {
        return "ACCOUNT-DETAIL-INCORRECT";
    }
}
