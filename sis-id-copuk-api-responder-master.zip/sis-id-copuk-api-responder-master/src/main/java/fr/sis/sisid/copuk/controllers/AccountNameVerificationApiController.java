package fr.sis.sisid.copuk.controllers;

import fr.sis.sisid.copuk.config.NameVerificationRequestCounter;
import fr.sis.sisid.copuk.cop.api.NameVerificationService;
import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.copapi.api.AccountsApi;
import fr.sis.sisid.copuk.copapi.model.InlineObject;
import fr.sis.sisid.copuk.copapi.model.InlineResponse200;
import fr.sis.sisid.copuk.mappers.CopRequestMapper;
import fr.sis.sisid.copuk.service.mapper.CopReplyMapperImpl;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;
import reactor.core.publisher.SignalType;

import javax.validation.Valid;

/**
 * Main controller implementation for the CoPUK Responder REST API for checking account names
 */
@RestController
@AllArgsConstructor(onConstructor = @__(@Autowired))
@NoArgsConstructor
@RequestMapping("/api/v1.0/pay.uk")
@Slf4j
public class AccountNameVerificationApiController implements AccountsApi {

    private CopReplyMapperImpl replyMapper;
    private CopRequestMapper requestMapper;
    private NameVerificationService confirmationOfPayee;
    private NameVerificationRequestCounter requestCounter;

    @Override
    public @ResponseBody Mono<ResponseEntity<InlineResponse200>> accountVerification(String authorization,
            String xFapiFinancialId, String xFapiInteractionId, String xJwsSignature,
            @Valid @RequestBody Mono<InlineObject> copPayload, ServerWebExchange webExchange) {

        return this.requestMapper.toDomain(copPayload, xFapiFinancialId)
                .flatMap(copRequest -> this.confirmationOfPayee.getCop(copRequest)
                        .flatMap(reply ->
                                Mono.deferContextual(ctx -> {
                                    VerificationContext.reply(ctx, reply);
                                    return Mono.just(this.replyMapper.toDTO(reply));
                                })
                        )
                        .flatMap(reply -> Mono.just(ResponseEntity.ok(reply)))
                        .doOnEach(tt -> {
                            if (SignalType.ON_NEXT.equals(tt.getType())) {
                                requestCounter.countNameVerificationRequest(false, tt.get());
                            }
                            if (SignalType.ON_ERROR.equals(tt.getType())) {
                                requestCounter.countNameVerificationRequest(true, tt.get());
                            }
                        })
                        .contextWrite(ctx -> {
                            VerificationContext.request(ctx, copRequest);
                            return ctx;
                        }));

    }
}
