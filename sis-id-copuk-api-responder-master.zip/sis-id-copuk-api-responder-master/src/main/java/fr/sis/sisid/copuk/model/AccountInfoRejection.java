package fr.sis.sisid.copuk.model;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = false)
@Builder
public class AccountInfoRejection implements AccountInfoReply {

    private String reason;

    private AccountInfoErrorCode code;
}
