package fr.sis.sisid.copuk.model;

import java.util.Optional;

import fr.sis.sisid.copuk.copapi.model.ReasonCodes;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CoreCopReply {

    @Builder.Default
    private Optional<String> name = Optional.empty();

    @Builder.Default
    private boolean matched = false;

    @Builder.Default
    private Optional<ReasonCodes> reasonCode = Optional.empty();
}
