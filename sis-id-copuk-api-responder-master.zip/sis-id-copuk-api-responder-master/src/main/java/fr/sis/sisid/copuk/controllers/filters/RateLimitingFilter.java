
package fr.sis.sisid.copuk.controllers.filters;

import fr.sis.sisid.copuk.controllers.errors.ClientRateLimitedException;
import fr.sis.sisid.copuk.controllers.errors.NonRepudiationException;
import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.service.RateLimitService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

import java.util.Optional;

@Slf4j
@Component
@Order(-503)
public class RateLimitingFilter extends NameVerificationFilter {

    private RateLimitService rateLimitService;

    protected RateLimitingFilter(@Value("${copuk.api.path-pattern:/api/v*/pay.uk}") String payUkPathPattern,
            RateLimitService rateLimitService) {
        super(payUkPathPattern);
        this.rateLimitService = rateLimitService;
    }

    @Override
    protected Mono<Void> nameVerificationFilter(ServerWebExchange exchange, WebFilterChain chain) {
        return Mono.deferContextual(ctx -> {
            // get client id out of the verification context
            VerificationContext verificationContext = ctx.get(VerificationContext.class);
            Optional<String> clientIdOpt = verificationContext.getClientId();
            if (clientIdOpt.isEmpty()) {
                return Mono.error(new NonRepudiationException("Client id is missing"));
            }
            String clientId = clientIdOpt.get();
            // see if rate limited, if so return an error
            var rateLimit = this.rateLimitService.isRateLimited(clientId);
            if (rateLimit.limited()) {
                exchange.getResponse().getHeaders().add("Retry-After", rateLimit.secondsToWait() + "");
                return Mono.error(new ClientRateLimitedException(clientId, rateLimit.secondsToWait()));
            }
            return chain.filter(exchange);
        });
    }
}
