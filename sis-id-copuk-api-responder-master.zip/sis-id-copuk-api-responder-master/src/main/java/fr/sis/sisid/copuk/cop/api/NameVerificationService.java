package fr.sis.sisid.copuk.cop.api;

import fr.sis.sisid.copuk.model.CoreCopReply;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import reactor.core.publisher.Mono;

/**
 * Confirmation of payee interface
 */
public interface NameVerificationService {

    /**
     * Returns a confirmation of payee reply, given a confirmation of payee request
     * @param request The query made by the TPP
     * @return A mono to the reply given by this responder
     */
    Mono<CoreCopReply> getCop(CoreCopRequest request);


}
