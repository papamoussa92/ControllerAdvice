package fr.sis.sisid.copuk.config;

import fr.sis.sisid.copuk.dto.AsymetricEncoder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import java.util.Optional;

@Configuration
public class AsymetricEncoderConfig {

    @Bean
    public AsymetricEncoder createBanAsymetricEncoder(@Value("${app.identifiant-ssa-public-key}") String publicKey) {
        return new AsymetricEncoder(Optional.empty(), publicKey);
    }
}




