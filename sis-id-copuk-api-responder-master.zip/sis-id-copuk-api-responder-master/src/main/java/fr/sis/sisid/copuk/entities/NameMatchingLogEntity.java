package fr.sis.sisid.copuk.entities;

import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import lombok.Data;

@Entity
@Table(name = "name_matching_log")
@Data
public class NameMatchingLogEntity {

    @Id
    @Column(name = "id", columnDefinition = "SERIAL")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "input_name")
    private String inputName;

    @Column(name = "reference_name")
    private String referenceName;

    @Column(name = "processed_input")
    private String processedInput;

    @Column(name = "processed_reference")
    private String processedReference;

    @Column(name = "rule_code")
    private String ruleCode;

    @Column(name = "score")
    private BigDecimal score;

    @Column(name = "decision")
    @Enumerated(EnumType.STRING)
    private MatchingDecision decision;

    @ManyToOne
    @JoinColumn(name = "audit_id", nullable = false)
    private Audit audit;

    @Column(name = "rule_order")
    private short ruleOrder;

    @Column(name = "date_audit")
    private Timestamp dateAudit;
}
