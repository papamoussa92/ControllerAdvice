package fr.sis.sisid.copuk.cop.spi;

import fr.sis.sisid.copuk.model.AccountInfoReply;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import reactor.core.publisher.Mono;

/**
 * Provides bank account informations
 */
public interface AccountInfoProvider {

    Mono<AccountInfoReply> getAccountInfo(CoreCopRequest copRequest);
}
