package fr.sis.sisid.copuk.cop.core.rules;

import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.rules.processors.AccountInfoEnricher;
import fr.sis.sisid.copuk.copapi.model.ReasonCodes;
import fr.sis.sisid.copuk.model.AccountInfoErrorCode;
import fr.sis.sisid.copuk.model.AccountInfoRejection;
import fr.sis.sisid.copuk.model.CoreCopReply;
import lombok.AllArgsConstructor;
import reactor.core.publisher.Mono;

@AllArgsConstructor(onConstructor = @__(@Autowired))
@Component
public class SortCodeNotSupportedRule implements VerificationRule {
    private AccountInfoEnricher accountInfoEnricher;

    @Override
    public boolean matches(VerificationContext context) {
        if (context.getReply().isPresent() || context.getAccountInfoError().isEmpty()) {
            return false;
        }
        return Set.of(
                AccountInfoErrorCode.UNSUPPORTED_CLEARING_SYSTEM_CODE,
                AccountInfoErrorCode.UNKNOWN_MEMBER_ID,
                AccountInfoErrorCode.UNSUPPORTED_CLEARING_SYSTEM,
                AccountInfoErrorCode.IDENTIFICATION_MEMBER_ID_MISMATCH).contains(
                        context.getAccountInfoError().map(
                                AccountInfoRejection::getCode).orElse(null));
    }

    @Override
    public Mono<VerificationContext> enrichContext(VerificationContext context) {
        if (context.getReply().isPresent()) {
            return Mono.just(context);
        }
        return this.accountInfoEnricher.enrichContext(context);
    }

    @Override
    public Mono<VerificationContext> process(VerificationContext context) {
        context.setReply(CoreCopReply.builder()
                .matched(false)
                .reasonCode(Optional.of(ReasonCodes.SCNS))
                .build());
        return Mono.just(context);
    }

    @Override
    public String getRuleCode() {
        return "SORT-CODE-NOT-SUPPORTED";
    }
}
