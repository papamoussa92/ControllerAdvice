package fr.sis.sisid.copuk.config;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import io.micrometer.core.instrument.ImmutableTag;
import io.micrometer.core.instrument.Tag;
import io.micrometer.prometheus.PrometheusMeterRegistry;

@Component
public class SlaRequestCounter {

    @Value("${copuk.sla:1500}")
    private long responseTimeSLA;

    @Autowired
    private PrometheusMeterRegistry metricsRegistry;

    @Async
    public void countResponsesAboveSLA(long responseDurationMillis) {
        List<Tag> responsesAboveSLATags = new LinkedList<>();
        responsesAboveSLATags.add(new ImmutableTag("above_sla", (responseDurationMillis > responseTimeSLA) + ""));
        this.metricsRegistry.counter("fr.sis.sisid.copuk.copreply.above_sla", responsesAboveSLATags).increment();
    }
}
