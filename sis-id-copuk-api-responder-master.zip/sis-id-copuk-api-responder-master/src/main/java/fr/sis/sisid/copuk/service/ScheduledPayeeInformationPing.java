package fr.sis.sisid.copuk.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import fr.sis.sisid.copuk.ext.bnp.api.PayeeInformationClient;

/**
 * Sends HEAD requests to the name verification API
 * at interval.
 * The API requires oauth authentication, pinging if
 * at interval forces spring to keep a fresh authentication
 * token ready at all times. This prevents us from having
 * to authenticate when performing a name-verification 
 * request, and saves on response time.
 */
@Service
public class ScheduledPayeeInformationPing {

    @Autowired
    private PayeeInformationClient payeeInfoClient;

    @Scheduled(cron = "${app.bnp.ping.cron:0 */25 * * * *}")
    public void ping() {
        this.payeeInfoClient.headRequest().subscribe();
    }

    @EventListener
    public void initializeCaches(ContextRefreshedEvent event) {
        this.ping();
    }
}
