package fr.sis.sisid.copuk.controllers.filters;

import org.springframework.http.HttpMethod;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.lang.NonNull;
import org.springframework.web.server.MethodNotAllowedException;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import org.springframework.web.util.pattern.PathPattern;
import org.springframework.web.util.pattern.PathPatternParser;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

/**
 * Subclass to apply filters specifically for the pay uk path
 */
public abstract class NameVerificationFilter implements WebFilter {

    private final PathPattern pathMatcher;

    protected NameVerificationFilter(String payUkPathPattern) {
        this.pathMatcher = new PathPatternParser().parse(payUkPathPattern);
    }

    @Override public final @NonNull Mono<Void> filter(@NonNull ServerWebExchange exchange,
            @NonNull WebFilterChain chain) {
        final ServerHttpRequest request = exchange.getRequest();

        if (pathMatcher.matchStartOfPath(request.getPath().pathWithinApplication()) != null) {
            if (!HttpMethod.POST.equals(exchange.getRequest().getMethod())) {
                return Mono.error(new MethodNotAllowedException(Optional.of(exchange.getRequest())
                        .map(ServerHttpRequest::getMethod).map(HttpMethod::name)
                        .orElse("Unknown"), List.of(HttpMethod.POST)));
            }
            return nameVerificationFilter(exchange, chain);
        }
        return chain.filter(exchange);
    }

    protected abstract Mono<Void> nameVerificationFilter(ServerWebExchange exchange, WebFilterChain chain);
}
