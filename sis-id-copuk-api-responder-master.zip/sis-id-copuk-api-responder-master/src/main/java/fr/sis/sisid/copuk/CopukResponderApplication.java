package fr.sis.sisid.copuk;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableAsync;

import fr.sis.sisid.copuk.config.AccountInfoProperties;
import fr.sis.sisid.copuk.config.ApplicationProperties;
import fr.sis.sisid.copuk.config.RateLimitProperties;
import fr.sis.sisid.copuk.tools.MicroserviceTools;
import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@EnableConfigurationProperties({ ApplicationProperties.class, AccountInfoProperties.class, RateLimitProperties.class })
@EnableAspectJAutoProxy
@EnableAsync
@EnableCaching
@Slf4j
public class CopukResponderApplication {

    private static final String DEV_PROFILE = "dev";

    private static final String PROD_PROFILE = "prod";

    private static final String CLOUD_PROFILE = "cloud";

    private final Environment env;

    public CopukResponderApplication(Environment env) {
        this.env = env;
    }

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(CopukResponderApplication.class);
        Map<String, Object> springProps = new HashMap<>();
        // use dev profile as default
        springProps.put("spring.profiles.default", DEV_PROFILE);
        app.setDefaultProperties(springProps);
        Environment env = app.run(args).getEnvironment();
        MicroserviceTools.logApplicationStartup(env);
    }

    /**
     * Initializes sp2-ms-skeleton.
     * <p>
     * Spring profiles can be configured with a program argument
     * --spring.profiles.active=your-active-profile
     * <p>
     * You can find more information on how profiles work with JHipster on <a href=
     * "https://www.jhipster.tech/profiles/">https://www.jhipster.tech/profiles/</a>.
     */
    @PostConstruct
    public void initApplication() {
        Collection<String> activeProfiles = Arrays.asList(env.getActiveProfiles());
        if (activeProfiles.contains(DEV_PROFILE) && activeProfiles.contains(PROD_PROFILE)) {
            log.error("You have misconfigured your application! It should not run "
                    + "with both the 'dev' and 'prod' profiles at the same time.");
        }
        if (activeProfiles.contains(DEV_PROFILE) && activeProfiles.contains(CLOUD_PROFILE)) {
            log.error("You have misconfigured your application! It should not "
                    + "run with both the 'dev' and 'cloud' profiles at the same time.");
        }
    }
}
