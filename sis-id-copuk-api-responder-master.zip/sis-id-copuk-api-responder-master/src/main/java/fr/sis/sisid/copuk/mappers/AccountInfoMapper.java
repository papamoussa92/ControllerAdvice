package fr.sis.sisid.copuk.mappers;

import fr.sis.sisid.copuk.ext.bnp.model.CopReply;
import fr.sis.sisid.copuk.model.AccountInfoReply;

public interface AccountInfoMapper {
    AccountInfoReply toDomain(CopReply dto);
}
