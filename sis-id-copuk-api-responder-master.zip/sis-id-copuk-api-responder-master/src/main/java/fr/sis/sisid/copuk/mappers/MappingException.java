package fr.sis.sisid.copuk.mappers;

public class MappingException extends RuntimeException {

    private static final long serialVersionUID = -2895695153083415777L;

    public MappingException(String message) {
        super(message);
    }

}
