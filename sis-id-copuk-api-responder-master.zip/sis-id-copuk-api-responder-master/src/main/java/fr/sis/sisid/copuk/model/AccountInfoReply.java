package fr.sis.sisid.copuk.model;

public interface AccountInfoReply {

}
