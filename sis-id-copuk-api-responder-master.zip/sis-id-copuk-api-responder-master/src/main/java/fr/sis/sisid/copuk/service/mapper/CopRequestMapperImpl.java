package fr.sis.sisid.copuk.service.mapper;

import fr.sis.sisid.copuk.copapi.model.InlineObject;
import fr.sis.sisid.copuk.copapi.model.OBExternalAccountType1Code;
import fr.sis.sisid.copuk.ext.bnp.model.AccountIdentificationChoice;
import fr.sis.sisid.copuk.ext.bnp.model.AccountTypeComponent;
import fr.sis.sisid.copuk.ext.bnp.model.CashAccount;
import fr.sis.sisid.copuk.ext.bnp.model.ClearingSystemIdentificationChoice;
import fr.sis.sisid.copuk.ext.bnp.model.ClearingSystemMemberIdentification;
import fr.sis.sisid.copuk.ext.bnp.model.CopRequest;
import fr.sis.sisid.copuk.ext.bnp.model.FinancialInstitutionIdentification;
import fr.sis.sisid.copuk.ext.bnp.model.GenericIdentification;
import fr.sis.sisid.copuk.mappers.CopRequestMapper;
import fr.sis.sisid.copuk.model.AccountType;
import fr.sis.sisid.copuk.model.CoreCopRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Arrays;

@Component public class CopRequestMapperImpl implements CopRequestMapper {
    @Value("${paramsGBDSC.codedentificationChoice}") private String codedentificationChoice;

    @Value("${currencyGBP.currency}") private String currency;

    @Value("${countryCodeGB.countryCode}") private String countryCode;

    public Mono<CoreCopRequest> toDomain(Mono<InlineObject> request, String xFapiInteractionId) {
        return request.map(dto -> {
            String sortCodeAccount = dto.getData().getIdentification();
            String sortCode = sortCodeAccount.trim().substring(0, 6);
            String accountNumber = sortCodeAccount.trim().substring(6);
            return CoreCopRequest.builder()
                    .accountNumber(accountNumber)
                    .sortCode(sortCode)
                    .xFapiInteractionId(xFapiInteractionId)
                    .name(dto.getData().getName())
                    .accountType(this.mapAccountType(dto.getData().getAccountType()))
                    .build();
        });
    }

    public CopRequest toDTO(CoreCopRequest domainObject) {
        ClearingSystemMemberIdentification csi = new ClearingSystemMemberIdentification().memberIdentification(
                        domainObject.getSortCode())
                .clearingSystemIdentification(new ClearingSystemIdentificationChoice().code(codedentificationChoice));
        FinancialInstitutionIdentification financeInstitut = new FinancialInstitutionIdentification().clearingSystemMemberIdentification(
                csi);
        CashAccount cashAccount = new CashAccount().identification(getAccountIdentificationChoice(domainObject))
                .currency(Arrays.asList(currency)).accountType(this.mapAccountType(domainObject.getAccountType()));
        return new CopRequest().country(countryCode).financialInstitution(financeInstitut).account(cashAccount);
    }

    private AccountIdentificationChoice getAccountIdentificationChoice(CoreCopRequest domainObject) {
        return new AccountIdentificationChoice().other(new GenericIdentification().identification(
                domainObject.getSortCode() + domainObject.getAccountNumber()));
    }

    private AccountType mapAccountType(OBExternalAccountType1Code accountType) {
        switch (accountType) {
            case BUSINESS: {
                return AccountType.BUSINESS;
            }
            case PERSONAL: {
                return AccountType.PRIVATE;
            }
            default: {
                return null;
            }
        }
    }

    private AccountTypeComponent mapAccountType(AccountType accountType) {
        switch (accountType) {
            case BUSINESS: {
                return AccountTypeComponent.ORGANISATION;
            }
            case PRIVATE: {
                return AccountTypeComponent.PRIVATE;
            }
            default: {
                return null;
            }
        }
    }
}