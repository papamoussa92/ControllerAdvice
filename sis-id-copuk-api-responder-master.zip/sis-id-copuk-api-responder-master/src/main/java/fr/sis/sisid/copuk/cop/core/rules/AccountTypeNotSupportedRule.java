package fr.sis.sisid.copuk.cop.core.rules;

import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.rules.processors.AccountInfoEnricher;
import fr.sis.sisid.copuk.copapi.model.ReasonCodes;
import fr.sis.sisid.copuk.model.AccountInfoErrorCode;
import fr.sis.sisid.copuk.model.AccountInfoRejection;
import fr.sis.sisid.copuk.model.CoreCopReply;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import reactor.core.publisher.Mono;

/**
 * Payee information was requested for an unsupported ( non-business ) account type
 */
@AllArgsConstructor(onConstructor = @__(@Autowired))
@Component
@NoArgsConstructor
public class AccountTypeNotSupportedRule implements VerificationRule {

    private AccountInfoEnricher accountInfoEnricher;

    @Override
    public boolean matches(VerificationContext context) {
        if (context.getReply().isPresent() || context.getAccountInfoError().isEmpty()) {
            return false;
        }
        return Objects.equals(AccountInfoErrorCode.UNSUPPORTED_ACCOUNT_TYPE,
                context.getAccountInfoError().map(AccountInfoRejection::getCode).orElse(null));
    }

    @Override
    public Mono<VerificationContext> enrichContext(VerificationContext context) {
        if (context.getReply().isPresent()) {
            return Mono.just(context);
        }
        return this.accountInfoEnricher.enrichContext(context);
    }

    @Override
    public Mono<VerificationContext> process(VerificationContext context) {
        context.setReply(CoreCopReply.builder()
                .matched(false)
                .reasonCode(Optional.of(ReasonCodes.ACNS))
                .build());
        return Mono.just(context);

    }

    @Override
    public String getRuleCode() {
        return "ACCOUNT-TYPE-NOT-SUPPORTED";
    }

}
