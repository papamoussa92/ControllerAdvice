package fr.sis.sisid.copuk.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;

import fr.sis.sisid.copuk.entities.CachedSynonymRepo;
import fr.sis.sisid.copuk.entities.InvoiceDiscountAccountImpl;
import fr.sis.sisid.copuk.entities.NatureEnterpriseImpl;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class CacheConfig {

    @Autowired
    private NatureEnterpriseImpl natureEnterprise;

    @Autowired
    private InvoiceDiscountAccountImpl invoiceDiscount;

    @Autowired
    private CachedSynonymRepo synonyms;

    @EventListener
    public void initializeCaches(ContextRefreshedEvent event) {
        // reset nature entreprise cache
        natureEnterprise.clearCache();
        natureEnterprise.getAllNatureEntreprise();
        log.info("Initialized nature-entreprise cache");
        // reset prefix cache
        invoiceDiscount.clearCache();
        invoiceDiscount.getPrefixes();
        log.info("Initialized invoice discount cache");
        // reset synonym cache
        this.synonyms.clearCache();
        this.synonyms.getAll();
        log.info("Initialized synonym cache");
    }

}
