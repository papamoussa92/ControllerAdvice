package fr.sis.sisid.copuk.entities;

import com.vladmihalcea.hibernate.type.json.JsonType;
import lombok.*;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "form")
@Getter
@Setter
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@TypeDef(name = "json", typeClass = JsonType.class)
@ToString(callSuper = true, exclude = "forms")
@EqualsAndHashCode(callSuper = true, exclude = "country")
public class FormEntity extends BaseEntity {
    private String name;

    @Type(type = "json")
    @Column(name = "spelling", columnDefinition = "json")
    private List<String> spellings;

    @ManyToOne
    @JoinColumn(name = "dictionary_id", nullable = false)
    private DictionaryEntity dictionary;
}
