package fr.sis.sisid.copuk.entities;

import java.util.List;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CompanySynonymSearchDao extends JpaRepository<CompanySynonymsDAO, Long> {

    @Override
    @Cacheable("synonyms")
    public List<CompanySynonymsDAO> findAll();
}
