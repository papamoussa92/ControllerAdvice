package fr.sis.sisid.copuk.entities;

import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

import fr.sis.sisid.copuk.namematching.processors.nature.NatureEnterprise;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class NatureEnterpriseImpl implements NatureEnterprise {

    private final NatureEnterpriseDAO natureEnterpriseDAO;

    public NatureEnterpriseImpl(NatureEnterpriseDAO natureEnterpriseDAO) {
        this.natureEnterpriseDAO = natureEnterpriseDAO;
    }

    @Override
    @Cacheable("nature-entreprise")
    public Set<String> getAllNatureEntreprise() {
        return this.natureEnterpriseDAO.findAll().stream().map(NatureEnterpriseEntity::getNature)
                .collect(Collectors.toSet());
    }

    @CacheEvict("nature-entreprise")
    public void clearCache() {
        // nothing to do
    }
}
