package fr.sis.sisid.copuk.controllers.validators;

import fr.sis.sisid.copuk.OpenBankingConstants;
import fr.sis.sisid.copuk.controllers.errors.InvalidHeaderException;
import fr.sis.sisid.copuk.controllers.errors.MissingHeaderException;
import fr.sis.sisid.copuk.copapi.OpenBankingErrorCode;
import fr.sis.sisid.copuk.copapi.model.OBError1;
import fr.sis.sisid.copuk.tools.errors.MissingSignatureException;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.UUID;
import java.util.stream.Stream;

@Component
@Slf4j
public class HeaderValidator {

    private final String orgId;

    public HeaderValidator(@Value("${app.organisation-id}") String orgId) {
        this.orgId = orgId;
    }

    public void check(HttpHeaders headers) throws InvalidHeaderException, MissingHeaderException {
        // Map missing headers to missing header OpenBanking errors

        if(StringUtils.isBlank(headers.getFirst(OpenBankingConstants.NON_REPUDIATION_HEADER))) {
            throw new MissingSignatureException("Missing signature");
        }
        var missingErrors = Stream.of(OpenBankingConstants.CORRELATION_ID_HEADER,
                        OpenBankingConstants.ORGANISATION_HEADER)
                .map(header -> new AbstractMap.SimpleEntry<>(header, headers.getFirst(header)))
                .filter(e -> StringUtils.isBlank(e.getValue()))
                .map(e -> new OBError1().errorCode(
                                OpenBankingErrorCode.HEADER_MISSING.getCode())
                        .message("Missing %s header".formatted(e.getKey())).path(e.getKey())).toList();

        if (!missingErrors.isEmpty()) {
            throw new MissingHeaderException(missingErrors);
        }



        var invalidErrors = new ArrayList<OBError1>();
        if (!validateFapiFinancialId(headers.getFirst(OpenBankingConstants.ORGANISATION_HEADER))) {
            invalidErrors.add(new OBError1().errorCode(OpenBankingErrorCode.HEADER_INVALID.getCode())
                    .message("Invalid %s ".formatted(OpenBankingConstants.ORGANISATION_HEADER))
                    .path(OpenBankingConstants.ORGANISATION_HEADER));
        }

        if (!validFapiInteractionId(headers.getFirst(OpenBankingConstants.CORRELATION_ID_HEADER))) {
            invalidErrors.add(new OBError1().errorCode(OpenBankingErrorCode.HEADER_INVALID.getCode())
                    .message("Invalid %s ".formatted(OpenBankingConstants.CORRELATION_ID_HEADER))
                    .path(OpenBankingConstants.CORRELATION_ID_HEADER));
        }

        if (!invalidErrors.isEmpty()) {
            throw new InvalidHeaderException(invalidErrors);
        }
    }

    private boolean validateFapiFinancialId(String fapiFinancialId) {
        return orgId.equals(fapiFinancialId);
    }

    private boolean validFapiInteractionId(String fapiInteractionId) {
        try {
            return !UUID.fromString(fapiInteractionId).toString().isEmpty();
        } catch (IllegalArgumentException | NullPointerException ex) {
            log.debug("invalid correlation ID passed:%s".formatted(fapiInteractionId), ex);
            return false;
        }
    }
}
