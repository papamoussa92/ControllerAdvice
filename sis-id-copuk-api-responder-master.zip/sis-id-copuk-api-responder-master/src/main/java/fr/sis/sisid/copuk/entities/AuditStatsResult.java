package fr.sis.sisid.copuk.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuditStatsResult {

    private Long nbPersonalRequests;

    private Long nbBusinessRequests;

    private Long nbMatched;

    private Long nbANNM;

    private Long nbMBAM;

    private Long nbBANM;

    private Long nbPANM;

    private Long nbBAMM;

    private Long nbAC01;

    private Long nbIVCR;

    private Long nbACNS;

    private Long nbOPTO;

    private Long nbCASS;

    private Long nbSCNS;

    private Long nbOutsideOfSLA;
}
