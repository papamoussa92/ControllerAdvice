package fr.sis.sisid.copuk.client;

import fr.sis.sisid.copuk.dto.SsaDTO;
import org.springframework.http.ResponseEntity;
import reactor.core.publisher.Mono;

public interface ClientRegistrationClient {

    Mono<ResponseEntity<SsaDTO>> getSSA(String clientId);
}
