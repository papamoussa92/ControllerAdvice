package fr.sis.sisid.copuk.cop.core.rules.processors;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import fr.sis.sisid.copuk.cop.core.rules.VerificationRuleException;
import fr.sis.sisid.copuk.copapi.model.ReasonCodes;
import fr.sis.sisid.copuk.model.CoreAccountInfo;
import fr.sis.sisid.copuk.model.CoreCopReply;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.util.Optional;

/**
 * Adds a CoP reply to the context, stating that the account
 * name is a near-match
 */
@Component
public class CloseMatchReplyProcessor implements VerificationContextProcessor {

    @Override
    public Mono<VerificationContext> enrichContext(VerificationContext context) {
        if (context.getAccountInfo().isEmpty()) {
            return Mono.error(new VerificationRuleException("No account info"));
        }
        context.setReply(CoreCopReply.builder()
                        .matched(false)
                        .name(context.getAccountInfo().map(CoreAccountInfo::getName))
                        .reasonCode(Optional.of(ReasonCodes.MBAM))
                        .build());
        return Mono.just(context);
    }

}
