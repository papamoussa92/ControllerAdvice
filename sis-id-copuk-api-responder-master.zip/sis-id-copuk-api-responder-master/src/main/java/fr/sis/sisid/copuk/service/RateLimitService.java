package fr.sis.sisid.copuk.service;

public interface RateLimitService {

    public record RateLimitResponse(boolean limited, long secondsToWait) {
    }

    /**
     * Looks if this client has been rate limited.
     * If it is, returns the number of seconds it would have to wait 
     * to make another request
     * @param clientId
     * @return
     */
    public RateLimitResponse isRateLimited(String clientId);

}
