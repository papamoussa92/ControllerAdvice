package fr.sis.sisid.copuk.config;

import fr.sis.sisid.copuk.controllers.converters.NameMatchingStatsCsvWriter;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.codec.ServerCodecConfigurer;
import org.springframework.web.reactive.config.WebFluxConfigurer;

@Configuration
public class WebConfig implements WebFluxConfigurer {
    @Override
    public void configureHttpMessageCodecs(ServerCodecConfigurer configurer) {
        NameMatchingStatsCsvWriter converter = new NameMatchingStatsCsvWriter();
        configurer.customCodecs().register(converter);

    }

}