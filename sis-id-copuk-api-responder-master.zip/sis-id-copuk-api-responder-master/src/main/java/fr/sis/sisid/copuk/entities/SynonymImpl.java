package fr.sis.sisid.copuk.entities;

import java.util.Collection;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import fr.sis.sisid.copuk.namematching.model.CompanySynonyms;
import fr.sis.sisid.copuk.namematching.processors.synonym.SynonymRepo;

//@Component
public class SynonymImpl implements SynonymRepo {
    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<CompanySynonyms> findByCompanyName(Collection<String> inputFromBnp) {
        CriteriaQuery<CompanySynonymsDAO> cq = createCriteriaQuery();
        Root<CompanySynonymsDAO> rootEntry = cq.from(CompanySynonymsDAO.class);
        Predicate[] predicates = inputFromBnp.stream().map(n -> "%" + n + "%")
                .map(n -> getCriteriaBuilder().like(getCriteriaBuilder().upper(rootEntry.get("accountName")), n))
                .toArray(Predicate[]::new);
        CriteriaQuery<CompanySynonymsDAO> all = cq.select(rootEntry).where(predicates);
        return findListByCriteria(all).stream()
                .map(companySynonymsEntity -> new CompanySynonyms(companySynonymsEntity.getId(),
                        companySynonymsEntity.getAccountName(), companySynonymsEntity.getTradingName()))
                .toList();
    }

    protected CriteriaQuery<CompanySynonymsDAO> createCriteriaQuery() {
        return createCriteriaQuery(CompanySynonymsDAO.class);
    }

    protected <E> CriteriaQuery<E> createCriteriaQuery(Class<E> eClass) {
        CriteriaBuilder cb = getCriteriaBuilder();
        return cb.createQuery(eClass);
    }

    protected CriteriaBuilder getCriteriaBuilder() {
        return entityManager.getCriteriaBuilder();
    }

    protected <E> List<E> findListByCriteria(CriteriaQuery<E> criteria) {
        TypedQuery<E> allQuery = entityManager.createQuery(criteria);

        return allQuery.getResultList();
    }
}
