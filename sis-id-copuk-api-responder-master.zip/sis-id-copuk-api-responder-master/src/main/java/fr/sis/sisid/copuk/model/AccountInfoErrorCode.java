package fr.sis.sisid.copuk.model;

import org.apache.commons.lang3.StringUtils;

import lombok.Getter;

public enum AccountInfoErrorCode {

    ACCOUNT_NOT_FOUND("BUS01"),
    UNSUPPORTED_ACCOUNT_TYPE("ERR17"),
    UNSUPPORTED_SCHEME_NAME("ERR10"),
    MISSING_COUNTRY("ERR11"),
    MISSING_CLEARING_SYSTEM_ID("ERR12"),
    UNSUPPORTED_CLEARING_SYSTEM_CODE("ERR13"),
    UNKNOWN_MEMBER_ID("ERR14"),
    IDENTIFICATION_MEMBER_ID_MISMATCH("ERR19"),
    UNSUPPORTED_CLEARING_SYSTEM("ERR18"),
    UNCOHERENT_COUNTRY("ERR15"),
    UNSUPPORTED_COUNTRY("ERR16"),
    ACCOUNT_OPT_OUT("CUSTOM_ACC_OPT_OUT"), // custom code
    ACCOUNT_SWITCHED("CUSTOM_ACC_SWITCHED"), // custom code
    UNKNOWN_ERROR_CODE("XXX");

    @Getter
    private String code;

    private AccountInfoErrorCode(String code) {
        this.code = code;
    }

    public static AccountInfoErrorCode fromCode(String code) {
        for (var aiec : AccountInfoErrorCode.values()) {
            if (StringUtils.equalsIgnoreCase(aiec.getCode(), code)) {
                return aiec;
            }
        }
        return UNKNOWN_ERROR_CODE;
    }
}
