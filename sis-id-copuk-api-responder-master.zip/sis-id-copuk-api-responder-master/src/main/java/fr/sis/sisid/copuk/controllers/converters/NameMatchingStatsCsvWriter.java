package fr.sis.sisid.copuk.controllers.converters;

import com.fasterxml.jackson.dataformat.csv.CsvMapper;
import com.fasterxml.jackson.dataformat.csv.CsvSchema;
import fr.sis.sisid.copuk.dto.NameMatchingStatsDTO;
import org.reactivestreams.Publisher;
import org.springframework.core.ResolvableType;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.http.MediaType;
import org.springframework.http.ReactiveHttpOutputMessage;
import org.springframework.http.codec.HttpMessageWriter;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.io.StringWriter;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Map;

/**
 * Http converter to write {@link NameMatchingStatsDTO} as CSV
 * Does not support reads
 */
@Component public class NameMatchingStatsCsvWriter implements HttpMessageWriter<NameMatchingStatsDTO> {

    private static final MediaType supportedMediaType = MediaType.valueOf("text/csv");

    @Override public @NonNull List<MediaType> getWritableMediaTypes() {
        return List.of(supportedMediaType);
    }

    @Override public boolean canWrite(ResolvableType elementType, MediaType mediaType) {
        return NameMatchingStatsDTO.class.isAssignableFrom(
                elementType.toClass()) && supportedMediaType.isCompatibleWith(mediaType);
    }

    @Override public @NonNull Mono<Void> write(@NonNull Publisher<? extends NameMatchingStatsDTO> inputStream,
            @NonNull ResolvableType elementType, MediaType mediaType,
            @NonNull ReactiveHttpOutputMessage message, @NonNull Map<String, Object> hints) {

        message.getHeaders().setContentType(mediaType);
        Charset charset = Charset.defaultCharset();

        CsvMapper csvMapper = new CsvMapper();
        CsvSchema csvSchema = csvMapper.schemaFor(NameMatchingStatsDTO.class).withHeader();

        return Mono.from(inputStream).flatMap(nameMatchingStatsDTO -> {
            try {
                StringWriter stringWriter = new StringWriter();
                csvMapper.writerFor(NameMatchingStatsDTO.class).with(csvSchema)
                        .writeValue(stringWriter, nameMatchingStatsDTO);

                ByteBuffer byteBuffer = charset.encode(stringWriter.toString());
                DataBuffer buffer = message.bufferFactory().wrap(byteBuffer); // wrapping only, no allocation
                message.getHeaders().setContentLength(byteBuffer.remaining());

                return message.writeWith(Mono.just(buffer));
            } catch (IOException e) {
                return Mono.error(new RuntimeException(e));
            }
        });

    }
}
