package fr.sis.sisid.copuk.model;

public enum AccountType {
    PRIVATE, BUSINESS
}
