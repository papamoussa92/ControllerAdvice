package fr.sis.sisid.copuk.controllers.errors;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.ServerResponse;

/**
 * Utility to help build an appropriate HTTP response based on the type of exception
 * @param <T> the type of exception matched
 */
public class ExceptionMatcher<T> {
    private final ExceptionProcessor exceptionProcessor;
    HttpStatus status;
    private ServerResponse.BodyBuilder bodyBuilder;
    T exception;

    public ExceptionMatcher(ExceptionProcessor exceptionProcessor, T cast) {
        this.exceptionProcessor = exceptionProcessor;
        exception = cast;
    }

    public ExceptionMatcher(ExceptionProcessor exceptionProcessor) {
        this.exceptionProcessor = exceptionProcessor;
    }

    public ExceptionMatcher<T> status(final HttpStatus status) {
        if (exception != null) {
            this.status = status;
            this.bodyBuilder = ServerResponse.status(status);
        }
        return this;
    }

    public ExceptionMatcher<T> status(ExceptionProcessor.StatusCodeBuilder<T> statusCodeBuilder) {
        if (exception != null) {
            this.status = statusCodeBuilder.build(exception);
            this.bodyBuilder = ServerResponse.status(status);
        }
        return this;
    }

    public ExceptionProcessor body(final ExceptionProcessor.ResponseBuilder<T> responseBuilder) {
        if (exception != null) {

            var serializedBody = responseBuilder.build(exception, this.status);
            exceptionProcessor.response = this.bodyBuilder.contentType(MediaType.APPLICATION_JSON)
                    .body(BodyInserters.fromValue(
                            serializedBody
                    ));
            exceptionProcessor.processBody(serializedBody, this.bodyBuilder);
        }
        return exceptionProcessor;
    }
}
