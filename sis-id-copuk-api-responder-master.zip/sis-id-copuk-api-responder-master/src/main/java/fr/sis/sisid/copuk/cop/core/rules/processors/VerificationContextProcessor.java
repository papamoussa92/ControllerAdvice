package fr.sis.sisid.copuk.cop.core.rules.processors;

import fr.sis.sisid.copuk.cop.core.VerificationContext;
import reactor.core.publisher.Mono;

/**
 * Contract of a function that modifies a verification context
 * by adding relevant information to it, or by generating a result.
 * Implementations of this interface are meant to be used across multiple verification rules
 *
 */
public interface VerificationContextProcessor {

    /**
     * Enriches a verification context with relevant information
     * @param context the verification context from previous processors
     * @return the amended verification context
     */
    Mono<VerificationContext> enrichContext(VerificationContext context);
}
