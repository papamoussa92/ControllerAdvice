package fr.sis.sisid.copuk.controllers.filters;

import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.lang.NonNull;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.ServerWebExchangeDecorator;

/**
 * Wrapper around the ServerWebExchange to be able to catch the request body in a usage string
 */
public class BodyWebExchangeDecorator extends ServerWebExchangeDecorator {

    private final RequestBodyDecorator requestBodyDecorator;
    private final ResponseBodyDecorator responseBodyDecorator;

    public BodyWebExchangeDecorator(ServerWebExchange exchange, RequestBodyDecorator requestBodyDecorator,
            ResponseBodyDecorator responseBodyDecorator) {
        super(exchange);
        this.requestBodyDecorator = requestBodyDecorator;

        this.responseBodyDecorator = responseBodyDecorator;
    }

    @Override
    public @NonNull ServerHttpRequest getRequest() {
        return requestBodyDecorator;
    }

    @Override @NonNull public ServerHttpResponse getResponse() {
        return responseBodyDecorator;
    }
}
