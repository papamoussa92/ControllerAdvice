package fr.sis.sisid.copuk.entities;

import java.util.Collection;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Component;

import fr.sis.sisid.copuk.namematching.model.CompanySynonyms;
import fr.sis.sisid.copuk.namematching.processors.synonym.SynonymRepo;

@Component
public class CachedSynonymRepo implements SynonymRepo {

    @Autowired
    private CompanySynonymSearchDao synonymRepository;

    @Override
    public List<CompanySynonyms> findByCompanyName(Collection<String> inputFromBnp) {
        return this.getAll().stream()
                .filter(synonym -> inputFromBnp.stream()
                        .allMatch(token -> StringUtils.containsIgnoreCase(synonym.getAccountName(), token)))
                .map(entity -> new CompanySynonyms(entity.getId(), entity.getAccountName(), entity.getTradingName()))
                .toList();
    }

    public List<CompanySynonymsDAO> getAll() {
        return this.synonymRepository.findAll();
    }

    @CacheEvict("synonyms")
    public void clearCache() {
        // nothing to do
    }

}
