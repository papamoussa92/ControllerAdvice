package fr.sis.sisid.copuk.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import fr.sis.sisid.copuk.ext.bnp.api.PayeeInformationClient;
import fr.sis.sisid.copuk.ext.bnp.model.CopReply;
import fr.sis.sisid.copuk.ext.bnp.model.CopRequest;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

/**
 * 
 * Calls the PayeeInformation endpoint
 *
 */
@Slf4j
@Component
public class PayeeInformationSrvClient implements PayeeInformationClient {

    private final WebClient webClient;

    @Autowired
    public PayeeInformationSrvClient(@Qualifier("bnpWebClient") WebClient webClient) {
        this.webClient = webClient;
    }

    @Override
    public Mono<ResponseEntity<CopReply>> providePayeeInformation(CopRequest copRequest) {
        log.debug("Querying confirmation-of-payee ...");
        var req = webClient.method(HttpMethod.POST)
                .uri(uriBuilder -> uriBuilder.path("/v1/confirmation-of-payee").build())
                .bodyValue(copRequest)
                .retrieve()
                .toEntity(CopReply.class)

                .log();
        log.debug("... queried confirmation-of-payee");
        return req;
    }

    @Override
    public Mono<ResponseEntity<Void>> headRequest() {
        log.info("Head request to the account informatino endpoint");
        return webClient.method(HttpMethod.HEAD)
                .uri(uriBuilder -> uriBuilder.path("/v1/confirmation-of-payee").build())
                .retrieve()
                .toBodilessEntity().log();
    }

}
