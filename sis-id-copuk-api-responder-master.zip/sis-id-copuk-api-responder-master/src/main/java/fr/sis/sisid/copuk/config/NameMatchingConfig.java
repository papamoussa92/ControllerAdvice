package fr.sis.sisid.copuk.config;

import fr.sis.sisid.copuk.entities.DictionaryRepository;
import fr.sis.sisid.copuk.entities.DictionaryEntity;
import fr.sis.sisid.copuk.entities.DictionaryType;
import fr.sis.sisid.copuk.namematching.NameMatchingProvider;
import fr.sis.sisid.copuk.namematching.RuleBasedNameMatchingProvider;
import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.processors.DerivedScorer;
import fr.sis.sisid.copuk.namematching.processors.NamePairProcessor;
import fr.sis.sisid.copuk.namematching.processors.NamePairProcessorType;
import fr.sis.sisid.copuk.namematching.processors.acronyms.AcronymProcessor;
import fr.sis.sisid.copuk.namematching.processors.acronyms.AcronymScorer;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.DictSearchProcessorImpl;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.DictSearchScorer;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.index.DictSearchIndex;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.index.DictSearchIndexBuilder;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.model.DictEntry;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.model.DictEntrySet;
import fr.sis.sisid.copuk.namematching.processors.nature.NatureEnterprise;
import fr.sis.sisid.copuk.namematching.processors.nature.NatureEnterpriseProcessor;
import fr.sis.sisid.copuk.namematching.processors.prefix.InvoiceDiscountAccount;
import fr.sis.sisid.copuk.namematching.processors.prefix.InvoiceDiscountAccountProcessor;
import fr.sis.sisid.copuk.namematching.processors.prefix.PrefixScorer;
import fr.sis.sisid.copuk.namematching.processors.structuredinput.StructuredInputProcessor;
import fr.sis.sisid.copuk.namematching.processors.synonym.SynonymProcessor;
import fr.sis.sisid.copuk.namematching.processors.synonym.SynonymRepo;
import fr.sis.sisid.copuk.namematching.scorer.FuzzyScorer;
import fr.sis.sisid.copuk.namematching.scorer.NamePairScorer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.BeanInitializationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;

import java.math.BigDecimal;
import java.util.EnumMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Configuration
@Slf4j
@Order(2)
public class NameMatchingConfig {

    private final InvoiceDiscountAccount invoiceDiscountAccount;
    private final DictionaryRepository countryRepository;
    @Value("${rosette.threshold.legal-form}")
    private BigDecimal legalFormThreshold;
    @Value("${rosette.threshold.geography}")
    private BigDecimal geographyThreshold;
    @Value("${rosette.threshold.match}")
    private BigDecimal thresholdMatch;
    @Value("${rosette.threshold.close-match}")
    private BigDecimal thresholdCloseMatch;
    @Value("${rosette.threshold.nature-enterprise}")
    private BigDecimal thresholdNatureEnterprise;
    @Value("${rosette.limit.legal-forms:CLOSE_MATCH}")
    private String limitLegalForms;
    @Value("${rosette.limit.acronyms:CLOSE_MATCH}")
    private String limitAcronyms;
    @Value("${rosette.limit.prefixes:MATCH}")
    private String limitPrefixes;
    @Value("${rosette.limit.prefixes:CLOSE_MATCH}")
    private String natureEnterprisePrefixes;
    @Value("${rosette.limit.geography:CLOSE_MATCH}")
    private String limitGeography;
    private SynonymRepo synonymRepo;
    private NatureEnterprise natureEnterprise;

    public NameMatchingConfig(InvoiceDiscountAccount invoiceDiscountAccount, DictionaryRepository countryRepository) {
        this.invoiceDiscountAccount = invoiceDiscountAccount;
        this.countryRepository = countryRepository;
    }

    @Autowired
    public void setNatureEnterprise(NatureEnterprise natureEnterprise) {
        this.natureEnterprise = natureEnterprise;
    }

    @Autowired
    public void setSynonymRepo(SynonymRepo synonymRepo) {
        this.synonymRepo = synonymRepo;
    }

    @Bean(name = "legal-form-dictionary")
    public DictSearchIndex legalFormIndexDB() {
        return  getDictSearchIndexByThreshold(legalFormThreshold, DictionaryType.LEGAL_FORM);
    }

    @Bean(name = "country-dictionary")
    public DictSearchIndex countryIndexDb() {
        return getDictSearchIndexByThreshold(geographyThreshold, DictionaryType.GEOGRAPHY);
    }

    @Bean(name = "legal-form-processor")
    public DictSearchProcessorImpl legalFormProcessor(
            @Qualifier("legal-form-dictionary") DictSearchIndex legalFormIndex) {
        return new DictSearchProcessorImpl(legalFormIndex, NamePairProcessorType.LEGAL_FORM);
    }

    @Bean(name = "country-processor")
    public DictSearchProcessorImpl countryProcessor(@Qualifier("country-dictionary") DictSearchIndex countryIndex) {
        return new DictSearchProcessorImpl(countryIndex, NamePairProcessorType.GEOGRAPHY);
    }

    @Bean
    public AcronymProcessor acronymProcessor() {
        return new AcronymProcessor();
    }

    @Bean
    public StructuredInputProcessor structuredInputProcessor() {
        return new StructuredInputProcessor();
    }

    @Bean
    public SynonymProcessor synonymProcessor() {
        return new SynonymProcessor(synonymRepo);
    }

    @Bean
    public NatureEnterpriseProcessor natureEnterpriseProcessor() {
        return new NatureEnterpriseProcessor(natureEnterprise, thresholdNatureEnterprise);
    }

    @Bean
    public InvoiceDiscountAccountProcessor invoiceDiscountAccountProcessor() {
        return new InvoiceDiscountAccountProcessor(invoiceDiscountAccount);
    }

    @Bean
    public NameMatchingProvider nameMatchingProvider(StructuredInputProcessor structuredInputProcessor,
                                                     AcronymProcessor acronymProcessor,
                                                     @Qualifier("legal-form-processor") DictSearchProcessorImpl legalFormProcessor,
                                                     @Qualifier("country-processor") DictSearchProcessorImpl countryProcessor) {
        var scorer = new FuzzyScorer(thresholdMatch, thresholdCloseMatch);
        LinkedList<NamePairProcessor> processors = new LinkedList<>();
        processors.addLast(structuredInputProcessor);
        processors.addLast(synonymProcessor());
        processors.addLast(natureEnterpriseProcessor());
        processors.addLast(invoiceDiscountAccountProcessor());
        processors.addLast(legalFormProcessor);
        processors.addLast(countryProcessor);
        processors.addLast(acronymProcessor);

        var legalFormBound = MatchingDecision.fromString(limitLegalForms);
        var acronymBound = MatchingDecision.fromString(limitAcronyms);
        var prefixBound = MatchingDecision.fromString(limitPrefixes);
        var natureEntrepiseBound = MatchingDecision.fromString(natureEnterprisePrefixes);
        var countryBound = MatchingDecision.fromString(limitGeography);
        if (legalFormBound == null || acronymBound == null || prefixBound == null || countryBound == null) {
            throw new BeanInitializationException("Could not parse the name matching bounds properly");
        }
        var legalFormScorer = new DictSearchScorer(thresholdMatch, thresholdCloseMatch, legalFormBound);
        var countryScorer = new DictSearchScorer(thresholdMatch, thresholdCloseMatch, countryBound);
        var acronymScorer = new AcronymScorer(thresholdMatch, acronymBound);
        var prefixScorer = new PrefixScorer(thresholdMatch, thresholdCloseMatch, prefixBound);
        var natureEntrepriseScorer = new DerivedScorer(NamePairProcessorType.NATURE_ENTERPRISE, thresholdMatch, thresholdCloseMatch, natureEntrepiseBound);

        Map<NamePairProcessorType, NamePairScorer> customScorers = new EnumMap<>(NamePairProcessorType.class);
        customScorers.put(NamePairProcessorType.LEGAL_FORM, legalFormScorer);
        customScorers.put(NamePairProcessorType.ACRONYMS, acronymScorer);
        customScorers.put(NamePairProcessorType.INVOICE_DISCOUNT, prefixScorer);
        customScorers.put(NamePairProcessorType.GEOGRAPHY, countryScorer);
        customScorers.put(NamePairProcessorType.NATURE_ENTERPRISE, natureEntrepriseScorer);

        return new RuleBasedNameMatchingProvider(processors, scorer, customScorers);
    }

    private DictSearchIndex getDictSearchIndexByThreshold(BigDecimal threshold, DictionaryType type) {
        //load data country from database
        List<DictionaryEntity> countryEntityList = this.countryRepository.findByType(type);
        var dictSearchIndexBuilder = new DictSearchIndexBuilder(threshold);
        //2. Mapping data Country Entity in DictSearchIndex
        countryEntityList.stream().forEach(countryEntity -> {
            DictEntrySet dictEntrySet = new DictEntrySet();
            dictEntrySet.setCountry(countryEntity.getCountry());
            dictEntrySet.setForms(countryEntity.getForms().stream().map(formEntity -> {
                DictEntry dictEntry = new DictEntry();
                dictEntry.setName(formEntity.getName());
                dictEntry.setSpellings(formEntity.getSpellings().stream().collect(Collectors.toSet()));
                return dictEntry;
            }).collect(Collectors.toSet()));
            dictSearchIndexBuilder.index(dictEntrySet);
        });
        return dictSearchIndexBuilder.build();
    }

}
