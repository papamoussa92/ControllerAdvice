package fr.sis.sisid.copuk.config;

import fr.sis.sisid.copuk.cop.core.rules.*;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import java.util.List;

@Configuration
public class RulesConfiguration {

    /**
     * Ordered list of business rules to execute. Each class must correspond to a single Spring bean
     *
     * @param context Spring context
     * @return the rule list containing all rules in order of execution
     */
    @Bean
    @Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
    public RulesList rules(ApplicationContext context) {
        return new RulesList(context,
                List.of(
                        NameMatchesRule.class, // names exactly match
                        AccountOptOutRule.class, // account opted out
                        AccountSwitchedRule.class, // account switched
                        ExternalNameMatchesRule.class, // names different but considered a match
                        AccountDetailIncorrectRule.class, // Account detail incorrect
                        SortCodeNotSupportedRule.class, // Sort code not supported
                        CloseMatchRule.class, // names are a close match
                        AccountNotFoundRule.class, // account not found
                        AccountTypeMismatchRule.class, // account type not compatible with the one requested
                        AccountTypeNotSupportedRule.class, // did not request a business account
                        DefaultRule.class // fallback rule
                ));
    }

}
