package fr.sis.sisid.copuk.namematching.processors.dictsearch;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Set;
import java.util.stream.Stream;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import fr.sis.sisid.copuk.namematching.processors.NamePairProcessorType;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.index.IndexTestTools;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.model.DictSearchProcessedNamePair;
import fr.sis.sisid.copuk.namematching.processors.model.NamePair;
import fr.sis.sisid.copuk.namematching.tools.StringTools;

class DictSearchProcessorImplTest {

    private static DictSearchProcessorImpl processor;

    @BeforeAll
    static void setup() throws IOException {
        var index = IndexTestTools.getIndex("legalforms/uk.json");
        processor = new DictSearchProcessorImpl(index, NamePairProcessorType.LEGAL_FORM, new BigDecimal("0.8"));
    }

    @ParameterizedTest
    @MethodSource("searchLegalFormTestArguments")
    void searchLegalFormTest(String input, String expectedQuery, boolean expectedFound) {
        var result = processor.searchEntry(StringTools.normalize(input));
        if(expectedFound) {
            Assertions.assertThat(result.get(0).getQuery()).isEqualTo(expectedQuery);
            Assertions.assertThat(result.get(0).isFound()).isEqualTo(expectedFound);
        } else {
            Assertions.assertThat(result).isEmpty();
        }
    }

    static Stream<Arguments> searchLegalFormTestArguments() {

        return Stream.of(
                Arguments.of("ARVAL LTD UK", "LTD", true),
                Arguments.of("ARVAL UK", null, false),
                Arguments.of("ARVAL UK LIMITED", "LIMITED", true),
                Arguments.of("ARVAL UK LTD", "LTD", true),
                Arguments.of("ARVAL UK RECEIPT", null, false),
                Arguments.of("ARVAL-U.K.-LIMITED", "LIMITED", true),
                Arguments.of("ARVAL-U.K.-LIMITED-PARTNERSHIP", "LIMITED PARTNERSHIP", true),
                Arguments.of("ARVAL U.K. LIMITED LIABILITY PARTNERSHIP", "LIMITED LIABILITY PARTNERSHIP", true));
    }


    @Test
    void searchMultipleLegalFormsTest() {
        var result = processor.searchEntry(StringTools.normalize("COGNITO PLC LIMITED"));
        Assertions.assertThat(result).hasSize(2);
        Assertions.assertThat(result.get(0).getQuery()).isIn("PLC", "LIMITED");
        Assertions.assertThat(result.get(1).getQuery()).isIn("PLC", "LIMITED");
    }

    @ParameterizedTest
    @MethodSource("processTestArguments")
    void processTest(NamePair input, Set<NamePair> expected) {
        Assertions.assertThat(processor.process(input)).containsExactlyInAnyOrderElementsOf(expected);
    }

    static Stream<Arguments> processTestArguments() {
        var first = new NamePair("ARVAL UK LIMITED", "ARVAL UK LTD");
        var second = new NamePair("ARVAL UK LIMITED", "ARVAL UK limited");
        var third = new NamePair("ARVAL UK LIMITED", "ARVAL UK");
        var fourth = new NamePair("ARVAL UK", "ARVAL UK LTD");
        var fifth = new NamePair("ARVAL UK", "ARVAL UK");
        var sixth = new NamePair("ARVAL UK LIMTED", "ARVAL UK LTD");
        var seventh = new NamePair("arval uk limited", "Arval UK Ltd");
        var eighth = new NamePair("ARVAL UK LLP", "ARVAL UK LTD");
        return Stream.of(Arguments.of(first, Set.of(
                first,
                new DictSearchProcessedNamePair(first.getInput(), "ARVAL UK", true),
                new DictSearchProcessedNamePair("ARVAL UK", first.getReference(), true),
                new DictSearchProcessedNamePair("ARVAL UK", "ARVAL UK", false))),
                Arguments.of(second, Set.of(
                        second,
                        new DictSearchProcessedNamePair(second.getInput(), "ARVAL UK", true),
                        new DictSearchProcessedNamePair("ARVAL UK", second.getReference(), true),
                        new DictSearchProcessedNamePair("ARVAL UK", "ARVAL UK", false))),
                Arguments.of(third, Set.of(
                        third,
                        new DictSearchProcessedNamePair("ARVAL UK", third.getReference(), true))),
                Arguments.of(fourth, Set.of(
                        fourth,
                        new DictSearchProcessedNamePair(fourth.getInput(), "ARVAL UK", true))),
                Arguments.of(fifth, Set.of(
                        fifth)),
                Arguments.of(sixth, Set.of(
                        sixth,
                        new DictSearchProcessedNamePair(sixth.getInput(), "ARVAL UK", true),
                        new DictSearchProcessedNamePair("ARVAL UK", sixth.getReference(), true),
                        new DictSearchProcessedNamePair("ARVAL UK", "ARVAL UK"))),
                Arguments.of(seventh, Set.of(
                        seventh,
                        new DictSearchProcessedNamePair(seventh.getInput(), "ARVAL UK", true),
                        new DictSearchProcessedNamePair("ARVAL UK", seventh.getReference(), true),
                        new DictSearchProcessedNamePair("ARVAL UK", "ARVAL UK"))),
                Arguments.of(eighth, Set.of(
                        eighth,
                        new DictSearchProcessedNamePair(eighth.getInput(), "ARVAL UK", true),
                        new DictSearchProcessedNamePair("ARVAL UK", eighth.getReference(), true),
                        new DictSearchProcessedNamePair("ARVAL UK", "ARVAL UK", true))));
    }
}
