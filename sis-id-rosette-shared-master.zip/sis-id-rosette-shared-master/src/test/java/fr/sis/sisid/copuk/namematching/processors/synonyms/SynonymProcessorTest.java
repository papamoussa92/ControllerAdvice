package fr.sis.sisid.copuk.namematching.processors.synonyms;

import fr.sis.sisid.copuk.namematching.model.CompanySynonyms;
import fr.sis.sisid.copuk.namematching.processors.model.NamePair;
import fr.sis.sisid.copuk.namematching.processors.synonym.SynonymProcessor;
import fr.sis.sisid.copuk.namematching.processors.synonym.SynonymRepo;
import org.junit.Assert;
import org.junit.jupiter.api.Test;

import java.util.Collection;
import java.util.List;
import java.util.Set;

class SynonymProcessorTest {

    @Test
    void processTest(){
        SynonymRepo synonymRepo = (Collection<String> inputFromBnp) -> List.of(new CompanySynonyms(1L,"accountName1", "accountTrading1"), new CompanySynonyms(1L,"accountName1", "accountTrading2"));
        SynonymProcessor synonymProcessor = new SynonymProcessor(synonymRepo);
        NamePair namePair = new NamePair("accountTrading1", "accountName1");
        Set<NamePair> excepted= Set.of(new NamePair("accountTrading1","accountTrading1"), new NamePair("accountTrading1","accountTrading2"));
        Assert.assertTrue(synonymProcessor.process(namePair).containsAll(excepted));
    }
}
