package fr.sis.sisid.copuk.namematching.processors.prefix;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.processors.model.NamePair;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

class PrefixScorerTest {


    @Test
    void testLowerBound() {
        PrefixScorer prefixScorer = new PrefixScorer(new BigDecimal("0.99"), new BigDecimal("0.67"), MatchingDecision.MATCH);
        NamePair np = new NamePair("IKO WHATEVER SOMETHING", "IKO PARTNERSHIP DIFFERENT");
        var result = prefixScorer.scoreNamePair(np, MatchingDecision.MATCH);
        assertEquals(MatchingDecision.CLOSE_MATCH, result.getDecision());
        assertThat(result.getScore()).isLessThan(new BigDecimal("0.67"));
    }

}