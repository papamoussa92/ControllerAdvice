package fr.sis.sisid.copuk.namematching.processors.prefix;

import fr.sis.sisid.copuk.namematching.processors.model.NamePair;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

class InvoiceDiscountAccountProcessorTest {

    @Test
    void invoiceAccount() {
        InvoiceDiscountAccount invoiceDiscountAccount = () -> List.of("ABC Invoicing Re", "BNPPCF RE");
        InvoiceDiscountAccountProcessor invoiceDiscountAccountProcessor = new InvoiceDiscountAccountProcessor(
                invoiceDiscountAccount);

        String nameAccountInverse = "XYZ Trading", namePayeeInverse = "ABC Invoicing Re XYZ Trading";
        String radicalInverse = "XYZ Trading";

        String payee = invoiceDiscountAccountProcessor.searchRadical(
                namePayeeInverse);
        String nameAccount = invoiceDiscountAccountProcessor.searchRadical(
                nameAccountInverse);
        Assertions.assertEquals(radicalInverse, payee);
        Assertions.assertEquals(radicalInverse, nameAccount);

        String nameAccount2 = "BNPPCF RE: AZELIS", namePayee2 = "AZELIS";
        String radicalInverse2 = "AZELIS";
        String payee2 = invoiceDiscountAccountProcessor.searchRadical(namePayee2);
        String nameAccountBnpp = invoiceDiscountAccountProcessor.searchRadical(nameAccount2);
        Assertions.assertEquals(radicalInverse2, payee2);
        Assertions.assertEquals(radicalInverse2, nameAccountBnpp);

    }

    @ParameterizedTest
    @MethodSource("searchPrefixes")
    void testMultiplePrefixes(String input, String reference, NamePair expectedInput) {

        InvoiceDiscountAccount invoiceDiscountAccount = () -> List.of(".+\s+RE");
        InvoiceDiscountAccountProcessor invoiceDiscountAccountProcessor = new InvoiceDiscountAccountProcessor(
                invoiceDiscountAccount);

        NamePair inputPair = new NamePair(input, reference);
        var resultSet = invoiceDiscountAccountProcessor.process(inputPair);
        var expected = Set.of(expectedInput);

        org.assertj.core.api.Assertions.assertThat(resultSet).containsExactlyInAnyOrderElementsOf(expected);
    }

    static Stream<Arguments> searchPrefixes() {

        return Stream.of(
                Arguments.of("GENIUS FOODS LTD", "BNP PARIBAS COMMERCIAL FINANCE LIMITED RE GENIUS FOODS LTD", new PrefixProcessedNamePair("GENIUS FOODS LTD", "GENIUS FOODS LTD")),
                Arguments.of("WHATEVER PROPERTY", "BNP PARIBAS RE WHATEVER PROPERTY", new PrefixProcessedNamePair("WHATEVER PROPERTY", "WHATEVER PROPERTY")),
                Arguments.of("WHATEVER PROPERTY", "BNP PARIBAS REAL ESTATE PROPERTY", new NamePair("WHATEVER PROPERTY", "BNP PARIBAS REAL ESTATE PROPERTY")),
                Arguments.of("EXCELLENT PRESENTS", "EXCELLENT PRESENTS", new NamePair("EXCELLENT PRESENTS", "EXCELLENT PRESENTS"))
        );
    }

}
