package fr.sis.sisid.copuk.namematching.processors.acronyms;

import fr.sis.sisid.copuk.namematching.processors.model.NamePair;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;

class AcronymProcessorTest {

    AcronymProcessor processor = new AcronymProcessor();

    @Test
    void testDeriveNullAcronyms() {
        var result = processor.deriveAcronyms(null);
        assertEquals(0, result.size());
    }

    @Test
    void testDeriveEmptyAcronyms() {
        var result = processor.deriveAcronyms("");
        assertEquals(0, result.size());
    }

    private static Stream<Arguments> inputCases() {
        return Stream.of(
                Arguments.of("Company", List.of()),
                Arguments.of("Fantastic Company", List.of()),
                Arguments.of("Fantastic Incredible Company",
                        List.of(new AcronymResult("FIC", ""))),
                Arguments.of("Fantastic Incredible Monstruous Company",
                        List.of(new AcronymResult("FIM", "Company"),
                                new AcronymResult("FIMC", ""))),
                Arguments.of("Fantastic Incredible Monstruous Extreme Company",
                        List.of(new AcronymResult("FIM", "Extreme Company"), new AcronymResult("FIME", "Company"))));
    }

    @ParameterizedTest
    @MethodSource("inputCases")
    void testDeriveWordAcronyms(String input, List<AcronymResult> expected) {
        var result = processor.deriveAcronyms(input);
        assertEquals(expected, result);
    }

    @Test
    void testProcess() {
        NamePair input = new NamePair("FIC", "Fantastic Incredible Company");
        var expected = Stream.of(new AcronymNamePair(new AcronymResult("", "FIC"), "FIC"), input)
                .collect(Collectors.toSet());
        Assertions.assertThat(processor.process(input)).containsAnyElementsOf(expected);
    }

    @Test
    void testProcessAcronymFormats() {
        NamePair input = new NamePair("EMD MUSIC SA", "E.M.D. MUSIC SA");
        var expected = Stream.of(
                        new AcronymNamePair(new AcronymResult("", "EMD MUSIC SA"), "EMD MUSIC SA"),
                        input)
                .collect(Collectors.toSet());
        Set<NamePair> result = processor.process(input);
        Assertions.assertThat(result).containsAnyElementsOf(expected);
    }

    @Test
    void testProcessAcronymComposite() {
        NamePair input = new NamePair("EMD MUSIC SA", "EVENTUELLEMENT METTRE DIMANCHE MUSIC SA");
        var expected = Stream.of(
                        new AcronymNamePair( new AcronymResult("EMD", "MUSIC SA"),"EMD MUSIC SA"))
                .collect(Collectors.toSet());
        Set<NamePair> result = processor.process(input);
        Assertions.assertThat(result).containsAll(expected);
    }

    @Test
    void testProcessAcronymwWithSpacing() {
        NamePair input = new NamePair("EMD MUSIC SA", "E M D MUSIC SA");
        var expected = Stream.of(
                        input)
                .collect(Collectors.toSet());
        Set<NamePair> result = processor.process(input);
        Assertions.assertThat(result).containsAnyElementsOf(expected);
    }


    @Test
    void testProcess_nullInput() {
        Assertions.assertThat(processor.process(null)).isEmpty();
        NamePair input = new NamePair("FIC", null);
        Assertions.assertThat(processor.process(input)).isEmpty();
        input = new NamePair(null, "Fantastic Incredible Company");
        Assertions.assertThat(processor.process(input)).isEmpty();
    }

}