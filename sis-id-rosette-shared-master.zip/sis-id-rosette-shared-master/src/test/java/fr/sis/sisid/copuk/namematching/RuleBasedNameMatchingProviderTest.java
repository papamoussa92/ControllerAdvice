package fr.sis.sisid.copuk.namematching;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.processors.NamePairProcessor;
import fr.sis.sisid.copuk.namematching.processors.NamePairProcessorType;
import fr.sis.sisid.copuk.namematching.processors.acronyms.AcronymProcessor;
import fr.sis.sisid.copuk.namematching.processors.acronyms.AcronymScorer;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.DictSearchProcessorImpl;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.DictSearchScorer;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.index.DictSearchIndex;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.index.DictSearchIndexBuilder;
import fr.sis.sisid.copuk.namematching.processors.prefix.InvoiceDiscountAccount;
import fr.sis.sisid.copuk.namematching.processors.prefix.InvoiceDiscountAccountProcessor;
import fr.sis.sisid.copuk.namematching.processors.prefix.PrefixScorer;
import fr.sis.sisid.copuk.namematching.processors.structuredinput.StructuredInputProcessor;
import fr.sis.sisid.copuk.namematching.scorer.FuzzyScorer;
import fr.sis.sisid.copuk.namematching.scorer.NamePairScorer;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.core.io.ClassPathResource;
import reactor.test.StepVerifier;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.EnumMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

class RuleBasedNameMatchingProviderTest {

    private final BigDecimal MATCH_THRESHOLD = BigDecimal.valueOf(0.92d);
    private final BigDecimal CLOSE_MATCH_THRESHOLD = BigDecimal.valueOf(0.6d);

    NameMatchingProvider nameMatching;

    @BeforeEach
    public void setup() throws IOException {
        var scorer = new FuzzyScorer(MATCH_THRESHOLD, CLOSE_MATCH_THRESHOLD);
        LinkedList<NamePairProcessor> processors = new LinkedList<>();
        // structured input
        StructuredInputProcessor structuredInputProcessor = new StructuredInputProcessor();
        processors.addLast(structuredInputProcessor);
        // Nature enterprise
        DictSearchIndex natureEnterpriseIndex = new DictSearchIndexBuilder(MATCH_THRESHOLD)
                .index(new ClassPathResource("natures/natures.json")).build();
        processors.addLast(new DictSearchProcessorImpl(natureEnterpriseIndex,
                NamePairProcessorType.NATURE_ENTERPRISE, MATCH_THRESHOLD));

        //
        InvoiceDiscountAccount invoiceDiscountAccount = () -> List.of(".+\\s+RE");
        processors.addLast(new InvoiceDiscountAccountProcessor(invoiceDiscountAccount));
        // legal form
        BigDecimal legalFormThreshold = BigDecimal.valueOf(0.85d);
        DictSearchIndex dictSearchIndex = new DictSearchIndexBuilder(legalFormThreshold)
                .index(new ClassPathResource("legalforms/be.json"))
                .index(new ClassPathResource("legalforms/de.json"))
                .index(new ClassPathResource("legalforms/eu.json"))
                .index(new ClassPathResource("legalforms/fr.json"))
                .index(new ClassPathResource("legalforms/nl.json"))
                .index(new ClassPathResource("legalforms/no.json"))
                .index(new ClassPathResource("legalforms/pl.json"))
                .index(new ClassPathResource("legalforms/se.json"))
                .index(new ClassPathResource("legalforms/uk.json"))
                .index(new ClassPathResource("legalforms/us.json"))
                .build();
        DictSearchProcessorImpl legalFormProcessor = new DictSearchProcessorImpl(dictSearchIndex,
                NamePairProcessorType.LEGAL_FORM, legalFormThreshold);
        processors.addLast(legalFormProcessor);

        // geography
        BigDecimal geographyThreshold = BigDecimal.valueOf(0.85d);
        DictSearchIndex geographyIndex = new DictSearchIndexBuilder(geographyThreshold)
                .index(new ClassPathResource("countries/countries.json")).build();
        DictSearchProcessorImpl geographyProcessor = new DictSearchProcessorImpl(geographyIndex,
                NamePairProcessorType.GEOGRAPHY, geographyThreshold);
        processors.addLast(geographyProcessor);

        // acronyms
        processors.addLast(new AcronymProcessor());

        Map<NamePairProcessorType, NamePairScorer> customScorers = new EnumMap<>(NamePairProcessorType.class);
        customScorers.put(NamePairProcessorType.LEGAL_FORM,
                new DictSearchScorer(MATCH_THRESHOLD, CLOSE_MATCH_THRESHOLD, MatchingDecision.CLOSE_MATCH));
        customScorers.put(NamePairProcessorType.GEOGRAPHY,
                new DictSearchScorer(MATCH_THRESHOLD, CLOSE_MATCH_THRESHOLD, MatchingDecision.CLOSE_MATCH));
        customScorers.put(NamePairProcessorType.ACRONYMS,
                new AcronymScorer(MATCH_THRESHOLD, CLOSE_MATCH_THRESHOLD, MatchingDecision.CLOSE_MATCH));
        customScorers.put(NamePairProcessorType.INVOICE_DISCOUNT,
                new PrefixScorer(MATCH_THRESHOLD, CLOSE_MATCH_THRESHOLD, MatchingDecision.CLOSE_MATCH));
        customScorers.put(NamePairProcessorType.NATURE_ENTERPRISE,
                new DictSearchScorer(MATCH_THRESHOLD, CLOSE_MATCH_THRESHOLD, MatchingDecision.CLOSE_MATCH));

        nameMatching = new RuleBasedNameMatchingProvider(processors, scorer, customScorers);
    }

    @ParameterizedTest
    @MethodSource("testNameMatchesArguments")
    void testNameMatches(String input, String reference, MatchingDecision expectedResult) {
        StepVerifier.create(this.nameMatching.nameMatch(input, reference))
                .assertNext(res -> Assertions.assertThat(res.getScore().getDecision()).isEqualTo(expectedResult))
                .expectComplete()
                .verify();
    }

    @ParameterizedTest
    @MethodSource("testgetNameArguments")
    void getProcessedAccountNameTest(String nameAccount, NamePairProcessorType namePairProcessorType, String result) {
        Assertions.assertThat(this.nameMatching.getProcessedAccountName(nameAccount, namePairProcessorType))
                .isEqualTo(result);
    }

    static Stream<Arguments> testNameMatchesArguments() {
        return Stream.of(
                Arguments.of("stérling, cooper draper pryce",
                        "Sterling Cooper Draper Pryce",
                        MatchingDecision.MATCH),
                Arguments.of("..sterling cooper, draper pryce ",
                        "Sterling Cooper Draper Pryce ",
                        MatchingDecision.MATCH),
                Arguments.of("sterling cooper draper pryce",
                        "Sterling Cooper Draper Pryce Limited Partnership",
                        MatchingDecision.CLOSE_MATCH),
                Arguments.of("SCDP",
                        "Sterling Cooper Draper Pryce",
                        MatchingDecision.CLOSE_MATCH),
                Arguments.of("SCDP lp",
                        "Sterling Cooper Draper Pryce Limited Partnership",
                        MatchingDecision.CLOSE_MATCH),
                Arguments.of(",,SCDP lp",
                        "Sterling Cooper Draper Pryce Limited Partnership",
                        MatchingDecision.CLOSE_MATCH),
                Arguments.of("abcdef", "ghijkl", MatchingDecision.NO_MATCH),
                Arguments.of("abcdef", "abcd12", MatchingDecision.CLOSE_MATCH),
                Arguments.of("abcdef", "abcde1", MatchingDecision.CLOSE_MATCH),
                Arguments.of("sterling cooper", "Sterling Cooper Draper Pryce", MatchingDecision.CLOSE_MATCH),
                Arguments.of("McCann Erickson", "Sterling Cooper Draper Pryce", MatchingDecision.NO_MATCH),
                Arguments.of("SCD", "Sterling Cooper Draper Pryce", MatchingDecision.NO_MATCH),
                Arguments.of("MCE", "Sterling Cooper Draper Pryce", MatchingDecision.NO_MATCH),
                Arguments.of("BMW", "Bayerische Motoren Werke Aktiengesellschaft", MatchingDecision.CLOSE_MATCH),
                Arguments.of("BMW AG", "Bayerische Motoren Werke Aktiengesellschaft", MatchingDecision.CLOSE_MATCH),
                Arguments.of("BMW GmbH", "Bayerische Motoren Werke Aktiengesellschaft", MatchingDecision.CLOSE_MATCH),
                Arguments.of("Bayerische Motor", "Bayerische Motoren Werke Aktiengesellschaft",
                        MatchingDecision.CLOSE_MATCH),
                Arguments.of(",,Bayerische Motor", "Bayerische Motoren Werke Aktiengesellschaft",
                        MatchingDecision.CLOSE_MATCH),
                Arguments.of("Volkswagen GMBH", "Bayerische Motoren Werke Aktiengesellschaft",
                        MatchingDecision.NO_MATCH),
                Arguments.of("VW AG", "Bayerische Motoren Werke Aktiengesellschaft", MatchingDecision.NO_MATCH),
                Arguments.of("Mr,John,Smith", "Mr John Smith", MatchingDecision.MATCH),
                Arguments.of("ACME", "ACME ZZ", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME Limited", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME ltd", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME PLC", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME LLP", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME GMBH", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME LLC", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME NV", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME BV", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME SA", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME SP ZOO", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME AB", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME AB (publ)", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME Inc", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME SARL", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME SPRL", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME SPC", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME AS", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME SRL", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME AG", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME GMBH & CO.KG", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME BVBA", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME SICAV", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME SAS", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME SPA", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME SE", MatchingDecision.CLOSE_MATCH),
                Arguments.of("Fortis Technology", "Fortis", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ABC Invoicing Re: XYZ Trading", "XYZ Trading", MatchingDecision.CLOSE_MATCH),
                Arguments.of("BNPPCF RE: AZELIS", "AZELIS UK LIMITED", MatchingDecision.CLOSE_MATCH),
                Arguments.of("BNPPCF RE: AZELIS UK LIMITED", "AZELIS UK LTD", MatchingDecision.CLOSE_MATCH),
                Arguments.of("BNPPCF RE: AZELIS", "AZELIS", MatchingDecision.CLOSE_MATCH),
                Arguments.of("XYZ Trading", "ABC Invoicing Re XYZ Trading", MatchingDecision.CLOSE_MATCH),
                Arguments.of("acme limited", "Acme Ltd", MatchingDecision.MATCH),
                Arguments.of("ACME", "ACME UK LTD", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME UK", "ACME UK LTD", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME limited", "ACME UK LTD", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME GB", "ACME UK LTD", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME GBR", "ACME UK LTD", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME GB", "ACME", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME GBR", "ACME", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME FR", "ACME UK", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME", "ACME UK", MatchingDecision.CLOSE_MATCH),
                Arguments.of("ACME LIMITED GBR", "ACME UK LTD", MatchingDecision.CLOSE_MATCH),
                Arguments.of("IKO PLC", "PARTNERSHIPS PLC", MatchingDecision.NO_MATCH),
                Arguments.of("CERATIZIT UK & IRELAND LLP", "CERATIZIT UK & IRELAND CO", MatchingDecision.CLOSE_MATCH),
                Arguments.of("CERATIZIT UK & IRELAND CO", "CERATIZIT UK & IRELAND LLP", MatchingDecision.CLOSE_MATCH),
                Arguments.of("CERATIZIT CO", "CERATIZIT LLP", MatchingDecision.CLOSE_MATCH),
                Arguments.of("E.M.D. MUSIC SA", "EVENTUELLEMENT METTRE DIMANCHE MUSIC SA", MatchingDecision.CLOSE_MATCH),
                Arguments.of("E.M.D. MUSIC SA", "EVENTUELLEMENT METTRE SAMEDI MUSIC SA", MatchingDecision.NO_MATCH),
                Arguments.of("E.M.D. MUSIC SA", "EMD MUSIC SA", MatchingDecision.MATCH),
                Arguments.of("ELI LILLY AND COMPANY LIMITED", "ELI LILLY AND CO LTD", MatchingDecision.MATCH),
                Arguments.of("ELI LILLY AND COMPANY LIMITED", "ELI LILLY & CO LTD", MatchingDecision.MATCH),
                Arguments.of("COLT TECHNOLOGY SERVICES", "COLT", MatchingDecision.CLOSE_MATCH)
                );
    }

    static Stream<Arguments> testgetNameArguments() {
        return Stream.of(
                Arguments.of("ABC Invoicing Re XYZ Trading", NamePairProcessorType.INVOICE_DISCOUNT, "XYZ Trading"),
                Arguments.of("ABC Invoicing Re XYZ Trading", NamePairProcessorType.LEGAL_FORM,
                        "XYZ Trading"),
                Arguments.of("ABC Invoicing Re XYZ Trading", NamePairProcessorType.NATURE_ENTERPRISE,
                        "ABC Invoicing Re XYZ Trading"),
                Arguments.of("ABC Invoicing Re XYZ Trading", NamePairProcessorType.ACRONYMS,
                        "XYZ Trading"),
                Arguments.of("ABC Invoicing Re XYZ Trading", NamePairProcessorType.STRUCTURED_INPUT,
                        "ABC Invoicing Re XYZ Trading"));
    }

}
