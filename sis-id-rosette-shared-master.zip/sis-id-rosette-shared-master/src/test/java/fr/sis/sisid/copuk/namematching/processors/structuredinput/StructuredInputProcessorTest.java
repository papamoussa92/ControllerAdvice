package fr.sis.sisid.copuk.namematching.processors.structuredinput;

import java.util.Collections;
import java.util.Set;
import java.util.stream.Stream;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import fr.sis.sisid.copuk.namematching.processors.model.NamePair;

class StructuredInputProcessorTest {

    @ParameterizedTest
    @MethodSource("testProcessArguments")
    void testProcess(NamePair input, Set<NamePair> expected) {
        var processor = new StructuredInputProcessor();
        Assertions.assertThat(processor.process(input)).isEqualTo(expected);
    }

    static Stream<Arguments> testProcessArguments() {
        return Stream.of(
                Arguments.of(new NamePair("Mr,John,Smith", "Mr John Smith"),
                        Collections.singleton(new NamePair("Mr John Smith", "Mr John Smith"))),
                Arguments.of(new NamePair(",,Mr John Smith", "Mr John Smith"),
                        Collections.singleton(new NamePair("Mr John Smith", "Mr John Smith"))),
                Arguments.of(new NamePair("Mr John Smith", "Mr John Smith"),
                        Collections.singleton(new NamePair("Mr John Smith", "Mr John Smith"))),
                Arguments.of(new NamePair("", "Mr John Smith"),
                        Collections.singleton(new NamePair("", "Mr John Smith"))),
                Arguments.of(new NamePair(null, "Mr John Smith"),
                        Collections.singleton(new NamePair("", "Mr John Smith")))

        );
    }

}
