package fr.sis.sisid.copuk.namematching;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeAll;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.testcontainers.containers.MockServerContainer;
import org.testcontainers.containers.wait.strategy.Wait;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;

@Testcontainers
@Slf4j
public class RosetteMockContainer {



    public static MockServerContainer initContainer() {

        MockServerContainer rosetteMockServer = new MockServerContainer(
                DockerImageName
                        .parse("mockserver/mockserver:5.13.2"))
                .waitingFor(Wait.forListeningPort());
        rosetteMockServer.start();
        return rosetteMockServer;
    }

}
