package fr.sis.sisid.copuk.namematching.tools;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class StringToolsTest {

    @Test
    void ngramTokensTokensTest() {
        List<String> input = Arrays.asList("bnp", "paribas", "commercial", "finance");
        List<String> expected = Stream.of(
                "paribas commercial finance",
                "bnp paribas commercial",
                "commercial finance",
                "paribas commercial",
                "bnp paribas",
                "commercial",
                "finance",
                "paribas",
                "bnp")
                .toList();

        Assertions.assertThat(StringTools.ngramTokens(input))
                .isEqualTo(expected);
    }

    @Test
    void removeDistinctWordIgnoreCase() {
        String input = "VF NORTHERN EUROPE LIMITED";
        String toRemove = "limited";
        Assertions.assertThat(StringTools.removeDistinctWordIgnoreCase(input, toRemove))
                .isEqualTo("VF NORTHERN EUROPE");
        input = "OFFICE DEPOT INTERNATIONAL (UK)";
        toRemove = "international";
        Assertions.assertThat(StringTools.removeDistinctWordIgnoreCase(input, toRemove))
                .isEqualTo("OFFICE DEPOT (UK)");
    }

    @Test
    void normalizedLvhTest() {
        Assertions.assertThat(StringTools.normalizedLvh("abcd", "acd"))
                .isEqualTo(BigDecimal.valueOf(0.25));
    }

    @Test
    void testNormalize() {
       assertEquals("COLT TECH SERVICES",StringTools.normalize(" COLT  TECH    Services "));
    }

    @Test
    void testNormalizeAggregateAcronyms() {
        assertEquals("COLT TBS MAIN",StringTools.normalize("COLT T B S MAIN"));
    }

    @Test
    void testreg() {
        assertEquals("EMD MUSIC SA", StringTools.convertSpacedAcronyms("E M D MUSIC SA"));
        assertEquals("EMDC MUSIC SA", StringTools.convertSpacedAcronyms("E M D C MUSIC SA"));
        assertEquals("EM MUSIC SA", StringTools.convertSpacedAcronyms("E M MUSIC SA"));
        assertEquals("E MUSIC SA", StringTools.convertSpacedAcronyms("E MUSIC SA"));

        assertEquals("SUPER EMD MUSIC SA", StringTools.convertSpacedAcronyms("SUPER E M D MUSIC SA"));
        assertEquals("SUPER EMDC MUSIC SA", StringTools.convertSpacedAcronyms("SUPER E M D C MUSIC SA"));
        assertEquals("SUPER EM MUSIC SA", StringTools.convertSpacedAcronyms("SUPER E M MUSIC SA"));
        assertEquals("SUPER E MUSIC SA", StringTools.convertSpacedAcronyms("SUPER E MUSIC SA"));

        assertEquals("EMD", StringTools.convertSpacedAcronyms("E M D"));
        assertEquals("EMDC", StringTools.convertSpacedAcronyms("E M D C"));
        assertEquals("EM", StringTools.convertSpacedAcronyms("E M"));
        assertEquals("E", StringTools.convertSpacedAcronyms("E"));

    }

    @Test
    void testTokenize() {
        assertEquals(List.of(), StringTools.tokenize(null));
        assertEquals(List.of(), StringTools.tokenize(""));
        assertEquals(List.of("WORD"), StringTools.tokenize("WORD"));
        assertEquals(List.of("WORD", "TWO"), StringTools.tokenize("WORD TWO"));
        assertEquals(List.of("WORD", "AND", "ANOTHER"), StringTools.tokenize("WORD\tAND\nANOTHER"));
    }

}
