package fr.sis.sisid.copuk.namematching;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.Reader;
import java.io.Writer;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.time.temporal.ChronoUnit;

import javax.validation.constraints.NotNull;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockserver.client.MockServerClient;
import org.mockserver.model.HttpRequest;
import org.mockserver.model.HttpResponse;
import org.mockserver.model.JsonPathBody;
import org.mockserver.model.MediaType;
import org.slf4j.event.Level;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import org.testcontainers.containers.MockServerContainer;

import com.opencsv.CSVWriter;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;

import fr.sis.sisid.copuk.namematching.model.MatchingResult;
import fr.sis.sisid.copuk.namematching.optimizer.MatchingCase;
import fr.sis.sisid.copuk.namematching.rosette.RosetteNameMatchingException;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.test.StepVerifier;

@Slf4j
public class RosetteNameMatchingProviderIT extends RosetteMockContainer {

    BigDecimal thresholdMatch = new BigDecimal("0.8");
    BigDecimal thresholdCloseMatch = new BigDecimal("0.6");

    String mockserverAddress;

    ClientHttpConnector httpConnector;

    static MockServerContainer rosetteMockServer;
    MockServerClient rosetteMockClient;

    RosetteNameMatchingProvider rosetteNameMatchingProvider;

    private final NameMatchingProviderTestTools testTools = new NameMatchingProviderTestTools();

    private final int throttleSeconds = 0;

    @BeforeAll
    public static void initStatic() {
        rosetteMockServer = RosetteMockContainer.initContainer();
    }

    @BeforeEach
    public void init() {

        mockserverAddress = rosetteMockServer.getHost() + ":" + rosetteMockServer.getServerPort();

        rosetteMockClient = mockServerClient(rosetteMockServer.getHost(), rosetteMockServer.getServerPort());

        mockSuccessfulRosette(rosetteMockClient);

        HttpClient httpClient = HttpClient.create();
        httpConnector = new ReactorClientHttpConnector(httpClient);

        WebClient webClient = WebClient.builder().clientConnector(httpConnector).build();
        rosetteNameMatchingProvider = new RosetteNameMatchingProvider(mockserverAddress + "/rest/v1/name-similarity",
                webClient, thresholdMatch, thresholdCloseMatch);
    }

    @Test
    void testBNPMatchingCases() throws Exception {
        Reader reader = Files.newBufferedReader(
                Path.of(new ClassPathResource("BNP_test_cases_limited.csv").getURI().getPath()));
        Writer writer = Files.newBufferedWriter(Path.of("./target/bnp_test_results_opt.csv"));
        final StatefulBeanToCsv<MatchingCase> beanToCsv = new StatefulBeanToCsvBuilder<MatchingCase>(
                writer).withSeparator(CSVWriter.DEFAULT_SEPARATOR).build();

        var cases = testTools.readCases(reader);
        var results = cases.map(matchingCase -> queryMatching(matchingCase).delayElement(
                Duration.of(throttleSeconds, ChronoUnit.SECONDS))
                .map(matchingResponse -> testTools.applyResult(matchingCase, matchingResponse))
                .map(testTools.writeData(beanToCsv, writer)).block()

        ).toList();

        assertEquals(2, results.size());
        assertEquals(new BigDecimal("0.7"), results.get(0).getMatchingRate());
        assertEquals("CLOSE_MATCH", results.get(0).getResult());
        assertEquals(new BigDecimal("0.4"), results.get(1).getMatchingRate());
        assertEquals("NO_MATCH", results.get(1).getResult());
        testTools.closeIO(reader, writer);

    }

    @Test
    void testRosetteServiceUnavailable() {
        WebClient webClient = WebClient.builder().clientConnector(httpConnector).build();
        var nameMatchingProvider = new RosetteNameMatchingProvider(mockserverAddress + "/invalidurl", webClient,
                thresholdMatch, thresholdCloseMatch);

        Mono<MatchingResult> result = nameMatchingProvider.nameMatch("test 1", "test2");

        StepVerifier.create(result).expectError(RosetteNameMatchingException.class).verify();

    }

    @NotNull
    private Mono<MatchingResult> queryMatching(@NotNull MatchingCase matchingCase) {
        return rosetteNameMatchingProvider.nameMatch(matchingCase.getRefName(), matchingCase.getNameReceived());
    }

    public void mockSuccessfulRosette(MockServerClient mockServerClient) {
        mockServerClient.reset();
        mockServerClient.when(HttpRequest.request("/rest/v1/name-similarity").withMethod("POST")
                .withBody(JsonPathBody.jsonPath("$[?(@.name1=~ /CEVA.*?/i)]"))).respond(HttpResponse.response("""
                        {
                            "score": "0.7"
                        }
                        """).withStatusCode(200).withContentType(MediaType.APPLICATION_JSON));

        mockServerClient.when(HttpRequest.request("/rest/v1/name-similarity").withMethod("POST")
                .withBody(JsonPathBody.jsonPath("$[?(@.name1=~ /ARVAL.*?/i)]"))).respond(HttpResponse.response("""
                        {
                            "score": "0.4"
                        }
                        """).withStatusCode(200).withContentType(MediaType.APPLICATION_JSON));
    }

    public MockServerClient mockServerClient(String mockServerIp, int mockServerPort) {
        log.debug("setting up a mockServerClient");
        org.mockserver.configuration.Configuration mockserverClientConfig = org.mockserver.configuration.Configuration
                .configuration()
                .logLevel(Level.INFO);
        return new MockServerClient(mockserverClientConfig, mockServerIp, mockServerPort).withSecure(true);
    }

}
