package fr.sis.sisid.copuk.namematching.processors.acronyms;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AcronymResultTest {

    @Test
    void getText() {
        assertEquals("" , new AcronymResult().getText());
        assertEquals("AMC" , new AcronymResult("AMC", null).getText());
        assertEquals("AMC" , new AcronymResult("AMC", "").getText());
        assertEquals("INSPIRING COMPANY LTD" , new AcronymResult(null, "INSPIRING COMPANY LTD").getText());
        assertEquals("INSPIRING COMPANY LTD" , new AcronymResult("", "INSPIRING COMPANY LTD").getText());

        assertEquals("AMC INSPIRING COMPANY LTD" , new AcronymResult("AMC", "INSPIRING COMPANY LTD").getText());
    }

}