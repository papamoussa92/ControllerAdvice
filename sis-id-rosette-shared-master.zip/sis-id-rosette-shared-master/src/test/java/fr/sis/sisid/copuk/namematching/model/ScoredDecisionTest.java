package fr.sis.sisid.copuk.namematching.model;

import java.math.BigDecimal;
import java.util.stream.Stream;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import fr.sis.sisid.copuk.namematching.scorer.ScoredDecision;

class ScoredDecisionTest {

    @ParameterizedTest
    @MethodSource("compareToTestParams")
    void compareToTest(ScoredDecision a, ScoredDecision b, boolean isPositive) {
        if (isPositive) {
            Assertions.assertThat(a).isGreaterThan(b);
        } else {
            Assertions.assertThat(a).isLessThan(b);
        }
    }

    static Stream<Arguments> compareToTestParams() {
        return Stream.of(
                Arguments.of(
                        new ScoredDecision(BigDecimal.valueOf(0.6), MatchingDecision.MATCH),
                        null,
                        true),
                Arguments.of(
                        new ScoredDecision(BigDecimal.valueOf(0.6), MatchingDecision.MATCH),
                        new ScoredDecision(BigDecimal.ONE, MatchingDecision.NO_MATCH),
                        true),
                Arguments.of(
                        new ScoredDecision(BigDecimal.valueOf(0.6), MatchingDecision.NO_MATCH),
                        new ScoredDecision(BigDecimal.ONE, MatchingDecision.MATCH),
                        false),
                Arguments.of(
                        new ScoredDecision(BigDecimal.valueOf(0.6), MatchingDecision.MATCH),
                        new ScoredDecision(BigDecimal.ONE, MatchingDecision.CLOSE_MATCH),
                        true),
                Arguments.of(
                        new ScoredDecision(BigDecimal.valueOf(0.6), MatchingDecision.CLOSE_MATCH),
                        new ScoredDecision(BigDecimal.ONE, MatchingDecision.MATCH),
                        false),
                Arguments.of(
                        new ScoredDecision(BigDecimal.valueOf(0.6), MatchingDecision.MATCH),
                        new ScoredDecision(BigDecimal.ONE, MatchingDecision.NO_MATCH),
                        true),
                Arguments.of(
                        new ScoredDecision(BigDecimal.valueOf(0.6), MatchingDecision.NO_MATCH),
                        new ScoredDecision(BigDecimal.ONE, MatchingDecision.MATCH),
                        false),
                Arguments.of(
                        new ScoredDecision(BigDecimal.valueOf(0.6), MatchingDecision.CLOSE_MATCH),
                        new ScoredDecision(BigDecimal.ONE, MatchingDecision.NO_MATCH),
                        true),
                Arguments.of(
                        new ScoredDecision(BigDecimal.valueOf(0.6), MatchingDecision.NO_MATCH),
                        new ScoredDecision(BigDecimal.ONE, MatchingDecision.CLOSE_MATCH),
                        false),
                Arguments.of(
                        new ScoredDecision(BigDecimal.valueOf(0.6), MatchingDecision.NO_MATCH),
                        new ScoredDecision(BigDecimal.valueOf(0.2), MatchingDecision.NO_MATCH),
                        true),
                Arguments.of(
                        new ScoredDecision(BigDecimal.valueOf(0.1), MatchingDecision.MATCH),
                        new ScoredDecision(BigDecimal.valueOf(0.2), MatchingDecision.MATCH),
                        false));
    }
}
