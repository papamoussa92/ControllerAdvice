package fr.sis.sisid.copuk.namematching.processors.dictsearch.index;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Stream;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import fr.sis.sisid.copuk.namematching.processors.dictsearch.index.DictSearchResult;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.model.DictEntry;

class DictSearchResultTest {

    @ParameterizedTest
    @MethodSource("testCompareToArguments")
    void testCompareTo(DictSearchResult a, DictSearchResult b, int expected) {
        Assertions.assertThat(a.compareTo(b)).isEqualTo(expected);
    }

    static Stream<Arguments> testCompareToArguments() {
        return Stream.of(
                Arguments.of(
                        new DictSearchResult(false, "query a", Set.of(), Optional.empty()),
                        new DictSearchResult(false, "query b", Set.of(), Optional.empty()),
                        0),
                Arguments.of(
                        new DictSearchResult(true, "query a", Set.of(new DictEntry()),
                                Optional.of(BigDecimal.valueOf(0.5))),
                        new DictSearchResult(false, "query b", Set.of(), Optional.empty()),
                        1),
                Arguments.of(
                        new DictSearchResult(false, "query a", Set.of(), Optional.empty()),
                        new DictSearchResult(true, "query b", Set.of(new DictEntry()),
                                Optional.of(BigDecimal.valueOf(0.5))),
                        -1),
                Arguments.of(
                        new DictSearchResult(true, "query a", Set.of(new DictEntry()),
                                Optional.of(BigDecimal.valueOf(0.4))),
                        new DictSearchResult(true, "query b", Set.of(new DictEntry()),
                                Optional.of(BigDecimal.valueOf(0.6))),
                        -1));
    }

}
