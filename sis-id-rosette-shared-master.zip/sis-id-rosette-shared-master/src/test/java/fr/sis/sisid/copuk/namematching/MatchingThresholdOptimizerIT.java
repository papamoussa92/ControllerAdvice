package fr.sis.sisid.copuk.namematching;

import com.opencsv.CSVWriter;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;
import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.model.MatchingResult;
import fr.sis.sisid.copuk.namematching.optimizer.CostFunction;
import fr.sis.sisid.copuk.namematching.optimizer.MatchingCase;
import fr.sis.sisid.copuk.namematching.optimizer.MatchingThresholdOptimizer;
import fr.sis.sisid.copuk.namematching.optimizer.OptimizationResult;
import fr.sis.sisid.copuk.namematching.optimizer.Scenario1;
import fr.sis.sisid.copuk.namematching.optimizer.Scenario2;
import fr.sis.sisid.copuk.namematching.optimizer.Scenario3;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

import javax.validation.constraints.NotNull;
import java.io.IOException;
import java.io.Writer;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

@Slf4j
class MatchingThresholdOptimizerIT {

    private static Writer writer;
    private static StatefulBeanToCsv<OptimizationResult> beanToCsv;

    @BeforeAll
    static void init() throws IOException {
        writer = Files.newBufferedWriter(Path.of("./target/full_report.csv"));
        beanToCsv = new StatefulBeanToCsvBuilder<OptimizationResult>(
                writer).withSeparator(
                        CSVWriter.DEFAULT_SEPARATOR)
                .withOrderedResults(true)
                .build();
    }

    @AfterAll
    static void close() throws IOException {
        writer.close();
    }

    @ParameterizedTest
    //@ValueSource(strings = { "./bnp_full_rules_20220929_fixed.csv" })
    @ValueSource(strings = { "./bnp_expected_10p.csv" })
    void optimizeMapReduce(String path) throws IOException {
        log.info("optimization based on test file: {}", path);
        MatchingThresholdOptimizer optimizer = new MatchingThresholdOptimizer();

        List<OptimizationResult> results = optimizer.optimizeMapReduce(path, List.of(new Scenario3()));

        assertEquals(1, results.size());
        Assertions.assertNotNull(results.get(0));

        results.forEach(result -> writeData(path, result));

        assertThat(results.get(0).getSuccessRatio()).isGreaterThan(new BigDecimal("0.95"));

    }

    @NotNull
    private void writeData(String path, OptimizationResult result) {

        try {
            result.setDescription(path);
            beanToCsv.write(result);
            writer.flush();
        } catch (CsvDataTypeMismatchException | CsvRequiredFieldEmptyException | IOException e) {
            throw new RuntimeException(e);
        }
    }

    @ParameterizedTest
    @MethodSource("scenarioCases")
    void testScenarios(CostFunction scenario, String expected, BigDecimal score, MatchingDecision decision, int expectedCost) {
        var cost = scenario.cost(MatchingCase.builder().expectedResponse(expected).build(),
                new MatchingResult(score, decision));
        assertEquals(expectedCost, cost);
    }

    static Stream<Arguments> scenarioCases() {
        var scenario1 = new Scenario1();
        var scenario2 = new Scenario2();
        var scenario3 = new Scenario3();
        return Stream.of(
                Arguments.of(scenario1, "MATCH", BigDecimal.ZERO, MatchingDecision.NO_MATCH, 1),
                Arguments.of(scenario1, "MATCH", BigDecimal.ZERO, MatchingDecision.MATCH, 0),
                Arguments.of(scenario1, "MATCH", BigDecimal.ZERO, MatchingDecision.CLOSE_MATCH, 1),
                Arguments.of(scenario1, "NO_MATCH", BigDecimal.ZERO, MatchingDecision.NO_MATCH, 0),
                Arguments.of(scenario1, "NO_MATCH", BigDecimal.ZERO, MatchingDecision.MATCH, 1),
                Arguments.of(scenario1, "NO_MATCH", BigDecimal.ZERO, MatchingDecision.CLOSE_MATCH, 1),
                Arguments.of(scenario1, "CLOSE_MATCH", BigDecimal.ZERO, MatchingDecision.NO_MATCH, 1),
                Arguments.of(scenario1, "CLOSE_MATCH", BigDecimal.ZERO, MatchingDecision.MATCH, 1),
                Arguments.of(scenario1, "CLOSE_MATCH", BigDecimal.ZERO, MatchingDecision.CLOSE_MATCH, 0),

                Arguments.of(scenario2, "MATCH", BigDecimal.ZERO, MatchingDecision.NO_MATCH, 1),
                Arguments.of(scenario2, "MATCH", BigDecimal.ZERO, MatchingDecision.MATCH, 0),
                Arguments.of(scenario2, "MATCH", BigDecimal.ZERO, MatchingDecision.CLOSE_MATCH, 1),
                Arguments.of(scenario2, "NO_MATCH", BigDecimal.ZERO, MatchingDecision.NO_MATCH, 0),
                Arguments.of(scenario2, "NO_MATCH", BigDecimal.ZERO, MatchingDecision.MATCH, 100),
                Arguments.of(scenario2, "NO_MATCH", BigDecimal.ZERO, MatchingDecision.CLOSE_MATCH, 1),
                Arguments.of(scenario2, "CLOSE_MATCH", BigDecimal.ZERO, MatchingDecision.NO_MATCH, 1),
                Arguments.of(scenario2, "CLOSE_MATCH", BigDecimal.ZERO, MatchingDecision.MATCH, 100),
                Arguments.of(scenario2, "CLOSE_MATCH", BigDecimal.ZERO, MatchingDecision.CLOSE_MATCH, 0),

                Arguments.of(scenario3, "MATCH", BigDecimal.ZERO, MatchingDecision.NO_MATCH, 100),
                Arguments.of(scenario3, "MATCH", BigDecimal.ZERO, MatchingDecision.MATCH, 0),
                Arguments.of(scenario3, "MATCH", BigDecimal.ZERO, MatchingDecision.CLOSE_MATCH, 1),
                Arguments.of(scenario3, "NO_MATCH", BigDecimal.ZERO, MatchingDecision.NO_MATCH, 0),
                Arguments.of(scenario3, "NO_MATCH", BigDecimal.ZERO, MatchingDecision.MATCH, 300),
                Arguments.of(scenario3, "NO_MATCH", BigDecimal.ZERO, MatchingDecision.CLOSE_MATCH, 1),
                Arguments.of(scenario3, "CLOSE_MATCH", BigDecimal.ZERO, MatchingDecision.NO_MATCH, 100),
                Arguments.of(scenario3, "CLOSE_MATCH", BigDecimal.ZERO, MatchingDecision.MATCH, 300),
                Arguments.of(scenario3, "CLOSE_MATCH", BigDecimal.ZERO, MatchingDecision.CLOSE_MATCH, 0)

        );
    }

}
