package fr.sis.sisid.copuk.namematching.scorer;

import java.math.BigDecimal;
import java.util.stream.Stream;

import org.assertj.core.api.Assertions;
//import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;

class ThresholdEvaluatorTest {

    @ParameterizedTest
    @MethodSource("evaluateThresholdTestParams")
    void evaluateThresholdTest(BigDecimal score, MatchingDecision expected) {
        ThresholdEvaluator evaluator = new ThresholdEvaluator(0.2, 0.1);
        ScoredDecision matchingResult = evaluator.evaluateThreshold("first name", "second name", score);
        Assertions.assertThat(matchingResult.getDecision()).isEqualTo(expected);
    }

    static Stream<Arguments> evaluateThresholdTestParams() {
        return Stream.of(
                Arguments.of(BigDecimal.valueOf(0.5), MatchingDecision.MATCH),
                Arguments.of(BigDecimal.valueOf(0.15), MatchingDecision.CLOSE_MATCH),
                Arguments.of(BigDecimal.valueOf(0.05), MatchingDecision.NO_MATCH));
    }

    @Test
    void evaluateThresholdNoResult() {
        ThresholdEvaluator evaluator = new ThresholdEvaluator(0.2, 0.1);
        Assertions.assertThatThrownBy(() -> evaluator.evaluateThreshold("first name", "second name", null))
                .isInstanceOf(EvaluatorException.class);
    }
}