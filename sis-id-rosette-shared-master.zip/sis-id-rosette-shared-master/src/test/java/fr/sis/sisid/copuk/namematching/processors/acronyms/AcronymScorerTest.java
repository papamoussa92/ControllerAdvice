package fr.sis.sisid.copuk.namematching.processors.acronyms;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.scorer.ScoredDecision;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;

class AcronymScorerTest {

    @Test
    void testAcronymWithFullString() {
        AcronymScorer acronymScorer = new AcronymScorer(new BigDecimal("0.8"), new BigDecimal("0.7"), MatchingDecision.CLOSE_MATCH);

        AcronymResult ai1 = new AcronymResult("", "AML");

        AcronymNamePair np = new AcronymNamePair(ai1, "AML");
        ScoredDecision scoredDecision = acronymScorer.scoreNamePair(np, MatchingDecision.CLOSE_MATCH);
        assertEquals(MatchingDecision.CLOSE_MATCH, scoredDecision.getDecision());
    }

}