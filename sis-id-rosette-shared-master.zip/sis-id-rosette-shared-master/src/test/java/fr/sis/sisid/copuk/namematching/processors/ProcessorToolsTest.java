package fr.sis.sisid.copuk.namematching.processors;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.stream.Stream;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.model.MatchingResult;
import fr.sis.sisid.copuk.namematching.model.NameMatchingLog;
import fr.sis.sisid.copuk.namematching.processors.model.NamePair;
import fr.sis.sisid.copuk.namematching.processors.model.ProcessedNamePair;
import fr.sis.sisid.copuk.namematching.scorer.ScoredDecision;

class ProcessorToolsTest {

    @Test
    void toMatchingResultTest() {
        ProcessedNamePair first = new ProcessedNamePair(
                new NamePair("BMW AG", "Bayerische Motoren Werke Aktiengesellschaft"),
                new ScoredDecision(BigDecimal.ZERO, MatchingDecision.NO_MATCH),
                NamePairProcessorType.ORIGINAL,
                null);

        ProcessedNamePair second = new ProcessedNamePair(
                new NamePair("BMW", "Bayerische Motoren Werke"),
                new ScoredDecision(BigDecimal.valueOf(0.2), MatchingDecision.NO_MATCH),
                NamePairProcessorType.LEGAL_FORM,
                first);

        ProcessedNamePair third = new ProcessedNamePair(
                new NamePair("BMW", "BMW"),
                new ScoredDecision(BigDecimal.ONE, MatchingDecision.MATCH),
                NamePairProcessorType.ACRONYMS,
                second);

        MatchingResult expected = new MatchingResult(BigDecimal.ONE, MatchingDecision.MATCH);
        NameMatchingLog firstLog = new NameMatchingLog();
        firstLog.setProcessedInput("BMW AG");
        firstLog.setProcessedReference("Bayerische Motoren Werke Aktiengesellschaft");
        firstLog.setRuleCode(NamePairProcessorType.ORIGINAL.getRuleCode());
        firstLog.setScore(0d);
        firstLog.setDecision(MatchingDecision.NO_MATCH);

        NameMatchingLog secondLog = new NameMatchingLog();
        secondLog.setInput("BMW AG");
        secondLog.setReference("Bayerische Motoren Werke Aktiengesellschaft");
        secondLog.setProcessedInput("BMW");
        secondLog.setProcessedReference("Bayerische Motoren Werke");
        secondLog.setRuleCode(NamePairProcessorType.LEGAL_FORM.getRuleCode());
        secondLog.setDecision(MatchingDecision.NO_MATCH);
        secondLog.setScore(0.2d);

        NameMatchingLog thirdLog = new NameMatchingLog();
        thirdLog.setInput("BMW");
        thirdLog.setReference("Bayerische Motoren Werke");
        thirdLog.setProcessedInput("BMW");
        thirdLog.setProcessedReference("BMW");
        thirdLog.setRuleCode(NamePairProcessorType.ACRONYMS.getRuleCode());
        thirdLog.setScore(1d);
        thirdLog.setDecision(MatchingDecision.MATCH);

        expected.setProcessorLog(Stream.of(firstLog, secondLog, thirdLog).toList());

        Assertions.assertThat(ProcessorTools.toMatchingResult(third))
                .isEqualTo(expected);

    }

    @Test
    void toMatchingResultTest_noProcessor() {
        ProcessedNamePair first = new ProcessedNamePair(
                new NamePair("BMW AG", "Bayerische Motoren Werke Aktiengesellschaft"),
                new ScoredDecision(BigDecimal.ZERO, MatchingDecision.NO_MATCH),
                NamePairProcessorType.ORIGINAL,
                null);

        MatchingResult expected = new MatchingResult(BigDecimal.ZERO, MatchingDecision.NO_MATCH);
        NameMatchingLog firstLog = new NameMatchingLog();
        firstLog.setProcessedInput("BMW AG");
        firstLog.setProcessedReference("Bayerische Motoren Werke Aktiengesellschaft");
        firstLog.setRuleCode(NamePairProcessorType.ORIGINAL.getRuleCode());
        firstLog.setScore(0d);
        firstLog.setDecision(MatchingDecision.NO_MATCH);

        expected.setProcessorLog(Collections.singletonList(firstLog));
        Assertions.assertThat(ProcessorTools.toMatchingResult(first))
                .isEqualTo(expected);
    }

}
