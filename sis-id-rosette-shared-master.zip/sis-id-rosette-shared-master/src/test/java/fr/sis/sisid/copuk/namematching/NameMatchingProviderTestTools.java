package fr.sis.sisid.copuk.namematching;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.function.Function;
import java.util.stream.Stream;

import javax.validation.constraints.NotNull;

import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;

import fr.sis.sisid.copuk.namematching.model.MatchingResult;
import fr.sis.sisid.copuk.namematching.optimizer.MatchingCase;

public class NameMatchingProviderTestTools {

    public void closeIO(Reader reader, Writer writer) {
        try {
            reader.close();
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @NotNull
    public Function<fr.sis.sisid.copuk.namematching.optimizer.MatchingCase, MatchingCase> writeData(
            StatefulBeanToCsv<MatchingCase> beanToCsv, Writer writer) {
        return matchingCaseW -> {
            try {
                beanToCsv.write(matchingCaseW);
                writer.flush();
            } catch (CsvDataTypeMismatchException | CsvRequiredFieldEmptyException | IOException e) {
                throw new RuntimeException(e);
            }
            return matchingCaseW;
        };
    }

    @NotNull
    public MatchingCase applyResult(MatchingCase matchingCase, MatchingResult matchingResponse) {
        return matchingCase.toBuilder()
                .matchingRate(matchingResponse.getScore().getScore())
                .result(matchingResponse.getScore().getDecision().toString())
                .build();
    }

    public Stream<MatchingCase> readCases(Reader reader) {
        CsvToBean<MatchingCase> cb = new CsvToBeanBuilder<MatchingCase>(reader)
                .withType(MatchingCase.class)
                .withSeparator(',')
                .withQuoteChar('"')
                .build();
        return cb.stream();
    }
}
