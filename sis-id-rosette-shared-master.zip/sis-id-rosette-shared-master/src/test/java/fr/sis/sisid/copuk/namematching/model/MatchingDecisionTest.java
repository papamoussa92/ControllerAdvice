package fr.sis.sisid.copuk.namematching.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;

class MatchingDecisionTest {

    @Test
    void testFromString() {
        assertEquals(MatchingDecision.NO_MATCH, MatchingDecision.fromString("NO_MATCH"));
        assertEquals(MatchingDecision.CLOSE_MATCH, MatchingDecision.fromString("CLOSE_MATCH"));
        assertEquals(MatchingDecision.MATCH, MatchingDecision.fromString("MATCH"));
        assertNull(MatchingDecision.fromString("anything"));
        assertNull(MatchingDecision.fromString(null));

    }
}