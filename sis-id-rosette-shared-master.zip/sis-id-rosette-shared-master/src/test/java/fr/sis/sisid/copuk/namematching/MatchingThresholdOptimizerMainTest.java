package fr.sis.sisid.copuk.namematching;

import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import fr.sis.sisid.copuk.namematching.optimizer.MatchingThresholdOptimizer;
import lombok.extern.slf4j.Slf4j;

@Slf4j
class MatchingThresholdOptimizerMainTest {

    @Test
    void testMainFail() {
        assertThrows(Exception.class, () -> MatchingThresholdOptimizer.main(null));
    }

    @Test
    void testMainInvalid() {
        assertThrows(Exception.class, () -> MatchingThresholdOptimizer.main(new String[] { "nopath" }));
    }

}
