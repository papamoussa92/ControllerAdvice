package fr.sis.sisid.copuk.namematching.scorer;

import java.math.BigDecimal;
import java.util.stream.Stream;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.processors.model.NamePair;
import lombok.Getter;

class BoundedScorerTest {

    @ParameterizedTest
    @MethodSource("scoreNamePairTestParams")
    void scoreNamePairTest(NamePair input, MatchingDecision expectedDecision) {
        var scorer = new BoundedScorer(BigDecimal.valueOf(0.66), BigDecimal.valueOf(0.33),
                np -> np instanceof BoundedNamePair && ((BoundedNamePair) np).isBounded(),
                MatchingDecision.CLOSE_MATCH);
        Assertions.assertThat(scorer.scoreNamePair(input, MatchingDecision.MATCH).getDecision())
                .isEqualTo(expectedDecision);
    }

    static Stream<Arguments> scoreNamePairTestParams() {
        return Stream.of(
                Arguments.of(new NamePair("aaaaab", "aaaaaa"), MatchingDecision.MATCH),
                Arguments.of(new NamePair("aaabcd", "aaaaaa"), MatchingDecision.CLOSE_MATCH),
                Arguments.of(new NamePair("bbccdd", "aaaaaa"), MatchingDecision.NO_MATCH),
                Arguments.of(new BoundedNamePair("aaaaab", "aaaaaa", false), MatchingDecision.MATCH),
                Arguments.of(new BoundedNamePair("aaabcd", "aaaaaa", false), MatchingDecision.CLOSE_MATCH),
                Arguments.of(new BoundedNamePair("bbccdd", "aaaaaa", false), MatchingDecision.NO_MATCH),
                Arguments.of(new BoundedNamePair("aaaaab", "aaaaaa", true), MatchingDecision.CLOSE_MATCH),
                Arguments.of(new BoundedNamePair("aaabcd", "aaaaaa", true), MatchingDecision.CLOSE_MATCH),
                Arguments.of(new BoundedNamePair("bbccdd", "aaaaaa", true), MatchingDecision.NO_MATCH));
    }

    private static class BoundedNamePair extends NamePair {

        @Getter
        private boolean bounded;

        public BoundedNamePair(String input, String reference, boolean bounded) {
            super(input, reference);
            this.bounded = bounded;
        }

    }

}
