package fr.sis.sisid.copuk.namematching.processors.dictsearch.index;

import java.io.IOException;
import java.io.Reader;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;

import org.springframework.core.io.ClassPathResource;

import com.fasterxml.jackson.databind.ObjectMapper;

import fr.sis.sisid.copuk.namematching.processors.dictsearch.index.DictSearchIndex;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.index.DictSearchIndexImpl;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.model.DictEntrySet;

public class IndexTestTools {

    public static DictSearchIndex getIndex(String dictionaryPath) throws IOException {
        return getIndex(dictionaryPath, BigDecimal.valueOf(0.8));
    }

    public static DictSearchIndex getIndex(String dictionaryPath, BigDecimal threshold) throws IOException {
        var indexImpl = new DictSearchIndexImpl(threshold);
        ObjectMapper jsonMapper = new ObjectMapper();
        Reader dictionaryReader = Files.newBufferedReader(
                Path.of(new ClassPathResource(dictionaryPath).getURI().getPath()));

        DictEntrySet ukDict = jsonMapper.readValue(dictionaryReader, DictEntrySet.class);
        indexImpl.index(ukDict);
        return indexImpl;
    }
}
