package fr.sis.sisid.copuk.namematching.scorer;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.processors.model.NamePair;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;

class FuzzyScorerTest {

    @Test
    void testScorerMatch() {
        FuzzyScorer fuzzyScorer = new FuzzyScorer(new BigDecimal("0.77"), new BigDecimal("0.67"));
        NamePair np = new NamePair("IKO PARTNERSIP", "IKO PARTNERSHIP");
        var result = fuzzyScorer.scoreNamePair(np, MatchingDecision.MATCH);
        assertEquals(MatchingDecision.MATCH, result.getDecision());
        assertThat(result.getScore()).isGreaterThan(new BigDecimal("0.77"));
    }

    @Test
    void testScorerStrictMatch() {
        FuzzyScorer fuzzyScorer = new FuzzyScorer(new BigDecimal("1.0"), new BigDecimal("0.67"));
        NamePair np = new NamePair("IKO PARTNERSHIP", "IKO PARTNERSHIP");
        var result = fuzzyScorer.scoreNamePair(np, MatchingDecision.MATCH);
        assertThat(result.getScore()).isEqualTo(new BigDecimal("1.0"));
        assertEquals(MatchingDecision.MATCH, result.getDecision());
    }

    @Test
    void testScorerNoMatch() {
        FuzzyScorer fuzzyScorer = new FuzzyScorer(new BigDecimal("0.97"), new BigDecimal("0.87"));
        NamePair np = new NamePair("TIKO", "IKO PARTNERSHIP");
        var result = fuzzyScorer.scoreNamePair(np, MatchingDecision.MATCH);
        assertEquals(MatchingDecision.NO_MATCH, result.getDecision());
        assertThat(result.getScore()).isLessThan(new BigDecimal("0.87"));
    }

    @Test
    void testScorerCloseMatch() {
        FuzzyScorer fuzzyScorer = new FuzzyScorer(new BigDecimal("0.99"), new BigDecimal("0.67"));
        NamePair np = new NamePair("IKO PARTNERSIP", "IKO PARTNERSHIP");
        var result = fuzzyScorer.scoreNamePair(np, MatchingDecision.MATCH);
        assertEquals(MatchingDecision.CLOSE_MATCH, result.getDecision());
        assertThat(result.getScore()).isLessThan(new BigDecimal("0.99"));
        assertThat(result.getScore()).isGreaterThan(new BigDecimal("0.67"));
    }

    @Test
    void testScorerSpacing() {
        FuzzyScorer fuzzyScorer = new FuzzyScorer(new BigDecimal("0.9"), new BigDecimal("0.6"));
        NamePair np = new NamePair("IKO PARTNERSHIP", "IKOPARTNERSHIP");
        var result = fuzzyScorer.scoreNamePair(np, MatchingDecision.MATCH);

        assertEquals(MatchingDecision.MATCH, result.getDecision());
        assertThat(result.getScore()).isGreaterThan(new BigDecimal("0.9"));
    }

}