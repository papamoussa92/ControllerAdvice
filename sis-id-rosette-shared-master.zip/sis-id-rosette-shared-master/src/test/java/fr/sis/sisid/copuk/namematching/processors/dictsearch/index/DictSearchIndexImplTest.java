package fr.sis.sisid.copuk.namematching.processors.dictsearch.index;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.stream.Stream;

import fr.sis.sisid.copuk.namematching.processors.dictsearch.model.DictEntry;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

class DictSearchIndexImplTest {

    private static DictSearchIndex index;

    @BeforeAll
    static void setup() throws IOException {
        index = IndexTestTools.getIndex("legalforms/uk.json", BigDecimal.valueOf(0.55));
    }

    @Test
    void testFind() {
        var ltdResult = index.findEntry("ltd");
        var limitedResult = index.findEntry("limited");

        Assertions.assertThat(ltdResult.isFound()).isTrue();
        Assertions.assertThat(limitedResult.isFound()).isTrue();
        Assertions.assertThat(ltdResult.getResult()).isEqualTo(limitedResult.getResult());

        Assertions.assertThat(index.findEntry("not a legal form").isFound()).isFalse();
    }

    @ParameterizedTest
    @MethodSource("testFuzzyFindParams")
    void testFuzzyFind(String query, boolean expectFound, String expectedName) {
        var result = index.findEntry(query);
        Assertions.assertThat(result.isFound()).isEqualTo(expectFound);
        if (expectFound) {
            Assertions.assertThat(result.getResult().stream().map(DictEntry::getName)).containsExactly(expectedName);
        }
    }

    static Stream<Arguments> testFuzzyFindParams() {
        return Stream.of(
                Arguments.of("ltd", true, "private limited company"),
                Arguments.of("limited", true, "private limited company"),
                Arguments.of("limi", true, "private limited company"),
                Arguments.of("llp", true, "limited liability partnership"),
                Arguments.of("limited liability partnership", true, "limited liability partnership"),
                Arguments.of("lim", false, null));
    }

}
