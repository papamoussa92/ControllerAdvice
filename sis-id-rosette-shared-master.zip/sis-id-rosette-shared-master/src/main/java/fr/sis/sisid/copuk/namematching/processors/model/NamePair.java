package fr.sis.sisid.copuk.namematching.processors.model;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@AllArgsConstructor
@Getter
@EqualsAndHashCode
@ToString
public class NamePair {

    private String input;

    private String reference;

}
