package fr.sis.sisid.copuk.namematching.optimizer;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.model.MatchingResult;

/**
 * Scenario 2: Optimize for correctness no false positive tolerated
 * <p>
 * Reduce the strict match so that no incorrect matching exists, «no match» are optimized the rests falls through «close match»
 */
public class Scenario2 implements CostFunction {

    public int cost(MatchingCase matchingCase, MatchingResult result) {
        if (result.getScore().getDecision() == MatchingDecision.MATCH
                && matchingCase.getExpectedDecision() != MatchingDecision.MATCH) {
            return 100;
        } else if (result.getScore().getDecision() != matchingCase.getExpectedDecision()) {
            return 1;
        }
        return 0;
    }

}
