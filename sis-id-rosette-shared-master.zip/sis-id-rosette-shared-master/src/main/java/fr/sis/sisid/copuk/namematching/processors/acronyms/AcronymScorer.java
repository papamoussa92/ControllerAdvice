package fr.sis.sisid.copuk.namematching.processors.acronyms;

import java.math.BigDecimal;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.processors.model.NamePair;
import fr.sis.sisid.copuk.namematching.scorer.BoundedScorer;
import fr.sis.sisid.copuk.namematching.scorer.NamePairScorer;
import fr.sis.sisid.copuk.namematching.scorer.ScoredDecision;
import org.apache.logging.log4j.util.Strings;

/**
 * Scorer dedicated to evaluating input or reference with acronyms detected.
 * The matching with acronyms is limited (bounded), typically to a close_match depending on configuration.
 * The acronyms parts found should match strictly. The reset of the input/reference not in the acronym should match fuzzily, without close_match tolerance
 */
public class AcronymScorer implements NamePairScorer {

    private final NamePairScorer scorer;

    public AcronymScorer(BigDecimal thresholdMatch, BigDecimal thresholdCloseMatch, MatchingDecision bound) {

        // Not allowing close match for acronyms, only fuzzy matching
        this.scorer = new BoundedScorer(thresholdMatch, thresholdCloseMatch,
                (AcronymNamePair.class::isInstance),
                bound);
    }

    @Override
    public ScoredDecision scoreNamePair(NamePair np, MatchingDecision bound) {
        if (np instanceof AcronymNamePair acronymNamePair) {
            if (!acronymPartsMatch(acronymNamePair)) {
                return new ScoredDecision(BigDecimal.ZERO, MatchingDecision.NO_MATCH);
            }
            if (!inputAcronymFoundInRef(acronymNamePair)) {
                return new ScoredDecision(BigDecimal.ZERO, MatchingDecision.NO_MATCH);
            }

        }
        return this.scorer.scoreNamePair(np, bound);
    }

    private boolean acronymPartsMatch(AcronymNamePair acronymNamePair) {
        return
                // Cannot find the acronym detected in the input in the reference text
                (Strings.isBlank(
                        acronymNamePair.getAcronym().getAcronymPart()) || acronymNamePair.getFullText().startsWith(acronymNamePair.getAcronym().getAcronymPart()));

    }

    private boolean inputAcronymFoundInRef(AcronymNamePair acronymNamePair) {
        return Strings.isBlank(acronymNamePair.getAcronym().getAcronymPart()) || acronymNamePair.getFullText().startsWith(acronymNamePair.getAcronym().getAcronymPart());
    }
}
