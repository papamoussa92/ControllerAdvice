package fr.sis.sisid.copuk.namematching.optimizer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.opencsv.ICSVWriter;
import com.opencsv.bean.CsvToBean;
import com.opencsv.bean.CsvToBeanBuilder;
import com.opencsv.bean.StatefulBeanToCsv;
import com.opencsv.bean.StatefulBeanToCsvBuilder;
import com.opencsv.exceptions.CsvDataTypeMismatchException;
import com.opencsv.exceptions.CsvRequiredFieldEmptyException;
import fr.sis.sisid.copuk.namematching.RuleBasedNameMatchingProvider;
import fr.sis.sisid.copuk.namematching.model.CompanySynonyms;
import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.processors.NamePairProcessor;
import fr.sis.sisid.copuk.namematching.processors.NamePairProcessorType;
import fr.sis.sisid.copuk.namematching.processors.acronyms.AcronymProcessor;
import fr.sis.sisid.copuk.namematching.processors.acronyms.AcronymScorer;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.DictSearchProcessorImpl;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.DictSearchScorer;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.index.DictSearchIndex;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.index.DictSearchIndexBuilder;
import fr.sis.sisid.copuk.namematching.processors.prefix.InvoiceDiscountAccount;
import fr.sis.sisid.copuk.namematching.processors.prefix.InvoiceDiscountAccountProcessor;
import fr.sis.sisid.copuk.namematching.processors.prefix.PrefixScorer;
import fr.sis.sisid.copuk.namematching.processors.structuredinput.StructuredInputProcessor;
import fr.sis.sisid.copuk.namematching.processors.synonym.SynonymProcessor;
import fr.sis.sisid.copuk.namematching.processors.synonym.SynonymRepo;
import fr.sis.sisid.copuk.namematching.scorer.FuzzyScorer;
import fr.sis.sisid.copuk.namematching.scorer.NamePairScorer;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.BeanInitializationException;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.math.BigDecimal;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.EnumMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

@Slf4j
public class MatchingThresholdOptimizer {

    private static final String LIMIT_LEGAL_FORMS = MatchingDecision.CLOSE_MATCH.name();
    private static final String LIMIT_ACRONYMS = MatchingDecision.CLOSE_MATCH.name();
    private static final String LIMIT_PREFIXES = MatchingDecision.MATCH.name();
    private static final String NATURE_ENTERPRISE_PREFIXES = MatchingDecision.CLOSE_MATCH.name();
    private static final String LIMIT_GEOGRAPHY = MatchingDecision.CLOSE_MATCH.name();

    private final StructuredInputProcessor structuredInputProcessor = new StructuredInputProcessor();
    private final BigDecimal legalFormRemainderThreshold;
    private final BigDecimal geographyRemainderThreshold;
    private final BigDecimal natureRemainderThreshold;
    private final BigDecimal acronymThresholdCloseMatch;

    Set<MatchingCase> matchingCases;
    private final SynonymProcessor synonymProcessor;

    private final DictSearchProcessorImpl natureEnterpriseProcessor;

    private final InvoiceDiscountAccountProcessor invoiceDiscountAccountProcessor;
    private final DictSearchProcessorImpl countryProcessor;
    private final DictSearchProcessorImpl legalFormProcessor;

    private final AcronymProcessor acronymProcessor;
    private final Writer resultWriter;
    private final StatefulBeanToCsv<MatchingOutcome> resultBeanWriter;

    public MatchingThresholdOptimizer() throws IOException {
        BigDecimal legalFormThreshold = BigDecimal.valueOf(0.8);
        BigDecimal geographyThreshold = BigDecimal.valueOf(0.8);
        BigDecimal natureThreshold = BigDecimal.valueOf(0.8);
        acronymThresholdCloseMatch = BigDecimal.valueOf(0.6);

        legalFormRemainderThreshold = BigDecimal.valueOf(0.96);
        geographyRemainderThreshold = BigDecimal.valueOf(0.95);
        natureRemainderThreshold = BigDecimal.valueOf(0.95);

        DictSearchIndex legalForms = new DictSearchIndexBuilder(legalFormThreshold)
                .index(new ClassPathResource("legalforms/be.json"))
                .index(new ClassPathResource("legalforms/eu.json"))
                .index(new ClassPathResource("legalforms/no.json"))
                .index(new ClassPathResource("legalforms/pl.json"))
                .index(new ClassPathResource("legalforms/uk.json"))
                .index(new ClassPathResource("legalforms/us.json"))
                .index(new ClassPathResource("legalforms/fr.json"))
                .index(new ClassPathResource("legalforms/de.json"))
                .index(new ClassPathResource("legalforms/nl.json"))
                .index(new ClassPathResource("legalforms/se.json"))
                .build();
        legalFormProcessor = new DictSearchProcessorImpl(legalForms, NamePairProcessorType.LEGAL_FORM,
                legalFormRemainderThreshold);

        DictSearchIndex countries = new DictSearchIndexBuilder(geographyThreshold)
                .index(new ClassPathResource("countries/countries.json")).build();
        countryProcessor = new DictSearchProcessorImpl(countries, NamePairProcessorType.GEOGRAPHY,
                geographyRemainderThreshold);

        ObjectMapper objectMapper = new ObjectMapper();

        CompanySynonyms[] companySynonyms = objectMapper.readerFor(CompanySynonyms[].class)
                .readValue(new ClassPathResource("tradingnames/tradingnames.json").getInputStream());
        SynonymRepo synonymRepo = inputFromBnp -> Stream.of(companySynonyms).filter(synonym -> inputFromBnp.stream()
                        .allMatch(token -> StringUtils.containsIgnoreCase(synonym.getAccountName(), token)))
                .map(entity -> new CompanySynonyms(entity.getId(), entity.getAccountName(), entity.getTradingName()))
                .toList();

        synonymProcessor = new SynonymProcessor(synonymRepo);

        DictSearchIndex natureEnterpriseIndex = new DictSearchIndexBuilder(natureThreshold)
                .index(new ClassPathResource("natures/natures.json")).build();
        natureEnterpriseProcessor = new DictSearchProcessorImpl(natureEnterpriseIndex,
                NamePairProcessorType.NATURE_ENTERPRISE, natureRemainderThreshold);

        var invoiceDiscountAccount = objectMapper.readValue(
                new ClassPathResource("prefixes/prefixes.json").getInputStream(), List.class);
        invoiceDiscountAccountProcessor = new InvoiceDiscountAccountProcessor(() -> invoiceDiscountAccount);

        acronymProcessor = new AcronymProcessor();

        this.resultWriter = Files.newBufferedWriter(Path.of(URI.create("./target/detailed_results.csv").getPath()));
        this.resultBeanWriter = new StatefulBeanToCsvBuilder<MatchingOutcome>(resultWriter).withSeparator(
                        ICSVWriter.DEFAULT_SEPARATOR)
                .withOrderedResults(true)
                .build();
    }

    /**
     * Test with test case CSV file path as first argument
     *
     * @param args path to test case file can be passed
     * @throws Exception if file loading or optimisation fails
     */
    public static void main(String[] args) throws Exception {
        new MatchingThresholdOptimizer().optimizeMapReduce(args[0],
                List.of(new Scenario1(), new Scenario2(), new Scenario3()));

    }

    private OptimizationConfiguration initRules(BigDecimal thresholdMatch, BigDecimal thresholdCloseMatch) {

        var scorer = new FuzzyScorer(thresholdMatch, thresholdCloseMatch);
        LinkedList<NamePairProcessor> processors = new LinkedList<>();

        processors.addLast(structuredInputProcessor);
        processors.addLast(synonymProcessor);
        processors.addLast(invoiceDiscountAccountProcessor);
        processors.addLast(natureEnterpriseProcessor);
        processors.addLast(legalFormProcessor);
        processors.addLast(countryProcessor);
        processors.addLast(acronymProcessor);

        var legalFormBound = MatchingDecision.fromString(LIMIT_LEGAL_FORMS);
        var acronymBound = MatchingDecision.fromString(LIMIT_ACRONYMS);
        var prefixBound = MatchingDecision.fromString(LIMIT_PREFIXES);
        var natureEntrepiseBound = MatchingDecision.fromString(NATURE_ENTERPRISE_PREFIXES);
        var countryBound = MatchingDecision.fromString(LIMIT_GEOGRAPHY);
        if (legalFormBound == null || acronymBound == null || prefixBound == null || countryBound == null) {
            throw new BeanInitializationException("Could not parse the name matching bounds properly");
        }
        var legalFormScorer = new DictSearchScorer(legalFormRemainderThreshold, thresholdCloseMatch, legalFormBound);
        var countryScorer = new DictSearchScorer(geographyRemainderThreshold, thresholdCloseMatch, countryBound);
        var acronymScorer = new AcronymScorer(thresholdMatch, acronymThresholdCloseMatch, acronymBound);
        var prefixScorer = new PrefixScorer(thresholdMatch, thresholdCloseMatch, prefixBound);
        var natureEntrepriseScorer = new DictSearchScorer(natureRemainderThreshold,
                thresholdCloseMatch, natureEntrepiseBound);

        Map<NamePairProcessorType, NamePairScorer> customScorers = new EnumMap<>(NamePairProcessorType.class);
        customScorers.put(NamePairProcessorType.LEGAL_FORM, legalFormScorer);
        customScorers.put(NamePairProcessorType.ACRONYMS, acronymScorer);
        customScorers.put(NamePairProcessorType.INVOICE_DISCOUNT, prefixScorer);
        customScorers.put(NamePairProcessorType.GEOGRAPHY, countryScorer);
        customScorers.put(NamePairProcessorType.NATURE_ENTERPRISE, natureEntrepriseScorer);

        return new OptimizationConfiguration(new RuleBasedNameMatchingProvider(processors, scorer, customScorers),
                thresholdMatch, thresholdCloseMatch);

    }

    /**
     * Simple map-reduce optimizer
     *
     * @return the list of solutions for each scenario
     * @throws IOException When test case file not readable
     */
    public List<OptimizationResult> optimizeMapReduce(String path, List<CostFunction> scenarios) throws IOException {
        matchingCases = loadDataSet(path);

        int precision = 100;
        return scenarios.stream().map(scenario -> {
            // Running optimisation across all domain to avoid missing overall optimum
            int thresholdMin = 96;
            int thresholdMax = 100;
            int closeThresholdMin = 59;
            int closeThresholdMax = 62;
            var result = IntStream.range(thresholdMin, thresholdMax).map(i -> thresholdMax - i + thresholdMin - 1)
                    .asDoubleStream()
                    // Run the first set of thresholds in parallel
                    .parallel()
                    // Revert to digit precision
                    .mapToObj(d -> d / precision)
                    // generate a flat map which is a cross product of the 2 threshold sets
                    .flatMap(d -> IntStream.range(closeThresholdMin, closeThresholdMax)
                            .map(i -> closeThresholdMax - i + closeThresholdMin - 1).asDoubleStream()
                            .map(d2 -> d2 / precision)
                            // Remove close match thresholds which are greater than the match thresholds
                            .filter(fd -> fd <= d)
                            .mapToObj(d2 -> initRules(BigDecimal.valueOf(d), BigDecimal.valueOf(d2))))
                    // reduce the results to the best parameters for this scenario
                    .reduce((e1, e2) -> evaluate(scenario, e1) > evaluate(scenario, e2) ? e2 : e1);

            var thresholds = result.isPresent() ? result.get() : "Not found";
            var ratios = Ratios
                    .calculateRatio(matchingCases,
                            result.map(OptimizationConfiguration::getProvider).orElse(null), this::writeResultDetails)
                    .orElseThrow();
            log.info("Final solution for {}: \n {}\n {}", scenario.getClass().getSimpleName(), thresholds, ratios);

            return new OptimizationResult(
                    scenario.getClass().getSimpleName(),
                    result.map(r -> r.getThresholdMatch().doubleValue()).orElse(null),
                    result.map(r -> r.getThresholdCloseMatch().doubleValue()).orElse(null),
                    ratios);
        }).toList();
    }

    private Set<MatchingCase> loadDataSet(String path) throws IOException {
        Reader reader = Files.newBufferedReader(Path.of(new ClassPathResource(path).getURI().getPath()));
        CsvToBean<MatchingCase> cb = new CsvToBeanBuilder<MatchingCase>(reader).withType(MatchingCase.class)
                .withSeparator(',').withQuoteChar('"').build();
        return cb.stream().collect(Collectors.toSet());
    }

    private boolean writeResultDetails(MatchingOutcome result) {
        try {
            resultBeanWriter.write(result);
            resultWriter.flush();
        } catch (CsvDataTypeMismatchException | CsvRequiredFieldEmptyException | IOException e) {
            log.error("Error writing detailed results", e);
            return false;
        }
        return true;
    }

    private int evaluate(CostFunction costFunction, OptimizationConfiguration nameMatchingConfiguration) {
        return matchingCases.stream().mapToInt(matchingCase -> {
            var result = nameMatchingConfiguration.getProvider()
                    .nameMatch(matchingCase.getNameReceived(), matchingCase.getRefName())
                    .block();
            return costFunction.cost(matchingCase, result);
        }).sum();

    }

}
