package fr.sis.sisid.copuk.namematching.model;

import lombok.extern.slf4j.Slf4j;

/**
 * Possible results when calling the name matching service
 */
@Slf4j
public enum MatchingDecision {

    NO_MATCH, CLOSE_MATCH, MATCH;

    public static MatchingDecision fromString(String s) {
        try {
            return valueOf(s.toUpperCase());
        } catch (IllegalArgumentException | NullPointerException e) {
            log.warn("Invalid decision {}", s, e);
            return null;
        }
    }

}
