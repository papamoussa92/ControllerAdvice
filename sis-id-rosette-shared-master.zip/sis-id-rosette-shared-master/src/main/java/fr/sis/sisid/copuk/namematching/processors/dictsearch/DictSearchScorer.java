package fr.sis.sisid.copuk.namematching.processors.dictsearch;

import java.math.BigDecimal;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.model.DictSearchProcessedNamePair;
import fr.sis.sisid.copuk.namematching.processors.model.NamePair;
import fr.sis.sisid.copuk.namematching.scorer.BoundedScorer;
import fr.sis.sisid.copuk.namematching.scorer.NamePairScorer;
import fr.sis.sisid.copuk.namematching.scorer.ScoredDecision;

/**
 * Scorer for name pairs processed by the legal form processor
 * Bounds decisions if the legal forms don't match
 *
 */
public class DictSearchScorer implements NamePairScorer {

    private final NamePairScorer scorer;

    /**
     * Scorer for dictionary search processed name pairs
     * @param thresholdMatch: match threshold
     * @param thresholdCloseMatch; close match threshold
     * @param boundIfMismatch: matching decision upper bound, when dict search results mismatch 
     */
    public DictSearchScorer(BigDecimal thresholdMatch, BigDecimal thresholdCloseMatch,
            MatchingDecision boundIfMismatch) {
        this.scorer = new BoundedScorer(thresholdMatch, thresholdCloseMatch,
                np -> np instanceof DictSearchProcessedNamePair lfpnp && lfpnp.isEntryMismatch(),
                boundIfMismatch);
    }

    @Override
    public ScoredDecision scoreNamePair(NamePair np, MatchingDecision bound) {
        return this.scorer.scoreNamePair(np, bound);
    }

}
