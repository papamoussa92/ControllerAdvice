package fr.sis.sisid.copuk.namematching.processors.acronyms;

import fr.sis.sisid.copuk.namematching.processors.NamePairProcessor;
import fr.sis.sisid.copuk.namematching.processors.NamePairProcessorType;
import fr.sis.sisid.copuk.namematching.processors.model.NamePair;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Utility to work out acronyms and match them against fully expanded list of words
 */
public class AcronymProcessor implements NamePairProcessor {
    private static final int MIMIMAL_TERM_SIZE = 3;
    private static final int MAXIMAL_TERM_SIZE = 4;

    /**
     * Provides a list of valid acronyms from 3 to 4 letters long base on the first words
     *
     * @param input A string which can have a number of words to get initials from
     * @return the list of valid acronyms
     */
    List<AcronymResult> deriveAcronyms(String input) {
        var result = new ArrayList<AcronymResult>();
        if (Strings.isEmpty(input)) {
            return result;
        }

        var words = StringUtils.split(input.trim());
        if (words.length < MIMIMAL_TERM_SIZE) {
            return result;
        }

        int maxAcronymWords = Math.min(words.length, MAXIMAL_TERM_SIZE);
        for (int w = MIMIMAL_TERM_SIZE; w <= maxAcronymWords; w++) {
            final int start = w;
            result.add(Stream.concat(
                            Stream.of(""),
                            Stream.of(words)).limit(w + 1L)
                    // aggregating first letter of each word
                    .reduce((w1, w2) -> w1 + w2.charAt(0)

                    )
                    .filter(Objects::nonNull)
                    // remaining words not transformed to acronyms
                    .map(s ->
                            (start < words.length) ?
                                    new AcronymResult(s,
                                            Arrays.stream(Arrays.copyOfRange(words, start, words.length)).collect(
                                                    Collectors.joining(" "))) :
                                    new AcronymResult(s, ""))

                    .orElse(new AcronymResult())

            );

        }

        return result;
    }

    @Override
    public Set<NamePair> process(NamePair input) {
        if (input == null || StringUtils.isAnyBlank(input.getInput(), input.getReference())) {
            return new HashSet<>();
        }
        String inputName = input.getInput().replace(".", "");
        String refName = input.getReference().replace(".", "");
        List<AcronymResult> refAcronyms = deriveAcronyms(refName);
        List<AcronymResult> inputAcronyms = deriveAcronyms(inputName);

        Set<NamePair> processedNamePairs = refAcronyms.stream()
                .map(refAcronym -> new AcronymNamePair(refAcronym, inputName))
                .collect(Collectors.toSet());

        processedNamePairs.addAll(inputAcronyms.stream()
                .map(inputAcronym -> new AcronymNamePair(inputAcronym, refName)).collect(Collectors.toSet()));
        processedNamePairs.add(input);
        return processedNamePairs;
    }

    @Override
    public NamePairProcessorType getProcessorType() {
        return NamePairProcessorType.ACRONYMS;
    }
}
