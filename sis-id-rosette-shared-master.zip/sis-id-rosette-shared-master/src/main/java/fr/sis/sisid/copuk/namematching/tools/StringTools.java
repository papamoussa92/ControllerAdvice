package fr.sis.sisid.copuk.namematching.tools;

import org.apache.commons.text.similarity.LevenshteinDistance;
import org.apache.logging.log4j.util.Strings;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

public class StringTools {

    private static final Pattern ACRONYM_PATTERN = Pattern.compile("\\b\\w(\\s)\\w\\b");

    private StringTools() {
    }

    /**
     * Lower cases a string, remove non word non digits from it
     * @param input text to normalize
     * @return normalized text
     */
    public static String normalize(String input) {
        String upperCase = input.toUpperCase(Locale.ROOT);
        // remove non word non digit characters except for '&'
        return convertSpacedAcronyms(upperCase.replace(".", "")
                .replace("&", "AND")
                .replaceAll("[\\W&&\\D&&[^&]]+", " ")
                // aggregate acronyms into single words
                .trim());
    }

    /**
     * Tokenize a string into a list of words ( whitespace separated )
     * @param input full text to split
     * @return text split as a list of the words separated by 1 space
     */
    public static List<String> tokenize(String input) {
        if(Strings.isBlank(input)) {
            return List.of();
        }
        // split around whitespaces
        return Arrays.asList(input.split("\\s"));
    }

    /**
     * Turns a list of n word tokens into sequences of [1, n-1] word tokens,
     * sorted from the longest to the shortest
     * @param tokens
     * @return
     */
    public static List<String> ngramTokens(List<String> tokens) {
        Set<String> ngramsSet = new HashSet<>();
        for (int n = 1; n < tokens.size(); n++) {

            for (int index = 0; index <= tokens.size() - n; index++) {
                List<String> ngram = new LinkedList<>();
                for (int nb = 0; nb < n; nb++) {
                    ngram.add(tokens.get(index + nb));
                }
                ngramsSet.add(String.join(" ", ngram));
            }
        }

        return ngramsSet.stream()
                .sorted()
                .sorted((s1, s2) -> s2.length() - s1.length())
                .toList();
    }

    /**
     * Removes a given token from an input string, case insensitive
     * @param input
     * @param toRemove
     * @return
     */
    public static String removeDistinctWordIgnoreCase(String input, String toRemove) {
        return String.join(" ",
                Pattern.compile("\\b" + toRemove + "\\b", Pattern.CASE_INSENSITIVE)
                        .matcher(input)
                        .replaceFirst("")
                        .split("\\s+"));
    }

    /**
     * Normalized edit distance. Returns a result between 0 and 1
     * @param a
     * @param b
     * @return
     */
    public static BigDecimal normalizedLvh(String a, String b) {
        int dist = new LevenshteinDistance().apply(a, b);
        double maxLength = Math.max(a.length(), b.length());
        return BigDecimal.ONE.subtract(BigDecimal.valueOf((maxLength - dist) / maxLength));
    }

    /**
     * Converts acronyms formed with spaces between letter to attached forms
     * i.e. A B C -> ABC
     * @param value the string to transform
     * @return the transformed string
     */
    public static String convertSpacedAcronyms(String value) {

        var matcher = ACRONYM_PATTERN.matcher(value);

        Set<Integer> positions = new HashSet<>();
        if (matcher.find()) {
            // loop through groups of letter-space-letter bounded i.e. " A B "
            do {
                positions.add(matcher.start(1));
            } while (matcher.find(matcher.start(1)));
        }

        StringBuilder sb = new StringBuilder(value);
        positions.stream().sorted(Comparator.reverseOrder()).forEach(sb::deleteCharAt);
        return sb.toString();

    }



}
