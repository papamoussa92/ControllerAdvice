package fr.sis.sisid.copuk.namematching.processors.dictsearch.model;

import java.util.Set;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

/**
 * Dictionary entry, and a list of spellings and abbreviations
 */
@Getter
@Setter
@RequiredArgsConstructor
public class DictEntry {

    private String name;

    private Set<String> spellings;
}
