package fr.sis.sisid.copuk.namematching.optimizer;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.model.MatchingResult;

/**
 * Scenario 3: No false responses tolerated. Fallback to «close match» whenever needed
 * <p>
 * A match will always only be given for expected match. A «no match» will always only be given for expected «no match». The rest falls back to «close match».
 */
public class Scenario3 implements CostFunction {

    public int cost(MatchingCase matchingCase, MatchingResult result) {
        if (result.getScore().getDecision() == MatchingDecision.MATCH
                && matchingCase.getExpectedDecision() != MatchingDecision.MATCH) {
            return 300;
        } else if (result.getScore().getDecision() == MatchingDecision.NO_MATCH
                && matchingCase.getExpectedDecision() != MatchingDecision.NO_MATCH) {
            return 100;
        } else if (result.getScore().getDecision() != matchingCase.getExpectedDecision()) {
            return 1;
        }
        return 0;
    }
}
