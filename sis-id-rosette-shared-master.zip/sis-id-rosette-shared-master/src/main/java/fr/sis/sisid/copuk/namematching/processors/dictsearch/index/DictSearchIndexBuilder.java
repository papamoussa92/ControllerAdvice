package fr.sis.sisid.copuk.namematching.processors.dictsearch.index;

import java.io.IOException;
import java.io.Reader;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;

import org.springframework.core.io.Resource;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

import fr.sis.sisid.copuk.namematching.processors.dictsearch.model.DictEntrySet;

public class DictSearchIndexBuilder {

    private final ObjectMapper mapper;

    private final DictSearchIndexImpl index;

    public DictSearchIndexBuilder(BigDecimal threshold) {
        index = new DictSearchIndexImpl(threshold);
        mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    public DictSearchIndexBuilder index(Resource resource) throws IOException {
        this.index.index(this.readDict(resource));
        return this;
    }

    public DictSearchIndexBuilder index(DictEntrySet dictEntrySet){
        this.index.index(dictEntrySet);
        return this;
    }

    public DictSearchIndex build() {
        return this.index;
    }

    private DictEntrySet readDict(Resource dictionaryResource) throws IOException {
        Reader dictionaryReader = Files.newBufferedReader(Path.of(dictionaryResource.getURI().getPath()));
        return this.mapper.readValue(dictionaryReader, DictEntrySet.class);
    }
}
