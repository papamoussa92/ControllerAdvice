package fr.sis.sisid.copuk.namematching.rosette;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
public class RosetteNameMatchingResult {

    private BigDecimal score;
}
