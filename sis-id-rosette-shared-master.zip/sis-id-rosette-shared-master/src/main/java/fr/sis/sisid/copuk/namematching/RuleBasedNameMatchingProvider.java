package fr.sis.sisid.copuk.namematching;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.model.MatchingResult;
import fr.sis.sisid.copuk.namematching.processors.NamePairProcessor;
import fr.sis.sisid.copuk.namematching.processors.NamePairProcessorType;
import fr.sis.sisid.copuk.namematching.processors.ProcessorTools;
import fr.sis.sisid.copuk.namematching.processors.model.NamePair;
import fr.sis.sisid.copuk.namematching.processors.model.ProcessedNamePair;
import fr.sis.sisid.copuk.namematching.scorer.NamePairScorer;
import fr.sis.sisid.copuk.namematching.scorer.ScoredDecision;
import fr.sis.sisid.copuk.namematching.tools.StringTools;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

import java.util.Comparator;
import java.util.EnumMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
public class RuleBasedNameMatchingProvider implements NameMatchingProvider {
    /*
     * Ordered list of processors to call, in map form Processor types mapped to the
     * next processor to use
     */
    private final Map<NamePairProcessorType, NamePairProcessor> nextProcessorMap;

    /**
     * Default scorer to use when evaluating name pairs
     */
    private final NamePairScorer defaultScorer;

    /**
     *  Scorers to use to evaluate name pair results for a given type of processors
     */
    private final Map<NamePairProcessorType, NamePairScorer> specificScorers;

    public RuleBasedNameMatchingProvider(List<NamePairProcessor> processors, NamePairScorer defaultScorer,
            Map<NamePairProcessorType, NamePairScorer> specificScorers) {
        this.defaultScorer = defaultScorer;
        this.specificScorers = specificScorers;
        this.nextProcessorMap = new EnumMap<>(NamePairProcessorType.class);
        NamePairProcessorType previousType = NamePairProcessorType.ORIGINAL;
        // build a map of processors to use
        for (NamePairProcessor processor : processors) {
            this.nextProcessorMap.put(previousType, processor);
            previousType = processor.getProcessorType();
        }
    }

    @Override
    public Mono<MatchingResult> nameMatch(String input, String reference) {
        log.debug("name matching start : [input={}], [ref={}]", input, reference);
        // initialize name pair
        NamePair source = new NamePair(StringTools.normalize(input.trim()), StringTools.normalize(reference.trim()));
        ScoredDecision score = this.getScorer(NamePairProcessorType.ORIGINAL).scoreNamePair(source,
                MatchingDecision.MATCH);
        ProcessedNamePair first = new ProcessedNamePair(source, score, NamePairProcessorType.ORIGINAL, null);
        // if raw input already matches, just return it
        if (MatchingDecision.MATCH.equals(score.getDecision())) {
            var result = ProcessorTools.toMatchingResult(first);
            this.logProcessorCalls(result, null);
            return Mono.just(result);
        }
        Map<NamePairProcessorType, Integer> processCount = new EnumMap<>(NamePairProcessorType.class);
        var processedNamePair = process(first, processCount);
        var result = ProcessorTools.toMatchingResult(processedNamePair);
        result.setNamePairProcessorType(processedNamePair.getProcessor());
        this.logProcessorCalls(result, processCount);
        return Mono.just(result);
    }

    /**
     * Returns the name reference has processed by the chain of processors.
     * This allows processors to limit what to return as part of the did you mean suggestion.
     *
     * @param reference, the original account reference
     * @param targetProcessorType The last processor type for in the execution chain
     * @return The account reference to be returned to the customer
     */
    @Override
    public String getProcessedAccountName(String reference, NamePairProcessorType targetProcessorType) {
        return nextProcessedName(reference, NamePairProcessorType.ORIGINAL, targetProcessorType);
    }

    private String nextProcessedName(String reference, NamePairProcessorType currentProcessorType,NamePairProcessorType targetProcessorType) {
        NamePairProcessor processor = this.nextProcessorMap.get(currentProcessorType);
        if(processor == null || currentProcessorType.equals(targetProcessorType)) {
            return reference;
        }
        return nextProcessedName(processor.getReference(reference), processor.getProcessorType(), targetProcessorType);
    }

    public ProcessedNamePair process(ProcessedNamePair np, Map<NamePairProcessorType, Integer> processCount) {
        log.trace("[{} | {} - {}]", np.getProcessor(), np.getNamePair().getInput(), np.getNamePair().getReference());
        if (!nextProcessorMap.containsKey(np.getProcessor())) {
            // no nextProcessor to apply, nothing to do
            return np;
        }
        // get nextProcessor to apply
        NamePairProcessor nextProcessor = getNextProcessor(np.getProcessor());
        // apply nextProcessor, get results
        Set<NamePair> processedNamePairs = nextProcessor.process(np.getNamePair());
        var processorCallCount = processCount.getOrDefault(nextProcessor.getProcessorType(), 0) + 1;
        processCount.put(nextProcessor.getProcessorType(), processorCallCount);
        // score and sort results from best to worst
        LinkedList<ProcessedNamePair> scoredProcessedNamePairs = processedNamePairs.stream()
                .map(namePair -> new ProcessedNamePair(
                        namePair,
                        this.getScorer(nextProcessor.getProcessorType()).scoreNamePair(namePair,
                                np.getResult().getUpperBound()),
                        nextProcessor.getProcessorType(),
                        np))
                .sorted(Comparator.comparing(ProcessedNamePair::getResult).reversed())
                .collect(Collectors.toCollection(LinkedList::new));
        // loop over scored results from best to worst, keep track of best result
        ProcessedNamePair bestResult = np;
        while (!scoredProcessedNamePairs.isEmpty()) {
            var result = scoredProcessedNamePairs.poll();
            if (MatchingDecision.MATCH.equals(result.getResult().getDecision())) {
                // return early if result matches
                return result;
            }
            ProcessedNamePair processedResult = result;
            // avoid recursive calls if there are no other processors to apply
            if (nextProcessorMap.containsKey(result.getProcessor())) {
                processedResult = process(result, processCount);
            }
            if (processedResult.getResult().compareTo(bestResult.getResult()) > 0) {
                bestResult = processedResult;
            }
        }
        return bestResult;
    }

    public NamePairScorer getScorer(NamePairProcessorType processorType) {
        if (this.specificScorers.containsKey(processorType)) {
            return this.specificScorers.get(processorType);
        }
        return this.defaultScorer;
    }

    public NamePairProcessor getNextProcessor(NamePairProcessorType processorType) {
        return this.nextProcessorMap.get(processorType);
    }

    private void logProcessorCalls(MatchingResult result, Map<NamePairProcessorType, Integer> processorCount) {
        log.debug("result : ");
        log.debug("[score : {}] [decision : {}]", result.getScore().getScore(), result.getScore().getDecision());

        result.getProcessorLog().forEach(processorLog -> log.debug("[processor: {}] [input: {}] [reference: {}]",
                processorLog.getRuleCode(), processorLog.getProcessedInput(), processorLog.getProcessedReference()));

        log.debug("recap : number of processor calls");
        if (processorCount == null) {
            log.debug("No name pair processor called to perform name matching");
            return;
        }
        processorCount.entrySet().stream().sorted(Comparator.comparingInt(Map.Entry::getValue)).forEach(
                entry -> log.debug("Name pair processor {} called {} times", entry.getKey(), entry.getValue()));
    }

}
