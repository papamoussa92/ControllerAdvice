package fr.sis.sisid.copuk.namematching;

import fr.sis.sisid.copuk.namematching.model.MatchingResult;
import fr.sis.sisid.copuk.namematching.processors.NamePairProcessorType;
import reactor.core.publisher.Mono;

/**
 * Name matching service interface
 *
 */
public interface NameMatchingProvider {

    /**
     * Returns whether the input name matches the target name
     * @param input The string passed to be queried
     * @param target The string from the reference
     * @return a deferred result container a score and a decision
     */
    Mono<MatchingResult> nameMatch(String input, String target);

    String getProcessedAccountName(String reference, NamePairProcessorType namePairProcessorType);
}
