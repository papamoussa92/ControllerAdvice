package fr.sis.sisid.copuk.namematching.scorer;

import java.math.BigDecimal;
import java.util.function.Predicate;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.processors.model.NamePair;

/**
 * Scorer that bounds the matching decision to an upper value,
 * based on a given predicate
 */
public class BoundedScorer implements NamePairScorer {

    /*
     * scorer to delegate the scoring to
     */
    private final NamePairScorer scorer;

    /*
     * predicate to decide if the result should be bounded
     */
    private final Predicate<NamePair> shouldBound;

    /*
     * Matching decision upper bound
     */
    private final MatchingDecision conditionalBound;

    /**
     * Scorer with an upper bound on the matching decision, applied when a given predicate matches 
     * @param thresholdMatch: match similarity threshold
     * @param thresholdCloseMatch: close match similarity threshold
     * @param shouldBound: matching decision will be bounded if this predicate evaluates to true
     * @param bound: matching decision upper bound
     */
    public BoundedScorer(BigDecimal thresholdMatch, BigDecimal thresholdCloseMatch, Predicate<NamePair> shouldBound,
            MatchingDecision bound) {
        this.scorer = new FuzzyScorer(thresholdMatch, thresholdCloseMatch);
        this.shouldBound = shouldBound;
        this.conditionalBound = bound;
    }

    @Override
    public ScoredDecision scoreNamePair(NamePair np, MatchingDecision bound) {
        var decision = this.scorer.scoreNamePair(np, bound);
        boolean decisionIsBounded = this.shouldBound.test(np);
        // if we should bound the result, set the bound regardless of if this result
        // actually gets bounded
        if (decisionIsBounded) {
            decision.setUpperBound(conditionalBound);
        }
        // bound the result
        if (decisionIsBounded && decision.getDecision().compareTo(this.conditionalBound) >= 0) {
            decision.setDecision(this.conditionalBound);
        }
        return decision;
    }

}
