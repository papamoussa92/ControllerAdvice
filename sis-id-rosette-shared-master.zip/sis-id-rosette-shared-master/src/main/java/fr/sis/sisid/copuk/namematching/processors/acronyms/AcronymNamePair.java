package fr.sis.sisid.copuk.namematching.processors.acronyms;

import fr.sis.sisid.copuk.namematching.processors.model.NamePair;
import lombok.EqualsAndHashCode;
import lombok.Getter;

@Getter
@EqualsAndHashCode(callSuper = true)
public class AcronymNamePair extends NamePair {
    /**
     * The acronym part found in the input text
     */
    private final AcronymResult acronym;

    /**
     * The acronym part found in the reference text
     */
    private final String fullText;

    public AcronymNamePair( AcronymResult acronym, String fullText) {
        super(acronym.getText(), fullText);
        this.acronym = acronym;
        this.fullText = fullText;
    }


}
