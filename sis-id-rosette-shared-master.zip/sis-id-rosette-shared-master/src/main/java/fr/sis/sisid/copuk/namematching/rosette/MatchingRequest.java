package fr.sis.sisid.copuk.namematching.rosette;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class MatchingRequest {
    private String name1;
    private String name2;

}
