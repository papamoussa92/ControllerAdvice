package fr.sis.sisid.copuk.namematching.optimizer;

import java.math.BigDecimal;

import lombok.Getter;
import lombok.Setter;

@Getter
public class OptimizationResult {

    @Setter
    String description;
    String scenario;
    private final double thresholdMatch;
    private final double thresholdCloseMatch;
    private final BigDecimal successRatio;
    private final BigDecimal falsePositive;
    private final BigDecimal falseNegative;
    private final BigDecimal closeMatchRatio;

    public OptimizationResult(String scenario, double thresholdMatch, double thresholdCloseMatch, Ratios ratios) {
        this.scenario = scenario;
        this.thresholdMatch = thresholdMatch;
        this.thresholdCloseMatch = thresholdCloseMatch;
        this.successRatio = ratios.getSuccessRatio();
        this.falsePositive = ratios.getFalsePositiveRatio();
        this.falseNegative = ratios.getFalseNegativeRatio();
        this.closeMatchRatio = ratios.getCloseMatchRatio();
    }
}
