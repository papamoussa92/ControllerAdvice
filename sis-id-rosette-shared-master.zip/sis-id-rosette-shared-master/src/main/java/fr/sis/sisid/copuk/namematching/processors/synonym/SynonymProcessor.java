package fr.sis.sisid.copuk.namematching.processors.synonym;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;

import fr.sis.sisid.copuk.namematching.model.CompanySynonyms;
import fr.sis.sisid.copuk.namematching.processors.NamePairProcessor;
import fr.sis.sisid.copuk.namematching.processors.NamePairProcessorType;
import fr.sis.sisid.copuk.namematching.processors.model.NamePair;

public class SynonymProcessor implements NamePairProcessor {

    private SynonymRepo synonymRepo;

    public SynonymProcessor(SynonymRepo synonymRepo) {
        this.synonymRepo = synonymRepo;
    }

    @Override
    public Set<NamePair> process(NamePair input) {
        if (input == null || StringUtils.isAnyBlank(input.getInput(), input.getReference())) {
            return new HashSet<>();
        }
        String refName = input.getReference();
        Set<String> synonyms = tokenizeSet(refName);
        Set<String> nameCompanyTrading = synonymRepo.findByCompanyName(synonyms).stream()
                .map(CompanySynonyms::getTradingName).collect(Collectors.toSet());
        nameCompanyTrading.add(input.getReference());
        return nameCompanyTrading.stream().map(synonym -> new NamePair(input.getInput(), synonym))
                .collect(Collectors.toSet());
    }

    List<String> tokenize(String in) {
        return Arrays.asList(in.split("\\s+"));
    }

    Set<String> tokenizeSet(String in) {
        return new HashSet<>(tokenize(in));
    }

    @Override
    public NamePairProcessorType getProcessorType() {
        return NamePairProcessorType.SYNONYMS;
    }
}
