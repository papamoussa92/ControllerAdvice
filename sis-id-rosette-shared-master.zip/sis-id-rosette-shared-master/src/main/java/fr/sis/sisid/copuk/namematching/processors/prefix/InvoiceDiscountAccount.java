package fr.sis.sisid.copuk.namematching.processors.prefix;

import java.util.List;

public interface InvoiceDiscountAccount {
    List<String> getPrefixes();
}
