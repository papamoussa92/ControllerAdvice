package fr.sis.sisid.copuk.namematching.scorer;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.processors.model.NamePair;

public interface NamePairScorer {

    ScoredDecision scoreNamePair(NamePair np, MatchingDecision bound);
}
