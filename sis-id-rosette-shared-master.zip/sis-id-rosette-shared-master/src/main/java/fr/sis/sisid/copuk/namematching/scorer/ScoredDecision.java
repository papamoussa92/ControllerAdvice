package fr.sis.sisid.copuk.namematching.scorer;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import lombok.Data;

import java.math.BigDecimal;

@Data
public class ScoredDecision implements Comparable<ScoredDecision> {

    private BigDecimal score;

    private MatchingDecision decision;

    private MatchingDecision upperBound;

    private MatchingDecision lowerBound;

    public ScoredDecision(BigDecimal score, MatchingDecision decision) {
        this.score = score;
        this.decision = decision;
        this.upperBound = MatchingDecision.MATCH;
        this.lowerBound = MatchingDecision.NO_MATCH;
    }

    @Override
    public int compareTo(ScoredDecision b) {
        if (b == null) {
            return 1;
        }
        /* @formatter:off
         * Compares 2 results, first by their matching decision, then by their score
         * MATCH > CLOSE_MATCH > NO_MATCH
         *  
         * | this \ other | MATCH          | CLOSE_MATCH    | NO_MATCH |
         * |--------------|----------------|----------------|----------------|
         * | MATCH        | compare scores | this > other   | this > other   |
         * | CLOSE_MATCH  | this < other   | compare scores | this > other   |
         * | NO_MATCH     | this < other   | this < other   | compare scores |
         * 
         * @formatter:on
         */
        if (!this.getDecision().equals(b.getDecision())) {
            MatchingDecision aDecision = this.getDecision();
            MatchingDecision bDecision = b.getDecision();
            return aDecision.compareTo(bDecision);
        }
        return this.getScore().compareTo(b.getScore());
    }
}
