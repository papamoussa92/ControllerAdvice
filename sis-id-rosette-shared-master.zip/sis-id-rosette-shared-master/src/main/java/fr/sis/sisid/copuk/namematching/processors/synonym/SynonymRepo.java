package fr.sis.sisid.copuk.namematching.processors.synonym;

import fr.sis.sisid.copuk.namematching.model.CompanySynonyms;

import java.util.Collection;
import java.util.List;

public interface SynonymRepo {
    public List<CompanySynonyms> findByCompanyName(Collection<String> inputFromBnp);
}
