package fr.sis.sisid.copuk.namematching.processors;

import java.util.Set;

import fr.sis.sisid.copuk.namematching.processors.model.NamePair;

public interface NamePairProcessor {

    Set<NamePair> process(NamePair input);

    NamePairProcessorType getProcessorType();

    default String getReference(String ref) {
        return ref;
    }

}
