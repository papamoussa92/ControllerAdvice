package fr.sis.sisid.copuk.namematching.model;

import lombok.Data;

/**
 * Trace of the outcome of a name pair processor having been called 
 *
 */
@Data
public class NameMatchingLog {

    /**
     * Input queried name
     */
    private String input;
    /**
     * Input reference name
     */
    private String reference;
    /**
     * Output queried name
     */
    private String processedInput;
    /**
     * Output reference name
     */
    private String processedReference;
    /**
     * Reference of the processor having been applied
     */
    private String ruleCode;
    /**
     * Similarity score for the processed input and reference
     */
    private double score;
    /**
     * MAtching decision for the processed input and reference
     */
    private MatchingDecision decision;

}
