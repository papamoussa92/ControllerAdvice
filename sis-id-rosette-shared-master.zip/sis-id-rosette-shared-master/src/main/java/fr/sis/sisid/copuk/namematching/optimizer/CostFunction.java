package fr.sis.sisid.copuk.namematching.optimizer;

import fr.sis.sisid.copuk.namematching.model.MatchingResult;

public interface CostFunction {
    int cost(MatchingCase matchingCase, MatchingResult result);
}
