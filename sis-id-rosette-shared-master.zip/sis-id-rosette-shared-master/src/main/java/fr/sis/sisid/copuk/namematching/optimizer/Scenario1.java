package fr.sis.sisid.copuk.namematching.optimizer;

import fr.sis.sisid.copuk.namematching.model.MatchingResult;

/**
 * Scenario 1: Optimize for overall correctness
 * <p>
 * Attempt to get the maximum cases of «match», «close match» and «no match» right as possible
 */
public class Scenario1 implements CostFunction {

    public int cost(MatchingCase matchingCase, MatchingResult result) {
        if (result.getScore().getDecision() != matchingCase.getExpectedDecision()) {
            return 1;
        }
        return 0;
    }

}
