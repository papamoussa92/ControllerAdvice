package fr.sis.sisid.copuk.namematching.processors.acronyms;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.util.Strings;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@ToString
@EqualsAndHashCode
public class AcronymResult {
    private String acronymPart;
    private String rest;

    public String getText() {
        return StringUtils.defaultIfBlank(acronymPart, "")
                +
                (Strings.isBlank(acronymPart) || Strings.isBlank(rest) ? "" : " ")
                +
                StringUtils.defaultIfBlank(rest, "");
    }
}
