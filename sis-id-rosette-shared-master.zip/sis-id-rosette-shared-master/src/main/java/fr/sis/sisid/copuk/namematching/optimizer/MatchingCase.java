package fr.sis.sisid.copuk.namematching.optimizer;

import com.opencsv.bean.CsvBindByName;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
public class MatchingCase {
    @CsvBindByName(column = "ref_name")
    private String refName;
    @CsvBindByName(column = "name_received")
    private String nameReceived;
    @CsvBindByName(column = "category")
    private String category;
    @CsvBindByName(column = "expected_response")
    private String expectedResponse;
    @CsvBindByName(column = "matching_rate")
    private BigDecimal matchingRate;
    @CsvBindByName(column = "result")
    private String result;

    public MatchingDecision getExpectedDecision() {
        return MatchingDecision.fromString(expectedResponse);
    }
}
