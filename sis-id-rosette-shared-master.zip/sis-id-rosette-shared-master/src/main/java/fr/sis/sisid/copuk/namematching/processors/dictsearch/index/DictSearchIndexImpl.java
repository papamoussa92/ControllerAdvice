package fr.sis.sisid.copuk.namematching.processors.dictsearch.index;

import fr.sis.sisid.copuk.namematching.processors.dictsearch.model.DictEntry;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.model.DictEntrySet;
import fr.sis.sisid.copuk.namematching.tools.StringTools;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Slf4j
public class DictSearchIndexImpl implements DictSearchIndex {

    /**
     * Distance threshold under which a given term is considered
     * to be matching a spelling for a given entry
     */
    private final BigDecimal maxDistance;

    private final Map<String, Set<DictEntry>> index = new HashMap<>();

    public DictSearchIndexImpl(BigDecimal threshold) {
        this.maxDistance = BigDecimal.ONE.subtract(threshold);
    }

    @Override
    public DictSearchResult findEntry(String word) {
        // Find the entry matching this term the best
        // by finding the closest spelling to it
        BigDecimal shortestDistance = BigDecimal.ONE;
        Set<DictEntry> bestResult = Set.of();

        for (Entry<String, Set<DictEntry>> dictEntry : index.entrySet()) {
            var dist = StringTools.normalizedLvh(StringTools.normalize(word), dictEntry.getKey());
            if (dist.compareTo(maxDistance) <= 0 && dist.compareTo(shortestDistance) <= 0) {
                shortestDistance = dist;
                bestResult = dictEntry.getValue();
            }
        }
        DictSearchResult result = new DictSearchResult();
        result.setQuery(word);
        result.setResult(bestResult);
        if (!bestResult.isEmpty()) {
            result.setFound(true);
            // return a score, not a distance
            result.setScore(Optional.of(BigDecimal.ONE.subtract(shortestDistance)));
        } else {
            result.setScore(Optional.empty());
        }
        log.debug("Search result for input {} -> {}", word, result);
        return result;
    }

    public void index(DictEntry form) {
        addToIndex(form, form.getName());
        if(form.getSpellings() != null) {
            for (String spelling : form.getSpellings()) {
                addToIndex(form, spelling);
            }
        }
    }

    private void addToIndex(DictEntry form, String term) {
        index.computeIfAbsent(StringTools.normalize(term), s -> Set.of(form));
        index.computeIfPresent(StringTools.normalize(term), (a,set) -> Stream.concat(set.stream(), Stream.of(form)).collect(
                Collectors.toSet()));
    }

    public void index(DictEntrySet dictionary) {
        for (DictEntry form : dictionary.getForms()) {
            this.index(form);
        }
    }

}
