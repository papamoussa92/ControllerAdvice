package fr.sis.sisid.copuk.namematching.rosette;

import java.io.Serial;

public class RosetteNameMatchingException extends RuntimeException {

    @Serial
    private static final long serialVersionUID = 2344855641832611317L;

    public RosetteNameMatchingException() {
        super();
    }

}
