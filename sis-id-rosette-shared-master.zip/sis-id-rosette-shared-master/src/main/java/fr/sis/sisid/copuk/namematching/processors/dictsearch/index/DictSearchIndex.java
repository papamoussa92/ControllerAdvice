package fr.sis.sisid.copuk.namematching.processors.dictsearch.index;

/**
 * Repository of known entries, indexed by their spellings
 * and abbreviations
 *
 */
public interface DictSearchIndex {

    /**
     * Searches for the entry that best matches this term
     * @param word
     * @return
     */
    DictSearchResult findEntry(String word);
}
