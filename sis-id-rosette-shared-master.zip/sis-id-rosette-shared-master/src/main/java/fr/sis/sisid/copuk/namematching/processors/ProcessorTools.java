package fr.sis.sisid.copuk.namematching.processors;

import java.util.LinkedList;

import fr.sis.sisid.copuk.namematching.model.MatchingResult;
import fr.sis.sisid.copuk.namematching.model.NameMatchingLog;
import fr.sis.sisid.copuk.namematching.processors.model.ProcessedNamePair;

public class ProcessorTools {

    private ProcessorTools() {
        // hide public constructor
    }

    /**
     * Builds a matching result out of a tree of processed name pairs
     * @param processedNamePair
     * @return
     */
    public static MatchingResult toMatchingResult(ProcessedNamePair processedNamePair) {
        MatchingResult result = new MatchingResult(processedNamePair.getResult().getScore(),
                processedNamePair.getResult().getDecision());
        LinkedList<NameMatchingLog> processorLog = new LinkedList<>();
        ProcessedNamePair current = processedNamePair;
        do {
            // unfold the processed name pair -> source tree into a list
            // of name matching logs
            var log = new NameMatchingLog();
            if (current.getSource() != null) {
                log.setInput(current.getSource().getNamePair().getInput());
                log.setReference(current.getSource().getNamePair().getReference());
            }
            log.setProcessedInput(current.getNamePair().getInput());
            log.setProcessedReference(current.getNamePair().getReference());
            log.setRuleCode(current.getProcessor().getRuleCode());
            log.setScore(current.getResult().getScore().doubleValue());
            log.setDecision(current.getResult().getDecision());
            processorLog.addFirst(log);
            current = current.getSource();
        } while (current != null);
        result.setProcessorLog(processorLog);
        return result;
    }

}
