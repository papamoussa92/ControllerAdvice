package fr.sis.sisid.copuk.namematching.optimizer;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Name matching performance statistics
 */
@AllArgsConstructor
@Getter
public class Counts implements Countable<Counts> {
    int successRatio;
    int falsePositiveRatio;
    int falseNegativeRatio;
    int closeMatchRatio;

    public Counts add(Counts c) {
        return new Counts(
                successRatio + c.successRatio,
                falsePositiveRatio + c.falsePositiveRatio,
                falseNegativeRatio + c.falseNegativeRatio,
                closeMatchRatio + c.closeMatchRatio);
    }

}
