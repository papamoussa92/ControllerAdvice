package fr.sis.sisid.copuk.namematching.processors.dictsearch.index;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.Set;

import fr.sis.sisid.copuk.namematching.processors.dictsearch.model.DictEntry;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Dictionary search result
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
public class DictSearchResult implements Comparable<DictSearchResult> {

    private boolean found;

    /**
     * Term that matched against this result
     */
    private String query;

    /**
     * Matched entry 
     */
    private Set<DictEntry> result;

    /**
     * Similarity score between the term and the matched entry spelling ( 1 -> 0)
     */
    private Optional<BigDecimal> score = Optional.empty();

    @Override
    public int compareTo(DictSearchResult o) {
        // compares scores
        boolean thisHasResult = (this.found && this.score.isPresent());
        boolean otherHasResult = o.isFound() && o.getScore().isPresent();

        if ((!thisHasResult) && !otherHasResult) {
            return 0;
        }
        if (thisHasResult && !otherHasResult) {
            return 1;
        }
        if (!thisHasResult) {
            return -1;
        }
        return this.score.get().compareTo(o.score.get());
    }

}
