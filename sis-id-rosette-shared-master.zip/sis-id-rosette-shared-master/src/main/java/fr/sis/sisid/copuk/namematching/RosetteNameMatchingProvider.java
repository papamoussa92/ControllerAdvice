package fr.sis.sisid.copuk.namematching;

import java.math.BigDecimal;

import fr.sis.sisid.copuk.namematching.processors.NamePairProcessorType;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;

import fr.sis.sisid.copuk.namematching.model.MatchingResult;
import fr.sis.sisid.copuk.namematching.rosette.MatchingRequest;
import fr.sis.sisid.copuk.namematching.rosette.RosetteNameMatchingException;
import fr.sis.sisid.copuk.namematching.rosette.RosetteNameMatchingResult;
import fr.sis.sisid.copuk.namematching.scorer.ScoredDecision;
import fr.sis.sisid.copuk.namematching.scorer.ThresholdEvaluator;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
public class RosetteNameMatchingProvider implements NameMatchingProvider {

    private final BigDecimal thresholdMatch;
    private final BigDecimal thresholdCloseMatch;

    private final WebClient webClient;
    private final String path;

    public RosetteNameMatchingProvider(
            @Value("${rosette.api.path}") String path,
            @Qualifier("rosetteWebClient") WebClient rosetteWebClient,
            @Value("${rosette.threshold.match}") BigDecimal thresholdMatch,
            @Value("${rosette.threshold.close-match}") BigDecimal thresholdCloseMatch) {
        this.path = path;
        log.info("Starting rosette service to path {}", path);
        this.webClient = rosetteWebClient;
        this.thresholdCloseMatch = thresholdCloseMatch;
        this.thresholdMatch = thresholdMatch;
    }

    @Override
    public Mono<MatchingResult> nameMatch(String input, String target) {
        log.info("Matching names with Rosette '{}' with '{}'", input, target);
        return webClient.post()
                .uri(f -> f.path(path).build())
                .body(Mono.just(new MatchingRequest(input, target)), MatchingRequest.class)
                .accept(MediaType.APPLICATION_JSON)
                .retrieve()
                .onStatus(HttpStatus::isError,
                        httpStatus -> {
                            log.warn("HTTP error calling naming service: {}", httpStatus.statusCode());
                            return Mono.error(new RosetteNameMatchingException());
                        })
                .bodyToMono(RosetteNameMatchingResult.class)
                .map(matchingResponse -> evaluateThreshold(input, target, matchingResponse.getScore()))
                .map(scoredDecision -> new MatchingResult(scoredDecision.getScore(), scoredDecision.getDecision()));
    }

    @Override
    public String getProcessedAccountName(String reference, NamePairProcessorType namePairProcessorType) {
        return null;
    }


    private ScoredDecision evaluateThreshold(String input, String target, BigDecimal score) {
        return new ThresholdEvaluator(thresholdMatch.doubleValue(), thresholdCloseMatch.doubleValue())
                .evaluateThreshold(input, target, score);

    }

}
