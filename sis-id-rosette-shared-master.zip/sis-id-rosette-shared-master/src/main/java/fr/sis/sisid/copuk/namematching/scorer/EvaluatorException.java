package fr.sis.sisid.copuk.namematching.scorer;

import java.io.Serial;

public class EvaluatorException extends RuntimeException {

    @Serial
    private static final long serialVersionUID = 8616905139797735635L;

    public EvaluatorException(String message) {
        super(message);
    }

}
