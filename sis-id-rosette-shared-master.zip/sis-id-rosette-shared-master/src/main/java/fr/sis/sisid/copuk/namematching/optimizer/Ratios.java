package fr.sis.sisid.copuk.namematching.optimizer;

import fr.sis.sisid.copuk.namematching.NameMatchingProvider;
import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.model.NameMatchingLog;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

/**
 * Aggregates name matching performance statistics
 */
@Getter
@AllArgsConstructor
@ToString
@Slf4j
public class Ratios {
    static MathContext mc = new MathContext(3);
    BigDecimal successRatio;
    BigDecimal falsePositiveRatio;
    BigDecimal falseNegativeRatio;
    BigDecimal closeMatchRatio;

    public static Optional<Ratios> calculateRatio(Set<MatchingCase> matchingCases,
            NameMatchingProvider nameMatchingProvider, Predicate<MatchingOutcome> tracer) {
        return matchingCases.stream().map(matchingCase -> {
            var result = nameMatchingProvider.nameMatch(matchingCase.getNameReceived(), matchingCase.getRefName())
                    .block();
            if(result == null) {
                log.error("Error finding result");
                return new Counts(0, 1, 1, 1);
            }
            int mismatch = result.getScore().getDecision() == matchingCase.getExpectedDecision() ? 0 : 1;
            int falsePositiveCount = result.getScore().getDecision() == MatchingDecision.MATCH &&
                    matchingCase.getExpectedDecision() != MatchingDecision.MATCH ? 1 : 0;
            int falseNegativeCount = result.getScore().getDecision() == MatchingDecision.NO_MATCH
                    && matchingCase.getExpectedDecision() != MatchingDecision.NO_MATCH ? 1 : 0;
            int closeMatchCount = result.getScore().getDecision() == MatchingDecision.CLOSE_MATCH ? 1 : 0;

            tracer.test(new MatchingOutcome(matchingCase.getNameReceived(), matchingCase.getRefName(),
                    matchingCase.getExpectedDecision(), result.getScore().getDecision(), falsePositiveCount,
                    falseNegativeCount, mismatch, result.getScore().getScore(), result.getProcessorLog().stream().map(
                    NameMatchingLog::getRuleCode).collect(
                    Collectors.joining(";"))));

            return new Counts(1 - mismatch, falsePositiveCount, falseNegativeCount, closeMatchCount);
        }).reduce(Counts::add).map(counts -> avgCount(counts, matchingCases.size()));
    }

    static Ratios avgCount(Counts counts, int total) {
        BigDecimal totalBD = new BigDecimal(total);
        return new Ratios(
                new BigDecimal(counts.getSuccessRatio()).divide(totalBD, mc),
                new BigDecimal(counts.getFalsePositiveRatio()).divide(totalBD, mc),
                new BigDecimal(counts.getFalseNegativeRatio()).divide(totalBD, mc),
                new BigDecimal(counts.getCloseMatchRatio()).divide(totalBD, mc));
    }
}
