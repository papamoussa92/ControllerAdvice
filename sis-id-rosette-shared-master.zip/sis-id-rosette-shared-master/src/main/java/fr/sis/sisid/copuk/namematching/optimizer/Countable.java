package fr.sis.sisid.copuk.namematching.optimizer;

public interface Countable<T> {
    T add(T c);
}
