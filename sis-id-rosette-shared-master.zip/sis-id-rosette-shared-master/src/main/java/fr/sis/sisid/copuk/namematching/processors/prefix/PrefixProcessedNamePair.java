package fr.sis.sisid.copuk.namematching.processors.prefix;

import fr.sis.sisid.copuk.namematching.processors.model.NamePair;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
public class PrefixProcessedNamePair extends NamePair {

    public PrefixProcessedNamePair(String input, String reference) {
        super(input, reference);
    }
}
