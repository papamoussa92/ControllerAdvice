package fr.sis.sisid.copuk.namematching.processors.dictsearch.model;

import fr.sis.sisid.copuk.namematching.processors.model.NamePair;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

@Getter
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class DictSearchProcessedNamePair extends NamePair {

    private boolean entryMismatch;

    public DictSearchProcessedNamePair(String input, String reference) {
        super(input, reference);
        this.entryMismatch = false;
    }

    public DictSearchProcessedNamePair(String input, String reference, boolean entryMismatch) {
        super(input, reference);
        this.entryMismatch = entryMismatch;
    }

}
