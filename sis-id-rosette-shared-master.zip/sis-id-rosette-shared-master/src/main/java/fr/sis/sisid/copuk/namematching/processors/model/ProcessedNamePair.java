package fr.sis.sisid.copuk.namematching.processors.model;

import fr.sis.sisid.copuk.namematching.processors.NamePairProcessorType;
import fr.sis.sisid.copuk.namematching.scorer.ScoredDecision;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Name pair having been processed by a name pair processor
 * This is a tree structure, it refers to itself through the source attribute
 */
@Getter
@AllArgsConstructor
public class ProcessedNamePair {

    /**
     * Processed name pair
     */
    private NamePair namePair;

    /**
     * Score for the processed name pair
     */
    private ScoredDecision result;

    /**
     * Processor having been applied
     */
    private NamePairProcessorType processor;

    /**
     * Name pair the processor has been applied to
     */
    private ProcessedNamePair source;
}
