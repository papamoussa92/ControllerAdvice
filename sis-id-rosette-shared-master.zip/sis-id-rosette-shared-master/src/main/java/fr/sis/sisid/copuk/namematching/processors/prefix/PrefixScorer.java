package fr.sis.sisid.copuk.namematching.processors.prefix;

import java.math.BigDecimal;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.processors.model.NamePair;
import fr.sis.sisid.copuk.namematching.scorer.BoundedScorer;
import fr.sis.sisid.copuk.namematching.scorer.NamePairScorer;
import fr.sis.sisid.copuk.namematching.scorer.ScoredDecision;
import fr.sis.sisid.copuk.namematching.tools.StringTools;

public class PrefixScorer implements NamePairScorer {

    private final NamePairScorer scorer;

    public PrefixScorer(BigDecimal thresholdMatch, BigDecimal thresholdCloseMatch, MatchingDecision bound) {
        this.scorer = new BoundedScorer(thresholdMatch, thresholdCloseMatch, PrefixProcessedNamePair.class::isInstance,
                bound);
    }

    @Override
    public ScoredDecision scoreNamePair(NamePair np, MatchingDecision bound) {
        var decision =  this.scorer.scoreNamePair(np, bound);
        if(StringTools.tokenize(np.getReference()).stream().findFirst()
                .map(r -> r.equalsIgnoreCase(StringTools.tokenize(np.getInput()).stream().findFirst().orElse(null)))
                .orElse(false)) {
            decision.setLowerBound(MatchingDecision.CLOSE_MATCH);
            if (decision.getDecision().compareTo(MatchingDecision.CLOSE_MATCH) <= 0) {
                decision.setDecision(MatchingDecision.CLOSE_MATCH);
            }
        }
        return decision;
    }

}
