package fr.sis.sisid.copuk.namematching.model;

import fr.sis.sisid.copuk.namematching.processors.NamePairProcessorType;
import fr.sis.sisid.copuk.namematching.scorer.ScoredDecision;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;

@Getter
@ToString
@EqualsAndHashCode
public class MatchingResult {

    private final ScoredDecision score;

    @Setter
    private List<NameMatchingLog> processorLog;

    @Setter
    private NamePairProcessorType namePairProcessorType;
    public MatchingResult(BigDecimal score, MatchingDecision matchingDecision) {
        this.score = new ScoredDecision(score, matchingDecision);
        this.processorLog = new LinkedList<>();
    }


}
