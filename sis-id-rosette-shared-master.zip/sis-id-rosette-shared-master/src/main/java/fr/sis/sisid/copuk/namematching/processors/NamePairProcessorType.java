package fr.sis.sisid.copuk.namematching.processors;

import lombok.Getter;

public enum NamePairProcessorType {

    ORIGINAL("MR-000", "Compare the name as queried by the requester, to the account name."),
    SYNONYMS("MR-005", "ALIASES : Compare the queried name to aliases of the account name."),
    STRUCTURED_INPUT("MR-011", "STRUCTURED_INPUT : Handles structured name input, in CSV format."),
    ACRONYMS("MR-002", "ACRONYMS : Compare the queried name to acronyms of the account name"),
    LEGAL_FORM("MR-003",
            "ENTITY DESCRIPTORS : Identifies entity descriptors in both the queried name and the account name"),
    NATURE_ENTERPRISE("MR-001", "NATURE ENTERPRISE : Allow to delete not pertinent word in the name matching"),
    INVOICE_DISCOUNT("MR-009", "INVOICE DISCOUNT ACCOUNT: Allow to delete prefix"),
    GEOGRAPHY("MR-010", "Identifies geographical descriptors in both the queried name and the account name");

    @Getter
    private String ruleCode;

    @Getter
    private String ruleDescription;

    private NamePairProcessorType(String ruleCode, String ruleDescription) {
        this.ruleCode = ruleCode;
        this.ruleDescription = ruleDescription;

    }
}
