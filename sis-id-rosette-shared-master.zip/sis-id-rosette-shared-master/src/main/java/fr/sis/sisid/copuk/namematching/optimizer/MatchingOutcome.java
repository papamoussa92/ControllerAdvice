package fr.sis.sisid.copuk.namematching.optimizer;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.math.BigDecimal;

@AllArgsConstructor
@Getter
public class MatchingOutcome {
    private String input;
    private String reference;
    private MatchingDecision expectedDecision;
    private MatchingDecision resultDecision;

    private int falsePositive;
    private int falseNegative;
    private int mismatch;
    private BigDecimal score;
    private String ruleLog;
}
