package fr.sis.sisid.copuk.namematching.processors.prefix;

import fr.sis.sisid.copuk.namematching.processors.NamePairProcessor;
import fr.sis.sisid.copuk.namematching.processors.NamePairProcessorType;
import fr.sis.sisid.copuk.namematching.processors.model.NamePair;
import org.apache.commons.lang3.StringUtils;

import java.util.HashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class InvoiceDiscountAccountProcessor implements NamePairProcessor {
    private final InvoiceDiscountAccount invoiceDiscountAccount;

    public InvoiceDiscountAccountProcessor(InvoiceDiscountAccount invoiceDiscountAccount) {
        this.invoiceDiscountAccount = invoiceDiscountAccount;
    }

    @Override
    public Set<NamePair> process(NamePair input) {
        if (StringUtils.isAnyBlank(input.getInput(), input.getReference())) {
            return new HashSet<>();
        }
        String inputNameAccount = searchRadical(input.getInput());
        String referenceNameAccount = searchRadical(input.getReference());
        HashSet<NamePair> resultSet = new HashSet<>();

        if (input.getInput().equals(inputNameAccount) && input.getReference().equals(referenceNameAccount)) {
            resultSet.add(input);
        } else {
            resultSet.add(new PrefixProcessedNamePair(inputNameAccount.trim(), referenceNameAccount.trim()));
        }

        return resultSet;
    }

    @Override
    public NamePairProcessorType getProcessorType() {
        return NamePairProcessorType.INVOICE_DISCOUNT;
    }

    @Override
    public String getReference(String ref) {
        return searchRadical(ref);
    }

    String searchRadical(String nameAccount) {
        String result = nameAccount;
        for (String prefix : this.invoiceDiscountAccount.getPrefixes()) {
            var pattern = Pattern.compile("^" + prefix + "[:\s]+(.*)$", Pattern.CASE_INSENSITIVE);
            final Matcher matcher = pattern.matcher(nameAccount);
            if (matcher.find() ) {
                String found = matcher.group(1).trim();
                if(found.length() < result.length()) {
                    result = found;
                }
            }
        }
        return result;
    }
}
