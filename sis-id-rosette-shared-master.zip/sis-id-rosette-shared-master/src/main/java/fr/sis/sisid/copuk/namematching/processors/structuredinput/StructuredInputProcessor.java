package fr.sis.sisid.copuk.namematching.processors.structuredinput;

import java.util.Collections;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import fr.sis.sisid.copuk.namematching.processors.NamePairProcessor;
import fr.sis.sisid.copuk.namematching.processors.NamePairProcessorType;
import fr.sis.sisid.copuk.namematching.processors.model.NamePair;

/**
 * Input names can be in a structured csv format,
 * either in the form "<greeting>,<firstname>,<lastname>"
 * or
 * ",,<input name>"
 * This processor simply removes the commas
 *
 */
public class StructuredInputProcessor implements NamePairProcessor {

    @Override
    public Set<NamePair> process(NamePair input) {
        return Collections.singleton(
                new NamePair(
                        StringUtils.defaultIfBlank(input.getInput(), "").replace(",", " ").trim(),
                        input.getReference()));
    }

    @Override
    public NamePairProcessorType getProcessorType() {
        return NamePairProcessorType.STRUCTURED_INPUT;
    }

}
