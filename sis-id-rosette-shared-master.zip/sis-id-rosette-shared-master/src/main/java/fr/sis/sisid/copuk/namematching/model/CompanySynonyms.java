package fr.sis.sisid.copuk.namematching.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CompanySynonyms {
    private Long id;
    private String accountName;
    private String tradingName;
}

