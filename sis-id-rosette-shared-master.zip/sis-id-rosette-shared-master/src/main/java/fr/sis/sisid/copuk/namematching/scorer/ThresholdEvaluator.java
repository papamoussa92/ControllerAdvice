package fr.sis.sisid.copuk.namematching.scorer;

import java.math.BigDecimal;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

/**
 * Makes a matching decision from a name matching score,
 * according to threshold parameters
 */
@AllArgsConstructor
@ToString
@Slf4j
@Getter
public class ThresholdEvaluator {
    private double thresholdMatch;
    private double thresholdCloseMatch;

    public ScoredDecision evaluateThreshold(String input, String target, BigDecimal score) {
        if (score == null) {
            log.warn("No result for matching algorithm with {} and {}", input, target);
            throw new EvaluatorException("Can not evaluate threshold, no score");
        } else if (score.compareTo(BigDecimal.valueOf(thresholdMatch)) >= 0) {
            log.trace("Matching with {} and {}", input, target);
            return new ScoredDecision(score, MatchingDecision.MATCH);
        } else if (score.compareTo(BigDecimal.valueOf(thresholdCloseMatch)) >= 0) {
            log.trace("Close match with {} and {}", input, target);
            return new ScoredDecision(score, MatchingDecision.CLOSE_MATCH);
        } else {
            log.trace("No match with {} and {}", input, target);
            return new ScoredDecision(score, MatchingDecision.NO_MATCH);
        }
    }
}