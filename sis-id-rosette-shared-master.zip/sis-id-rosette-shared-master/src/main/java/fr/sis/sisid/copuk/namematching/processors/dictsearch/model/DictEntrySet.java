package fr.sis.sisid.copuk.namematching.processors.dictsearch.model;

import java.util.Set;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

/**
 * A set of entries
 */
@Getter
@Setter
@RequiredArgsConstructor
public class DictEntrySet {

    private String country;

    private Set<DictEntry> forms;
}
