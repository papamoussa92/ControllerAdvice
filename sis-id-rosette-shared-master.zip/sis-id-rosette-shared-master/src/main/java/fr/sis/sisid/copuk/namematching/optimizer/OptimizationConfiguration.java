package fr.sis.sisid.copuk.namematching.optimizer;

import fr.sis.sisid.copuk.namematching.RuleBasedNameMatchingProvider;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NonNull;
import lombok.ToString;

import java.math.BigDecimal;

@Getter
@AllArgsConstructor
@ToString class OptimizationConfiguration {
    @NonNull RuleBasedNameMatchingProvider provider;
    @NonNull BigDecimal thresholdMatch;
    @NonNull BigDecimal thresholdCloseMatch;


}
