package fr.sis.sisid.copuk.namematching.scorer;

import fr.sis.sisid.copuk.namematching.model.MatchingDecision;
import fr.sis.sisid.copuk.namematching.processors.model.NamePair;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;
import me.xdrop.fuzzywuzzy.FuzzySearch;

import java.math.BigDecimal;

/**
 * Scores a name pair using fuzzy wuzzy
 */
@AllArgsConstructor
@ToString
@Getter
public class FuzzyScorer implements NamePairScorer {

    private BigDecimal thresholdMatch;

    private BigDecimal thresholdCloseMatch;

    @Override
    public ScoredDecision scoreNamePair(NamePair np, MatchingDecision bound) {
        String input = np.getInput().toUpperCase();
        String reference = np.getReference().toUpperCase();
        int ratio = FuzzySearch.ratio(input, reference);
        var decision = evaluateThreshold(input, reference, BigDecimal.valueOf((ratio / 100d)));
        decision.setUpperBound(bound);
        if (decision.getDecision().compareTo(bound) >= 0) {
            decision.setDecision(bound);
        }
        return decision;
    }

    private ScoredDecision evaluateThreshold(String input, String target, BigDecimal score) {
        return new ThresholdEvaluator(thresholdMatch.doubleValue(), thresholdCloseMatch.doubleValue())
                .evaluateThreshold(input, target, score);
    }

}
