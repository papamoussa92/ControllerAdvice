package fr.sis.sisid.copuk.namematching.processors.dictsearch;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;

import fr.sis.sisid.copuk.namematching.processors.NamePairProcessor;
import fr.sis.sisid.copuk.namematching.processors.NamePairProcessorType;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.index.DictSearchIndex;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.index.DictSearchResult;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.model.DictEntry;
import fr.sis.sisid.copuk.namematching.processors.dictsearch.model.DictSearchProcessedNamePair;
import fr.sis.sisid.copuk.namematching.processors.model.NamePair;
import fr.sis.sisid.copuk.namematching.tools.StringTools;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DictSearchProcessorImpl implements NamePairProcessor {

    private final DictSearchIndex index;

    private final NamePairProcessorType processorType;

    private final BigDecimal matchThreshold;

    public DictSearchProcessorImpl(DictSearchIndex index, NamePairProcessorType processorType,
            BigDecimal matchThreshold) {
        this.index = index;
        this.processorType = processorType;
        this.matchThreshold = matchThreshold;
    }

    /**
     * Query the dictionary index
     * @param input text to search the dictionary term (ex Ltd or Limited) from.
     * @return A descriptive result of the likelihood of a dictionary term in the text
     */
    public List<DictSearchResult> searchEntry(String input) {
        List<DictSearchResult> results = new ArrayList<>();
        String searchInput = input;
        // Iterate until no more valid result is found
        while(true){
            DictSearchResult result = findBestResult(searchInput);
            if (result != null && result.getScore().orElse(BigDecimal.ZERO).compareTo(matchThreshold) > 0) {
                results.add(result);
                searchInput = searchInput.replace(result.getQuery(), "");
            } else {
                break;
            }
        }

        log.debug("Best dictionary term result for {} -> \n{}", input, results);
        return results;
    }

    public DictSearchResult findBestResult(String input) {
        // split the company name into multiple tokens
        List<String> ngrams = StringTools.ngramTokens(StringTools.tokenize(input));
        DictSearchResult bestResult = new DictSearchResult();
        bestResult.setFound(false);
        // query the index with each token keep the best scoring token
        for (String ngram : ngrams) {
            var result = this.index.findEntry(ngram);
            if (bestResult.compareTo(result) < 0) {
                bestResult = result;
                if (bestResult.getScore().isPresent()
                        && bestResult.getScore().orElse(BigDecimal.ZERO).equals(BigDecimal.ONE)) {
                    break;
                }
            }
        }
        return bestResult;
    }

    @Override
    public Set<NamePair> process(NamePair input) {
        // look for dictionary term in both names
        String normalizedInput = StringTools.normalize(input.getInput());
        String normalizedReference = StringTools.normalize(input.getReference());

        List<DictSearchResult> inputDictTerms = searchEntry(normalizedInput);
        List<DictSearchResult> referenceDictTerms = searchEntry(normalizedReference);

        String processedInput = normalizedInput;
        String processedReference = normalizedReference;
        // strip dictionary terms from both names, if any is found
        Set<NamePair> resultSet = new HashSet<>();

        boolean bothFormsPresent = !inputDictTerms.isEmpty() && !referenceDictTerms.isEmpty();
        if (!inputDictTerms.isEmpty()) {
            for (var inputDictTerm: inputDictTerms) {
                processedInput = StringTools.removeDistinctWordIgnoreCase(processedInput,
                        inputDictTerm.getQuery());
            }
            // add [processed input - original reference ] to the result set
            resultSet.add(new DictSearchProcessedNamePair(processedInput, input.getReference(), true));
        }
        if (!referenceDictTerms.isEmpty()) {
            for (var referenceDictTerm: referenceDictTerms) {
                processedReference = StringTools.removeDistinctWordIgnoreCase(processedReference,
                        referenceDictTerm.getQuery());
            }
            // add [original input - processed reference ] to the result set
            resultSet.add(new DictSearchProcessedNamePair(input.getInput(), processedReference, true));
        }
        if (bothFormsPresent) {
            boolean dictTermMismatch = inputDictTerms.size() != referenceDictTerms.size() || !inputDictTerms.stream().allMatch(
                    termInReference(referenceDictTerms));

            // add [processed input - processed reference] to the result set
            resultSet.add(new DictSearchProcessedNamePair(processedInput, processedReference, dictTermMismatch));
        }
        resultSet.add(input);
        return resultSet;
    }

    private static Predicate<DictSearchResult> termInReference(List<DictSearchResult> referenceDictTerms) {
        return inputDictTerm -> inputDictTerm.getResult().stream().map(DictEntry::getName).anyMatch(
                name -> referenceDictTerms.stream().anyMatch(
                        referenceDictTerm -> referenceDictTerm.getResult().stream().map(DictEntry::getName)
                                .anyMatch(n -> n.equalsIgnoreCase(name))));
    }

    @Override
    public NamePairProcessorType getProcessorType() {
        return this.processorType;
    }

}
