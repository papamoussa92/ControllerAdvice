package fr.sis.sisid.copuk.tools;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.net.URI;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClient;

import fr.sis.sisid.copuk.tools.errors.JOSEValidationException;
import fr.sis.sisid.copuk.tools.errors.MalformedJOSESignatureException;
import fr.sis.sisid.copuk.tools.errors.MissingJOSEClaimException;
import fr.sis.sisid.copuk.tools.errors.MissingSignatureException;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@ExtendWith(MockitoExtension.class)
class JoseDecoderTest {

    List<String> supportedAlgorithms;

    List<JoseHeaderValidator<?>> validators;

    String jwksURI;

    @Mock
    private WebClient webClientMock;
    @Mock
    private WebClient.RequestHeadersSpec requestHeadersMock;
    @Mock
    private WebClient.RequestHeadersUriSpec requestHeadersUriMock;
    @Mock
    private WebClient.ResponseSpec responseMock;

    final String PAYLOAD = "{\"hello\":\"world\"}";

    final String VALID_SIGNATURE = "eyJjdHkiOiJhcHBsaWNhdGlvblwvanNvbiIsImI2NCI6ZmFsc2UsInR5cCI6IkpPU0UiLCJodHRwOlwvXC9vcGVuYmFua2luZy5vcmcudWtcL2lzcyI6Im9yZy1pZFwvc3NhLWlkIiwiYWxnIjoiUFMyNTYiLCJraWQiOiJPWE9LbTlVOGM0OEgwOXp3NDZQOE81NGw0UUE9In0..MIw77bze67tTuHJgrJt46dQi8xhxVh-kFO7NpkTEWbY8ugfmsJWJv_0yBkbG4DLl3W6eGcOrETpwCzFtUYBFl51V9iTonAbkeI8GvcdF_UWirsLvM0n2FdUZO6aycbztlJ00sOtUdTNCHUpgawo893AvtevalJ6LeNdr6MUVlBdLkIgYpTzmDZI6q3x39RBs3DMhB5usSdzKtjGRdOUpFXgpMBjsU8O-aCSWJuymDMyXU0pcu6V5miHabqZYnXRSA4Ps4vLFTlirRLryba-BAs1e76VPGaKmraOjx9EKzghbDBiCjhFnU6t63g-6EhGsYsX5ek4NJBq3o-o0R5HKMg";
    private String validJWKS;

    @BeforeEach
    void setup() {
        validJWKS = """
                  {
                  "keys": [
                    {
                      "kty": "RSA",
                      "e": "AQAB",
                      "use": "sig",
                      "kid": "OXOKm9U8c48H09zw46P8O54l4QA=",
                      "alg": "PS256",
                      "n": "pZpBF_gunYuXkolDNRuaCScWMVtKE4iyDYnPgQQcWd1_a0PB9JrdE96lJhSjIkojeo4Lo5hW0bU7AeQ1iOnW5g-K1WjHXpbl9Iu2iW8S7ybHYdPbQKhA6ybbyK7XFK6cazU2TTtieUMtHP3rVei6C4SY0blEcOgOLGuXroEJKZ_nqy-9rDUuQxxyIKA7HYeK-Ub_fh2EyGlS-WoK_BJBSCBCEpI5N-ZZjJXRY55JItBAd4kyhiN4Bm8b95ajut8kyfmcbKu_VFx2gfwE3DKrWJZ4SbtJ28ZghK918eu0nEV14I6nItFU_M1IY0v3IgIIegjA6rl8Pqa5HdbVdM6hdw"
                    }
                  ]
                }
                """;
        jwksURI = "http://example.com";
        this.supportedAlgorithms = Collections.singletonList("PS256");
        validators = Arrays.asList(
                new JoseHeaderValidator<>("cty", cty -> Arrays.asList("application/json", "json").contains(cty)),
                new JoseRequiredHeaderValidator<>("http://openbanking.org.uk/iss", "org-id/ssa-id"::equals));
    }

    void mockWebClient() {
        when(webClientMock.get()).thenReturn(requestHeadersUriMock);
        when(requestHeadersUriMock.uri(URI.create(jwksURI))).thenReturn(requestHeadersMock);
        when(requestHeadersMock.accept(any(MediaType.class))).thenReturn(requestHeadersMock);
        when(requestHeadersMock.retrieve()).thenReturn(responseMock);
    }

    @Test
    void testValidate_okToken() {
        this.mockWebClient();
        var jwks = validJWKS;
        when(responseMock.toEntity(String.class)).thenReturn(Mono.just(new ResponseEntity<>(jwks, HttpStatus.OK)));

        var decoder = new JoseDecoder(jwksURI, supportedAlgorithms, webClientMock, validators);

        StepVerifier.create(decoder.validate(
                VALID_SIGNATURE,
                PAYLOAD))
                .expectNext(Boolean.TRUE)
                .verifyComplete();
    }

    @Test
    void testValidate_validatorFails() {
        this.mockWebClient();
        var jwks = validJWKS;
        when(responseMock.toEntity(String.class)).thenReturn(Mono.just(new ResponseEntity<>(jwks, HttpStatus.OK)));

        var decoder = new JoseDecoder(jwksURI, supportedAlgorithms, webClientMock, validators);

        StepVerifier.create(decoder.validate(
                "eyJjdHkiOiJ0ZXh0XC9odG1sIiwiYjY0IjpmYWxzZSwidHlwIjoiSk9TRSIsImh0dHA6XC9cL29wZW5iYW5raW5nLm9yZy51a1wvaXNzIjoib3JnLWlkXC9zc2EtaWQiLCJhbGciOiJQUzI1NiIsImtpZCI6Ik9YT0ttOVU4YzQ4SDA5enc0NlA4TzU0bDRRQT0ifQ..NUUrdBeHTLlyKvXISsAmwwqePnaT5cBCHWqAMKacUHpC8hT-fQqhoXWR9aikr7kd1pRQYSWyAmtK0u-6KPWJViq6dezYCQs80GN8hyJbnujex9z3a_8mR4KaU203qeA1d86q7g8Pjc1JuLcgRhwG3GrnGlqWE8yRWowzIuVpVVsaWnFyy5Ce3ATqD1Jq5p7hpTpppHzfsiKVS3LcZT6eC4wclOy2k0e5tzGadvwKgttYj-RehPmrAatEK6LYvlReBD6hYqDJeHS-LILKdKtvFh7vuvgMD_d5vt83s694QUIF9en1oLICCB-eZGA1A63DkrMrm4sHeMegWfVzHP5Qsg",
                PAYLOAD))
                .expectErrorMatches(throwable -> throwable instanceof JOSEValidationException)
                .verify();
    }

    @Test
    void testValidate_missingRequiredHeader() {
        this.mockWebClient();
        var jwks = """
                  {
                  "keys": [
                    {
                      "kty": "RSA",
                      "e": "AQAB",
                      "use": "sig",
                      "kid": "OXOKm9U8c48H09zw46P8O54l4QA=",
                      "alg": "PS256",
                      "n": "pZpBF_gunYuXkolDNRuaCScWMVtKE4iyDYnPgQQcWd1_a0PB9JrdE96lJhSjIkojeo4Lo5hW0bU7AeQ1iOnW5g-K1WjHXpbl9Iu2iW8S7ybHYdPbQKhA6ybbyK7XFK6cazU2TTtieUMtHP3rVei6C4SY0blEcOgOLGuXroEJKZ_nqy-9rDUuQxxyIKA7HYeK-Ub_fh2EyGlS-WoK_BJBSCBCEpI5N-ZZjJXRY55JItBAd4kyhiN4Bm8b95ajut8kyfmcbKu_VFx2gfwE3DKrWJZ4SbtJ28ZghK918eu0nEV14I6nItFU_M1IY0v3IgIIegjA6rl8Pqa5HdbVdM6hdw"
                    }
                  ]
                }
                """;
        when(responseMock.toEntity(String.class)).thenReturn(Mono.just(new ResponseEntity<>(jwks, HttpStatus.OK)));

        var decoder = new JoseDecoder(jwksURI, supportedAlgorithms, webClientMock, validators);

        StepVerifier.create(decoder.validate(
                "eyJiNjQiOmZhbHNlLCJodHRwOlwvXC9vcGVuYmFua2luZy5vcmcudWtcL2lhdCI6MTY1NDI2ODUxOSwiaHR0cDpcL1wvb3BlbmJhbmtpbmcub3JnLnVrXC90YW4iOiJvcGVuYmFua2luZy5vcmcudWsiLCJraWQiOiJPWE9LbTlVOGM0OEgwOXp3NDZQOE81NGw0UUE9IiwiY3R5IjoiYXBwbGljYXRpb25cL2pzb24iLCJ0eXAiOiJKT1NFIiwiYWxnIjoiUFMyNTYifQ..NtZd3aJkGBoEmFRblX_Y_InTc8t8Em9jvtC4NlJzd3S7mmtr-vmOT4iJRa9uk9GdeRJrDXPiIoxcWzNBDPbdC7MTRLJiUil8O63ev6foMyXQJIAVNPEgEPbSIwJOoIZfwD1qGDYWtkih_OUKm2e5xl7xeQVOZPxiNTS-SuxfmTl0ZFTGGFP3tewSWYCPB6hCpKH1E1E4IKXT268LQnnv4xNVsYX0QJp-_3a2w-I5-thu-cefXZmXi6fSFM3pZ8IjwLQ8a3UD1Yul6Pt05TK03O2VCK3D8K5n3AdxaVgft4PE04BHqELwKxhGLOiOqkEdG3UEzYrMC-vfMBeNrOAGdw",
                PAYLOAD))
                .expectErrorMatches(throwable -> throwable instanceof MissingJOSEClaimException)
                .verify();
    }

    @Test
    void testValidate_wrong_algorithm() {
        this.mockWebClient();
        var jwks = validJWKS;
        when(responseMock.toEntity(String.class)).thenReturn(Mono.just(new ResponseEntity<>(jwks, HttpStatus.OK)));

        var decoderWrongAlgorithm = new JoseDecoder(this.jwksURI, Collections.singletonList("ES256"),
                webClientMock, this.validators);

        StepVerifier.create(decoderWrongAlgorithm.validate(VALID_SIGNATURE, PAYLOAD))
                .expectErrorMatches(throwable -> throwable instanceof JOSEValidationException)
                .verify();
    }

    @Test
    void testValidate_withCustomCrit() {
        this.mockWebClient();
        var jwks = """
                  {
                  "keys": [
                    {
                      "kty": "RSA",
                      "e": "AQAB",
                      "use": "sig",
                      "kid": "OXOKm9U8c48H09zw46P8O54l4QA=",
                      "alg": "PS256",
                      "n": "pZpBF_gunYuXkolDNRuaCScWMVtKE4iyDYnPgQQcWd1_a0PB9JrdE96lJhSjIkojeo4Lo5hW0bU7AeQ1iOnW5g-K1WjHXpbl9Iu2iW8S7ybHYdPbQKhA6ybbyK7XFK6cazU2TTtieUMtHP3rVei6C4SY0blEcOgOLGuXroEJKZ_nqy-9rDUuQxxyIKA7HYeK-Ub_fh2EyGlS-WoK_BJBSCBCEpI5N-ZZjJXRY55JItBAd4kyhiN4Bm8b95ajut8kyfmcbKu_VFx2gfwE3DKrWJZ4SbtJ28ZghK918eu0nEV14I6nItFU_M1IY0v3IgIIegjA6rl8Pqa5HdbVdM6hdw"
                    }
                  ]
                }
                """;

        when(responseMock.toEntity(String.class)).thenReturn(Mono.just(new ResponseEntity<>(jwks, HttpStatus.OK)));

        var decoder = new JoseDecoder(jwksURI, supportedAlgorithms, webClientMock, validators);

        var tokenWCrit = "eyJiNjQiOmZhbHNlLCJjcml0IjpbImh0dHA6XC9cL29wZW5iYW5raW5nLm9yZy51a1wvaXNzIl0sImtpZCI6Ik9YT0ttOVU4YzQ4SDA5enc0NlA4TzU0bDRRQT0iLCJjdHkiOiJhcHBsaWNhdGlvblwvanNvbiIsInR5cCI6IkpPU0UiLCJodHRwOlwvXC9vcGVuYmFua2luZy5vcmcudWtcL2lzcyI6Im9yZy1pZFwvc3NhLWlkIiwiYWxnIjoiUFMyNTYifQ..aCL8-8ptNw6spNDQcqQbeK0148kpCE3N85q-7fVr9Bu264ap0JjDrVvl5vCzPIm_1b4FcynM6QbsmRT-vu3kR5ivM9h2_jFY4k3AxMwum2LkVsV9d0m5spMAQc6e2diVhTLo9H-lDl_K0GyQbbLwv2kpiopuBfL_HP1vI5ic2lszyJa1Hr17dj0s_-iiz1VsWVYS8AFws1PHPWdZlqjBAXCS1QawXFvDmDoC2vAGBkcG-rfDeIlVNE34sFgPZFN2MNKBJHRBUQvLY_5t0YVL2moj2_H4TodzVU9b0EnadIqiMJl1LzdUEbYEHy8U6XF54Qk8hmH3qBF9LQN8xMQb1A";
        StepVerifier.create(decoder.validate(tokenWCrit, PAYLOAD))
                .expectNext(Boolean.TRUE)
                .verifyComplete();
    }

    @Test
    void testValidate_payloadHasSpaces() {
        this.mockWebClient();
        when(responseMock.toEntity(String.class)).thenReturn(Mono.just(new ResponseEntity<>(validJWKS, HttpStatus.OK)));
        var tokenWSpaces = "eyJiNjQiOmZhbHNlLCJodHRwOlwvXC9vcGVuYmFua2luZy5vcmcudWtcL2lhdCI6MTY1NDI2ODUxOSwiaHR0cDpcL1wvb3BlbmJhbmtpbmcub3JnLnVrXC90YW4iOiJvcGVuYmFua2luZy5vcmcudWsiLCJjcml0IjpbImh0dHA6XC9cL29wZW5iYW5raW5nLm9yZy51a1wvaWF0IiwiaHR0cDpcL1wvb3BlbmJhbmtpbmcub3JnLnVrXC90YW4iLCJodHRwOlwvXC9vcGVuYmFua2luZy5vcmcudWtcL2lzcyJdLCJraWQiOiJPWE9LbTlVOGM0OEgwOXp3NDZQOE81NGw0UUE9IiwiY3R5IjoiYXBwbGljYXRpb25cL2pzb24iLCJ0eXAiOiJKT1NFIiwiaHR0cDpcL1wvb3BlbmJhbmtpbmcub3JnLnVrXC9pc3MiOiIwMDE0SDAwMDAzQVJuVG1RQUxcLzVkNWMwOGUwOGM2YTQxZTkiLCJhbGciOiJQUzI1NiJ9..FIKhslyFaSTX65PbEPyfY1uNl4JVealnALfEd-QnuOCJYD0KWPC65qyzIg_hbqlY4QJdsK449oYaPTYocAi7YjOmNfSqs2uaab3kMYFCMBIbIPGlVQOoM1Nc4V4gSUnn9n-vfQybOcCmbjlx2GNyFAHxgkNzt1TMXSTVvDv4q-3mQ8qtoFbYvuKavvRjgFhv11o_U4anovQeEUkSZ7uOOs0n1oAtUxuYAb35xHLqnMLXhqkWx_87sqbJwHg4y5HuCiXPbB1LeZQ-Q_MwOI6hsfxGarWH-47iWlz3JWbTvB0tuOtgNdNYtZnS577DhGYO4twUAlGMJvDi40WPO1eNfg";
        var payloadWSpaces = "{\"Data\":{\"SchemeName\":\"SortCodeAccountNumber\",\"AccountType\":\"Business\",\"Identification\":\"40638412345678\",\"Name\":\"hello world\"}}";
        var decoder = new JoseDecoder(this.jwksURI, this.supportedAlgorithms, webClientMock,
                new LinkedList<>());
        StepVerifier.create(decoder.validate(tokenWSpaces, payloadWSpaces))
                .expectNext(Boolean.TRUE)
                .verifyComplete();
    }

    @Test
    void testValidate__unreachableJwks() {
        this.mockWebClient();
        when(responseMock.toEntity(String.class)).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.NOT_FOUND)));

        var decoderUnreachableJwks = new JoseDecoder(this.jwksURI, this.supportedAlgorithms, webClientMock,
                this.validators);
        StepVerifier.create(decoderUnreachableJwks.validate(VALID_SIGNATURE, PAYLOAD))
                .expectErrorMatches(throwable -> throwable instanceof IOException)
                .verify();
    }

    @Test
    void testValidate_ES256Token() {
        this.mockWebClient();
        var es256Jwks = """
                { "keys": [
                {
                    "kty": "EC",
                    "use": "sig",
                    "crv": "P-256",
                    "kid": "r6XyzVloXZtNauLh_ElJArIC6gEjQtcSmMiexoOZ0n4",
                    "x": "pdwj8HEDSJd8Dv0zZAQtUunpu8h8LXszgDpz2pW7tZQ",
                    "y": "gk4DnkSAtAmA8EX7HKoFEHRbD3D-B0KDZ1EEiMDB8Xw",
                    "alg": "ES256"
                }]}
                """;

        when(responseMock.toEntity(String.class)).thenReturn(Mono.just(new ResponseEntity<>(es256Jwks, HttpStatus.OK)));
        String token = "eyJhbGciOiJFUzI1NiIsInR5cCI6IkpPU0UiLCJraWQiOiJyNlh5elZsb1hadE5hdUxoX0VsSkFySUM2Z0VqUXRjU21NaWV4b09aMG40IiwiYjY0Ijp0cnVlfQ..7FhqAYXQheLUEABPZTlERQc-y5Ky9iF89IBNtQtobuZ6Jvtqmns5TfIzMm59OAwu6caXA_tpTRI4XpLwBfqpng";
        var decoder = new JoseDecoder(this.jwksURI, Collections.singletonList("ES256"), webClientMock,
                new LinkedList<>());
        StepVerifier.create(decoder.validate(token, PAYLOAD))
                .expectNext(Boolean.TRUE)
                .verifyComplete();
    }

    @Test
    void testValidate_HS256Token() {
        this.mockWebClient();
        var hs256Jwks = """
                {
                    "keys": [
                        {
                            "kty": "oct",
                            "use": "sig",
                            "kid": "DtxR2HEX9NU0pFXX5GWQ94CDbi5ge8vnIiZHWCunac4",
                            "k": "sTmpL75jj9DhjevcbSqshc0l40_rmjL0ftHVRepkcTNlDZ0cWDDiU_V6Rc54om80cG_myDjM3H9pDTAy9UhSwkT-VkgDha7RdcqDUr4Lc9cyr2J6bv14ptN55Ln0LIreh1EhIumucrwbll7hz8doUcnbn3HGzM0MDfKPU6goBVk0qecjhiU2H2CQyIEIDP4Jf6CX6Y3wCKl3wfphoE6bKPnaLh8uPLfsq3tiUgRIAlHvxCXMRPct-rFOhqp9sGcRc9e0P2lCUS5LsezTLWM1HcDh1NjYuT_M0CkKa9nyfU7Xi6J0nhILw9lXaiKCvnDUhszA86t0323okAAqyLwqJg",
                            "alg": "HS256"
                        }
                    ]
                }
                """;

        when(responseMock.toEntity(String.class)).thenReturn(Mono.just(new ResponseEntity<>(hs256Jwks, HttpStatus.OK)));

        String token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpPU0UiLCJraWQiOiJEdHhSMkhFWDlOVTBwRlhYNUdXUTk0Q0RiaTVnZTh2bklpWkhXQ3VuYWM0IiwiYjY0Ijp0cnVlfQ..U5oxlQy9dKyWwSwo1lgXJ9nh5gHqvu2UiTNVDUokWjk";
        var decoder = new JoseDecoder(this.jwksURI, Collections.singletonList("HS256"), webClientMock,
                new LinkedList<>());
        StepVerifier.create(decoder.validate(token, PAYLOAD))
                .expectNext(Boolean.TRUE)
                .verifyComplete();
    }

    @Test
    void testInit_malformedJwksUrl() {
        var list = new LinkedList<JoseHeaderValidator<?>>();
        var webClient = WebClient.builder().build();
        Assertions
                .assertThatThrownBy(
                        () -> new JoseDecoder("google.com", supportedAlgorithms, webClient, list))
                .isInstanceOf(IllegalArgumentException.class);

    }

    @Test
    void testValidate_nullSignature() {
        this.mockWebClient();
        var jwks = validJWKS;
        when(responseMock.toEntity(String.class)).thenReturn(Mono.just(new ResponseEntity<>(jwks, HttpStatus.OK)));
        var decoder = new JoseDecoder(jwksURI, supportedAlgorithms, webClientMock, validators);
        StepVerifier.create(decoder.validate(
                null,
                PAYLOAD))
                .expectError(MissingSignatureException.class)
                .verify();
    }

    @Test
    void testValidate_malformedSignature() {
        this.mockWebClient();
        var jwks = validJWKS;
        when(responseMock.toEntity(String.class)).thenReturn(Mono.just(new ResponseEntity<>(jwks, HttpStatus.OK)));
        var decoder = new JoseDecoder(jwksURI, supportedAlgorithms, webClientMock, validators);
        StepVerifier.create(decoder.validate(
                "not a jose signature",
                PAYLOAD))
                .expectError(MalformedJOSESignatureException.class)
                .verify();
    }

    @Test
    void testValidate_emptyJwks() {
        this.mockWebClient();
        when(responseMock.toEntity(String.class)).thenReturn(Mono.just(new ResponseEntity<>("", HttpStatus.OK)));
        var decoder = new JoseDecoder(jwksURI, supportedAlgorithms, webClientMock, validators);
        StepVerifier.create(decoder.validate(
                VALID_SIGNATURE,
                PAYLOAD))
                .expectError(IOException.class)
                .verify();
    }
}
