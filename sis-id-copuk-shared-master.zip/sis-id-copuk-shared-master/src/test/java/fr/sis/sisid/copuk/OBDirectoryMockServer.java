package fr.sis.sisid.copuk;

import java.util.HashMap;
import java.util.Map;

import org.mockserver.client.MockServerClient;
import org.mockserver.configuration.Configuration;
import org.slf4j.event.Level;
import org.testcontainers.containers.BindMode;
import org.testcontainers.containers.MockServerContainer;
import org.testcontainers.containers.wait.strategy.Wait;
import org.testcontainers.utility.DockerImageName;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class OBDirectoryMockServer {

    private static final String MOCKSERVER_VERSION = "mockserver/mockserver:5.13.2";

    private static MockServerContainer mockServerContainer;

    private static final boolean REUSE_CONTAINERS = false;

    public static MockServerContainer getMockServerContainer() {
        if (mockServerContainer != null && mockServerContainer.isRunning()) {
            return mockServerContainer;
        }
        log.info("starting mockserver container ...");
        Map<String, String> mockServerProperties = new HashMap<>();
        mockServerProperties.put("MOCKSERVER_CERTIFICATE_AUTHORITY_PRIVATE_KEY", "/config/CA-key.pem");
        mockServerProperties.put("MOCKSERVER_CERTIFICATE_AUTHORITY_X509_CERTIFICATE", "/config/CA-cert.pem");
        mockServerProperties.put("MOCKSERVER_TLS_X509_CERTIFICATE_PATH", "/config/ssl-cert.pem");
        mockServerProperties.put("MOCKSERVER_TLS_PRIVATE_KEY_PATH", "/config/ssl-key.pem");
        mockServerProperties.put("MOCKSERVER_PROACTIVELY_INITIALISE_TLS", "true");
        mockServerProperties.put("MOCKSERVER_TLS_MUTUAL_AUTHENTICATION_REQUIRED", "true");

        mockServerContainer = new MockServerContainer(DockerImageName.parse(MOCKSERVER_VERSION))
                .withReuse(REUSE_CONTAINERS)
                .withEnv(mockServerProperties)
                .withLabel("reuse.UUID", "09f5294e-077a-11ed-b9f2-6b51e1512d3c")
                .withClasspathResourceMapping("certs/mockserver", "/config", BindMode.READ_ONLY)
                .waitingFor(Wait.forListeningPort());
        log.info("... mockserver container started");
        return mockServerContainer;
    }

    public static MockServerClient getMockServerClient() {
        if (mockServerContainer == null || !mockServerContainer.isRunning()) {
            log.error("mockserver down");
            throw new RuntimeException("mockserver is not running");
        }

        var config = Configuration.configuration()
                .controlPlaneTLSMutualAuthenticationRequired(true)
                .controlPlaneTLSMutualAuthenticationCAChain("certs/mockserver-client/CA-cert.pem")
                .controlPlanePrivateKeyPath("certs/mockserver-client/client-key.pem")
                .controlPlaneX509CertificatePath("certs/mockserver-client/client-cert.pem")
                .logLevel(Level.DEBUG);

        return new MockServerClient(config, mockServerContainer.getContainerIpAddress(),
                mockServerContainer.getServerPort()).withSecure(true);
    }
}
