package fr.sis.sisid.copuk.tools;

import java.text.ParseException;
import java.time.Instant;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.jwk.JWK;

import fr.sis.sisid.copuk.tools.ResponseSigner.ResponseSignerBuilder;

class ResponseSignerTest {

    private ResponseSignerBuilder signerBuilder;

    private final String PAYLOAD = """
            {
              "hello": "world"
            }
            """;

    private final String PRIVATE_KEY = """
            -----BEGIN PRIVATE KEY-----
            MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQClmkEX+C6di5eS
            iUM1G5oJJxYxW0oTiLINic+BBBxZ3X9rQ8H0mt0T3qUmFKMiSiN6jgujmFbRtTsB
            5DWI6dbmD4rVaMdeluX0i7aJbxLvJsdh09tAqEDrJtvIrtcUrpxrNTZNO2J5Qy0c
            /etV6LoLhJjRuURw6A4sa5eugQkpn+erL72sNS5DHHIgoDsdh4r5Rv9+HYTIaVL5
            agr8EkFIIEISkjk35lmMldFjnkki0EB3iTKGI3gGbxv3lqO63yTJ+Zxsq79UXHaB
            /ATcMqtYlnhJu0nbxmCEr3Xx67ScRXXgjqci0VT8zUhjS/ciAgh6CMDquXw+prkd
            1tV0zqF3AgMBAAECggEBAJ0N4DIlU8BihQuaVjzlwn5vrWJ925EPER451qvbBDBO
            GuvVxPqAbK7Ndv7Yj6aTfXZbhLpQXfZg1GeE0SjZ7M8famHfD0WsAsacQi+xQdnB
            g1JKJCP77iWWItb+ykh5GSuruaYhbdDnXr+iKTC+mMMXq/8qn7gcvGRwXdhH1DK+
            R8hSC9us15rWf/3OlCgDIVAq5Ts8MvDc1ZaA1JbS4pOb0GgYcvf9vsUh5+5i67Tm
            9zkSXeEAVK5vrOcvqxTajS+rWuTrU1+4j3XpnQpbOX9mBKh9KvPBvs2e/eIVbYWd
            cFqycmxwGp4A+ZRnbAeWoIVbjQkuAjK8e2f2hgWvjtECgYEA0qlXp+K8bS95QEKi
            aAtGgO4/AP8GoaAKOxkoB7BrDeEIyKgMf1C6yMJIe+Gw9gZw6qTSQIUG8x0fPCgz
            b+wRJ5YvCejWOrqOiAmkGTs+Skbz28AvznE25MfGP8Mgn+yuFXogR8I3S1K2OLQT
            4Gk6Z4uo2UOhXtA6TlomQHso+vUCgYEAyT5VYNlkYJlmNVmzlEHUQ7NyuzHW6dNm
            yQt8sWxkO0ab9afwO+g0hmQJpkSNq1HfdETl0lVXDHU+Ihg0oDiE8jIqkBNVCwi/
            rPRZD8AwxQeWWosziiyaQ5ntPev0yhcRcQXmTJmnNqyarvPswQvrUlxnbJiskT+8
            +u/muk6gvzsCgYA8vtwp6zXOfkwGfbB7NBUmhIziaqes34tTs1NZtEOKgwOXaO4B
            oHPcBDoGjvQKXZ0d7F08gZ+ZZyJkpGsAsR/ZPHNf9iYgVT9Ydv88z1qM7JzRF0Ax
            1W+w1PKT3F6B/yvLwaWhS53KOJWXEEZTBcTzqtALpnbX8k993Hz/RwRwKQKBgFuM
            pd6XRxjC8EJY+l75y4y49/q8454f8+SF+0Xjn31v08dfjORT8IEqxVEEYsaLSnJk
            XYDgHeem9osgI+C3lZNwyvgcM1X/tuMBjfqiXg1kNDwgk2PKgqs6PTksPIIrGF4o
            Zup2BCHVR9FLWms/9t/S9aHrmqXBL0GhHX+oAWy9AoGBAMLmujn0UZxpgjAyXZnj
            HvO589RJbaG9RxDOJH4sRUVtvsyAqQXxys5OmG2vax/Z0Uxi7EphGtpWrWnmpgKo
            aK5lHGuDy9NMx3tAqBkdPH4nnX+5na+DJ8h6IaoErNiWiGa4cKjDOfkJCcpTCgJx
            I0qdrfWqICaJ3f51hZY8V5x1
            -----END PRIVATE KEY-----
            """;

    private final String PUBLIC_KEY = """
            -----BEGIN PUBLIC KEY-----
            MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApZpBF/gunYuXkolDNRua
            CScWMVtKE4iyDYnPgQQcWd1/a0PB9JrdE96lJhSjIkojeo4Lo5hW0bU7AeQ1iOnW
            5g+K1WjHXpbl9Iu2iW8S7ybHYdPbQKhA6ybbyK7XFK6cazU2TTtieUMtHP3rVei6
            C4SY0blEcOgOLGuXroEJKZ/nqy+9rDUuQxxyIKA7HYeK+Ub/fh2EyGlS+WoK/BJB
            SCBCEpI5N+ZZjJXRY55JItBAd4kyhiN4Bm8b95ajut8kyfmcbKu/VFx2gfwE3DKr
            WJZ4SbtJ28ZghK918eu0nEV14I6nItFU/M1IY0v3IgIIegjA6rl8Pqa5HdbVdM6h
            dwIDAQAB
            -----END PUBLIC KEY-----
            """;

    private RSASSAVerifier verifier;

    @BeforeEach
    public void setup() throws JOSEException {
        this.signerBuilder = ResponseSigner.builder()
                // .algorithm("PS256")
                .privateKey(PRIVATE_KEY)
                .typHeaderValue("JOSE")
                .orgId("0014H00003ARnTmQAL")
                .keyId("OXOKm9U8c48H09zw46P8O54l4QA=");

        var publicKey = JWK.parseFromPEMEncodedObjects(PUBLIC_KEY).toRSAKey();
        this.verifier = new RSASSAVerifier(publicKey);
    }

    @Test
    void testSignPayload() throws JOSEException, ParseException {
        var signer = this.signerBuilder.build();
        Instant now = Instant.now();
        String signature = signer.signPayload(PAYLOAD, now);

        var jose = JWSObject.parse(signature, new Payload(PAYLOAD));
        Assertions.assertThatNoException().isThrownBy(() -> jose.verify(this.verifier));
        var header = jose.getHeader();

        Assertions.assertThat(header.getAlgorithm()).isEqualTo(JWSAlgorithm.PS256);
        Assertions.assertThat(header.getKeyID()).isEqualTo("OXOKm9U8c48H09zw46P8O54l4QA=");
        Assertions.assertThat(header.getCriticalParams()).containsOnly("http://openbanking.org.uk/iat",
                "http://openbanking.org.uk/tan", "http://openbanking.org.uk/iss");
        Assertions.assertThat(header.getCustomParam("http://openbanking.org.uk/tan")).isEqualTo("openbanking.org.uk");
        Assertions.assertThat(header.getCustomParam("http://openbanking.org.uk/iss")).isEqualTo("0014H00003ARnTmQAL");
        Assertions.assertThat(header.getCustomParam("http://openbanking.org.uk/iat"))
                .isEqualTo(now.toEpochMilli() / 1000l);
    }

    @Test
    void testSignPayload_noPrivateKey() {
        var signer = ResponseSigner.builder()
                .orgId("0014H00003ARnTmQAL")
                .keyId("OXOKm9U8c48H09zw46P8O54l4QA=")
                .build();
        var now = Instant.now();
        Assertions.assertThatThrownBy(() -> signer.signPayload(PAYLOAD, now))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void testSignPayload_noOrgId() throws JOSEException {
        var signer = ResponseSigner.builder()
                .privateKey(PRIVATE_KEY)
                .keyId("OXOKm9U8c48H09zw46P8O54l4QA=")
                .build();
        var now = Instant.now();
        Assertions.assertThatThrownBy(() -> signer.signPayload(PAYLOAD, now))
                .isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void testSignPayload_noKeyId() throws JOSEException {
        var signer = ResponseSigner.builder()
                .privateKey(PRIVATE_KEY)
                .orgId("0014H00003ARnTmQAL")
                .build();
        var now = Instant.now();
        Assertions.assertThatThrownBy(() -> signer.signPayload(PAYLOAD, now))
                .isInstanceOf(IllegalArgumentException.class);
    }

}
