package fr.sis.sisid.copuk.tools;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.jwt.JwtValidators;
import org.springframework.security.oauth2.jwt.ReactiveJwtDecoder;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jwt.SignedJWT;

import fr.sis.sisid.copuk.tools.errors.JwtDeserializationException;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

@Slf4j
class JwtToolsTest {

    static ObjectMapper objectMapper;

    JwtTools jwtTools;

    String ps256Jwt;

    @BeforeAll
    static void setup() {
        var mapper = new ObjectMapper();
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper = mapper;
    }

    @BeforeEach
    void beforeEach() throws IOException {
        jwtTools = new JwtTools(objectMapper, Stream.of("PS256", "ES256").collect(Collectors.toSet()));
        ps256Jwt = readResourceAsString("jwt/PS256/test.jwt");
    }

    @Test
    void deserializeClaimsTest() throws IOException {
        var testPayload = jwtTools.deserializeClaims(ps256Jwt, TestPayload.class);
        Assertions.assertThat(testPayload).isNotNull();
        Assertions.assertThat(testPayload.hello).isEqualTo("world");
    }

    @Test
    void deserializeClaims_noArgs() {
        Assertions.assertThatThrownBy(() -> {
            this.jwtTools.deserializeClaims("", null);
        }).isInstanceOf(IllegalArgumentException.class);
        Assertions.assertThatThrownBy(() -> {
            this.jwtTools.deserializeClaims(
                    "eyJhbGciOiJQUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiYWRtaW4iOnRydWUsImlhdCI6MTUxNjIzOTAyMn0.Y3gm1tmGDWi9OCIuVzGuWY2ZdAr2iWxTrh7jJIvvINOh6Lu5B5AoRN2Df4Yh0F9YjiAcDcS-6xg4yDTHno5SkijJ2iW27m6x9afEI6gIV9WCfcOmAZbh2tWixir2nmcNvXcDlERg_XyeVt53mOBHjJA9B-yYvng18HBZVeNCm1FyMVO8KMjW2Yxq82a35ESEa3QL244yl8Mf5XAhVrjEk-t6_1sl4XVSnz0OVBtECyYe-UGq_9AnF-VI_JAFemM2438b8aKvSEFl-G47bGg2gPlWvViHXvSPZZK8A__E997yqtAQgp-bQpParbCHPbU88pHgSGlEaAo3LbXzSf-HEg",
                    null);
        }).isInstanceOf(IllegalArgumentException.class);
    }

    @Test
    void deserializeClaims_badArgs() {
        Assertions.assertThatThrownBy(() -> {
            this.jwtTools.deserializeClaims("aaabbbccc.aaabbbccc.aaabbbccc",
                    TestPayload.class);
        }).isInstanceOf(JwtDeserializationException.class);
    }

    @ParameterizedTest
    @MethodSource("getClaimsTestArguments")
    void getClaimsTest(String jwtPath, JwtStringClaims claim, String expected) throws IOException {
        String rawJws = readResourceAsString(jwtPath);
        Assertions.assertThat(jwtTools.getClaims(rawJws, claim)).isEqualTo(expected);
    }

    static Stream<Arguments> getClaimsTestArguments() {
        return Stream.of(
                Arguments.of("jwt/PS256/test.jwt", JwtStringClaims.ALGORITHM, "PS256"),
                Arguments.of("jwt/PS256/test.jwt", JwtStringClaims.ISSUER, "sis-id"),
                Arguments.of("jwt/PS256/test.jwt", JwtStringClaims.KEY_ID, "OXOKm9U8c48H09zw46P8O54l4QA="),
                Arguments.of("jwt/PS256/test.jwt", JwtStringClaims.TYPE, "JWT"));
    }

    @Test
    void getClaims_noFieldsTest() throws IOException {
        String rawJws = readResourceAsString("jwt/PS256/nofields.jwt");
        Assertions.assertThatThrownBy(() -> {
            jwtTools.getClaims(rawJws, JwtStringClaims.KEY_ID);
        }).isInstanceOf(JwtDeserializationException.class);
        Assertions.assertThatThrownBy(() -> {
            jwtTools.getClaims(rawJws, JwtStringClaims.ISSUER);
        }).isInstanceOf(JwtDeserializationException.class);
    }

    @Test
    void getClaims_unparseable() {
        String unparseable = "aaabbbccc.aaabbbccc.aaabbbccc";
        Assertions.assertThatThrownBy(() -> {
            jwtTools.getClaims(unparseable, JwtStringClaims.KEY_ID);
        }).isInstanceOf(JwtDeserializationException.class);
    }

    @Test
    void getFromJws_unparseable() throws ParseException {
        String unparseable = "eyJhbGciOiJQUzI1NiIsInR5cCI6IkpXVCJ9.W10.eTGN2i1TnzKbrPU73h_XDYLAxvlsu5efV2DGUISyIdwp9JVzVyi-2C1_fJYTp9Sa_y90IRbkX16wNGBrHcQCCel0Sz95WxI5uunQRC3xaNwAHrAXjwRZ-q9uLGYgVFQo7isTUOjEHnJg7D7bsn3P6Oc-yVKT2yYuI4uXTYPmSeAK91Pj_mlmtAwk30qKXwMus44fr_ThyWdlg1cahZJVsH6WqNHPZXsmjA7GxgcQyC2YrwaZhbTS0gA3ozEpls-rCuvK0Lr7Ng7nWQVeOTaao4TgiVxab3KSii6OCfOt0_dUXKqpITmsyaVADc6dzHYJIYntA89gRAUl1IkdSD3qHQ";
        var t = SignedJWT.parse(unparseable);
        Assertions.assertThatThrownBy(() -> {
            jwtTools.getFromJws(t, token -> token.getJWTClaimsSet().getIssuer(), "test");
        }).isInstanceOf(JwtDeserializationException.class);
    }

    @Test
    void getExpiresAtTest() {
        LocalDateTime expected = ZonedDateTime.of(LocalDateTime.of(2022, 05, 19, 17, 19, 31), ZoneId.of("Europe/Paris"))
                .withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime();
        Assertions.assertThat(jwtTools.getExpiresAt(ps256Jwt)).isEqualTo(expected);
    }

    @Test
    void getExpiresAt_unparseable() {
        String unparseable = "aaabbbccc.aaabbbccc.aaabbbccc";
        Assertions.assertThatThrownBy(() -> {
            jwtTools.getExpiresAt(unparseable);
        }).isInstanceOf(JwtDeserializationException.class);
    }

    @Test
    void getJwtDecoderTest() {
        var testJwksWebClient = jwksWebClient();
        ReactiveJwtDecoder jwtDecoder = this.jwtTools.getJwtDecoder("http://localhost",
                testJwksWebClient, Collections.singleton(JwtValidators.createDefault()));

        String testToken = "eyJhbGciOiJQUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiYWRtaW4iOnRydWUsImlhdCI6MTUxNjIzOTAyMn0.Y3gm1tmGDWi9OCIuVzGuWY2ZdAr2iWxTrh7jJIvvINOh6Lu5B5AoRN2Df4Yh0F9YjiAcDcS-6xg4yDTHno5SkijJ2iW27m6x9afEI6gIV9WCfcOmAZbh2tWixir2nmcNvXcDlERg_XyeVt53mOBHjJA9B-yYvng18HBZVeNCm1FyMVO8KMjW2Yxq82a35ESEa3QL244yl8Mf5XAhVrjEk-t6_1sl4XVSnz0OVBtECyYe-UGq_9AnF-VI_JAFemM2438b8aKvSEFl-G47bGg2gPlWvViHXvSPZZK8A__E997yqtAQgp-bQpParbCHPbU88pHgSGlEaAo3LbXzSf-HEg";
        StepVerifier.create(jwtDecoder.decode(testToken))
                .assertNext(token -> Assertions.assertThat(token).isNotNull())
                .expectComplete()
                .verify();
    }

    @Test
    void getJwtDecoderTest_joseTyp() {
        var testJwksWebClient = jwksWebClient();
        ReactiveJwtDecoder jwtDecoder = this.jwtTools.getJwtDecoder("http://localhost",
                testJwksWebClient, Collections.singleton(JwtValidators.createDefault()));

        String testToken = "eyJhbGciOiJQUzI1NiIsInR5cCI6IkpPU0UifQ.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiYWRtaW4iOnRydWUsImlhdCI6MTUxNjIzOTAyMn0.UAxAwTrxYm_W9IbGWYBercYz_sh5JLY0OPfqMua5oYKGbsuvWFlYP5xHZxGi63im25U-ZvKQXAemGU8ShWZX7_cWjNd-bL8QAhn6DNC9saWFZaVi3XbrzrRuA0ZX96ykMOv3hqJmeq8c6Uc0GkOejXarEe9yLipP4JZOwV5nSjA32bzrOgyhTQtXRjIzVr3HS2rnYRKOfC42mEernc5VfgtthSvoK9J36wbNOJ6Jv9hFOM8P8ESJHbJuR-ddxdfMf51_qr7heEMZWrQ3iN9i3nJgncDOo3sIbTOZC0THVE0rrFQp3IO5ao5D1M2BTiB7BGGEfkLKvn6ynx7GsWVJyQ";
        StepVerifier.create(jwtDecoder.decode(testToken))
                .assertNext(token -> Assertions.assertThat(token).isNotNull())
                .expectComplete()
                .verify();
    }

    /** helpers **/

    private String readResourceAsString(String resourcePath) throws IOException {
        return Files.readString(Path.of(new ClassPathResource(resourcePath).getURI().getPath()));
    }

    @Data
    static class TestPayload {

        String hello;

        public TestPayload() {
        }
    }

    RestTemplate getRestTemplate() {
        return new RestTemplate() {

            @SuppressWarnings("unchecked")
            @Override
            public <T> ResponseEntity<T> exchange(RequestEntity<?> entity, Class<T> responseType)
                    throws RestClientException {
                if (String.class != responseType) {
                    return ResponseEntity.notFound().build();
                }
                return ResponseEntity
                        .ok((T) """
                                  {
                                  "keys": [
                                    {
                                      "kty": "RSA",
                                      "e": "AQAB",
                                      "use": "sig",
                                      "kid": "OXOKm9U8c48H09zw46P8O54l4QA=",
                                      "alg": "PS256",
                                      "n": "pZpBF_gunYuXkolDNRuaCScWMVtKE4iyDYnPgQQcWd1_a0PB9JrdE96lJhSjIkojeo4Lo5hW0bU7AeQ1iOnW5g-K1WjHXpbl9Iu2iW8S7ybHYdPbQKhA6ybbyK7XFK6cazU2TTtieUMtHP3rVei6C4SY0blEcOgOLGuXroEJKZ_nqy-9rDUuQxxyIKA7HYeK-Ub_fh2EyGlS-WoK_BJBSCBCEpI5N-ZZjJXRY55JItBAd4kyhiN4Bm8b95ajut8kyfmcbKu_VFx2gfwE3DKrWJZ4SbtJ28ZghK918eu0nEV14I6nItFU_M1IY0v3IgIIegjA6rl8Pqa5HdbVdM6hdw"
                                    }
                                  ]
                                }
                                """);
            }
        };
    }

    public WebClient jwksWebClient() {
        log.info("Stubbed jwks web client");
        String jwks = """
                  {
                  "keys": [
                    {
                      "kty": "RSA",
                      "e": "AQAB",
                      "use": "sig",
                      "kid": "OXOKm9U8c48H09zw46P8O54l4QA=",
                      "alg": "PS256",
                      "n": "pZpBF_gunYuXkolDNRuaCScWMVtKE4iyDYnPgQQcWd1_a0PB9JrdE96lJhSjIkojeo4Lo5hW0bU7AeQ1iOnW5g-K1WjHXpbl9Iu2iW8S7ybHYdPbQKhA6ybbyK7XFK6cazU2TTtieUMtHP3rVei6C4SY0blEcOgOLGuXroEJKZ_nqy-9rDUuQxxyIKA7HYeK-Ub_fh2EyGlS-WoK_BJBSCBCEpI5N-ZZjJXRY55JItBAd4kyhiN4Bm8b95ajut8kyfmcbKu_VFx2gfwE3DKrWJZ4SbtJ28ZghK918eu0nEV14I6nItFU_M1IY0v3IgIIegjA6rl8Pqa5HdbVdM6hdw"
                    }
                  ]
                }
                """;
        return WebClient.builder()
                .exchangeFunction(clientRequest -> Mono.just(ClientResponse.create(HttpStatus.OK)
                        .header("content-type", "application/json")
                        .body(jwks)
                        .build())
                        .doOnNext(res -> log.info("Called stubbed jwks")))
                .build();
    }

}
