package fr.sis.sisid.copuk.tools;

import java.util.Collections;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import com.nimbusds.jose.JOSEObject;
import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.Payload;

import fr.sis.sisid.copuk.OpenBankingConstants;
import fr.sis.sisid.copuk.tools.errors.JOSEValidationException;

class NonRepudiationValidatorsTest {

    @ParameterizedTest
    @MethodSource("validatorTestArguments")
    void validatorTest(JoseHeaderValidator<?> validator, JOSEObject token, boolean isValid) {
        if (isValid) {
            Assertions.assertThatNoException().isThrownBy(() -> validator.validate(token));
        } else {
            Assertions.assertThatThrownBy(() -> validator.validate(token))
                    .isInstanceOf(JOSEValidationException.class);
        }
    }

    static Stream<Arguments> validatorTestArguments() {
        return Stream.of(
                Arguments.of(
                        NonRepudiationValidators.typValidator("JOSE"),
                        headerWithClaim(builder -> builder.type(JOSEObjectType.JOSE)),
                        true),
                Arguments.of(
                        NonRepudiationValidators.typValidator("JOSE"),
                        headerWithClaim(builder -> builder),
                        true),
                Arguments.of(
                        NonRepudiationValidators.typValidator("JOSE"),
                        headerWithClaim(builder -> builder.type(JOSEObjectType.JWT)),
                        false),
                Arguments.of(
                        NonRepudiationValidators.ctyValidator(Collections.singletonList("application/json")),
                        headerWithClaim(builder -> builder.contentType("application/json")),
                        true),
                Arguments.of(
                        NonRepudiationValidators.ctyValidator(Collections.singletonList("application/json")),
                        headerWithClaim(builder -> builder),
                        true),
                Arguments.of(
                        NonRepudiationValidators.ctyValidator(Collections.singletonList("application/json")),
                        headerWithClaim(builder -> builder.contentType("text/html")),
                        false),
                Arguments.of(
                        NonRepudiationValidators.iatValidator(),
                        headerWithClaim(
                                builder -> builder.customParam(OpenBankingConstants.CUSTOM_IAT_CLAIM, 1660809300l)),
                        true),
                Arguments.of(
                        NonRepudiationValidators.iatValidator(),
                        headerWithClaim(builder -> builder),
                        false),
                Arguments.of(
                        NonRepudiationValidators.iatValidator(),
                        headerWithClaim(builder -> builder.customParam(OpenBankingConstants.CUSTOM_IAT_CLAIM, null)),
                        false),
                Arguments.of(
                        NonRepudiationValidators.iatValidator(),
                        headerWithClaim(
                                builder -> builder.customParam(OpenBankingConstants.CUSTOM_IAT_CLAIM, 3554258100l)),
                        false),
                Arguments.of(
                        NonRepudiationValidators.responderIssValidator("org-id"),
                        headerWithClaim(
                                builder -> builder.customParam(OpenBankingConstants.CUSTOM_ISS_CLAIM, "org-id")),
                        true),
                Arguments.of(
                        NonRepudiationValidators.responderIssValidator("org-id"),
                        headerWithClaim(builder -> builder),
                        false),
                Arguments.of(
                        NonRepudiationValidators.responderIssValidator("org-id"),
                        headerWithClaim(builder -> builder.customParam(OpenBankingConstants.CUSTOM_ISS_CLAIM, " ")),
                        false),
                Arguments.of(
                        NonRepudiationValidators.responderIssValidator("org-id"),
                        headerWithClaim(
                                builder -> builder.customParam(OpenBankingConstants.CUSTOM_ISS_CLAIM, "other-org-id")),
                        false),
                Arguments.of(
                        NonRepudiationValidators.requesterIssValidator("org-id",
                                "software-id"),
                        headerWithClaim(
                                builder -> builder.customParam(OpenBankingConstants.CUSTOM_ISS_CLAIM,
                                        "org-id/software-id")),
                        true),
                Arguments.of(
                        NonRepudiationValidators.requesterIssValidator("org-id",
                                "software-id"),
                        headerWithClaim(builder -> builder),
                        false),
                Arguments.of(
                        NonRepudiationValidators.requesterIssValidator("org-id",
                                "software-id"),
                        headerWithClaim(builder -> builder.customParam(OpenBankingConstants.CUSTOM_ISS_CLAIM, " ")),
                        false),
                Arguments.of(
                        NonRepudiationValidators.requesterIssValidator("org-id",
                                "software-id"),
                        headerWithClaim(
                                builder -> builder.customParam(OpenBankingConstants.CUSTOM_ISS_CLAIM,
                                        "org-id/other-software-id")),
                        false),
                Arguments.of(
                        NonRepudiationValidators.tanValidator("openbanking.org.uk"),
                        headerWithClaim(
                                builder -> builder.customParam(OpenBankingConstants.CUSTOM_TAN_CLAIM,
                                        "openbanking.org.uk")),
                        true),
                Arguments.of(
                        NonRepudiationValidators.tanValidator("openbanking.org.uk"),
                        headerWithClaim(builder -> builder),
                        false),
                Arguments.of(
                        NonRepudiationValidators.tanValidator("openbanking.org.uk"),
                        headerWithClaim(builder -> builder.customParam(OpenBankingConstants.CUSTOM_TAN_CLAIM, " ")),
                        false),
                Arguments.of(
                        NonRepudiationValidators.tanValidator("openbanking.org.uk"),
                        headerWithClaim(
                                builder -> builder.customParam(OpenBankingConstants.CUSTOM_TAN_CLAIM, "fma.au")),
                        false),
                Arguments.of(
                        NonRepudiationValidators.critValidator(),
                        headerWithClaim(builder -> builder.criticalParams(
                                Stream.of(OpenBankingConstants.CUSTOM_IAT_CLAIM, OpenBankingConstants.CUSTOM_ISS_CLAIM,
                                        OpenBankingConstants.CUSTOM_TAN_CLAIM).collect(Collectors.toSet()))),
                        true),
                Arguments.of(
                        NonRepudiationValidators.critValidator(),
                        headerWithClaim(builder -> builder),
                        false),
                Arguments.of(
                        NonRepudiationValidators.critValidator(),
                        headerWithClaim(builder -> builder.criticalParams(null)),
                        false),
                Arguments.of(
                        NonRepudiationValidators.critValidator(),
                        headerWithClaim(builder -> builder.criticalParams(
                                Stream.of(OpenBankingConstants.CUSTOM_IAT_CLAIM, OpenBankingConstants.CUSTOM_ISS_CLAIM,
                                        OpenBankingConstants.CUSTOM_TAN_CLAIM, "other-crit")
                                        .collect(Collectors.toSet()))),
                        false),
                Arguments.of(
                        NonRepudiationValidators.critValidator(),
                        headerWithClaim(builder -> builder.criticalParams(
                                Stream.of(OpenBankingConstants.CUSTOM_IAT_CLAIM,
                                        OpenBankingConstants.CUSTOM_TAN_CLAIM).collect(Collectors.toSet()))),
                        false),
                Arguments.of(NonRepudiationValidators.kidValidator(),
                        headerWithClaim(builder -> builder.keyID("test-123")), true),
                Arguments.of(NonRepudiationValidators.kidValidator(), headerWithClaim(builder -> builder), false)

        );
    }

    static JWSObject headerWithClaim(Function<JWSHeader.Builder, JWSHeader.Builder> fn) {
        var builder = new JWSHeader.Builder(JWSAlgorithm.PS256);
        fn.apply(builder);
        return new JWSObject(builder.build(), new Payload(""));
    }

}
