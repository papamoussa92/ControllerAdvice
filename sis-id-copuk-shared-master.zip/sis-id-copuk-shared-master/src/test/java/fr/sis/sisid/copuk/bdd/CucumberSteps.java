package fr.sis.sisid.copuk.bdd;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class CucumberSteps {

    @Given("the Application is built")
    public void the_application_is_built() {
        assertTrue(true, "Application built");
    }

    @When("the Application runs the tests")
    public void the_application_runs_the_tests() {
        assertTrue(true, "Tests are running");
    }

    @Then("the Cucumber scenario is executed")
    public void the_cucumber_scenario_is_executed() {
        assertTrue(true, "Cucumber is running");
    }

}
