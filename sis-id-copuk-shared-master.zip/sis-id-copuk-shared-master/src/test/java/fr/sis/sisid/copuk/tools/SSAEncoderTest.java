package fr.sis.sisid.copuk.tools;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import fr.sis.sisid.copuk.openbanking.model.OrgStatus;
import fr.sis.sisid.copuk.openbanking.model.SoftwareStatementAssertionPayload;
import org.junit.jupiter.api.Test;

import java.lang.ref.PhantomReference;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class SSAEncoderTest {

    @Test
    void testEncode() throws JOSEException, ParseException {
        String keyID = UUID.randomUUID().toString();
        SSAEncoder encoder = new SSAEncoder(TEST_PRIVATE_KEY, keyID);

        var ssa = encoder.encode(applyTestDefaults());

        SignedJWT token = SignedJWT.parse(ssa);
        assertEquals(keyID, token.getHeader().getKeyID());
        assertEquals("OpenBanking Ltd", token.getJWTClaimsSet().getIssuer());
    }

    /**
     * Sets claims for TESTING ONLY
     *
     * @return a builder pre-populated with reasonable test values for the claims
     */
    public SoftwareStatementAssertionPayload applyTestDefaults() {

        return SoftwareStatementAssertionPayload.builder()
                .iss("OpenBanking Ltd")
                .iat(System.currentTimeMillis()/1000)
                .jti(UUID.randomUUID().toString())
                .softwareMode("Test")
                .softwareEnvironment("test")
                .softwareId("Kscn50uvJzCMgB2AEewAJu")
                .softwareClientId("Kscn50uvJzCMgB2AEewAJu")
                .softwareClientName("COP Message Simulator")
                .softwareClientDescription("Pay.UK's Message Simulator for testing adherence to the CoP standards")
                .softwareVersion("1")
                .softwareClientUri("https://client.iliad-solutions.com")
                .softwareRedirectUris(List.of("https://redirect.sis-id4banks.com"))
                .softwareRoles(List.of("COPRequester", "COPResponder"))
                .softwareLogoUri("https://logo.iliad-solutions.com")
                .orgStatus(OrgStatus.ACTIVE)
                .orgId("0014H00003ARna3QAD")
                .orgName("CoP Message Simulator").build();
    }

    private static final String TEST_PRIVATE_KEY = """
            -----BEGIN PRIVATE KEY-----
            MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQClmkEX+C6di5eS
            iUM1G5oJJxYxW0oTiLINic+BBBxZ3X9rQ8H0mt0T3qUmFKMiSiN6jgujmFbRtTsB
            5DWI6dbmD4rVaMdeluX0i7aJbxLvJsdh09tAqEDrJtvIrtcUrpxrNTZNO2J5Qy0c
            /etV6LoLhJjRuURw6A4sa5eugQkpn+erL72sNS5DHHIgoDsdh4r5Rv9+HYTIaVL5
            agr8EkFIIEISkjk35lmMldFjnkki0EB3iTKGI3gGbxv3lqO63yTJ+Zxsq79UXHaB
            /ATcMqtYlnhJu0nbxmCEr3Xx67ScRXXgjqci0VT8zUhjS/ciAgh6CMDquXw+prkd
            1tV0zqF3AgMBAAECggEBAJ0N4DIlU8BihQuaVjzlwn5vrWJ925EPER451qvbBDBO
            GuvVxPqAbK7Ndv7Yj6aTfXZbhLpQXfZg1GeE0SjZ7M8famHfD0WsAsacQi+xQdnB
            g1JKJCP77iWWItb+ykh5GSuruaYhbdDnXr+iKTC+mMMXq/8qn7gcvGRwXdhH1DK+
            R8hSC9us15rWf/3OlCgDIVAq5Ts8MvDc1ZaA1JbS4pOb0GgYcvf9vsUh5+5i67Tm
            9zkSXeEAVK5vrOcvqxTajS+rWuTrU1+4j3XpnQpbOX9mBKh9KvPBvs2e/eIVbYWd
            cFqycmxwGp4A+ZRnbAeWoIVbjQkuAjK8e2f2hgWvjtECgYEA0qlXp+K8bS95QEKi
            aAtGgO4/AP8GoaAKOxkoB7BrDeEIyKgMf1C6yMJIe+Gw9gZw6qTSQIUG8x0fPCgz
            b+wRJ5YvCejWOrqOiAmkGTs+Skbz28AvznE25MfGP8Mgn+yuFXogR8I3S1K2OLQT
            4Gk6Z4uo2UOhXtA6TlomQHso+vUCgYEAyT5VYNlkYJlmNVmzlEHUQ7NyuzHW6dNm
            yQt8sWxkO0ab9afwO+g0hmQJpkSNq1HfdETl0lVXDHU+Ihg0oDiE8jIqkBNVCwi/
            rPRZD8AwxQeWWosziiyaQ5ntPev0yhcRcQXmTJmnNqyarvPswQvrUlxnbJiskT+8
            +u/muk6gvzsCgYA8vtwp6zXOfkwGfbB7NBUmhIziaqes34tTs1NZtEOKgwOXaO4B
            oHPcBDoGjvQKXZ0d7F08gZ+ZZyJkpGsAsR/ZPHNf9iYgVT9Ydv88z1qM7JzRF0Ax
            1W+w1PKT3F6B/yvLwaWhS53KOJWXEEZTBcTzqtALpnbX8k993Hz/RwRwKQKBgFuM
            pd6XRxjC8EJY+l75y4y49/q8454f8+SF+0Xjn31v08dfjORT8IEqxVEEYsaLSnJk
            XYDgHeem9osgI+C3lZNwyvgcM1X/tuMBjfqiXg1kNDwgk2PKgqs6PTksPIIrGF4o
            Zup2BCHVR9FLWms/9t/S9aHrmqXBL0GhHX+oAWy9AoGBAMLmujn0UZxpgjAyXZnj
            HvO589RJbaG9RxDOJH4sRUVtvsyAqQXxys5OmG2vax/Z0Uxi7EphGtpWrWnmpgKo
            aK5lHGuDy9NMx3tAqBkdPH4nnX+5na+DJ8h6IaoErNiWiGa4cKjDOfkJCcpTCgJx
            I0qdrfWqICaJ3f51hZY8V5x1
            -----END PRIVATE KEY-----
            """;
}