package fr.sis.sisid.copuk.tools;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.StandardEnvironment;

import io.cucumber.java.After;

class MicroserviceToolsTest {

    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;

    @Test
    void logApplicationStartupTest() throws UnknownHostException {
        // setup
        ConfigurableEnvironment environment = new StandardEnvironment();
        MutablePropertySources propertySources = environment.getPropertySources();
        Map<String, Object> properties = new HashMap<>();
        properties.put("server.port", "1000");

        propertySources.addFirst(new MapPropertySource("test_properties", properties));

        // redirect System.out
        System.setOut(new PrintStream(outContent));
        // test, assert log output contains relevant address and ports
        MicroserviceTools.logApplicationStartup(environment);
        String outContentOutput = outContent.toString();
        Assertions.assertThat(outContentOutput).isNotBlank();
        String expected = """
                \tApplication 'null' is running! Access URLs:
                \tLocal: \t\thttp://localhost:1000/
                \tExternal: \thttp://%s:1000/
                \tProfile(s): \t[default]
                """.formatted(InetAddress.getLocalHost().getHostAddress());
        Assertions.assertThat(outContentOutput).contains(expected);
    }

    @After
    void fixSystemOut() {
        System.setOut(originalOut);
    }

}
