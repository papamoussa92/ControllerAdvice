package fr.sis.sisid.copuk.ext.bnp.model;

import java.util.Arrays;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

class JsonMappingTest {

    @Test
    void testCopRequestSerializesProperly() throws JsonProcessingException {
        var copRequest = new CopRequest()
                .country("GB") // hardcoded
                .financialInstitution(
                        new FinancialInstitutionIdentification()
                                .clearingSystemMemberIdentification(
                                        new ClearingSystemMemberIdentification()
                                                .memberIdentification("406384")
                                                .clearingSystemIdentification(
                                                        new ClearingSystemIdentificationChoice()
                                                                .code("GBDSC"))))
                .account(new CashAccount()
                        .identification(
                                new AccountIdentificationChoice()
                                        .other(
                                                new GenericIdentification()
                                                        .identification("40638412345678")))
                        .currency(Arrays.asList("GBP"))
                        .accountType(AccountTypeComponent.ORGANISATION));
        String expected = """
                {
                  "account" : {
                    "identification" : {
                      "other" : {
                        "identification" : "40638412345678"
                      }
                    },
                    "currency" : [ "GBP" ],
                    "accountType" : "Organisation"
                  },
                  "financialInstitution" : {
                    "clearingSystemMemberIdentification" : {
                      "clearingSystemIdentification" : {
                        "code" : "GBDSC"
                      },
                      "memberIdentification" : "406384"
                    }
                  },
                  "country" : "GB"
                }""";
        var mapper = new ObjectMapper();
        mapper.setSerializationInclusion(Include.NON_NULL);
        String serialized = mapper
                .writerWithDefaultPrettyPrinter()
                .writeValueAsString(copRequest);
        Assertions.assertThat(serialized).isEqualTo(expected);
    }
}
