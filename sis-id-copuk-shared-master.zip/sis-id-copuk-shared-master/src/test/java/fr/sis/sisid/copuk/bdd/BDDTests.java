package fr.sis.sisid.copuk.bdd;

import io.cucumber.core.options.Constants;
import org.junit.jupiter.api.Test;
import org.junit.platform.suite.api.ConfigurationParameter;
import org.junit.platform.suite.api.SelectClasspathResource;
import org.junit.platform.suite.api.Suite;

import static org.junit.jupiter.api.Assertions.assertTrue;


@Suite
@SelectClasspathResource("cucumber")
@ConfigurationParameter(key = Constants.PLUGIN_PUBLISH_QUIET_PROPERTY_NAME, value = "true")
@ConfigurationParameter(key = Constants.PLUGIN_PROPERTY_NAME, value = "html:target/acceptance_report.html")
class BDDTests {

    @Test
    void testBDDInSonar() {
        assertTrue(true, "Necessary test to avoid sonar smell");
    }

}

