package fr.sis.sisid.copuk.copapi;

import java.util.Arrays;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

class OpenBankingErrorCodeTest {

    @Test
    void errorCodesAreDefined() {
        Assertions.assertThat(OpenBankingErrorCode.values()).isNotEmpty();
        Arrays.asList(OpenBankingErrorCode.values()).forEach(val -> Assertions.assertThat(val.getCode()).isNotBlank());
    }

}
