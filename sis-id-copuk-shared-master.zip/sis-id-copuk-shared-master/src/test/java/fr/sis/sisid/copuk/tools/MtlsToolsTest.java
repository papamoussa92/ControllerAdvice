package fr.sis.sisid.copuk.tools;

import java.io.IOException;
import java.nio.charset.Charset;
import java.security.PrivateKey;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashSet;

import javax.net.ssl.SSLException;

import org.apache.commons.io.IOUtils;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.core.io.ClassPathResource;

import io.netty.handler.ssl.SslContext;

class MtlsToolsTest {

    private static final String PEM_KEYPAIR = """
            -----BEGIN PRIVATE KEY-----
            MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCyi2Z+kx1KAUQy
            kimTU2UsmysYylAD4rkMKiuZ9nsAMLtLWPeYTCPadvliwIK5ZMsznVgNd3XMV6xT
            +wYE5vbJoJC0j395pBGBXbTD+uPYLCoiK0NOlB2uADJKCrQPxxfkGr/BzVJt051c
            RCrSHYnG3bOZIOgoZRSMNZs/lOj1QUDHyBdTJlEKmUnkmtrRxOzYHPqRyZaa3NDC
            l1nwIgvKosnJ9clwOLqlm9wdLAt8hfZZXdNWi342P/2/rzAaGfP7hr5jE5581lNv
            8j6r/eormwEMt1NUBMyoHJxYNxexk+2ZrTO5wChJL4rSl90tMYwHM9RrfiMzVAzd
            HQM/1EaHAgMBAAECggEBAIDKQXLIV/ZMF4+LE2ZsX6zfeST2uuUypFz8BluXCn7G
            qDPfxyoasjoiXB4505I7/MAMnbmJFHYEQBCMIHlkyVwD8J3ubPunt+DjYUOFNNl4
            ciQXpQOHoCklhyEVu3EuIjOuf+giXXVPklE98s2B9SJ4RdcNf6mz0DCbcpNYrPpL
            lKAdvEE4DenGw/LA0sBVLYQC0cE8Yal0g3fD4e8QS1RoYGjvjsrsPG79RvJcwh/B
            G38RGsTRnN70MBymixyu/Ae5SMB9aVtImDPN3Kck81RA6J7R6vmP1dUoz50KUb2e
            r2KzUjSzUgT4ljy68/TuKe878pwmqiMfxyaWbhyOMcECgYEA4sW/2jNsdkmk38Sc
            +azzi/2TYS9RKbL2KzIRaWYvj9SdyJTXhqcCk1IcLhE9l5oTM5zpAT/38U6BlinV
            d03KcMBt+nt1Cy/DyKeFTNsLgXfN4F8meEfmlHqlzP3KCGDahpE+ov7TQU8oHKPh
            B1XwaqtNm9F9HXoKJA7PPcMBWxcCgYEAyY5kqf9fqbmebAto3ZiTDLzcNFjJh64A
            ElrtO0OXV/ewZIFKBHnDsJXC3JZNoNbPR1f1AtYqWwyrgrCC9c9zbvaTdg53rFOX
            t2nET8PgbYa2dGjuIPuIPgVKVfoUFU4OwISGEAVKPwmndHqK8k3Qo+muhVL7TWPk
            Dt9+eOko1hECgYEApTf2I3+70iKtoOqag73iY2gIbJIQzBS7DZWY4fW1SVFa87yd
            mlkrozH7ngSpnz5+Juh3SpXUi1brSwCHqjhe+e75Mbmo+NGADz0d/XTJ2TX0JTit
            yox4Dk2dZtCw1ZHbJJfFzvNh7v9A9jzfwnx2gQD1tkTWpxc3NDYl/5WH81kCgYAS
            nNem6zJGViHPEG6qqABMWNRs8RYLNYJEL6lgo6lCMllTrqzLJQNxNyM7g5W/mJaj
            m/fAP07CAbWE6A/v6yxZvuN3L3bVrxJ/mYDLbOc4tgv7TAVRfmjicVKgBev826x5
            EsPejt6AW7/e/cH/BjiSKm43WaZjSyowRWtEdyOSQQKBgCXGlDzQLuRJ4NJEcDJ8
            f6xvFHX1jRhVfltC3gPLwdEiLZIa6c+tjx0yUCOysM3bGmIRDRUk9hPY1wijo3DF
            RClOO0mhTI5N+o4SUzzVHqoWofY7z72UlQPTU2c/tInt8uOYQGDeZQLiKBLB6xgJ
            QI4is7AJ1J/2ucM3PzfQhk/d
            -----END PRIVATE KEY-----
            """;

    @Test
    void parsePEMKeyTest() throws IOException {
        String pemKey = IOUtils.toString(new ClassPathResource("certs/mockserver/ssl-key.pem").getInputStream(),
                Charset.defaultCharset());
        PrivateKey parsedKey = MtlsTools.parsePEMKey(pemKey);
        Assertions.assertThat(parsedKey).isNotNull();
    }

    @Test
    void parsePEMKTest_keyPair() throws IOException {
        Assertions.assertThat(MtlsTools.parsePEMKey(PEM_KEYPAIR)).isNotNull();
    }

    @Test
    void getMtlsContextTest() throws IOException, CertificateException {
        String pemKey = IOUtils.toString(
                new ClassPathResource("certs/mockserver-client/client-key.pem").getInputStream(),
                Charset.defaultCharset());
        String pemCert = IOUtils.toString(
                new ClassPathResource("certs/mockserver-client/client-cert.pem").getInputStream(),
                Charset.defaultCharset());
        PrivateKey parsedKey = MtlsTools.parsePEMKey(pemKey);
        X509Certificate parsedCert = MtlsTools.parsePEMCert(pemCert);
        SslContext mtlsContext = MtlsTools.getMtlsSSLContext(parsedKey, parsedCert, new HashSet<>());
        Assertions.assertThat(mtlsContext).isNotNull();
    }

    @Test
    void getMtlsContextTest_keyCertMisMatch() throws IOException, CertificateException {
        String pemCert = IOUtils.toString(
                new ClassPathResource("certs/mockserver-client/client-cert.pem").getInputStream(),
                Charset.defaultCharset());
        X509Certificate parsedCert = MtlsTools.parsePEMCert(pemCert);
        Assertions.assertThatThrownBy(() -> MtlsTools.getMtlsSSLContext(null, parsedCert, new HashSet<>()))
                .isInstanceOf(SSLException.class);
    }

}
