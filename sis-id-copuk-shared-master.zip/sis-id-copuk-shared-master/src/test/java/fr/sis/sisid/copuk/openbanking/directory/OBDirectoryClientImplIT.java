package fr.sis.sisid.copuk.openbanking.directory;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockserver.model.Header;
import org.mockserver.model.HttpRequest;
import org.mockserver.model.HttpResponse;
import org.mockserver.model.Parameter;
import org.mockserver.model.ParameterBody;
import org.springframework.core.io.ClassPathResource;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.util.IOUtils;
import com.nimbusds.jwt.SignedJWT;

import fr.sis.sisid.copuk.OBDirectoryMockServer;
import lombok.extern.slf4j.Slf4j;
import reactor.test.StepVerifier;

@Slf4j
class OBDirectoryClientImplIT {

    private static final String SSA_ID = "UVpTUUTzBFoQHpISL2ii91";
    private static final String AUD = "https://matls-sso.openbankingtest.org.uk/as/token.oauth2";
    private static final String SCOPE = "ASPSPReadAccess";

    private static OBDirectoryClientImpl directoryClient;

    @BeforeAll
    static void setup() {
        // OB Directory mockserver
        var mockServer = OBDirectoryMockServer.getMockServerContainer();

        mockServer.start();

        String mockServerAddr = "https://" + mockServer.getContainerIpAddress() + ":" + mockServer.getServerPort();

        // build ob directory client
        var properties = new OBDirectoryProperties();
        properties.setApiBaseUrl(mockServerAddr + "/api");
        properties.setSsoBaseUrl(mockServerAddr + "/sso");
        properties.setAuthenticationAud(AUD);
        properties.setSigningKeyId("l6lJXi-eepEMW0kPnwX-8SZ_TnU");
        properties.setSsaId(SSA_ID);
        properties.setAuthenticationScope(SCOPE);

        String signingKey;
        String transportKey;
        String transportCert;
        String certAuthority;
        try {
            signingKey = IOUtils.readInputStreamToString(
                    new ClassPathResource("certs/mockserver-client/client-key.pem").getInputStream());
            transportKey = IOUtils.readInputStreamToString(
                    new ClassPathResource("certs/mockserver-client/client-key.pem").getInputStream());
            transportCert = IOUtils.readInputStreamToString(
                    new ClassPathResource("certs/mockserver-client/client-cert.pem").getInputStream());
            certAuthority = IOUtils.readInputStreamToString(
                    new ClassPathResource("certs/mockserver-client/CA-cert.pem").getInputStream());
        } catch (IOException err) {
            Assertions.fail(err.getMessage());
            return;
        }
        directoryClient = new OBDirectoryClientImpl(
                signingKey, transportKey, transportCert, List.of(certAuthority), properties);

        // mockserver setup - mock ob directory SSO
        var mockServerClient = OBDirectoryMockServer.getMockServerClient();
        mockServerClient.reset();
        mockServerClient.when(
                HttpRequest
                        .request("/sso/as/token.oauth2")
                        .withMethod("POST")
                        .withHeaders(Header.header("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8"))
                        .withBody(ParameterBody.params(
                                Parameter.param("client_assertion_type",
                                        "urn:ietf:params:oauth:client-assertion-type:jwt-bearer"),
                                Parameter.param("grant_type", "client_credentials"),
                                Parameter.param("client_id", SSA_ID),
                                Parameter.param("client_assertion"))))
                .respond(HttpResponse
                        .response(
                                """
                                                {
                                                  "access_token": "eyJhbGciOiJkaXIiLCJlbmMiOiJBMTI4R0NNIiwiY3R5IjoiSldUIiwia2lkIjoiRW5jcnlwdCIsInBpLmF0bSI6IjNqbmUifQ..4WA2uXtDZYnVXIWX.T2a1FC4U2G85IAPUNvATueiscsB2qfQAj42fz2mbnpb6qMEP24vGPG5kyE4o-hV6OwQuChv0aYUj0VM2BtMy0Yt6QkwcLZqXcShsHc4jqIfXPJEa1eV4537kuBdczPHoCBWPJYpnkd8HpQ5SHpgsDlB3bVjvcd411xXDPptdfvYbfMih4pZZtN75vXOyfYAixTiC5_Dycei2WyaZYgacQ0AHKJZS8xMdgpjODZng9FhJGuog6fEX5HWPI1K7zwhPJiYyEOTAvYYfoPBuai2g2rG9_sWxW2L06H779204DmM061gpoQW8RnSo3-XILLPLYq5CiBLC17YNxkIqTVEscKr9iDANZMPvRcW111t8rc2qnvsIi6wt0Ns3tuOVeVCC2aAGLweSnsBxgAcV5IeOhpGXB2POLhgC-AA90mn3OMkXraJPdUw8ZGLVyphFzgVRGTZWT17weWvvgsNT1ACgGZetwqqdPogrkhZgQxTGD-Wh3E1lubQalCD3V-_vwbOGwt8ZgmFwdt2_erdYv7XNTTKN8qVnE2N0XQdJsoMiICt7jG7fQ_L9m-QOgLlv1ts4p7HLA1gqSNFnnuf0Dv2vDb4JGuO6oJrgdPvrJO3U8ycNeftg8vrgVM-tEFxypiqir5wtxsOSGTq_UXxpgMMFBeKD9d2nXUzDIFjoOQpItzP4NT5_K9KOm5MgMz8hpZS_Vjt8Pzi_c-WoS5uDwVXc5i_CwMEOzD10Yx703g2FBVtOdbW3BUiOwieP3is-_qPOmBM6dlD-h-4tD26fha6uTvrPGWXk2x9dYspixVm8-KAPHBi3haIIZu06hjRUi-EF-CmiuDPsTd4W_TojewwbvFofruaf9NkTi4dS8uBV0jM9pdIWH7Yi9Vcvqf_-hVKIJMzlbFgiXf_1BHGxR5NuZyBxQzOeX2XeU_vrIHa-XA.fB1wX8Qy3kDC6GjKe_ST3g",
                                                  "token_type": "Bearer",
                                                  "expires_in": 899
                                                }
                                        """)
                        .withStatusCode(200)
                        .withHeader("Content-Type", "application/json"));
        // mock list of third party providers
        String participantList;
        try {
            participantList = IOUtils
                    .readInputStreamToString(new ClassPathResource("participants.json").getInputStream());
        } catch (IOException err) {
            Assertions.fail(err.getMessage(), err);
            return;
        }
        mockServerClient.when(
                HttpRequest
                        .request("/api/scim/v2/OBThirdPartyProviders")
                        .withMethod("GET")
                        .withHeader("Authorization", "Bearer .*"))
                .respond(HttpResponse
                        .response(participantList)
                        .withStatusCode(200)
                        .withHeader("Content-Type", "application/json"));
    }

    @Test
    void authenticateTest() throws InterruptedException {
        log.debug("authenticateTest - start");
        // test authentication
        String expectedAuthToken = "eyJhbGciOiJkaXIiLCJlbmMiOiJBMTI4R0NNIiwiY3R5IjoiSldUIiwia2lkIjoiRW5jcnlwdCIsInBpLmF0bSI6IjNqbmUifQ..4WA2uXtDZYnVXIWX.T2a1FC4U2G85IAPUNvATueiscsB2qfQAj42fz2mbnpb6qMEP24vGPG5kyE4o-hV6OwQuChv0aYUj0VM2BtMy0Yt6QkwcLZqXcShsHc4jqIfXPJEa1eV4537kuBdczPHoCBWPJYpnkd8HpQ5SHpgsDlB3bVjvcd411xXDPptdfvYbfMih4pZZtN75vXOyfYAixTiC5_Dycei2WyaZYgacQ0AHKJZS8xMdgpjODZng9FhJGuog6fEX5HWPI1K7zwhPJiYyEOTAvYYfoPBuai2g2rG9_sWxW2L06H779204DmM061gpoQW8RnSo3-XILLPLYq5CiBLC17YNxkIqTVEscKr9iDANZMPvRcW111t8rc2qnvsIi6wt0Ns3tuOVeVCC2aAGLweSnsBxgAcV5IeOhpGXB2POLhgC-AA90mn3OMkXraJPdUw8ZGLVyphFzgVRGTZWT17weWvvgsNT1ACgGZetwqqdPogrkhZgQxTGD-Wh3E1lubQalCD3V-_vwbOGwt8ZgmFwdt2_erdYv7XNTTKN8qVnE2N0XQdJsoMiICt7jG7fQ_L9m-QOgLlv1ts4p7HLA1gqSNFnnuf0Dv2vDb4JGuO6oJrgdPvrJO3U8ycNeftg8vrgVM-tEFxypiqir5wtxsOSGTq_UXxpgMMFBeKD9d2nXUzDIFjoOQpItzP4NT5_K9KOm5MgMz8hpZS_Vjt8Pzi_c-WoS5uDwVXc5i_CwMEOzD10Yx703g2FBVtOdbW3BUiOwieP3is-_qPOmBM6dlD-h-4tD26fha6uTvrPGWXk2x9dYspixVm8-KAPHBi3haIIZu06hjRUi-EF-CmiuDPsTd4W_TojewwbvFofruaf9NkTi4dS8uBV0jM9pdIWH7Yi9Vcvqf_-hVKIJMzlbFgiXf_1BHGxR5NuZyBxQzOeX2XeU_vrIHa-XA.fB1wX8Qy3kDC6GjKe_ST3g";
        String authToken = directoryClient.authenticate().block();
        Assertions.assertThat(authToken).isEqualTo(expectedAuthToken);
    }

    @Test
    void getLoginJwsTest() throws ParseException {
        log.debug("getLoginJwsTest - start");
        String authToken;
        try {
            authToken = directoryClient.getLoginJws();
        } catch (JOSEException err) {
            Assertions.fail(err.getMessage(), err);
            return;
        }
        SignedJWT jws = SignedJWT.parse(authToken);
        var claims = jws.getJWTClaimsSet();
        Assertions.assertThat(claims.getIssuer()).isEqualTo(SSA_ID);
        Assertions.assertThat(claims.getSubject()).isEqualTo(SSA_ID);
        Assertions.assertThat(claims.getAudience().get(0)).isEqualTo(AUD);
        Assertions.assertThat(claims.getClaim("scope")).isEqualTo(SCOPE);
        Assertions.assertThat(claims.getJWTID()).isNotBlank();
        Assertions.assertThat(claims.getIssueTime()).isBefore(new Date());
        Assertions.assertThat(claims.getExpirationTime()).isAfter(new Date());
    }

    @Test
    void fetchSsasTest() {
        log.debug("fetchSsasTest - start");
        String authtoken = directoryClient.authenticate().block();
        StepVerifier.create(directoryClient.fetchSsas(authtoken).map(ssa -> ssa.getId()))
                .expectNext("ZOweevsn0W0cnGuUsbacki")
                .expectNext("UNdIFt55DjcTGQGFK4sVTI")
                .expectNext("5V3KmP9ulP0TqoF1lmpb4W")
                .expectNext("5vAqTqeICwt9Dq15KUNBdD")
                .expectNext("cKyaCCpSqnAnJsmKBa37mw")
                .expectComplete()
                .verify();
    }

    @Test
    void fetchParticipantsTest() {
        log.debug("fetchParticipantsTest - start");
        String authToken = directoryClient.authenticate().block();
        StepVerifier
                .create(directoryClient.fetchParticipants(authToken)
                        .map(participant -> participant.getUrnColonOpenbankingColonOrganisationColon10()
                                .getOrganisationCommonName()))
                .expectNext("Coventry Building Society")
                .expectNext("ALLPAY LIMITED")
                .expectComplete()
                .verify();
    }
}
