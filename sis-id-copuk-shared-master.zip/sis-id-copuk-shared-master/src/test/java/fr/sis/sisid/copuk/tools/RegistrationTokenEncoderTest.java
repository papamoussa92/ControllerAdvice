package fr.sis.sisid.copuk.tools;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jwt.SignedJWT;
import fr.sis.sisid.copuk.registration.model.OBClientRegistration1;
import org.junit.jupiter.api.Test;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.util.Base64;
import java.util.Date;
import java.util.UUID;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.lessThan;
import static org.junit.jupiter.api.Assertions.*;

class RegistrationTokenEncoderTest {

    @Test
    void testEncode() throws NoSuchAlgorithmException, ParseException, JOSEException, JsonProcessingException {
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        keyGen.initialize(2048);
        KeyPair keyPair = keyGen.genKeyPair();

        String keyID = UUID.randomUUID().toString();
        String privateKey = "-----BEGIN PRIVATE KEY-----\n" + Base64.getMimeEncoder().encodeToString(keyPair.getPrivate().getEncoded()) + "\n-----END PRIVATE KEY-----";
        System.out.println(privateKey);
        RegistrationTokenEncoder encoder = new RegistrationTokenEncoder(
                privateKey, new OBClientRegistration1(), 10000,
                keyID);


        String token = encoder.encode();
        SignedJWT signedJWT = SignedJWT.parse(token);
        assertEquals(keyID, signedJWT.getHeader().getKeyID());
        assertThat(signedJWT.getJWTClaimsSet().getIssueTime(), lessThan(new Date()));
        assertThat(signedJWT.getJWTClaimsSet().getExpirationTime(), greaterThan(new Date()));

    }
}