package fr.sis.sisid.copuk.dto;

import java.util.Optional;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

class AsymetricEncoderTest {

    private static final String PUBLIC_KEY = """
            -----BEGIN PUBLIC KEY-----
            MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEAzPpHQ5RdtPlnUX9bQi2H
            61vQbClvjFT3h8zCBsKQWLvrTf/OiJfrh5Dwc8E5CH1xZ2IFR1yoBBwmnXXctLl7
            bznsvDDjJaBvLC5UMrhYVvyuM86mKGwVM4Xzdgrgf07MmErpntex7Y1q2kYxGRle
            LBmGjFvWeEzmuHVGwZO3aZLEiAv3oga/vAOHMIO+vYEagWu+ZGX+zUK6coJM47+9
            oPooVMrLnDP10rXLM5Hx6jch9RVmOsBZnHtxi0304NxDKpD3Fmh0ROej2YCgAvoW
            w5ujVS8shajPE0ii3Cnny5lIMHnvbr583NSf+T6Kw695J7X6P7R+Ml8L9LcCclz8
            jHy8Je5r0gN3pgiV5PMyze4z2TyTXlHrc58VrK98Eh3w+lAnAcHL1ZYGVZVCW5I2
            0r+Yn+/LAHCBjD9/xYkCjpNr+QFh8zpiVOFKYrb+gJo5N2LMynUEm0HwspM9mBM2
            5H4IanuPydrxAgOdvNYutWhhFIEJEJkukDix4X+Dnu9HTk/8C8aSjVbeV3bDL/gI
            obve+ydVAaaM1cmjaJaAA6Eu4ibSJQ1PueD+4OMNzja9/D++0Jk572ixrStxVwxa
            jGsNv3POFaiQQBA6R2s7Hl0fQyVy7MZXk7oB12EuQgBgBX60o/tyVta9adDqAlxa
            1A94+e/oj6fEiG0v9XcbjOcCAwEAAQ==
            -----END PUBLIC KEY-----
            """;

    private static final String PRIVATE_KEY = """
            -----BEGIN PRIVATE KEY-----
            MIIJQgIBADANBgkqhkiG9w0BAQEFAASCCSwwggkoAgEAAoICAQDM+kdDlF20+WdR
            f1tCLYfrW9BsKW+MVPeHzMIGwpBYu+tN/86Il+uHkPBzwTkIfXFnYgVHXKgEHCad
            ddy0uXtvOey8MOMloG8sLlQyuFhW/K4zzqYobBUzhfN2CuB/TsyYSume17HtjWra
            RjEZGV4sGYaMW9Z4TOa4dUbBk7dpksSIC/eiBr+8A4cwg769gRqBa75kZf7NQrpy
            gkzjv72g+ihUysucM/XStcszkfHqNyH1FWY6wFmce3GLTfTg3EMqkPcWaHRE56PZ
            gKAC+hbDm6NVLyyFqM8TSKLcKefLmUgwee9uvnzc1J/5PorDr3kntfo/tH4yXwv0
            twJyXPyMfLwl7mvSA3emCJXk8zLN7jPZPJNeUetznxWsr3wSHfD6UCcBwcvVlgZV
            lUJbkjbSv5if78sAcIGMP3/FiQKOk2v5AWHzOmJU4Upitv6Amjk3YszKdQSbQfCy
            kz2YEzbkfghqe4/J2vECA5281i61aGEUgQkQmS6QOLHhf4Oe70dOT/wLxpKNVt5X
            dsMv+Aihu977J1UBpozVyaNoloADoS7iJtIlDU+54P7g4w3ONr38P77QmTnvaLGt
            K3FXDFqMaw2/c84VqJBAEDpHazseXR9DJXLsxleTugHXYS5CAGAFfrSj+3JW1r1p
            0OoCXFrUD3j57+iPp8SIbS/1dxuM5wIDAQABAoICAEvmJLsuVeBsNUilGtqPV3Pb
            5HoYgbh5wcpkFDhClQZ2VvPj08saTdk93vtNwduV74bzcbbx5TjYX6gQe2/j+oO9
            9B3fEEzfciru4LiDMBrNp4eBbl8rXlJcuECuWGBrgjCmFIl/nt+ybK10Ljv3+7ni
            ncKdQvX6q7gDnPaSxuhtsx4ZKFGzpA1vVQCu19L92h2wEqjEZ6wDmFxMSUJPvly8
            JHD5QpmNV+n07NAkq2opjgZdLSR2EvhxcSK+8/zLMoexc/y1ItBc4XvpN9bCWemG
            WN1zAU5gqoSecceKMM1f7a4diH3+ROfUR4QYF3PMJtWAebBbGht2vEuZ9Gr6aXzF
            Q/UiEq8+7vqTr3Ok0+4F3qaWIHsHnHXT7AOw0zqnsf4rOZ8OuOGfUuKWnJncl/mt
            PMEnTvErCDXpR9TG8MBnZEc9TEyWem5laQOzcCWukVzToci/BpH5AsW4b51J6XjS
            FCfZF0ib+UnipQagTPPnOxPIZ4OjNM+fdekI8Lv1YK/BLECI+IZlVch9HreyPkgU
            IP5iIzq0Z1goKThlAHlRnQ+6tyNi1WYi9XjFxO8tYuvtVFnqFeGRs5UvMCz1sofE
            Mhe4h4Yio6r0Mr6Br5MM/Op/L9a908yjU1SytPwRNp2kVa1HEkjbAEEdrhwV1Cyg
            /KGMIH8e36THdp35PoyxAoIBAQDPzj25jpdPFKr4Px49GIfEHtuX3yuDEbh+JTeZ
            4yh+ArNoaqdGfaTXx5Kltyce09QV4vdtVO8u/ONziMhrQ2CveF0+eVWBTTAioLqU
            v0/Xcl2Rsum/iIHmrFXUENCcMy0ZMfyHWBlpAWiDrMwT7fzAqkrpRNiSj9zym9Y4
            B2aKtzyJuEl8symc1zwu3oOfGGpMolf3jPPQEpqsv3TZJouYUatuIIv3q+6h3qtv
            PovDsyuRt6XHaNiS9kapeoUkNH++t41FM0zONd/8z+65idYJs0ocCvTjc7Ihz0SD
            dLDXvEfVTTjIdT7dDcpMFPS6B1NxET0/BddKYvifRicdkF5fAoIBAQD8hCKxCAur
            V/DVpG/NnxzNe89gYBZS7DK7j+dVxQOhKzNdmEWXJUwzaTPGwhaCfrneYLNX1Jg+
            wBLascDGzexuNB8P/08R2CCvWfHuk/Pvwi8Ti3KWM+ZNYwgubKMTJZJpq2DplRtD
            vdm+6THFTlaboqCqwIllRiwc+vrYUa/BzSCea32e66TcDCFAtP4H9kzS/YauWHcU
            4EdrJtmV6DKWbomRSG5OsVbtGTpdpgtDOKCit1lAxslCe7R1ewMBMADO4Gn10KyJ
            cSJqo+gWFuK66Sq2W8N1svr0J/tgr/LNEH7EbY1Ox7cGMkO1fmoOpMpguH82UBJY
            sGvktMfXok55AoIBAFXK7x7ZqMxkWwWsgV517y9gEgcMgxlUypeB5Aerif8kPE+i
            oLbwjorrgTbbe9I1YD08/CvuQeVjUMBVO3FVWuh2yABP9aYxaOsS8pUQuvTW6ZyK
            ggiqYf8LLVAlNQsX8cmSIpD6JVt90llykLq1qYEdjVnrK4Ku1GhxQCrXm1Uvu1Wc
            ePJ7wXVYQyeShEK9wL0s1SaF0e8YjzU8whAY4s8bAKyx0TeKizXXCW4fI3LDWPyL
            Fm1Scv+Rn7C+vZMp/YeOnktwl4gXJAdrDUMajfxpQfJ774isLmHZAY9IMO6QdBOz
            EvtntHFtDRUGHddjyOZIWMHZNn4miECxpNqGzP8CggEAdxnfvv4beuqUlj/j1+kn
            TagK7NsFTIFJgHvkUekFyDu3E3shv6OA6HLDUAj1UwFwq3mSvWdxk49GlU3nrh0s
            WeJNkF8MLU9yQyK6YJv6H2jIiYBpQH0kL/X4wuTMmdhL0Xla0XFZlb7y9//HUNed
            M/UlsMP1SgYqAlVCgUsuCcu1ieMLMizU6lDyUjHL63d5Tr7zikIBkKAkL174m6MU
            US27xwGRvZ4ZcOVISSlrAH6yDW1LNKlN/gSY3hxyE1pP10Oz1pRg/MaWxBOhAOI0
            eJJHahGoBFix0v0UrMrwS1ZvZDiDwNej9NE6bF0+qr+BENOUdMqZjKlRimLWK1fL
            iQKCAQEAof0nzuqZot8ixu6yaWiT7Il3Q9wcbwH1AW+XfEx8xBbpU12FCWWphDQP
            ty1/VmJ4/kGWKcqLZXP5sjyMdSsCTRdPp0uT6SMbQNIZ5Mc2W57XfcBF84uP4CMl
            Z+3MtycH1vHcdgUQG5aGJ3t4ncBlFntM+w0iMzqPkkMvZPPC/oFHV6+ukwJ5c1iK
            GX1DIj1gSiXCG/qU8KwZZsxO6LYuP3TecHI/bOsjHHVy5PVIa8gXoDtK2qWXUQz3
            3RcNUiphD0DvrJq5iHoubMh+lj1eN4hOb3M3ZhDQJf/SuwYeYlaF9s52asUKAp/5
            bUNKnYUo5Hf4pQjDZuBJDdOl8Ds9Tg==
            -----END PRIVATE KEY-----
            """;

    @Test
    void encryptDecryptTest() {
        AsymetricEncoder rsaEncrypter = new AsymetricEncoder(Optional.of(PRIVATE_KEY), PUBLIC_KEY);
        String payload = """
                test
                1234
                ;:/dsdfdf<>!!
                """;
        String encryptedPayload = rsaEncrypter.encryptToBase64(payload);
        Assertions.assertThat(encryptedPayload).isNotBlank().isNotEqualTo(payload);
        String deEncryptedPayload = rsaEncrypter.decryptFromBase64(encryptedPayload);
        Assertions.assertThat(deEncryptedPayload).isEqualTo(payload);
    }
}
