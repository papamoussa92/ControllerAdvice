package fr.sis.sisid.copuk;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class UnitTest {

    @Test
    void testUnitTestWorking() {
        assertTrue(true, "Unit testing is working");
    }

}
