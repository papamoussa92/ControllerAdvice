package fr.sis.sisid.copuk.bdd;

import fr.sis.sisid.copuk.SpringTestConfiguration;
import org.springframework.test.context.ContextConfiguration;
import io.cucumber.spring.CucumberContextConfiguration;

@CucumberContextConfiguration
@ContextConfiguration(classes = { SpringTestConfiguration.class })
public class CucumberSpringContextConfig {

}
