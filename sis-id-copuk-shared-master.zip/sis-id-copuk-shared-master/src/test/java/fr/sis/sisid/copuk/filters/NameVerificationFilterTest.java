package fr.sis.sisid.copuk.filters;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;
import org.springframework.web.server.MethodNotAllowedException;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilterChain;

import lombok.Getter;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

class NameVerificationFilterTest {

    @Test
    void testFilter_pathMatches() {
        WebFilterChain mockedChain = Mockito.mock(WebFilterChain.class);
        Mockito.when(mockedChain.filter(Mockito.any()))
                .thenReturn(Mono.empty());
        var request = MockServerHttpRequest.post("/v1.0/api/name-verification").build();
        var exchange = MockServerWebExchange.from(request);
        var nvFilter = new TestNVFilter("/v1.0/api/**");
        StepVerifier.create(nvFilter.filter(exchange, mockedChain))
                .expectComplete().verify();
        Assertions.assertThat(nvFilter.isCalled()).isTrue();
    }

    @Test
    void testFilter_pathDoesNotMatch() {
        WebFilterChain mockedChain = Mockito.mock(WebFilterChain.class);
        Mockito.when(mockedChain.filter(Mockito.any()))
                .thenReturn(Mono.empty());
        var request = MockServerHttpRequest.post("/different/path").build();
        var exchange = MockServerWebExchange.from(request);
        var nvFilter = new TestNVFilter("/v1.0/api/**");
        StepVerifier.create(nvFilter.filter(exchange, mockedChain))
                .expectComplete().verify();
        Assertions.assertThat(nvFilter.isCalled()).isFalse();
    }

    @Test
    void testFilter_pathMatchesWrongMethod() {
        WebFilterChain mockedChain = Mockito.mock(WebFilterChain.class);
        Mockito.when(mockedChain.filter(Mockito.any()))
                .thenReturn(Mono.empty());
        var request = MockServerHttpRequest.get("/v1.0/api/name-verification").build();
        var exchange = MockServerWebExchange.from(request);
        var nvFilter = new TestNVFilter("/v1.0/api/**");
        StepVerifier.create(nvFilter.filter(exchange, mockedChain))
                .expectError(MethodNotAllowedException.class).verify();
        Assertions.assertThat(nvFilter.isCalled()).isFalse();
    }

    private static class TestNVFilter extends NameVerificationFilter {

        @Getter
        private boolean called = false;

        protected TestNVFilter(String payUkPathPattern) {
            super(payUkPathPattern);
        }

        @Override
        protected Mono<Void> nameVerificationFilter(ServerWebExchange exchange, WebFilterChain chain) {
            this.called = true;
            return chain.filter(exchange);
        }

    }
}
