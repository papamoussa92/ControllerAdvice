package fr.sis.sisid.copuk.filters;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.mock.http.server.reactive.MockServerHttpRequest;
import org.springframework.mock.web.server.MockServerWebExchange;

import reactor.test.StepVerifier;

class BodyCaptureExchangeTest {

    @Test
    void getFullBodyTest() {
        MockServerHttpRequest request = MockServerHttpRequest.post("/different/path")
                .body("test body");
        MockServerWebExchange exchange = MockServerWebExchange.from(request);
        BodyCaptureExchange wrappedExcahnge = new BodyCaptureExchange(exchange);
        StepVerifier.create(wrappedExcahnge.getRequest().getBody())
                .consumeNextWith((n) -> {
                })
                .verifyComplete();
        Assertions.assertThat(wrappedExcahnge.getRequest().getFullBody()).isEqualTo("test body");

    }
}
