package fr.sis.sisid.copuk.tokens;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.ParseException;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.assertj.core.api.Assertions;
import org.joda.time.LocalDateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.core.io.ClassPathResource;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.jwk.JWK;

import fr.sis.sisid.copuk.OpenBankingConstants;
import lombok.extern.slf4j.Slf4j;

@Slf4j
class OpenBankingTokenFactoryTest {

    private String privateKey;

    private String publicKey;

    private Date now;

    private Date nowPlus1d;

    @BeforeEach
    void setup() throws IOException {
        this.privateKey = Files
                .readString(Path.of(new ClassPathResource("certs/signing/rsa-private.pem").getURI().getPath()));
        this.publicKey = Files
                .readString(Path.of(new ClassPathResource("certs/signing/rsa-public.pem").getURI().getPath()));
        this.now = new Date(ZonedDateTime.now().toEpochSecond() * 1000l);
        this.nowPlus1d = LocalDateTime.now().plusDays(1).toDate();
    }

    @Test
    void registrationTokenTest() throws JOSEException, ParseException {

        RegistrationTokenParameters params = RegistrationTokenParameters.builder()
                .privateKey(privateKey)
                .ssa("ssa")
                .kid("kid")
                .audience("audience")
                .issuer("issuer")
                .issueTime(now)
                .subject("subject")
                .grantsTypes(new String[] { "grant", "types" })
                .redirectUris(new String[] { "redirect", "uris" })
                .tokenEndpointAuthMethod("token endpoint auth method")
                .scope("scope")
                .idTokenSignedResponseAlg("id token signed response alg")
                .tokenEndpointAuthSigningAlg("token endpoint auth signing alg")
                .jwtId("jwt id")
                .jwsAlgorithm(JWSAlgorithm.PS256)
                .expiresAt(nowPlus1d)
                .requestObjectEncryptionAlg("request object encryption alg")
                .responseTypes(new String[] { "response", "types" })
                .requestObjectSigningAlg("request object signing alg")
                .softwareId("software-id")
                .tlsClientAuthSubjectDn("tls client auth dn")
                .build();

        String token = OpenBankingTokenFactory.makeToken(params);

        var parsedToken = JWSObject.parse(token);

        JWSVerifier verifier = new RSASSAVerifier(JWK.parseFromPEMEncodedObjects(publicKey).toRSAKey());
        Assertions.assertThat(parsedToken.verify(verifier)).isTrue();

        var claimsMap = parsedToken.getPayload().toJSONObject();
        Assertions.assertThat(claimsMap)
                .containsEntry("aud", "audience")
                .containsEntry("iss", "issuer")
                .containsEntry("iat", now.getTime() / 1000l)
                .containsEntry("sub", "subject")
                .containsEntry("scope", "scope")
                .containsEntry("software_statement", "ssa")
                .containsEntry("id_token_signed_response_alg", "id token signed response alg")
                .containsEntry("token_endpoint_auth_signing_alg", "token endpoint auth signing alg")
                .containsEntry("jti", "jwt id")
                .containsEntry("exp", nowPlus1d.getTime() / 1000l)
                .containsEntry("request_object_encryption_alg", "request object encryption alg")
                .containsEntry("request_object_signing_alg", "request object signing alg")
                .containsEntry("software_id", "software-id")
                .containsEntry("tls_client_auth_subject_dn", "tls client auth dn");
        Assertions.assertThat(new LinkedList<>((List<Object>) claimsMap.get("grant_types")))
                .containsExactlyInAnyOrder("grant", "types");
        Assertions.assertThat(new LinkedList<>((List<Object>) claimsMap.get("redirect_uris")))
                .containsExactlyInAnyOrder("redirect", "uris");
        Assertions.assertThat(new LinkedList<>((List<Object>) claimsMap.get("response_types")))
                .containsExactlyInAnyOrder("response", "types");
    }

    @Test
    void registrationTokenTest_nullFields() throws JOSEException, ParseException {
        var params = RegistrationTokenParameters.builder()
                .privateKey(privateKey)
                .ssa("ssa")
                .kid("kid")
                .audience("audience")
                .issuer("issuer")
                .issueTime(now)
                .subject("subject")
                .grantsTypes(new String[] { "grant", "types" })
                .redirectUris(new String[] { "redirect", "uris" })
                .tokenEndpointAuthMethod("token endpoint auth method")
                .scope("scope")
                .idTokenSignedResponseAlg("id token signed response alg")
                .tokenEndpointAuthSigningAlg("token endpoint auth signing alg")
                .jwtId("jwt id")
                .jwsAlgorithm(JWSAlgorithm.PS256)
                .expiresAt(null)
                .requestObjectEncryptionAlg(null)
                .responseTypes(null)
                .requestObjectSigningAlg(null)
                .softwareId(null)
                .tlsClientAuthSubjectDn(null)
                .build();

        String token = OpenBankingTokenFactory.makeToken(params);

        var parsedToken = JWSObject.parse(token);

        JWSVerifier verifier = new RSASSAVerifier(JWK.parseFromPEMEncodedObjects(publicKey).toRSAKey());
        Assertions.assertThat(parsedToken.verify(verifier)).isTrue();

        var claimsMap = parsedToken.getPayload().toJSONObject();
        Assertions.assertThat(claimsMap)
                .doesNotContainKeys("exp", "request_object_encryption_alg", "response_types",
                        "request_object_signing_alg", "software_id", "tls_client_auth_subject_dn");
    }

    @Test
    void registrationToken_noRedirectUris() throws JOSEException, ParseException {
        RegistrationTokenParameters params = RegistrationTokenParameters.builder()
                .privateKey(privateKey)
                .ssa("ssa")
                .kid("kid")
                .redirectUris(null)
                .build();
        String token = OpenBankingTokenFactory.makeToken(params);
        var claimsMap = JWSObject.parse(token).getPayload().toJSONObject();
        Assertions.assertThat(claimsMap).doesNotContainKey("redirect_uris");
    }

    @Test
    void loginTokenTest() throws JOSEException, ParseException {
        LoginTokenParameters params = LoginTokenParameters.builder()
                .audience("audience")
                .issuer("issuer")
                .subject("subject")
                .issueTime(now)
                .jwtId("jwt id")
                .expirationTime(now)
                .jwsAlgorithm(JWSAlgorithm.PS256)
                .rsaKey(privateKey)
                .build();
        String token = OpenBankingTokenFactory.makeToken(params);

        var parsedToken = JWSObject.parse(token);

        JWSVerifier verifier = new RSASSAVerifier(JWK.parseFromPEMEncodedObjects(publicKey).toRSAKey());
        Assertions.assertThat(parsedToken.verify(verifier)).isTrue();

        var claimsMap = parsedToken.getPayload().toJSONObject();
        Assertions.assertThat(claimsMap)
                .containsEntry("aud", "audience")
                .containsEntry("iss", "issuer")
                .containsEntry("sub", "subject")
                .containsEntry("iat", now.getTime() / 1000l)
                .containsEntry("jti", "jwt id")
                .containsEntry("exp", now.getTime() / 1000l);
    }

    @Test
    void nonRepudiationTokenTest() throws JOSEException, ParseException {
        NonRepudiationTokenParameters params = NonRepudiationTokenParameters.builder()
                .rsaKey(privateKey)
                .payload("{\"hello\":\"world\"}")
                .jwsAlgorithm(JWSAlgorithm.PS256)
                .objecType(JOSEObjectType.JOSE)
                .kid("kid")
                .contentType("application/json")
                .iat(now.getTime() / 1000)
                .tan("tan")
                .iss("iss")
                .build();

        String token = OpenBankingTokenFactory.makeToken(params);

        JWSObject parsedToken = JWSObject.parse(token, new Payload("{\"hello\":\"world\"}"));

        JWSVerifier verifier = new RSASSAVerifier(JWK.parseFromPEMEncodedObjects(publicKey).toRSAKey().toRSAPublicKey(),
                parsedToken.getHeader().getCriticalParams());

        Assertions.assertThat(parsedToken.verify(verifier)).isTrue();

        var headerClaims = parsedToken.getHeader().toJSONObject();
        Assertions.assertThat(headerClaims)
                .containsEntry("kid", "kid")
                .containsEntry("typ", "JOSE")
                .containsEntry("alg", "PS256")
                .containsEntry("cty", "application/json")
                .containsEntry("http://openbanking.org.uk/iat", now.getTime() / 1000l)
                .containsEntry("http://openbanking.org.uk/tan", "tan")
                .containsEntry("http://openbanking.org.uk/iss", "iss");

        Assertions.assertThat((List<String>) headerClaims.get("crit"))
                .contains("http://openbanking.org.uk/iat")
                .contains("http://openbanking.org.uk/tan")
                .contains("http://openbanking.org.uk/iss");
    }

    @Test
    void nonRepudiationTokenTest_nullFields() throws JOSEException, ParseException {
        NonRepudiationTokenParameters params = NonRepudiationTokenParameters.builder()
                .rsaKey(privateKey)
                .payload("{\"hello\":\"world\"}")
                .jwsAlgorithm(JWSAlgorithm.PS256)
                .objecType(JOSEObjectType.JOSE)
                .kid("kid")
                .contentType("application/json")
                .iat(now.getTime() / 1000)
                .tan("tan")
                .iss("iss")
                .objecType(null)
                .kid(null)
                .contentType(null)
                .iat(null)
                .tan(null)
                .iss(null)
                .crit(null)
                .build();

        String token = OpenBankingTokenFactory.makeToken(params);

        JWSObject parsedToken = JWSObject.parse(token, new Payload("{\"hello\":\"world\"}"));

        JWSVerifier verifier = new RSASSAVerifier(JWK.parseFromPEMEncodedObjects(publicKey).toRSAKey().toRSAPublicKey(),
                parsedToken.getHeader().getCriticalParams());

        Assertions.assertThat(parsedToken.verify(verifier)).isTrue();

        var headerClaims = parsedToken.getHeader().toJSONObject();
        Assertions.assertThat(headerClaims)
                .doesNotContainKeys("typ", "kid", "cty", OpenBankingConstants.CUSTOM_IAT_CLAIM,
                        OpenBankingConstants.CUSTOM_ISS_CLAIM, OpenBankingConstants.CUSTOM_TAN_CLAIM, "crit");
    }

    @Test
    void ssaTokenTest() throws JOSEException, ParseException {
        var ssaParams = SsaTokenParameters.builder()
                .kid("OXOKm9U8c48H09zw46P8O54l4QA=")
                .privateKey(privateKey)
                .jwtId("test-ssa-id")
                .build();

        String ssa = OpenBankingTokenFactory.makeToken(ssaParams);
        var parsedToken = JWSObject.parse(ssa);

        JWSVerifier verifier = new RSASSAVerifier(JWK.parseFromPEMEncodedObjects(publicKey).toRSAKey());
        Assertions.assertThat(parsedToken.verify(verifier)).isTrue();

        var claimsMap = parsedToken.getPayload().toJSONObject();
        Assertions.assertThat(claimsMap)
                .containsEntry("iss", "OpenBanking Ltd")
                .containsEntry("jti", "test-ssa-id");
    }

}
