package fr.sis.sisid.copuk.tools.errors;

import java.io.Serial;

/**
 * UK.OBIE.Signature.Invalid :
 * The signature header x-jws-signature was parsed and has
 * a valid JOSE header that complies with the specification.
 * However, the signature itself could not be verified
 */
public class InvalidJOSESignatureException extends JOSEValidationException {

    @Serial
    private static final long serialVersionUID = 4779091539298939457L;

    public InvalidJOSESignatureException(String message, Throwable err) {
        super(message, err);
    }
}
