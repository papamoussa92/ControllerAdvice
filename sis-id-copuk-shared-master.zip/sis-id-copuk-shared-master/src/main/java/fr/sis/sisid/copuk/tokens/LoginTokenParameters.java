package fr.sis.sisid.copuk.tokens;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.UUID;

import com.nimbusds.jose.JWSAlgorithm;

import lombok.Builder;
import lombok.Data;

/**
 * Parameters for an OAuth authentication token to our own authentication server.
 */
@Data
@Builder
public class LoginTokenParameters {

    private String audience;

    private String issuer;

    private String subject;

    @Builder.Default
    private Date issueTime = new Date();

    @Builder.Default
    private String jwtId = UUID.randomUUID().toString();

    @Builder.Default
    private Date expirationTime = Date
            .from(LocalDateTime.now().plus(6000, ChronoUnit.MINUTES).atZone(ZoneId.systemDefault()).toInstant());

    @Builder.Default
    private JWSAlgorithm jwsAlgorithm = JWSAlgorithm.PS256;

    private String rsaKey;
}
