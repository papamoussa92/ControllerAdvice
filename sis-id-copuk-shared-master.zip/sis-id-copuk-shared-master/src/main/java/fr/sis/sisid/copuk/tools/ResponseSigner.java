package fr.sis.sisid.copuk.tools;

import java.time.Instant;

import org.apache.commons.lang3.StringUtils;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.RSAKey;

import fr.sis.sisid.copuk.OpenBankingConstants;
import fr.sis.sisid.copuk.tokens.NonRepudiationTokenParameters;
import fr.sis.sisid.copuk.tokens.OpenBankingTokenFactory;
import lombok.Builder;

/**
 * Signs a payload served by the responder
 * Holds information about how to sign a paylaod.
 *
 */
@Builder
public class ResponseSigner {

    /**
     * Private key used to sign the payload
     */
    private RSAKey privateKey;

    /**
     * Algorithm used to sign the payload, must be compatible
     * with the key
     */
    @Builder.Default
    private JWSAlgorithm algorithm = JWSAlgorithm.PS256;

    /**
     * Ord id assigned to us by openbanking
     */
    private String orgId;

    /**
     * Id of the signing key
     */
    private String keyId;

    /**
     * Value of the TYP header of the generated signature
     */
    @Builder.Default
    private JOSEObjectType typHeaderValue = JOSEObjectType.JOSE;

    /**
     * Value of the CTY header of the generated signature
     */
    @Builder.Default
    private String ctyHeaderValue = "application/json";

    /**
     * Name of the custom IAT header claim of the generated signature
     */
    @Builder.Default
    private String iatHeaderName = OpenBankingConstants.CUSTOM_IAT_CLAIM;

    /**
     * Name of the custom TAN header claim of the generated signature
     */
    @Builder.Default
    private String tanHeaderName = OpenBankingConstants.CUSTOM_TAN_CLAIM;

    /**
     * Name of the generated ISS header claim of the generated signature
     */
    @Builder.Default
    private String issHeaderName = OpenBankingConstants.CUSTOM_ISS_CLAIM;

    /**
     * Value for the custom TAN header claim, should be the open banking domain
     */
    @Builder.Default
    private String tanHeaderValue = "openbanking.org.uk";

    /**
     * Builds a non-repudiaton signature for this payload
     * Signature is a jws with detached payload, payload is not base64 encoded
     * @param payload
     * @param currentTime
     * @return
     * @throws JOSEException
     */
    public String signPayload(String payload, Instant currentTime) throws JOSEException {
        if (this.privateKey == null || StringUtils.isAnyBlank(this.orgId, this.keyId)) {
            throw new IllegalArgumentException(
                    "Can not sign payload, missing required parameter with no default value");
        }
        var signatureParameters = NonRepudiationTokenParameters.builder()
                .parsedRsaKey(privateKey)
                .payload(payload)
                .jwsAlgorithm(this.algorithm)
                .objecType(this.typHeaderValue)
                .kid(this.keyId)
                .contentType(this.ctyHeaderValue)
                .iat(currentTime.toEpochMilli() / 1000l)
                .tan(this.tanHeaderValue)
                .iss(this.orgId).build();
        return OpenBankingTokenFactory.makeToken(signatureParameters);
    }

    public static class ResponseSignerBuilder {

        // These fields are used by the builder generated
        // by lombok. We override their definition to allow us
        // to set them from strings
        @SuppressWarnings("unused")
        private JOSEObjectType typHeaderValue;

        @SuppressWarnings("unused")
        private JWSAlgorithm algorithm;

        public ResponseSignerBuilder algorithm(String algorithm) {
            this.algorithm = JWSAlgorithm.parse(algorithm);
            return this;
        }

        public ResponseSignerBuilder privateKey(String privateKey) throws JOSEException {
            this.privateKey = JWK.parseFromPEMEncodedObjects(privateKey).toRSAKey();
            return this;
        }

        public ResponseSignerBuilder typHeaderValue(String typ) {
            this.typHeaderValue = new JOSEObjectType(typ);
            return this;
        }
    }
}
