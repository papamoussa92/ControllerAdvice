package fr.sis.sisid.copuk.exceptions;

import java.io.Serial;

public class EncryptionException extends RuntimeException {

    @Serial
    private static final long serialVersionUID = -3779996340551479412L;

    public EncryptionException(String msg, Throwable cause) {
        super(msg, cause);
    }

    public EncryptionException(String messge) {
        super(messge);
    }
}
