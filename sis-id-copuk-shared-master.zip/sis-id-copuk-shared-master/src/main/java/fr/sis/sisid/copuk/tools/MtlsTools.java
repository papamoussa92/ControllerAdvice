package fr.sis.sisid.copuk.tools;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.security.GeneralSecurityException;
import java.net.Socket;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.Principal;
import java.security.PrivateKey;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import javax.net.ssl.SSLEngine;
import javax.net.ssl.SSLException;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509ExtendedKeyManager;
import javax.net.ssl.X509TrustManager;

import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;

import io.netty.handler.ssl.ClientAuth;
import io.netty.handler.ssl.OpenSslX509KeyManagerFactory;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;

/**
 * Utility functions involving mutual TLS
 *
 */
public class MtlsTools {
    private MtlsTools() {
        // hide constructor
    }

    /**
     * Builds an ssl context to call external services which require mtls
     * @param signingKey
     * @param signingCert
     * @param transportCAs
     * @return
     * @throws SSLException
     */
    public static SslContext getMtlsSSLContext(PrivateKey signingKey, X509Certificate signingCert,
            Collection<X509Certificate> transportCAs) throws SSLException {
        try {
            return SslContextBuilder
                    .forClient().clientAuth(ClientAuth.OPTIONAL)
                    .trustManager(transportCAs)
                    .keyManager(new PinnedKeyManager(signingKey, signingCert))
                    .build();
        } catch (KeyManagementException e) {
            throw new SSLException(e);
        }
    }

    /**
     * Parses a PEM String representation of a private key to a PrivateKey object
     * @param rawPEMKey the encoded pem format string
     * @return
     * @throws IOException
     */
    public static PrivateKey parsePEMKey(String rawPEMKey) throws IOException {
        PEMParser pemParser = new PEMParser(new StringReader(rawPEMKey));
        JcaPEMKeyConverter converter = new JcaPEMKeyConverter();

        Object pemKey = pemParser.readObject();
        PrivateKey clientKey;
        if (pemKey instanceof PrivateKeyInfo privateKeyInfo) {
            clientKey = converter.getPrivateKey(privateKeyInfo);
        } else if (pemKey instanceof PEMKeyPair pemKeyPair) {
            clientKey = converter.getPrivateKey(pemKeyPair.getPrivateKeyInfo());
        } else {
            throw new IOException("Could not cast the client key");
        }
        return clientKey;
    }

    /**
     * Parses a PEM string representation of a certificate to an X509Certificate object 
     * @param rawPEMCert the encoded pem format string
     * @return
     * @throws CertificateException
     */
    public static X509Certificate parsePEMCert(String rawPEMCert) throws CertificateException {
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        return (X509Certificate) cf.generateCertificate(new ByteArrayInputStream(
                rawPEMCert.getBytes()));
    }

    /**
     * Gets default trusted certificates for ssl
     * @return
     * @throws NoSuchAlgorithmException
     * @throws KeyStoreException
     */
    public static Collection<X509Certificate> getBaseTrustedCertificates()  throws GeneralSecurityException {
        TrustManagerFactory trustManagerFactory = TrustManagerFactory
                .getInstance(TrustManagerFactory.getDefaultAlgorithm());
        trustManagerFactory.init((KeyStore) null);
        List<TrustManager> trustManagers = Arrays.asList(trustManagerFactory.getTrustManagers());
        return trustManagers.stream()
                .filter(X509TrustManager.class::isInstance)
                .map(X509TrustManager.class::cast)
                .map(trustManager -> Arrays.asList(trustManager.getAcceptedIssuers()))
                .flatMap(Collection::stream)
                .toList();
    }

    /**
     * Client cert key manager to allow for pinned client certificate instead of CA validation which the JDK supports.
     * @See https://bugs.openjdk.org/browse/JDK-8272351
     */

    private static class PinnedKeyManager extends X509ExtendedKeyManager {
        private static final String KEY_ALIAS = "key";

        private OpenSslX509KeyManagerFactory keyManagerFactory;

        private X509ExtendedKeyManager delegate;

        public PinnedKeyManager(PrivateKey privateKey, X509Certificate... certificates) throws KeyManagementException {
            try {
                KeyStore keystore = KeyStore.getInstance(KeyStore.getDefaultType());
                keystore.load(null, "".toCharArray());
                keystore.setKeyEntry(KEY_ALIAS, privateKey, "".toCharArray(), certificates);
                keyManagerFactory = new OpenSslX509KeyManagerFactory();
                keyManagerFactory.init(keystore, "".toCharArray());
                this.delegate = (X509ExtendedKeyManager) keyManagerFactory.getKeyManagers()[0];
            } catch (KeyStoreException | IOException | NoSuchAlgorithmException | CertificateException
                    | UnrecoverableKeyException e) {
                throw new KeyManagementException(e);
            }
        }

        @Override
        public String[] getClientAliases(String keyType, Principal[] issuers) {
            return delegate.getClientAliases(keyType, issuers);
        }

        @Override
        public String chooseEngineClientAlias(String[] keyType, Principal[] issuers, SSLEngine engine) {
            return this.chooseClientAlias(keyType, issuers, null);
        }

        @Override
        public String chooseClientAlias(String[] keyType, Principal[] issuers, Socket socket) {
            String alias = delegate.chooseClientAlias(keyType, issuers, socket);
            if (alias == null) {
                return KEY_ALIAS;
            }
            return alias;
        }

        @Override
        public String[] getServerAliases(String keyType, Principal[] issuers) {
            return new String[0];
        }

        @Override
        public String chooseServerAlias(String keyType, Principal[] issuers, Socket socket) {
            return delegate.chooseServerAlias(keyType, issuers, socket);
        }

        @Override
        public X509Certificate[] getCertificateChain(String alias) {
            return delegate.getCertificateChain(alias);
        }

        @Override
        public PrivateKey getPrivateKey(String alias) {
            return delegate.getPrivateKey(alias);
        }
    }

}
