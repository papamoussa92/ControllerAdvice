package fr.sis.sisid.copuk.exceptions;

import java.io.Serial;

import fr.sis.sisid.copuk.copapi.model.OBErrorResponse1;
import lombok.Getter;

/**
 * Exception that wraps an OpenBanking error DTO,
 * to be returned to the client along with an http status code
 *
 */
public class OBErrorResponseException extends RuntimeException {

    @Serial
    private static final long serialVersionUID = -1651834830077903780L;

    @Getter
    private final transient OBErrorResponse1 errorDTO;

    @Getter
    private final int statusCode;

    public OBErrorResponseException(OBErrorResponse1 errorDTO, int statusCode) {
        super(errorDTO.getMessage());
        this.statusCode = statusCode;
        this.errorDTO = errorDTO;
    }

}
