package fr.sis.sisid.copuk.dto;

import lombok.Data;

@Data
public class SsaDTO {

    private String jti;

    private String orgId;

    private String softwareJwksEndpoint;
    private String softwareId;
}
