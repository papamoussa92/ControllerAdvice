package fr.sis.sisid.copuk.openbanking.directory;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import fr.sis.sisid.copuk.openbanking.directory.model.InlineResponse200;
import fr.sis.sisid.copuk.openbanking.directory.model.Participants;
import fr.sis.sisid.copuk.openbanking.directory.model.SoftwareStatementSoftwareStatements;
import fr.sis.sisid.copuk.tools.MtlsTools;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.ssl.SslContext;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHeaders;
import org.openapitools.jackson.nullable.JsonNullableModule;
import org.springframework.beans.factory.BeanInitializationException;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.http.codec.json.Jackson2JsonDecoder;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import reactor.netty.tcp.SslProvider.SslContextSpec;
import reactor.netty.transport.logging.AdvancedByteBufFormat;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Slf4j
public class OBDirectoryClientImpl implements OBDirectoryClient {

    // authentication web client
    private final WebClient authenticationObDirectoryWebClient;

    // api webclient
    private final WebClient obDirectoryWebClient;

    // private key to sign a client assertion when authenticating
    private final RSAKey signingPrivateKey;

    // directory access related properties
    private final OBDirectoryProperties properties;

    /**
     * Creates an openbanking directory client
     * @param signingKey: private key to sign software assertions
     * @param transportKey: private transport key for mtls purposes
     * @param transportCert: mtls client cert
     * @param transportCAs: CAs to trust for ssl purposes
     * @param properties: openbanking directory access related properties
     *  
     */
    public OBDirectoryClientImpl(
            String signingKey,
            String transportKey,
            String transportCert,
            Collection<String> transportCAs,
            OBDirectoryProperties properties) {
        this(signingKey, transportKey, transportCert, transportCAs,
                properties, new ObjectMapper());
    }

    /**
     * Creates an openbaking directory client
     * @param signingKey: private key to sign software assertions
     * @param transportKey: private transport key for mtls purposes
     * @param transportCert: mtls client cert
     * @param transportCAs: CAs to trust for ssl purposes
     * @param properties: openbanking directory access related properties
     * @param objectMapper: object mapper to deserialize results with
     *  
     */
    public OBDirectoryClientImpl(
            String signingKey,
            String transportKey,
            String transportCert,
            Collection<String> transportCAs,
            OBDirectoryProperties properties,
            ObjectMapper objectMapper) {
        try {
            this.properties = properties;
            PrivateKey transportPrivateKey = MtlsTools.parsePEMKey(transportKey);
            X509Certificate transportx509Certificate = MtlsTools.parsePEMCert(transportCert);
            // make a list of CA to trust for ssl
            List<X509Certificate> caCertificates = new LinkedList<>();
            for (String ca : transportCAs) {
                // CA from parameters
                caCertificates.add(MtlsTools.parsePEMCert(ca));
            }
            // CA from system
            caCertificates.addAll(MtlsTools.getBaseTrustedCertificates());
            // ssl context with client cert + custom list of CA
            SslContext mtlsSslContext = MtlsTools.getMtlsSSLContext(transportPrivateKey, transportx509Certificate,
                    caCertificates);
            // http client using custom ssl context + with logging
            HttpClient httpClient = HttpClient.create()
                    .wiretap(log.getName(), LogLevel.DEBUG, AdvancedByteBufFormat.TEXTUAL)
                    .secure((SslContextSpec sslContextSpec) -> sslContextSpec.sslContext(mtlsSslContext));
            // create a webclient for authenticating
            this.authenticationObDirectoryWebClient = WebClient.builder()
                    .clientConnector(new ReactorClientHttpConnector(httpClient))
                    .baseUrl(properties.getSsoBaseUrl())
                    .build();
            // create another weblient to call the API with ( different base URLs )
            objectMapper.registerModule(new JsonNullableModule());
            ExchangeStrategies strategies = ExchangeStrategies.builder()
                    .codecs(codecs -> {
                        codecs.defaultCodecs().maxInMemorySize(1024 * 1024); // 1Mb
                        codecs.defaultCodecs()
                                .jackson2JsonDecoder(new Jackson2JsonDecoder(objectMapper, MediaType.APPLICATION_JSON));
                    })
                    .build();
            this.obDirectoryWebClient = WebClient.builder()
                    .clientConnector(new ReactorClientHttpConnector(httpClient))
                    .baseUrl(properties.getApiBaseUrl())
                    // response body can be big, this prevents
                    // org.springframework.core.io.buffer.DataBufferLimitException
                    .exchangeStrategies(strategies)
                    .build();
            // parse and store the signing private key, to be used when authenticating
            this.signingPrivateKey = JWK.parseFromPEMEncodedObjects(signingKey).toRSAKey();
        } catch (IOException | GeneralSecurityException | JOSEException err) {
            throw new BeanInitializationException("Failed to initialize OB directory client", err);
        }
    }

    @Override
    public Flux<SoftwareStatementSoftwareStatements> fetchSsas(String authenticationToken) {
        // query a list of every participant
        return this.obDirectoryWebClient
                .method(HttpMethod.GET)
                .uri("/scim/v2/OBThirdPartyProviders")
                .header("Authorization", "Bearer " + authenticationToken)
                .header(HttpHeaders.ACCEPT, "application/json")
                .retrieve()
                .bodyToMono(InlineResponse200.class)
                // map it to a flux of software statements
                .flatMapIterable(tppListResponse ->
                     tppListResponse.getResources().stream()
                            .map(Participants::getUrnColonOpenbankingColonSoftwarestatementColon10)
                            .filter(Objects::nonNull)
                            .flatMap(softwareStatement -> softwareStatement.getSoftwareStatements().stream()
                                    .filter(Objects::nonNull))
                            .toList()
                );
    }

    @Override
    public Flux<Participants> fetchParticipants(String authenticationToken) {
        return this.obDirectoryWebClient
                .method(HttpMethod.GET)
                .uri("/scim/v2/OBThirdPartyProviders")
                .header("Authorization", "Bearer " + authenticationToken)
                .header(HttpHeaders.ACCEPT, "application/json")
                .retrieve()
                .bodyToMono(InlineResponse200.class)
                .flatMapIterable(InlineResponse200::getResources);
    }

    /**
     * Builds a client assertion used in the authentication form
     * @return a serialized jws
     * @throws JOSEException
     */
    public String getLoginJws() throws JOSEException {
        var claims = new JWTClaimsSet.Builder()
                .issuer(this.properties.getSsaId())
                .subject(this.properties.getSsaId())
                .audience(this.properties.getAuthenticationAud())
                .claim("scope", this.properties.getAuthenticationScope())
                .jwtID(UUID.randomUUID().toString())
                .issueTime(new Date())
                .expirationTime(Date.from(LocalDateTime.now().plusHours(1L).atZone(ZoneId.systemDefault()).toInstant()))
                .build();
        var header = new JWSHeader.Builder(JWSAlgorithm.RS256)
                .type(JOSEObjectType.JWT)
                .keyID(this.properties.getSigningKeyId())
                .build();
        var jws = new SignedJWT(header, claims);
        jws.sign(new RSASSASigner(this.signingPrivateKey));
        return jws.serialize();
    }

    @Override
    public Mono<String> authenticate() {
        // 1. build jwt
        String loginJWS;
        try {
            loginJWS = this.getLoginJws();
        } catch (JOSEException err) {
            return Mono.error(err);
        }

        // 2. send auth req
        return this.authenticationObDirectoryWebClient
                .method(HttpMethod.POST)
                .uri("/as/token.oauth2")
                .header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE)
                .body(
                        BodyInserters
                                .fromFormData("client_assertion_type",
                                        "urn:ietf:params:oauth:client-assertion-type:jwt-bearer")
                                .with("grant_type", "client_credentials")
                                .with("client_id", this.properties.getSsaId())
                                .with("client_assertion", loginJWS))
                .retrieve()
                .bodyToMono(OBDirectoryAuthenticationResponse.class)
                .flatMap(authenticationResponse -> Mono.just(authenticationResponse.getAccessToken()));
    }

}
