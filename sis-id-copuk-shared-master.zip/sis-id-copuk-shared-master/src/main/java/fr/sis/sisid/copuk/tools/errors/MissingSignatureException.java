package fr.sis.sisid.copuk.tools.errors;

public class MissingSignatureException extends JOSEValidationException{

    public MissingSignatureException(String message, Throwable err) {
        super(message, err);
    }

    public MissingSignatureException(String message) {
        super(message);
    }
}
