package fr.sis.sisid.copuk.tools;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.jose.jws.SignatureAlgorithm;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.NimbusReactiveJwtDecoder;
import org.springframework.security.oauth2.jwt.ReactiveJwtDecoder;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.nimbusds.oauth2.sdk.util.StringUtils;

import fr.sis.sisid.copuk.tools.errors.JwtDeserializationException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JwtTools {

    private static final String JWT_PARSING_GENERIC_ERR = "Could not deserialize JWT";

    private final ObjectMapper objectMapper;

    private final Set<JWSAlgorithm> supportedAlgorithms;

    public JwtTools(ObjectMapper objectMapper, Collection<String> supportedAlgorithms) {
        this.objectMapper = objectMapper;
        this.supportedAlgorithms = supportedAlgorithms.stream().map(JWSAlgorithm::parse).collect(Collectors.toSet());
    }

    /**
     * Deserializes claims from a jwt into an object
     *
     * @param <T>
     * @param serializedJws
     * @param type
     * @return
     * @throws JwtDeserializationException
     */
    public <T> T deserializeClaims(String serializedJws, Class<T> type) throws JwtDeserializationException {
        if (StringUtils.isBlank(serializedJws) || type == null) {
            throw new IllegalArgumentException();
        }
        try {
            SignedJWT jws = SignedJWT.parse(serializedJws);
            JWTClaimsSet claims = jws.getJWTClaimsSet();
            String claimsJsonObject = claims.toString(false);
            return objectMapper.readValue(claimsJsonObject, type);
        } catch (ParseException | JsonProcessingException e) {
            throw new JwtDeserializationException(JWT_PARSING_GENERIC_ERR, e);
        }
    }

    public String getClaims(String serializedJws, JwtStringClaims claim) throws JwtDeserializationException {
        try {
            SignedJWT jws = SignedJWT.parse(serializedJws);
            return switch (claim) {
            case ALGORITHM ->
                getFromJws(jws, token -> token.getHeader().getAlgorithm(), "JWT has no algorithm in its header")
                        .getName();
            case ISSUER -> getFromJws(jws, token -> token.getJWTClaimsSet().getIssuer(), "JWT has no issuer claim");
            case KEY_ID -> getFromJws(jws, token -> token.getHeader().getKeyID(), "JWT has no kid in its header");
            case TYPE -> getFromJws(jws, token -> token.getHeader().getType(),
                    "JWT has no typ in its header").toString();
            case AUTHORIZED_PARTY ->
                getFromJws(jws, token -> token.getJWTClaimsSet().getStringClaim("azp"), "JWR has no azp claim");
            default -> throw new JwtDeserializationException("Unknown claim type");
            };
        } catch (ParseException err) {
            throw new JwtDeserializationException(JWT_PARSING_GENERIC_ERR, err);
        }
    }

    public <T> T getFromJws(SignedJWT jwt, ParseJwt<T> accessor, String errMsg) {
        try {
            T result;
            result = accessor.apply(jwt);
            if (result == null || (result instanceof String stringResult && StringUtils.isBlank(stringResult))) {
                throw new JwtDeserializationException(errMsg);
            }
            return result;
        } catch (ParseException e) {
            throw new JwtDeserializationException(JWT_PARSING_GENERIC_ERR, e);
        }

    }

    public LocalDateTime getExpiresAt(String serializedJws) {
        try {
            SignedJWT jws = SignedJWT.parse(serializedJws);
            return LocalDateTime.ofInstant(jws.getJWTClaimsSet().getExpirationTime().toInstant(),
                    ZoneId.systemDefault());
        } catch (ParseException err) {
            throw new JwtDeserializationException(JWT_PARSING_GENERIC_ERR, err);
        }
    }

    @FunctionalInterface
    public interface ParseJwt<T> {
        T apply(SignedJWT token) throws ParseException;
    }

    public ReactiveJwtDecoder getJwtDecoder(String jwksUrl, WebClient jwtClient,
            Collection<OAuth2TokenValidator<Jwt>> validators) {
        var algorithms = this.supportedAlgorithms.stream().map(JWSAlgorithm::getName).collect(Collectors.toSet());
        return this.getJwtDecoder(jwksUrl, algorithms, jwtClient, validators);
    }

    public ReactiveJwtDecoder getJwtDecoder(String jwksUrl, Set<String> supportedAlgorithms, WebClient jwksClient,
            Collection<OAuth2TokenValidator<Jwt>> validators) {
        Set<SignatureAlgorithm> algorithms = supportedAlgorithms.stream().map(SignatureAlgorithm::from)
                .collect(Collectors.toSet());
        var jwtDecoder = NimbusReactiveJwtDecoder.withJwkSetUri(jwksUrl)
                // validate algorithm
                .jwsAlgorithms((Set<SignatureAlgorithm> signatureAlgorithms) -> {
                    signatureAlgorithms.clear();
                    signatureAlgorithms.addAll(algorithms);
                })
                // a verification is done by default on the typ header, and rejects anything
                // other than JWT
                // we override this behaviour
                .jwtProcessorCustomizer(jwtProcessor -> jwtProcessor.setJWSTypeVerifier((type, context) -> {
                    // no verification, accept all token types
                }))
                .webClient(jwksClient)
                .build();
        jwtDecoder.setJwtValidator(new DelegatingOAuth2TokenValidator<>(validators));
        return jwtDecoder;
    }

    public JoseDecoder getJoseDecoder(
            String jwksUrl, WebClient webClient,
            List<JoseHeaderValidator<?>> validators) {
        return this.getJoseDecoder(
                jwksUrl,
                this.supportedAlgorithms.stream().map(JWSAlgorithm::getName).collect(Collectors.toSet()),
                webClient,
                validators);
    }

    public JoseDecoder getJoseDecoder(
            String jwksUrl, Set<String> supportedAlgorithms, WebClient webClient,
            List<JoseHeaderValidator<?>> validators) {
        return new JoseDecoder(jwksUrl, supportedAlgorithms, webClient, validators);
    }

}
