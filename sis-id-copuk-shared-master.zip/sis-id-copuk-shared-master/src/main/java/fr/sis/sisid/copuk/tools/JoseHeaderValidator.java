package fr.sis.sisid.copuk.tools;

import java.util.function.Predicate;

import org.springframework.util.Assert;

import com.nimbusds.jose.JOSEObject;

import fr.sis.sisid.copuk.tools.errors.InvalidJOSEClaimException;
import fr.sis.sisid.copuk.tools.errors.JOSEValidationException;
import lombok.extern.slf4j.Slf4j;

/**
 * Validate a header in a {@link JOSEObject} against a provided
 * {@link Predicate}
 *
 * @param <T> Type to cast the header value to
 */
@Slf4j
public class JoseHeaderValidator<T> {

    protected final String headerName;

    private final Predicate<T> test;

    private final JOSEValidationException error;

    /**
     * Constructs a validator using the provided parameters
     * @param headerName - is the name of the header in {@link JOSEObject} to validate
     * @param test - is the predicate function for the header to test against.
     */
    public JoseHeaderValidator(String headerName, Predicate<T> test) {
        Assert.notNull(headerName, "header can not be null");
        Assert.notNull(test, "test can not be null");
        this.headerName = headerName;
        this.test = test;
        this.error = new InvalidJOSEClaimException(this.headerName);
    }

    /**
     * Validates the header in this token
     * @param token
     * @throws JOSEValidationException if the header is invalid
     */
    public void validate(JOSEObject token) throws JOSEValidationException {
        Assert.notNull(token, "token cannot be null");
        try {
            T headerValue = getHeaderValue(token);
            if (!this.test.test(headerValue)) {
                log.debug(this.error.getMessage());
                throw this.error;
            }
        } catch (ClassCastException err) {
            log.debug(err.getMessage(), err);
            throw this.error;
        }
    }

    protected T getHeaderValue(JOSEObject token) {
        return (T) token.getHeader().toJSONObject().get(headerName);
    }
}
