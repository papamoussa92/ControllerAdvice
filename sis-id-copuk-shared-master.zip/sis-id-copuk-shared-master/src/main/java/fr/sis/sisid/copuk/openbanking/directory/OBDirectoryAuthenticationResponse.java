package fr.sis.sisid.copuk.openbanking.directory;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.Data;

/**
 * Successful response when authenticating to the open banking directory SSO
 */
@Data
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class OBDirectoryAuthenticationResponse {
    private String tokenType;
    private long expiresIn;
    private String accessToken;
}
