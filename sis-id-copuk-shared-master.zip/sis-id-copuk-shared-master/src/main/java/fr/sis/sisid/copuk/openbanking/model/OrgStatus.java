package fr.sis.sisid.copuk.openbanking.model;

import com.fasterxml.jackson.annotation.JsonValue;

import lombok.Getter;

@Getter
public enum OrgStatus {

    ACTIVE("Active"), REVOKED("Revoked"), WITHDRAWN("Withdrawn");

    @JsonValue
    private String value;

    private OrgStatus(String value) {
        this.value = value;
    }
}
