package fr.sis.sisid.copuk.copapi;

public enum OpenBankingErrorCode {
    /**
     * An invalid value is supplied in one of the fields. Reference
     * of the invalid field should be provided in the path field,
     * and url field may have the link to a website explaining the
     * valid behaviour. The error message should describe the
     * problem in detail
     */
    INVALID_FIELD("UK.OBIE.Field.Invalid"),
    /**
     * A mandatory field, required for the API, is missing from
     * the payload. This error code can be used, if it is not
     * already captured under the validation for
     * UK.OBIE.Resource.InvalidFormat. Reference of the
     * missing field should be provided in the path field, and
     * URL field may have the link to a website explaining the
     * valid behaviour.
     */
    FIELD_MISSING("UK.OBIE.Field.Missing"),
    /**
     * An invalid value is supplied in the HTTP header. HTTP
     * Header should be specified in the path element.
     */
    HEADER_INVALID("UK.OBIE.Header.Invalid"),
    /**
     * A required HTTP header has not been provided. HTTP
     * Header should be specified in the path element.
     */
    HEADER_MISSING("UK.OBIE.Header.Missing"),
    /**
     * The signature header x-jws-signature was parsed and has
     * a valid JOSE header that complies with the specification.
     * However, the signature itself could not be verified.
     */
    SIGNATURE_INVALID("UK.OBIE.Signature.Invalid"),
    /**
     * The JOSE header in the x-jws-signature has one or more
     * claims with an invalid value. (e.g. a kid that does not
     * resolve to a valid certificate). The name of the missing
     * claim should be specified in the path field of the error
     * response.
     */
    SIGNATURE_INVALID_CLAIM("UK.OBIE.Signature.InvalidClaim"),
    /**
     * The JOSE header in the x-jws-signature has one or more
     * mandatory claim(s) that are not specified. The name of
     * the missing claim(s) should be specified in the path field
     * of the error response.
     */
    SIGNATURE_MISSING_CLAIM("UK.OBIE.Signature.MissingClaim"),
    /**
     * The x-jws-signature in the request header was malformed
     * and could not be parsed as a valid JWS.
     */
    SIGNATURE_MALFORMED("UK.OBIE.Signature.Malformed"),
    /**
     * The API request expected an x-jws-signature in the
     * header, but it was missing.
     */
    SIGNATURE_MISSING("UK.OBIE.Signature.Missing"),

    /**
     * Returned when a resource with the specified Id does not exist (and hence could not be operated upon).
     */
    RESOURCE_NOT_FOUND("UK.OBIE.Resource.NotFound"),

    /**
     * An error code that can be used, when an unexpected
     * error occurs. The CoP Responder must populate the
     * message with a meaningful error description, without
     * revealing sensitive information.
     */
    UNEXPECTED_ERROR("UK.OBIE.UnexpectedError");

    private String code;

    OpenBankingErrorCode(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
