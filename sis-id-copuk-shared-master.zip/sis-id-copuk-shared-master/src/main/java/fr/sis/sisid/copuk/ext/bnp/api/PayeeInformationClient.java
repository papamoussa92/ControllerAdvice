package fr.sis.sisid.copuk.ext.bnp.api;

import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;

import fr.sis.sisid.copuk.ext.bnp.model.CopReply;
import fr.sis.sisid.copuk.ext.bnp.model.CopRequest;
import reactor.core.publisher.Mono;

/**
 * Client for the BNP PayeeInformation API
 */
public interface PayeeInformationClient {

    /**
     * Fetch payee information
     * 
     * This API provides from an account:
     *  - the client name 
     *  - the list of currencies associated to the account 
     *  - the account type (Organisation, Private)        
     * 
     * @param copRequest
     * @return a confirmation of payee response
     * @throws RestClientException
     */
    public Mono<ResponseEntity<CopReply>> providePayeeInformation(CopRequest copRequest);

    /**
     * Performs a an HTTP HEAD request to the payee informatino endpoint
     * @return
     */
    public Mono<ResponseEntity<Void>> headRequest();
}
