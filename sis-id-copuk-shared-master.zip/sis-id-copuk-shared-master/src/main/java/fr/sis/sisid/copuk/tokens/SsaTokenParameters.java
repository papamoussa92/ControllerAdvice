package fr.sis.sisid.copuk.tokens;

import java.util.Date;

import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SsaTokenParameters {

    public static final String DEFAULT_BNPP_SITE = "https://www.bnpparibas.co.uk/en/";
    private String privateKey;

    @Builder.Default
    private JWSAlgorithm jwsAlgorithm = JWSAlgorithm.PS256;

    private String kid;

    @Builder.Default
    private JOSEObjectType objectType = JOSEObjectType.JWT;

    @Builder.Default
    private String issuer = "OpenBanking Ltd";

    @Builder.Default
    private Date issuedAt = new Date(1653374609 * 1000l);

    private Date expiresAt;

    @Builder.Default
    private String jwtId = "a24a6ea4-ce75-4665-a070-57453082c256";

    @Builder.Default
    private String softwareEnvironment = "sandbox";

    @Builder.Default
    private String softwareMode = "Test";

    @Builder.Default
    private String softwareId = "UVpTUUTzBFoQHpISL2ii91";

    @Builder.Default
    private String softwareClientId = "UVpTUUTzBFoQHpISL2ii91";

    @Builder.Default
    private String softwareClientName = "Sis ID";

    @Builder.Default
    private String softwareClientDescription = "Integration testing";

    @Builder.Default
    private String softwareClientVersion = "0.1";

    @Builder.Default
    private String softwareClientUri = DEFAULT_BNPP_SITE;

    @Builder.Default
    private String[] softwareRedirectUris = new String[] { "https://copuk-int.sis-id4banks.com/copuk-responder" };

    @Builder.Default
    private String[] softwareRoles = new String[] { "COPRequester", "COPResponder" };

    @Data
    @Builder
    public static class OrganisationCompetentAuthorityClaims {

        @Builder.Default
        private String authorityId = "PAYUKGBR";

        @Builder.Default
        private String registrationId = "100054";

        @Builder.Default
        private String status = "Active";

        @Data
        @Builder
        public static class Authorisations {

            @Builder.Default
            private String memberState = "GB";

            @Builder.Default
            private String[] roles = new String[] { "COPRequester", "COPResponder" };
        }

        @Builder.Default
        private Authorisations[] authorisations = new Authorisations[] { Authorisations.builder().build() };

    }

    @Builder.Default
    private OrganisationCompetentAuthorityClaims organisationCompetentAuthorityClaims = OrganisationCompetentAuthorityClaims
            .builder().build();

    @Builder.Default
    private String softwareLogoUri = DEFAULT_BNPP_SITE;

    @Builder.Default
    private String orgStatus = "Active";

    @Builder.Default
    private String orgId = "0014H00003ARnTmQAL";

    @Builder.Default
    private String orgName = "BNP Paribas London Branch";

    @Data
    @Builder
    public static class OrgContacts {

        @Builder.Default
        private String name = "Technical";

        @Builder.Default
        private String email = "nicolas.cousyn@sis-id.com";

        @Builder.Default
        private String type = "Technical";

        private String phone;

    }

    @Builder.Default
    private OrgContacts[] orgContacts = new OrgContacts[] { OrgContacts.builder().build() };

    @Builder.Default
    private String orgJwksEndpoint = "https://keystore.openbankingtest.org.uk/0014H00003ARnTmQAL/0014H00003ARnTmQAL.jwks";

    @Builder.Default
    private String orgJwksRevokedEndpoint = "https://keystore.openbankingtest.org.uk/0014H00003ARnTmQAL/revoked/0014H00003ARnTmQAL.jwks";

    @Builder.Default
    private String softwareJwksEndpoint = "https://keystore.openbankingtest.org.uk/0014H00003ARnTmQAL/UVpTUUTzBFoQHpISL2ii91.jwks";

    @Builder.Default
    private String softwareJwksRevokedEndpoint = "https://keystore.openbankingtest.org.uk/0014H00003ARnTmQAL/revoked/UVpTUUTzBFoQHpISL2ii91.jwks";

    @Builder.Default
    private String softwarePolicyUri = DEFAULT_BNPP_SITE;

    @Builder.Default
    private String softwareTosUri = DEFAULT_BNPP_SITE;

    @Builder.Default
    private String softwareOnBehalfOfOrg = "BNP Paribas London";

}
