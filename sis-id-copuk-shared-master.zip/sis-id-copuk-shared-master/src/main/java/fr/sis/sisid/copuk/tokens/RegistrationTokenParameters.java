package fr.sis.sisid.copuk.tokens;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.UUID;

import com.nimbusds.jose.JWSAlgorithm;

import lombok.Builder;
import lombok.Data;

/** 
 * Parameters to generate a dynamic client registration JWS
 */
@Builder(toBuilder = true)
@Data
public class RegistrationTokenParameters {

    private String privateKey;

    private String ssa;

    private String kid;

    @Builder.Default
    private String audience = "0014H00003ARnTmQAL";

    @Builder.Default
    private String issuer = "UVpTUUTzBFoQHpISL2ii91";

    @Builder.Default
    private Date issueTime = new Date();

    @Builder.Default
    private String subject = "f1e33ab3-027f-47c5-bb07-8dd8ab37a2d3";

    @Builder.Default
    private String[] grantsTypes = new String[] { "client_credentials" };

    @Builder.Default
    private String[] redirectUris = new String[] { "https://copuk-int.sis-id4banks.com/copuk-responder" };

    @Builder.Default
    private String tokenEndpointAuthMethod = "private_key_jwt";

    @Builder.Default
    private String scope = "openid name-verification";

    @Builder.Default
    private String idTokenSignedResponseAlg = JWSAlgorithm.PS256.getName();

    @Builder.Default
    private String tokenEndpointAuthSigningAlg = JWSAlgorithm.PS256.getName();

    @Builder.Default
    private String jwtId = UUID.randomUUID().toString();

    @Builder.Default
    private JWSAlgorithm jwsAlgorithm = JWSAlgorithm.PS256;

    @Builder.Default
    private Date expiresAt = Date.from(LocalDateTime.now().plusHours(1).atZone(ZoneId.systemDefault()).toInstant());

    private String requestObjectEncryptionAlg;

    private String[] responseTypes;

    @Builder.Default
    private String requestObjectSigningAlg = JWSAlgorithm.PS256.getName();

    @Builder.Default
    private String applicationType = "web";

    private String softwareId;

    private String tlsClientAuthSubjectDn;

}
