package fr.sis.sisid.copuk.tokens;

import java.time.Instant;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.jwk.RSAKey;

import fr.sis.sisid.copuk.OpenBankingConstants;
import lombok.Builder;
import lombok.Data;

/**
 * Parameters to generate a non repudiation JWS with a detached, non-encoded payload
 * This is used in HHTTP requests between CoP responders and requesters.
 *
 */
@Data
@Builder(toBuilder = true)
public class NonRepudiationTokenParameters {

    private String rsaKey;

    private RSAKey parsedRsaKey;

    private String payload;

    @Builder.Default
    private JWSAlgorithm jwsAlgorithm = JWSAlgorithm.PS256;

    @Builder.Default
    private JOSEObjectType objecType = JOSEObjectType.JOSE;

    private String kid;

    @Builder.Default
    private String contentType = "application/json";

    @Builder.Default
    private Long iat = Instant.now().toEpochMilli() / 1000l;

    private String tan;

    private String iss;

    @Builder.Default
    private Set<String> crit = Stream.of(
            OpenBankingConstants.CUSTOM_IAT_CLAIM,
            OpenBankingConstants.CUSTOM_ISS_CLAIM,
            OpenBankingConstants.CUSTOM_TAN_CLAIM)
            .collect(Collectors.toSet());

}
