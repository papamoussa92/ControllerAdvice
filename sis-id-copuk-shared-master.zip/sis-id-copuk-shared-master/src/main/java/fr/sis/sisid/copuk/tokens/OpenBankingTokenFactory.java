package fr.sis.sisid.copuk.tokens;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;

import fr.sis.sisid.copuk.OpenBankingConstants;
import fr.sis.sisid.copuk.tokens.SsaTokenParameters.OrgContacts;
import fr.sis.sisid.copuk.tokens.SsaTokenParameters.OrganisationCompetentAuthorityClaims.Authorisations;

public class OpenBankingTokenFactory {

    private OpenBankingTokenFactory() {
        /* hide constructor */
    }

    public static String makeToken(RegistrationTokenParameters param) throws JOSEException {
        var rsaKey = JWK.parseFromPEMEncodedObjects(param.getPrivateKey()).toRSAKey();
        var claimsBuilder = new JWTClaimsSet.Builder()
                .audience(param.getAudience())
                .issuer(param.getIssuer())
                .issueTime(param.getIssueTime())
                .subject(param.getSubject())
                .claim("grant_types", param.getGrantsTypes())
                .claim("redirect_uris", param.getRedirectUris())
                .claim("token_endpoint_auth_method", param.getTokenEndpointAuthMethod())
                .claim("scope", param.getScope())
                .claim("software_statement", param.getSsa())
                .claim("id_token_signed_response_alg", param.getIdTokenSignedResponseAlg())
                .claim("token_endpoint_auth_signing_alg", param.getTokenEndpointAuthSigningAlg())
                .claim("application_type", param.getApplicationType())
                .jwtID(param.getJwtId());
        if (param.getExpiresAt() != null) {
            claimsBuilder.expirationTime(param.getExpiresAt());
        }
        if (param.getRequestObjectEncryptionAlg() != null) {
            claimsBuilder.claim("request_object_encryption_alg", param.getRequestObjectEncryptionAlg());
        }
        if (param.getResponseTypes() != null) {
            claimsBuilder.claim("response_types", param.getResponseTypes());
        }
        if (param.getRequestObjectSigningAlg() != null) {
            claimsBuilder.claim("request_object_signing_alg", param.getRequestObjectSigningAlg());
        }

        if (param.getSoftwareId() != null) {
            claimsBuilder.claim("software_id", param.getSoftwareId());
        }

        if (param.getTlsClientAuthSubjectDn() != null) {
            claimsBuilder.claim("tls_client_auth_subject_dn", param.getTlsClientAuthSubjectDn());
        }

        var claims = claimsBuilder.build();

        var header = new JWSHeader.Builder(param.getJwsAlgorithm())
                .type(JOSEObjectType.JWT)
                .keyID(param.getKid())
                .build();
        var jws = new SignedJWT(header, claims);
        jws.sign(new RSASSASigner(rsaKey));
        return jws.serialize();
    }

    public static String makeToken(LoginTokenParameters param) throws JOSEException {
        var rsaKey = JWK.parseFromPEMEncodedObjects(param.getRsaKey()).toRSAKey();

        var claims = new JWTClaimsSet.Builder()
                .audience(param.getAudience())
                .issuer(param.getIssuer())
                .subject(param.getSubject())
                .issueTime(param.getIssueTime())
                .jwtID(param.getJwtId())
                .expirationTime(param.getExpirationTime())
                .build();
        var header = new JWSHeader.Builder(param.getJwsAlgorithm())
                .type(JOSEObjectType.JWT)
                .build();
        var jws = new SignedJWT(header, claims);
        jws.sign(new RSASSASigner(rsaKey));
        return jws.serialize();
    }

    public static String makeToken(NonRepudiationTokenParameters params) throws JOSEException {
        RSAKey rsaKey;
        if (params.getParsedRsaKey() != null) {
            rsaKey = params.getParsedRsaKey();
        } else {
            rsaKey = JWK.parseFromPEMEncodedObjects(params.getRsaKey()).toRSAKey();
        }

        Payload detachedPayload = new Payload(params.getPayload());

        var headerBuilder = new JWSHeader.Builder(params.getJwsAlgorithm());
        headerBuilder.base64URLEncodePayload(false);
        if (params.getObjecType() != null) {
            headerBuilder.type(params.getObjecType());
        }
        if (params.getKid() != null) {
            headerBuilder.keyID(params.getKid());
        }
        if (params.getContentType() != null) {
            headerBuilder.contentType(params.getContentType());
        }
        if (params.getIat() != null) {
            headerBuilder.customParam(OpenBankingConstants.CUSTOM_IAT_CLAIM, params.getIat());
        }
        if (params.getTan() != null) {
            headerBuilder.customParam(OpenBankingConstants.CUSTOM_TAN_CLAIM, params.getTan());
        }
        if (params.getIss() != null) {
            headerBuilder.customParam(OpenBankingConstants.CUSTOM_ISS_CLAIM, params.getIss());
        }
        if (params.getCrit() != null) {
            headerBuilder.criticalParams(params.getCrit());
        }
        JWSHeader header = headerBuilder.build();

        JWSObject token = new JWSObject(header, detachedPayload);
        token.sign(new RSASSASigner(rsaKey));

        return token.serialize(true);
    }

    public static String makeToken(SsaTokenParameters params) throws JOSEException {
        var claimsBuilder = new JWTClaimsSet.Builder();
        if (params.getIssuer() != null) {
            claimsBuilder.issuer(params.getIssuer());
        }
        if (params.getIssuedAt() != null) {
            claimsBuilder.issueTime(params.getIssuedAt());
        }
        if (params.getExpiresAt() != null) {
            claimsBuilder.expirationTime(params.getExpiresAt());
        }
        if (params.getJwtId() != null) {
            claimsBuilder.jwtID(params.getJwtId());
        }
        addClaimIfPresent(claimsBuilder,  params.getSoftwareEnvironment(), "software_environment");
        addClaimIfPresent(claimsBuilder,  params.getSoftwareMode(), "software_mode");
        addClaimIfPresent(claimsBuilder,  params.getSoftwareId(), "software_id");
        addClaimIfPresent(claimsBuilder,  params.getSoftwareClientId(), "software_client_id");
        addClaimIfPresent(claimsBuilder,  params.getSoftwareClientName(), "software_client_name");
        addClaimIfPresent(claimsBuilder,  params.getSoftwareClientDescription(), "software_client_description");
        addClaimIfPresent(claimsBuilder,  params.getSoftwareClientVersion(), "software_version");
        addClaimIfPresent(claimsBuilder,  params.getSoftwareClientUri(), "software_client_uri");
        addClaimIfPresent(claimsBuilder,  params.getSoftwareRedirectUris(), "software_redirect_uris");
        addClaimIfPresent(claimsBuilder,  params.getSoftwareRoles(), "software_roles");

        if (params.getOrganisationCompetentAuthorityClaims() != null) {
            buildOrgAuthorityClaims(params, claimsBuilder);
        }

        addClaimIfPresent(claimsBuilder,  params.getSoftwareLogoUri(), "software_logo_uri");
        addClaimIfPresent(claimsBuilder,  params.getOrgStatus(), "org_status");
        addClaimIfPresent(claimsBuilder,  params.getOrgId(), "org_id");
        addClaimIfPresent(claimsBuilder,  params.getOrgName(), "org_name");

        if (params.getOrgContacts() != null) {
            buildOrContactClaims(params, claimsBuilder);
        }
        addClaimIfPresent(claimsBuilder,  params.getOrgJwksEndpoint(), "org_jwks_endpoint");
        addClaimIfPresent(claimsBuilder,  params.getOrgJwksRevokedEndpoint(), "org_jwks_revoked_endpoint");
        addClaimIfPresent(claimsBuilder,  params.getSoftwareJwksEndpoint(), "software_jwks_endpoint");
        addClaimIfPresent(claimsBuilder,  params.getSoftwareJwksRevokedEndpoint(), "software_jwks_revoked_endpoint");
        addClaimIfPresent(claimsBuilder,  params.getSoftwarePolicyUri(), "software_policy_uri");
        addClaimIfPresent(claimsBuilder,  params.getSoftwareTosUri(), "software_tos_uri");
        addClaimIfPresent(claimsBuilder,  params.getSoftwareOnBehalfOfOrg(), "software_on_behalf_of_org");

        var claims = claimsBuilder.build();

        var header = new JWSHeader.Builder(params.getJwsAlgorithm())
                .type(params.getObjectType())
                .keyID(params.getKid())
                .build();
        SignedJWT token = new SignedJWT(header, claims);
        token.sign(new RSASSASigner(JWK.parseFromPEMEncodedObjects(params.getPrivateKey()).toRSAKey()));
        return token.serialize();
    }

    private static void buildOrContactClaims(SsaTokenParameters params, JWTClaimsSet.Builder claimsBuilder) {
        List<Map<String, Object>> orgContacts = new LinkedList<>();
        for (OrgContacts orgContact : params.getOrgContacts()) {
            Map<String, Object> orgContactMap = new HashMap<>();
            if (orgContact.getEmail() != null) {
                orgContactMap.put("email", orgContact.getEmail());
            }
            if (orgContact.getName() != null) {
                orgContactMap.put("name", orgContact.getName());
            }
            if (orgContact.getPhone() != null) {
                orgContactMap.put("phone", orgContact.getPhone());
            }
            if (orgContact.getType() != null) {
                orgContactMap.put("type", orgContact.getType());
            }
            orgContacts.add(orgContactMap);
        }
        claimsBuilder.claim("org_contacts", orgContacts);
    }

    private static void buildOrgAuthorityClaims(SsaTokenParameters params, JWTClaimsSet.Builder claimsBuilder) {
        Map<String, Object> ocacMap = new HashMap<>();
        var ocac = params.getOrganisationCompetentAuthorityClaims();
        if (ocac.getAuthorityId() != null) {
            ocacMap.put("authority_id", ocac.getAuthorityId());
        }
        if (ocac.getRegistrationId() != null) {
            ocacMap.put("registration_id", ocac.getRegistrationId());
        }
        if (ocac.getStatus() != null) {
            ocacMap.put("status", ocac.getStatus());
        }
        if (ocac.getAuthorisations() != null) {

            List<Map<String, Object>> authorisations = new LinkedList<>();
            for (Authorisations auth : ocac.getAuthorisations()) {
                Map<String, Object> authMap = new HashMap<>();
                if (auth.getMemberState() != null) {
                    authMap.put("member_state", auth.getMemberState());
                }
                if (auth.getRoles() != null) {
                    authMap.put("roles", auth.getRoles());
                }
                authorisations.add(authMap);
            }
            ocacMap.put("authorisations", authorisations);

        }
        claimsBuilder.claim("organisation_competent_authority_claims", ocacMap);
    }

    private static void addClaimIfPresent(JWTClaimsSet.Builder claimsBuilder, Object claimValue, String claimName) {
        if(claimValue != null) {
            claimsBuilder.claim(claimName, claimValue);
        }
    }

}
