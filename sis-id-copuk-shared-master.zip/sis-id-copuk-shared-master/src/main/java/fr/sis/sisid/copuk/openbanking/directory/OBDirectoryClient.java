package fr.sis.sisid.copuk.openbanking.directory;

import fr.sis.sisid.copuk.openbanking.directory.model.Participants;
import fr.sis.sisid.copuk.openbanking.directory.model.SoftwareStatementSoftwareStatements;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface OBDirectoryClient {

    /**
     * Queries the software statements of third party providers enrolled into UK open banking
     * @param authenticationToken : a valid authorization token
     * @return
     */
    public Flux<SoftwareStatementSoftwareStatements> fetchSsas(String authenticationToken);

    /**
     * Queries the list of open banking participants
     * @param authenticationToken
     * @return
     */
    public Flux<Participants> fetchParticipants(String authenticationToken);

    /**
     * Authenticates to the open banking directory SSO
     * @return an access token
     */
    public Mono<String> authenticate();

}
