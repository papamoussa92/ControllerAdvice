package fr.sis.sisid.copuk.tools.errors;

public class JwtDeserializationException extends RuntimeException {

    private static final long serialVersionUID = 4382365811643873708L;

    public JwtDeserializationException(String message, Throwable cause) {
        super(message, cause);
    }

    public JwtDeserializationException(String message) {
        super(message);
    }
}
