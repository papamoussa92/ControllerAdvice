package fr.sis.sisid.copuk;

public class OpenBankingConstants {
    public static final String ORGANISATION_HEADER = "x-fapi-financial-id";
    public static final String CORRELATION_ID_HEADER = "x-fapi-interaction-id";
    public static final String NON_REPUDIATION_HEADER = "x-jws-signature";

    public static final String CUSTOM_TAN_CLAIM = "http://openbanking.org.uk/tan";
    public static final String CUSTOM_ISS_CLAIM = "http://openbanking.org.uk/iss";
    public static final String CUSTOM_IAT_CLAIM = "http://openbanking.org.uk/iat";

    private OpenBankingConstants() {
        // hide constructor
    }

}
