package fr.sis.sisid.copuk.openbanking.directory;

import lombok.Data;

@Data
public class OBDirectoryProperties {

    /**
     * Scope to request when authenticating to ob directory
     */
    private String authenticationScope;

    /**
     * Software id of the ssa we authenticate with
     */
    private String ssaId;

    /**
     * Kid of the key used to sign the client assertion JWS, when authenticating to ob directory
     */
    private String signingKeyId;

    /**
     * Aud claim when authenticating to ob directory
     */
    private String authenticationAud;

    /**
     * Base url of the ob directory sso
     */
    private String ssoBaseUrl;

    /**
     * Base url of the ob driectory api
     */
    private String apiBaseUrl;
}
