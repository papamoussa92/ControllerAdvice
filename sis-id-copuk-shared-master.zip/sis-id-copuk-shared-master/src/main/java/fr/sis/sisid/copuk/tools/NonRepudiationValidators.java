package fr.sis.sisid.copuk.tools;

import java.time.Instant;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.nimbusds.oauth2.sdk.util.StringUtils;

import fr.sis.sisid.copuk.OpenBankingConstants;

/**
 * Shared JOSE validators to validate CoP non-repudiation
 *
 */
public class NonRepudiationValidators {

    private NonRepudiationValidators() {
        // hide constructor
    }

    /**
     * Validates the optional typ claim
     * @param supportedTyp
     * @return
     */
    public static JoseHeaderValidator<String> typValidator(String supportedTyp) {
        return new JoseHeaderValidator<>("typ", typ -> StringUtils.isBlank(typ) || supportedTyp.equals(typ));
    }

    /**
     * Validates the optional cty claim
     * @param supportedCty
     * @return
     */
    public static JoseHeaderValidator<String> ctyValidator(List<String> supportedCty) {
        return new JoseHeaderValidator<>("cty", cty -> StringUtils.isBlank(cty) || supportedCty.contains(cty));
    }

    /**
     * Validates the required iat header
     * @param iatClaimName
     * @return
     */
    public static JoseHeaderValidator<Long> iatValidator() {
        return new JoseRequiredHeaderValidator<>(OpenBankingConstants.CUSTOM_IAT_CLAIM,
                iat -> iat != null && Instant.ofEpochSecond(iat).isBefore(Instant.now()));
    }

    /**
     * Validates the required iss claim coming from a responder
     * @param issClaimName
     * @param responderOrgId: orgId of the responder signing the payload
     * @return
     */
    public static JoseHeaderValidator<String> responderIssValidator(String responderOrgId) {
        return new JoseRequiredHeaderValidator<>(OpenBankingConstants.CUSTOM_ISS_CLAIM,
                iss -> StringUtils.isNotBlank(iss) && responderOrgId.trim().equals(iss.trim()));
    }

    /**
     * Validates the required iss claim coming from a requester
     * @param issClaimName
     * @param requesterOrgId : orgId of the requester signing the paylaod
     * @param requesterSoftwareId : software id of the requester signing the payload
     * @return
     */
    public static JoseHeaderValidator<String> requesterIssValidator(String requesterOrgId, String requesterSoftwareId) {
        return new JoseRequiredHeaderValidator<>(OpenBankingConstants.CUSTOM_ISS_CLAIM,
                iss -> StringUtils.isNotBlank(iss)
                        && (requesterOrgId.trim() + "/" + requesterSoftwareId.trim()).equals(iss.trim()));
    }

    /**
     * Validates the required tan claim
     * @param tanClaimName
     * @param supportedTan
     * @return
     */
    public static JoseHeaderValidator<String> tanValidator(String supportedTan) {
        return new JoseRequiredHeaderValidator<>(OpenBankingConstants.CUSTOM_TAN_CLAIM,
                tan -> StringUtils.isNotBlank(tan) && supportedTan.equals(tan));
    }

    /**
     * Validates the required crit claim 
     * @param iatClaimName
     * @param issClaimName
     * @param tanClaimName
     * @return
     */
    public static JoseHeaderValidator<Collection<String>> critValidator() {
        Set<String> headerNames = Stream.of(OpenBankingConstants.CUSTOM_IAT_CLAIM,
                OpenBankingConstants.CUSTOM_ISS_CLAIM, OpenBankingConstants.CUSTOM_TAN_CLAIM)
                .collect(Collectors.toSet());
        return new JoseRequiredHeaderValidator<>("crit",
                crit -> crit != null && headerNames.containsAll(crit) && crit.containsAll(headerNames));
    }

    /**
     * Validates the required kid header
     * @return
     */
    public static JoseHeaderValidator<String> kidValidator() {
        return new JoseRequiredHeaderValidator<>("kid", StringUtils::isNotBlank);
    }

}
