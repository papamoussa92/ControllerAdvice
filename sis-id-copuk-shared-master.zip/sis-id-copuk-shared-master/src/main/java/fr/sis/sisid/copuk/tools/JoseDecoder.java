package fr.sis.sisid.copuk.tools;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.text.ParseException;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.logging.log4j.util.Strings;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.jwk.source.RemoteJWKSet;
import com.nimbusds.jose.proc.BadJOSEException;
import com.nimbusds.jose.proc.DefaultJOSEProcessor;
import com.nimbusds.jose.proc.JOSEProcessor;
import com.nimbusds.jose.proc.JWSVerificationKeySelector;
import com.nimbusds.jose.proc.SecurityContext;
import com.nimbusds.jose.util.Resource;
import com.nimbusds.jose.util.ResourceRetriever;
import com.nimbusds.oauth2.sdk.util.StringUtils;

import fr.sis.sisid.copuk.tools.errors.InvalidJOSESignatureException;
import fr.sis.sisid.copuk.tools.errors.JOSEValidationException;
import fr.sis.sisid.copuk.tools.errors.MalformedJOSESignatureException;
import fr.sis.sisid.copuk.tools.errors.MissingSignatureException;
import lombok.Data;
import reactor.core.publisher.Mono;

/**
 * Parses and validate a JOSE object
 * Handles objects with detached payloads
 */
public class JoseDecoder {

    private final JOSEProcessor<SecurityContext> joseProcessor;

    private final List<JoseHeaderValidator<?>> validators;
    private final Mono<Resource> jwksResource;

    /**
     * Constructs a JOSE decoder
     *
     * @param jwksURI             : URI of the jwks holding the public key to validate signatures
     * @param supportedAlgorithms : allowed signature algorithms
     * @param webClient           : Rest template to fetch the JWK with
     * @param validators          : List of validators applied in order against the parsed JOSE
     */
    public JoseDecoder(
            String jwksURI,
            Collection<String> supportedAlgorithms,
            WebClient webClient,
            List<JoseHeaderValidator<?>> validators) {
        Set<JWSAlgorithm> algorithms = supportedAlgorithms.stream().map(JWSAlgorithm::parse)
                .collect(Collectors.toSet());
        URL jwksURL;
        try {
            jwksURL = new URL(jwksURI);
        } catch (MalformedURLException e) {
            throw new IllegalArgumentException("Jwks url is invalid");
        }
        var processor = new DefaultJOSEProcessor<>();
        var resourceRetriever = getResourceRetriever(webClient);
        jwksResource = resourceRetriever.fetchResource(jwksURL);
        var jwkSource = new RemoteJWKSet<>(jwksURL, resourceRetriever);
        var jwsKeySelector = new JWSVerificationKeySelector<>(algorithms, jwkSource);
        processor.setJWSKeySelector(jwsKeySelector);
        processor.setJWSVerifierFactory(new CritIgnoringJWSVerifierFactory());
        this.joseProcessor = processor;
        this.validators = new LinkedList<>(validators);

    }

    /**
     * Validates a JOSE with detached payload
     *
     * @param headerSignature b64 encoded header + signature
     * @param payload         : detached payload
     * @throws JOSEValidationException if the object is invalid
     */
    public Mono<Boolean> validate(String headerSignature, String payload) {
        return jwksResource.flatMap(v -> {
            try {
                if (Strings.isBlank(headerSignature)) {
                    return Mono.error(new MissingSignatureException("Missing signature"));
                }
                var parsedJws = JWSObject.parse(headerSignature, new Payload(payload));
                this.joseProcessor.process(parsedJws, null);
                for (var validator : this.validators) {
                    validator.validate(parsedJws);
                }
                return Mono.just(Boolean.TRUE);
            } catch (ParseException e) {
                return Mono.error(new MalformedJOSESignatureException("Could not process this token"));
            } catch (BadJOSEException | JOSEException e) {
                return Mono.error(new InvalidJOSESignatureException("Could not process this token", e));
            }

        });
    }

    /**
     * Fetches JWKS from a URI
     *
     * @param webClient The REST client to use for reading a remote resource
     * @return A Handle to retrieve a resource
     */
    private ReactiveResourceRetriever getResourceRetriever(WebClient webClient) {

        return new ReactiveResourceRetriever() {

            @Override
            Mono<Resource> fetchResource(URL url) {
                // do a GET request
                try {
                    return webClient.get().uri(url.toURI())
                            .accept(MediaType.APPLICATION_JSON, new MediaType("application", "jwk-set+json")).retrieve()
                            .toEntity(String.class).flatMap(response -> {
                                // throw if not HTTP 200
                                if (response.getStatusCodeValue() != 200) {
                                    return Mono.error(new IOException(response.toString()));
                                }
                                if (StringUtils.isBlank(response.getBody())) {
                                    return Mono.error(new IOException("empty response"));
                                }

                                return Mono.just(createResource(response.getBody(), "UTF-8"));
                            });

                } catch (URISyntaxException e) {
                    return Mono.error(new IOException(e));
                }
            }
        };

    }

    @Data
    private abstract static class ReactiveResourceRetriever implements ResourceRetriever {

        Resource resource;

        abstract Mono<Resource> fetchResource(URL url);

        public Resource createResource(String content, String contentType) {
            this.resource = new Resource(content, contentType);
            return this.resource;
        }

        @Override
        public Resource retrieveResource(URL url) {
            return resource;
        }
    }

}
