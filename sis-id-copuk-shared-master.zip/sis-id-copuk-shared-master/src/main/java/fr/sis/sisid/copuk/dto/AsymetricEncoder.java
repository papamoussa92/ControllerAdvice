package fr.sis.sisid.copuk.dto;

import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.KeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Optional;

import javax.crypto.Cipher;

import fr.sis.sisid.copuk.exceptions.EncryptionException;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AsymetricEncoder {

    private static final String ALGO = "RSA/ECB/OAEPWITHSHA-256ANDMGF1PADDING";
    private final KeyFactory keyFactory;
    private PrivateKey privateKey;
    private final PublicKey publicKey;

    public AsymetricEncoder(Optional<String> privateKeyFile, String publicKeyFile) {
        try {
            this.keyFactory = KeyFactory.getInstance("RSA");
        } catch (NoSuchAlgorithmException e) {
            throw new EncryptionException("Encryption algorithm not found", e);
        }
        if (privateKeyFile.isPresent()) {
            this.privateKey = getPrivateKey(privateKeyFile.get());
        }
        this.publicKey = getPublicKey(publicKeyFile);
    }

    private PrivateKey getPrivateKey(String privateKeyFile) {
        try {
            String privateKeyString = privateKeyFile
                    .replaceAll(System.lineSeparator(), "")
                    .replace("-----BEGIN PRIVATE KEY-----", "")
                    .replace("-----END PRIVATE KEY-----", "")
                    .trim();

            byte[] decoded = Base64
                    .getDecoder()
                    .decode(privateKeyString);
            KeySpec keySpec = new PKCS8EncodedKeySpec(decoded);

            return keyFactory.generatePrivate(keySpec);
        } catch (Exception e) {
            throw new EncryptionException("Invalid encryption private Key", e);
        }
    }

    protected PublicKey getPublicKey(String publicKeyFile) {
        try {
            String publicKeyString = publicKeyFile
                    .replaceAll(System.lineSeparator(), "")
                    .replace("-----BEGIN PUBLIC KEY-----", "")
                    .replace("-----END PUBLIC KEY-----", "")
                    .trim();
            byte[] decoded = Base64.getDecoder().decode(publicKeyString);
            KeySpec keySpec = new X509EncodedKeySpec(decoded);

            return keyFactory.generatePublic(keySpec);
        } catch (Exception e) {
            throw new EncryptionException("Invalid encryption public key", e);
        }
    }

    public String encryptToBase64(String identifiantNumber) {
        String encoded = null;
        try {
            Cipher cipher = Cipher.getInstance(ALGO);
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
            byte[] encrypted = cipher.doFinal(identifiantNumber.getBytes());
            encoded = Base64.getEncoder().encodeToString(encrypted);
        } catch (Exception e) {
            throw new EncryptionException("Failed to encrypt", e);
        }
        return encoded;
    }

    public String decryptFromBase64(String base64EncodedEncryptedBytes) {
        if (privateKey == null) {
            throw new EncryptionException("Failed to decrypt, missing private key");
        }
        try {
            final Cipher cipher = Cipher.getInstance(ALGO);
            cipher.init(Cipher.DECRYPT_MODE, privateKey);
            byte[] decoded = Base64
                    .getDecoder()
                    .decode(base64EncodedEncryptedBytes);
            byte[] decrypted = cipher.doFinal(decoded);
            return new String(decrypted);
        } catch (Exception e) {
            throw new EncryptionException("Failed to decrypt", e);
        }

    }
}
