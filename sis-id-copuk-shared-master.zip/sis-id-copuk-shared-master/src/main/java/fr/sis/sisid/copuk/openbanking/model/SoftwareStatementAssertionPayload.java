package fr.sis.sisid.copuk.openbanking.model;

import java.util.List;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Schema of the payload of a software statement assertion
 * cf https://github.com/OpenBankingUK/directory-api-specs/blob/master/directory-api-swagger.yaml
 * 
 *
 */
@Data
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SoftwareStatementAssertionPayload {

//    | Metadata | Description | Source Specification |
//    |----------|-------------|----------------------|
//    |`software_id`|Unique Identifier for TPP Client Software|[RFC7591]|
    private String softwareId;
//    |`iss`|SSA Issuer|[RFC7519]|
    private String iss;
//    |`iat`|Time SSA issued|[RFC7519]|
    private Long iat;
//    |`jti`|JWT ID|[RFC7519]|
    private String jti;
//    The following software metadata is additionally defined for this profile:
//    |Metadata |Description |Field Size |Default values |
//    |---------|------------|-----------|---------------|
//    |`software_client_id`|The Client ID Registered at OB used to access OB resources|Base62 GUID (22 chars)| |
    private String softwareClientId;
//    |`software_client_description`|Human-readable detailed description of the client|Max256Text| |
    private String softwareClientDescription;
//    |`software_client_name`|Human-readable Software Name|Max40Text| |
    private String softwareClientName;
//    |`software_client_uri`|The website or resource root uri|Max256Text| |
    private String softwareClientUri;
//    |`software_version`|The version number of the software should a TPP choose to register and / or maintain it|decimal| |
    private String softwareVersion;
//    |`software_environment`|Requested additional field to avoid certificate check|Max256Text| |
    private String softwareEnvironment;
//    |`software_jwks_endpoint`|Contains all active signing and network certs for the software|Max256Text| |
    private String softwareJwksEndpoint;
//    |`software_jwks_revoked_endpoint`|Contains all revoked signing and network certs for the software|Max256Text| |
    private String softwareJwksRevokedEndpoint;
//    |`software_logo_uri`|Link to the TPP logo. Note, ASPSPs are not obliged to display images hosted by third parties|Max256Text| |
    private String softwareLogoUri;
//    |`software_mode`|ASPSP Requested additional field to indicate that this software is `Test` or `Live` the default is `Live`. Impact and support for `Test` software is up to the ASPSP.|Max40Text| |
    private String softwareMode;
//    |`software_on_behalf_of_org`|A reference to fourth party organsiation resource on the OB Directory if the registering TPP is acting on behalf of another.|Max40Text| |
    private String softwareOnBehalfOfOrg;
//    |`software_policy_uri`|A link to the software's policy page|Max256Text| |
    private String softwarePolicyUri;
//    |`software_redirect_uris`|Registered client callback endpoints as registered with Open Banking|A string array of Max256Text items|
    private List<String> softwareRedirectUris;
//    |`software_roles`|A multi value list of PSD2 roles that this software is authorized to perform.|A string array of Max256Text items| |
    private List<String> softwareRoles;
//    |`software_tos_uri`|A link to the software's terms of service page|Max256Text| |
    private String softwareTosUri;
//    The following Organisational metadata is defined for this profile:
//    |Metadata |Description |Field Size | Default values |
//    |---------|------------|-----------|----------------|
//    |`organisation_competent_authority_claims`|Authorisations granted to the organsiation by an NCA|CodeList {`AISP`, `PISP`, `CBPII`, `ASPSP`}| |
    private OrganisationCompetentAuthorityClaims organisationCompetentAuthorityClaims;
//    |`org_status`|Included to cater for voluntary withdrawal from OB scenarios|`Active`, `Revoked`, or `Withdrawn`| |
    private OrgStatus orgStatus;
//    |`org_id`|The Unique TPP or ASPSP ID held by OpenBanking.|Max35Text| |
    private String orgId;
//    |`org_name`|Legal Entity Identifier or other known organisation name|Max140Text| |
    private String orgName;
//    |`org_contacts`|JSON array of objects containing a triplet of name, email, and phone number|Each item Max256Text| |
    private List<OrgContact> orgContacts;
//    |`org_jwks_endpoint`|Contains all active signing and network certs for the organisation|Max256Text| |
    private String orgJwksEndpoint;
//    |`org_jwks_revoked_endpoint`|Contains all revoked signing and network certs for the organisation|Max256Text| |
    private String orgJwksRevokedEndpoint;

}
