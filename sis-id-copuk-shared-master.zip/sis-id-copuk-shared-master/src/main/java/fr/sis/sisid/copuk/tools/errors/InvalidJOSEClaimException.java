package fr.sis.sisid.copuk.tools.errors;

import java.io.Serial;

import lombok.Getter;

/**
 * UK.OBIE.Signature.InvalidClaim
 * The JOSE header in the x-jws-signature has one or more
 * claims with an invalid value. (e.g. a kid that does not
 * resolve to a valid certificate). The name of the missing
 * claim should be specified in the path field of the error
 * response.
 *
 */
public class InvalidJOSEClaimException extends JOSEValidationException {

    @Serial
    private static final long serialVersionUID = -4633129638909462167L;

    @Getter
    private final String headerName;

    public InvalidJOSEClaimException(String headerName) {
        super("The header claim " + headerName + " is invalid");
        this.headerName = headerName;
    }
}
