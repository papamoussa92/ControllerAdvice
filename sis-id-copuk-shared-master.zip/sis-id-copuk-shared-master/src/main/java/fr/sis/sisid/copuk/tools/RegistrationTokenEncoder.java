package fr.sis.sisid.copuk.tools;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JOSEObjectType;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.jwk.JWK;
import com.nimbusds.jose.jwk.RSAKey;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import fr.sis.sisid.copuk.registration.model.OBClientRegistration1;
import fr.sis.sisid.copuk.registration.model.SupportedAlgorithms;
import org.springframework.core.codec.EncodingException;

import java.text.ParseException;
import java.util.UUID;

/**
 * Utility to create a JWT to register with a Responder in private_key_jwt mode
 */
public class RegistrationTokenEncoder {

    private final String privateKey;
    private final OBClientRegistration1 registration;

    private final Integer expirationInSeconds;

    private final String keyID;

    public RegistrationTokenEncoder(String privateKey, OBClientRegistration1 registration, Integer expirationInSeconds,
            String keyID) {
        this.privateKey = privateKey;
        this.registration = registration;
        this.expirationInSeconds = expirationInSeconds;
        this.keyID = keyID;
        this.applyDefaults();
    }

    public String encode() throws EncodingException {
        RSAKey rsaKey;
        try {
            rsaKey = JWK.parseFromPEMEncodedObjects(privateKey).toRSAKey();

            ObjectMapper objectMapper = new ObjectMapper();
            String registrationJson = objectMapper.writeValueAsString(registration);
            var claims = JWTClaimsSet.parse(registrationJson);
            var header = new JWSHeader.Builder(JWSAlgorithm.PS256).type(JOSEObjectType.JWT).keyID(keyID).build();
            var jws = new SignedJWT(header, claims);
            jws.sign(new RSASSASigner(rsaKey));
            return jws.serialize();
        } catch (JOSEException | ParseException | JsonProcessingException e) {
            throw new EncodingException("Failed to encode registration token", e);
        }
    }

    public RegistrationTokenEncoder applyDefaults() {
        int now = (int) (System.currentTimeMillis() / 1000);
        registration.idTokenSignedResponseAlg(SupportedAlgorithms.PS256)
                .tokenEndpointAuthSigningAlg(SupportedAlgorithms.PS256)
                .tokenEndpointAuthMethod(OBClientRegistration1.TokenEndpointAuthMethodEnum.PRIVATE_KEY_JWT).iat(now)
                .exp(now + expirationInSeconds).jti(UUID.randomUUID().toString());
        return this;
    }

}
