package fr.sis.sisid.copuk.tools.errors;

public class UnsupportedAlgorithmException extends RuntimeException {

    private static final long serialVersionUID = 5422469976360198981L;

    public UnsupportedAlgorithmException(String message) {
        super(message);
    }

}
