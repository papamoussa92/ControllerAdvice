package fr.sis.sisid.copuk.tools.errors;

import java.io.Serial;

/**
 * Base exception class for different kinds of
 * JOSE detached payload validation errors
 *
 * These needs to be be kept distinct to be displayed
 * as different kinds of error messages, as per spec
 */
public class JOSEValidationException extends RuntimeException {

    @Serial
    private static final long serialVersionUID = 2005488477287746132L;

    protected JOSEValidationException(String message, Throwable err) {
        super(message, err);
    }

    protected JOSEValidationException(String message) {
        super(message);
    }

}
