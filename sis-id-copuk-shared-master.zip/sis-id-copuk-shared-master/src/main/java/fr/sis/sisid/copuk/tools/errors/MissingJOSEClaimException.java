package fr.sis.sisid.copuk.tools.errors;

import java.io.Serial;

import lombok.Getter;

public class MissingJOSEClaimException extends JOSEValidationException {

    @Serial
    private static final long serialVersionUID = -8961454669454742448L;

    @Getter
    private final String headerName;

    public MissingJOSEClaimException(String headerName) {
        super("The required header claim " + headerName + " is missing");
        this.headerName = headerName;
    }
}
