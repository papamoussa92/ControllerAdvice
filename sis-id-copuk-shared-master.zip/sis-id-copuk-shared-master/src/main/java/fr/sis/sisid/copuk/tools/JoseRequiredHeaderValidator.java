package fr.sis.sisid.copuk.tools;

import java.util.function.Predicate;

import com.nimbusds.jose.JOSEObject;

import fr.sis.sisid.copuk.tools.errors.JOSEValidationException;
import fr.sis.sisid.copuk.tools.errors.MissingJOSEClaimException;

/**
 * Validates a JOSE header the same way {@link JoseHeaderValidator} does,
 * but first valdiates if the header is present.
 * @param <T>
 */
public class JoseRequiredHeaderValidator<T> extends JoseHeaderValidator<T> {

    private final MissingJOSEClaimException requiredClaimError;

    public JoseRequiredHeaderValidator(String headerName, Predicate<T> test) {
        super(headerName, test);
        this.requiredClaimError = new MissingJOSEClaimException(super.headerName);
    }

    @Override
    public void validate(JOSEObject token) throws JOSEValidationException {
        T headerValue = super.getHeaderValue(token);
        if (headerValue == null) {
            throw this.requiredClaimError;
        }
        super.validate(token);
    }

}
