package fr.sis.sisid.copuk.tools;

public enum JwtStringClaims {

    ISSUER, KEY_ID, ALGORITHM, TYPE, AUTHORIZED_PARTY;
}
