package fr.sis.sisid.copuk.tools;

import java.security.Key;
import java.security.interfaces.ECPublicKey;
import java.security.interfaces.RSAPublicKey;

import javax.crypto.SecretKey;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSVerifier;
import com.nimbusds.jose.KeyTypeException;
import com.nimbusds.jose.crypto.ECDSAVerifier;
import com.nimbusds.jose.crypto.MACVerifier;
import com.nimbusds.jose.crypto.RSASSAVerifier;
import com.nimbusds.jose.crypto.factories.DefaultJWSVerifierFactory;
import com.nimbusds.jose.crypto.impl.ECDSAProvider;
import com.nimbusds.jose.crypto.impl.MACProvider;
import com.nimbusds.jose.crypto.impl.RSASSAProvider;

/**
 * JWSVerifierFactory that passes the list of crit headers along to the verifier,
 * for them to be ignored
 *
 */
public class CritIgnoringJWSVerifierFactory extends DefaultJWSVerifierFactory {

    @Override
    public JWSVerifier createJWSVerifier(final JWSHeader header, final Key key)
            throws JOSEException {

        JWSVerifier verifier;

        if (MACProvider.SUPPORTED_ALGORITHMS.contains(header.getAlgorithm())) {

            if (!(key instanceof SecretKey)) {
                throw new KeyTypeException(SecretKey.class);
            }

            SecretKey macKey = (SecretKey) key;

            verifier = new MACVerifier(macKey);

        } else if (RSASSAProvider.SUPPORTED_ALGORITHMS.contains(header.getAlgorithm())) {

            if (!(key instanceof RSAPublicKey)) {
                throw new KeyTypeException(RSAPublicKey.class);
            }

            RSAPublicKey rsaPublicKey = (RSAPublicKey) key;
            // crit headers are to be ignored
            verifier = new RSASSAVerifier(rsaPublicKey, header.getCriticalParams());

        } else if (ECDSAProvider.SUPPORTED_ALGORITHMS.contains(header.getAlgorithm())) {

            if (!(key instanceof ECPublicKey)) {
                throw new KeyTypeException(ECPublicKey.class);
            }

            ECPublicKey ecPublicKey = (ECPublicKey) key;
            // crit headers to be ignored
            verifier = new ECDSAVerifier(ecPublicKey, header.getCriticalParams());

        } else {

            throw new JOSEException("Unsupported JWS algorithm: " + header.getAlgorithm());
        }

        // Apply JCA context, SecureRandom expensive and not needed for verification
        // (iss #385)
        verifier.getJCAContext().setProvider(super.getJCAContext().getProvider());

        return verifier;
    }

}
