package fr.sis.sisid.copuk.tools.errors;

import java.io.Serial;

/**
 * UK.OBIE.Signature.Malformed : 
 * The x-jws-signature in the request header was malformed
 * and could not be parsed as a valid JWS
 */
public class MalformedJOSESignatureException extends JOSEValidationException {

    @Serial
    private static final long serialVersionUID = 8742312493214536248L;

    public MalformedJOSESignatureException(String message) {
        super(message);
    }

}
